package com.loonxi.ju53;

import android.test.AndroidTestCase;

import com.loonxi.ju53.utils.AesSecretUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.TimeUtil;
import com.loonxi.ju53.utils.UrlUtil;

public class MyTest extends AndroidTestCase{

    public void testAES(){
        String key = "LONGXIWWWJU53COM";
        String src = "hello";
        try {
            String encrypt = AesSecretUtil.aesEncryptModeBase64(src);
            LogUtil.mLog().d("加密后：" + encrypt);
            String decrypt = AesSecretUtil.aesDecryptModeBase64(encrypt);
            LogUtil.mLog().d("解密后：" + decrypt);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void testUrl(){
        String content = "我的网站为:winter8.iteye.com/blog/1463244哈哈";
        LogUtil.mLog().e("解析结果：" + UrlUtil.splitUrl(content));
    }

    public void testTime(){
        long time = 0l;
        int hour = TimeUtil.getHour(time);
        int minute = TimeUtil.getMinute(time);
        int second = TimeUtil.getSecond(time);
        LogUtil.mLog().e(hour + ":" + minute +":" + second);
    }
}
