package com.loonxi.ju53.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class FavTabBar extends LinearLayout implements View.OnClickListener {

    @ViewInject(R.id.tab_fav_layout_product)
    private RelativeLayout mLayoutProduct;
    @ViewInject(R.id.tab_fav_layout_product_line)
    private TextView mLayoutProductLine;
    @ViewInject(R.id.tab_fav_tv_product)
    private TextView mTvProduct;
    @ViewInject(R.id.tab_fav_layout_company)
    private RelativeLayout mLayoutCompany;
    @ViewInject(R.id.tab_fav_layout_company_line)
    private TextView mLayoutCompanyLine;
    @ViewInject(R.id.tab_fav_tv_company)
    private TextView mTvCompany;

    private int mCurrentPosition = 0;
    private OnFavTabClickListener mListener;

    public FavTabBar(Context context) {
        this(context, null);
    }

    public FavTabBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        View bar = LayoutInflater.from(context).inflate(R.layout.include_tab_fav, null);
        addView(bar, LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        x.view().inject(this, bar);
        mLayoutProduct.setOnClickListener(this);
        mLayoutCompany.setOnClickListener(this);
        changeTab(1);
    }


    @Override
    public void onClick(View v) {
        if (mListener == null) {
            return;
        }
        switch (v.getId()) {
            case R.id.tab_fav_layout_product:
                changeTab(1);
                mListener.onTabClick(1);
                break;
            case R.id.tab_fav_layout_company:
                changeTab(2);
                mListener.onTabClick(2);
                break;
        }
    }

    public void changeTab(int position) {
        mCurrentPosition = position;
        switch (position) {
            case 1:
                mTvProduct.setTextColor(getResources().getColor(R.color.app_red));
                mTvCompany.setTextColor(getResources().getColor(R.color.app_black));
                mLayoutProductLine.setVisibility(VISIBLE);
                mLayoutCompanyLine.setVisibility(GONE);
                break;
            case 2:
                mTvProduct.setTextColor(getResources().getColor(R.color.app_black));
                mTvCompany.setTextColor(getResources().getColor(R.color.app_red));
                mLayoutProductLine.setVisibility(GONE);
                mLayoutCompanyLine.setVisibility(VISIBLE);
                break;
        }
    }

    public void setOnFavTabClickListener(OnFavTabClickListener listener) {
        mListener = listener;
    }

    public interface OnFavTabClickListener {
        void onTabClick(int position);
    }
}
