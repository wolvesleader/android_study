package com.loonxi.ju53.entity;

import java.util.List;

/**
 * 发送评论 entity
 * Created by laojiaqi on 2016/2/16.
 */
public class SendCommentEntity {

    String requestType;
    String version;
    String ratedUserName;//供应商姓名
    String orderId;//订单id
    int score;//总体评价
    List<ProductCommentEntity> items;
    int serviceScore;//服务星级
    int speedScore;//物流星级
    int anon;//是否匿名 1.匿名
    String ratedUserId;//供应商id

    public String getRatedUserName() {
        return ratedUserName;
    }

    public void setRatedUserName(String ratedUserName) {
        this.ratedUserName = ratedUserName;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public List<ProductCommentEntity> getItems() {
        return items;
    }

    public void setItems(List<ProductCommentEntity> items) {
        this.items = items;
    }

    public int getServiceScore() {
        return serviceScore;
    }

    public void setServiceScore(int serviceScore) {
        this.serviceScore = serviceScore;
    }

    public int getSpeedScore() {
        return speedScore;
    }

    public void setSpeedScore(int speedScore) {
        this.speedScore = speedScore;
    }

    public int getAnon() {
        return anon;
    }

    public void setAnon(int anon) {
        this.anon = anon;
    }

    public String getRatedUserId() {
        return ratedUserId;
    }

    public void setRatedUserId(String ratedUserId) {
        this.ratedUserId = ratedUserId;
    }


    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
