package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.OrderState;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.widgets.FixedListView;

import java.util.List;

/**
 * "分销订单adapter"
 * Created by Xuzue on 2016/1/7.
 */
public class SaleOrderAdapter extends BaseObjectListAdapter<SaleOrderEntity> {


    public SaleOrderAdapter(Context context, List<SaleOrderEntity> datas) {
        super(context, datas);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_sale_order_parent, null);
            holder.mLayoutCompany = (LinearLayout) convertView.findViewById(R.id.listitem_sale_order_parent_layout_company);
            holder.mTvCompanyName = (TextView) convertView.findViewById(R.id.listitem_sale_order_parent_tv_company);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_sale_order_parent_tv_status);
            holder.mFlv = (FixedListView) convertView.findViewById(R.id.listitem_sale_order_parent_flv);
            holder.mTvTotal = (TextView) convertView.findViewById(R.id.listitem_sale_order_parent_tv_total);
            holder.mTvOrderNo = (TextView) convertView.findViewById(R.id.listitem_sale_order_parent_tv_orderno);
            holder.mTvTime = (TextView) convertView.findViewById(R.id.listitem_sale_order_parent_tv_time);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        SaleOrderEntity order = get(position);
        holder.mTvCompanyName.setText(order.getCustomName());
        setStatus(holder, order);
        String price = (StringUtil.isEmpty(order.getPrice()) ? "0.00" : order.getPrice());
        String freight = StringUtil.isEmpty(order.getFreight()) ? "0.00" : order.getFreight();
        Spanned total = Html.fromHtml("共" + order.getNum() + "件商品合计: <font color=\"#ee0c00\">¥"
                + price + "</font> (含运费" + freight + "元)");
        holder.mTvTotal.setText(total);
        holder.mTvOrderNo.setText("订单号: " + order.getOrderId());
        holder.mTvTime.setText(order.getTime());

        SaleOrderChildAdapter childAdapter = new SaleOrderChildAdapter(mContext, order.getAttr(), order);
        holder.mFlv.setAdapter(childAdapter);
        setListener(holder, order);
        return convertView;
    }

    /**
     * 设置状态
     *
     * @param holder
     * @param order
     */
    private void setStatus(ViewHolder holder, SaleOrderEntity order) {
        if (holder == null || order == null || StringUtil.isEmpty(order.getState())) {
            return;
        }
        int status = Integer.parseInt(order.getState());
        OrderState.setOrderState(holder.mTvStatus, status);
    }

    private void setListener(ViewHolder holder, final SaleOrderEntity order) {
        if (holder == null || order == null) {
            return;
        }
        holder.mLayoutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", order.getCustomId());
                intent.putExtra("userName", order.getCustomName());
                mContext.startActivity(intent);
            }
        });
    }

    class ViewHolder {
        LinearLayout mLayoutCompany;
        TextView mTvCompanyName;
        TextView mTvStatus;
        FixedListView mFlv;
        TextView mTvTotal;
        TextView mTvOrderNo;
        TextView mTvTime;
    }
}
