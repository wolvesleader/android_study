package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.StoreProductExtraEntity;
import com.loonxi.ju53.models.IStoreProductDetailModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.ProductService;
import com.loonxi.ju53.modules.request.service.StoreService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by XuZue on 2016/5/4 0004.
 */
public class StoreProductDetailModel implements IStoreProductDetailModel {
    @Override
    public Call<JsonInfo<ProductDetailEntity>> getBaseInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback) {
        Call<JsonInfo<ProductDetailEntity>> call = Request.creatApi(ProductService.class).getBaseInfo(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonInfo<ProductDetailEntity>> getDetailInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback) {
        Call<JsonInfo<ProductDetailEntity>> call = Request.creatApi(ProductService.class).getDetailInfo(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> offSale(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).offSaleProduct(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> onSale(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).onSaleStoreProduct(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonInfo<StoreProductExtraEntity>> getExtraInfo(Map<String, Object> map, Callback<JsonInfo<StoreProductExtraEntity>> callback) {
        Call<JsonInfo<StoreProductExtraEntity>> call = NewRequest.creatApi(StoreService.class).getStoreProductExtraInfo(map);
        call.enqueue(callback);
        return call;
    }
}
