package com.loonxi.ju53.models.impl;

import android.text.TextUtils;

import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.entity.VerifyCodeEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.service.UpdatePasswordService;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.MD5;
import com.loonxi.ju53.utils.MapUtil;
import com.loonxi.ju53.utils.StringUtil;

import java.util.Map;

import retrofit.Call;

/**
 * "更新密码"model
 * Created by laojiaqi on 2016/2/17.
 */
public class UpdatePasswordModel {

    /**
     * 更新_登入_密码
     *
     * @param newPassword
     * @param oldPassword
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> updateLoginPassword(String newPassword, String oldPassword, Callback<BaseJsonInfo> callback) {
        if (callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("newPassword", newPassword);
        map.put("oldPassword", oldPassword);
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).updateLoginPassword(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 更新_支付_密码
     *
     * @param newCashPassword
     * @param oldCashPassword
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> updatePayPassword(String newCashPassword, String oldCashPassword, Callback<BaseJsonInfo> callback) {
        if (callback == null || TextUtils.isEmpty(newCashPassword) || TextUtils.isEmpty(oldCashPassword)) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("newCashPassword", newCashPassword);
        map.put("oldCashPassword", oldCashPassword);
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).updatePayPassword(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 获得_登录密码_验证码
     *
     * @param mobile
     * @param callback
     * @return
     */
    public Call<VerifyCodeEntity> getLoginPasswordVerifyCode(String mobile, Callback<VerifyCodeEntity> callback) {
        if (TextUtils.isEmpty(mobile) || callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("mobile", mobile);
        map.put("service", ApiConst.Code.PSWD_FORGET);
        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));
        Call<VerifyCodeEntity> call = Request.creatApi(UpdatePasswordService.class).getLoginPasswordVerifyCode(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 验证_登录密码_验证码
     *
     * @param mobile
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> checkLoginPasswordVerifyCode(String mobile, String verifyCode, Callback<BaseJsonInfo> callback) {
        if (TextUtils.isEmpty(mobile) || TextUtils.isEmpty(verifyCode) || callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("mobile", mobile);
        map.put("verifyCode", verifyCode);
        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).checkLoginPasswordVerifyCode(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 忘记登录密码_重置_登录密码
     *
     * @param mobile
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> resetLoginPassword(String newPassword, String mobile, Callback<BaseJsonInfo> callback) {
        if (TextUtils.isEmpty(newPassword) || TextUtils.isEmpty(mobile) || callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("mobile", mobile);
        map.put("newPassword", newPassword);
        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).resetLoginPassword(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 忘记支付密码_重置_支付密码
     *
     * @param mobile
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> resetPayPassword(String newCashPassword, String mobile, Callback<BaseJsonInfo> callback) {
        if (TextUtils.isEmpty(newCashPassword) || TextUtils.isEmpty(mobile) || callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("mobile", mobile);
        map.put("newCashPassword", newCashPassword);
        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).resetPayPassword(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 忘记支付密码_验证_登录密码
     *
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> checkLoginPassword(String loginPassword, Callback<BaseJsonInfo> callback) {
        if (TextUtils.isEmpty(loginPassword) || callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("oldPassword", loginPassword);
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).checkLoginPassword(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 退出登录
     *
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> logout(Callback<BaseJsonInfo> callback) {
        if (callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        Call<BaseJsonInfo> call = Request.creatApi(UpdatePasswordService.class).logout(map);
        call.enqueue(callback);
        return call;
    }


}
