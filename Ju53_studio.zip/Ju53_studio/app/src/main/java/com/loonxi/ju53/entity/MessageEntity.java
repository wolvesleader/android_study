package com.loonxi.ju53.entity;

/**
 * "消息Entity"
 * Created by laojiaqi on 2016/2/2.
 */
public class MessageEntity {
    String content;
    String picPath; //缩略图地址
    String summary;//概括文字
    String title; //标题
    String jointId;//详情id
    String topic;
    long created;
    long pid;
    int status;//状态
    int type;//类型
    int order_cate;//订单类型 1：进货订单 2：分销订单


    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public long getCreated() {
        return created;
    }

    public long getPid() {
        return pid;
    }

    public int getStatus() {
        return status;
    }

    public int getType() {
        return type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPicPath() {
        return picPath;
    }

    public void setPicPath(String picPath) {
        this.picPath = picPath;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getJointId() {
        return jointId;
    }

    public void setJointId(String jointId) {
        this.jointId = jointId;
    }

    public void setCreated(int created) {
        this.created = created;
    }


    public void setPid(int pid) {
        this.pid = pid;
    }


    public void setStatus(int status) {
        this.status = status;
    }


    public void setType(int type) {
        this.type = type;
    }

    public int getOrder_cate() {
        return order_cate;
    }

    public void setOrder_cate(int order_cate) {
        this.order_cate = order_cate;
    }
}
