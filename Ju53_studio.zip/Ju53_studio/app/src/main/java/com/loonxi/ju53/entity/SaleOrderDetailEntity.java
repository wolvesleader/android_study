package com.loonxi.ju53.entity;

/**
 * 分销商订单详情
 * Created by XuZue on 2016/5/12 0012.
 */
public class SaleOrderDetailEntity {

    private SaleOrderDetailTime time;
    private SaleOrderDetailAddress address;
    private SaleOrderEntity product;

    public SaleOrderDetailTime getTime() {
        return time;
    }

    public void setTime(SaleOrderDetailTime time) {
        this.time = time;
    }

    public SaleOrderDetailAddress getAddress() {
        return address;
    }

    public void setAddress(SaleOrderDetailAddress address) {
        this.address = address;
    }

    public SaleOrderEntity getOrder() {
        return product;
    }

    public void setOrder(SaleOrderEntity order) {
        this.product = order;
    }
}
