package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.AgentProductEntity;

import java.util.List;

/**
 * Created by Xuzue on 2016/2/19.
 */
public interface IAgentView {
    void onGetAgentProductSuccess(List<AgentProductEntity> jsonArrayInfo);
    void onGetAgentProductFailed(int apiErrorCode, String message);
}
