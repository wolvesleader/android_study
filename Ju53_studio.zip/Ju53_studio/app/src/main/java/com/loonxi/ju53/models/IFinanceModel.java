package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.CashCardEntity;
import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.entity.CashRecordInfo;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public interface IFinanceModel {
    Call<JsonInfo<FinanceEntity>> getFinanceInfo(Map<String, Object> map, Callback<JsonInfo<FinanceEntity>> callback);

    Call<BaseJsonInfo> cashApply(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<JsonInfo<CashRecordInfo>> getCashRecord(Map<String, Object> map, Callback<JsonInfo<CashRecordInfo>> callback);

    Call<JsonArrayInfo<CashCardEntity>> getCashAccount(Map<String, Object> map, Callback<JsonArrayInfo<CashCardEntity>> callback);

    Call<BaseJsonInfo> bandCashAccount(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> unbandCashAccount(Map<String, Object> map, Callback<BaseJsonInfo> callback);
}
