package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.presenters.CashApplyPresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ICashApplyView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

/**
 * 申请提现
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashApplyActivity extends ActionBarActivity implements View.OnClickListener, ICashApplyView {

    @ViewInject(R.id.cash_apply_tv_available)
    private TextView mTvAvailable;
    @ViewInject(R.id.cash_apply_tv_applynum)
    private EditText mTvApplynum;
    @ViewInject(R.id.cash_apply_tv_cashaccount)
    private TextView mTvCashAccount;
    @ViewInject(R.id.cash_apply_tv_applycash)
    private TextView mTvApplycash;
    @ViewInject(R.id.cash_apply_tv_min_tip)
    private TextView mTvMinTip;

    private CashApplyPresenter mPresenter;
    private FinanceEntity mFinance;
    private int mMinMoney = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cash_apply);
    }


    @Override
    public void initView() {
        setTitle("我要提现");
    }

    @Override
    public void initContent() {
        mPresenter = new CashApplyPresenter(this);
        mFinance = getIntent().getParcelableExtra("finance");
        if (mFinance != null) {
            mMinMoney = mFinance.getFloor() <= 0 ? 10 : (int)mFinance.getFloor();
            mTvAvailable.setText(mFinance.getBalance());
            mTvCashAccount.setText("支付宝(" + mFinance.getAccount() + ")" + mFinance.getAccount_name());
            mTvMinTip.setText("金额低于" + mMinMoney + "时，不能提现，请努力赚钱哟");
            double balance = StringUtil.isEmpty(mFinance.getBalance()) ? 0 : Double.parseDouble(mFinance.getBalance());
            if (balance > 0) {
                mTvApplycash.setEnabled(true);
            }
        }
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mTvApplycash.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.cash_apply_tv_applycash:
                applyCash();
                break;
        }
    }

    /**
     * 申请提现
     */
    private void applyCash() {
        String apply = mTvApplynum.getText().toString().trim();
        if (StringUtil.isEmpty(apply)) {
            showToast("请输入提现金额");
            return;
        }
        double money = Double.parseDouble(apply);
        if (money < mMinMoney) {
            showToast("提现金额需大于" + mMinMoney + "元");
            return;
        }
        if (mPresenter != null) {
            mPresenter.cashApply(apply, mFinance == null ? "" : mFinance.getPid());
        }
    }

    @Override
    public void cashApplySuccess() {
        showToast("申请成功");
        startActivity(new Intent(mContext, CashRecordActivity.class));
        finish();
    }

    @Override
    public void cashApplyFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
