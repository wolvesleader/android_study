package com.loonxi.ju53.listener;

/**
 * Created by Xuzue on 2016/1/26.
 */
public interface AlipayListener {
    void onAlipaySuccess(double payMoney, String orderId);
    void onAlipayCancel();
    void onAlipayFailed();
    void onAlipayConfirming();
}
