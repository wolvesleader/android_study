package com.loonxi.ju53.models;

import android.content.Context;

import com.loonxi.ju53.entity.UserEntity;
import com.loonxi.ju53.modules.request.Callback;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/5.
 */
public interface ILoginModel {
    Call<UserEntity> login(Map<String, Object> map, Callback<UserEntity> callback);

    void saveLoginInfo(Context context, UserEntity object);
}
