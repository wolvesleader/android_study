package com.loonxi.ju53.constants;

import android.content.Context;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;

/**
 * 退款状态
 * (0-未退款,1-已申请,2-不同意退款,3-同意退款(实际已退款),4-退款结束(确认收货会把退款结束掉）
 * 5.退款修改-1-取消退款.6同意退款实未退7退货退款时的卖家同意退货 8.退货退款时买家退回货物)
 * Created by Xuzue on 2016/1/27.
 */
public class RefundState {
    public static final int CANCEL = -1;
    public static final int NONE = 0;
    public static final int APPLYED = 1;
    public static final int DENIED = 2;
    public static final int AGREED_REFUNED = 3;
    public static final int FINISH = 4;
    public static final int MODIFY = 5;
    public static final int AGREED_NO_REFUNED = 6;
    public static final int AGREED_REFUNED_GOODS = 7;
    public static final int GOODS_BACK = 8;


    public static void setRefundState(TextView tv, int state){
        Context context = BaseApplication.instance;
        if(tv == null){
            return;
        }
        switch (state){
            case APPLYED:
                tv.setText(context.getResources().getString(R.string.refund_state_modify));
                break;
            case DENIED:
                tv.setText(context.getResources().getString(R.string.refund_state_denied));
                break;
            case AGREED_REFUNED:
                tv.setText(context.getResources().getString(R.string.refund_state_finish));
                break;
            case FINISH:
                tv.setText(context.getResources().getString(R.string.refund_state_finish));
                break;
            case MODIFY:
                tv.setText(context.getResources().getString(R.string.refund_state_modify));
                break;
            case CANCEL:
//                tv.setText(context.getResources().getString(R.string.refund_state_cancel));
                break;
            case AGREED_NO_REFUNED:
                tv.setText(context.getResources().getString(R.string.refund_state_finish));
                break;
            case AGREED_REFUNED_GOODS:
                tv.setText(context.getResources().getString(R.string.refund_state_agree_refund_goods));
                break;
            case GOODS_BACK:
                tv.setText(context.getResources().getString(R.string.refund_state_goods_back));
                break;
        }
    }
}
