package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ViewFlipper;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.register.AuthStep;
import com.loonxi.ju53.activity.register.CodeStep;
import com.loonxi.ju53.activity.register.PhoneStep;
import com.loonxi.ju53.activity.register.RegisterStep;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by Xuzue on 2016/1/4.
 */
public class RegisterActivity extends ActionBarActivity implements View.OnClickListener, RegisterStep.onNextActionListener{

    @ViewInject(R.id.register_vfp)
    private ViewFlipper mVfp;

    private RegisterStep mCurStep;
    private int mCurStepIndex = 1;

    private PhoneStep mPhoneStep;
    private CodeStep mCodeStep;
    private AuthStep mAuthStep;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    @Override
    public void initView() {

    }

    @Override
    public void initContent() {
        mCurStep = initStep();
        mCurStep.setOnNextActionListener(this);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
    }


    private RegisterStep initStep(){
        switch (mCurStepIndex){
            case 1:
                if(mPhoneStep == null){
                    mPhoneStep = new PhoneStep(RegisterActivity.this, RegisterActivity.this, mVfp.getChildAt(0));
                }
                setTitle(R.string.register);
                return mPhoneStep;
            case 2:
                mCodeStep = new CodeStep(RegisterActivity.this, RegisterActivity.this, mVfp.getChildAt(1));
                setTitle(R.string.register_title_input_code);
                return mCodeStep;
            case 3:
                if(mAuthStep == null){
                    mAuthStep = new AuthStep(RegisterActivity.this, RegisterActivity.this, mVfp.getChildAt(2));
                }
                setTitle(R.string.register);
                return mAuthStep;
        }
        return null;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case ActionBar.LEFT_CLICK_ID:
                back();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        back();
    }

    @Override
    public void next(boolean isChange) {
        LogUtil.mLog().e("next " + isChange);
        String phone = mCurStep.getMobile();
        String code = mCurStep.getCode();
        String count = mCurStep.getAccount();
        String password = mCurStep.getPassword();
        if(mCurStepIndex == 2 && StringUtil.isEmpty(code)){
            return;
        }
        if(mCurStepIndex == mVfp.getChildCount()){
            finish();
            return;
        }
        mCurStepIndex++;
        LogUtil.mLog().e("index:" + mCurStepIndex);
        mCurStep = initStep();
        mCurStep.setMobile(phone);
        mCurStep.setCode(code);
        mCurStep.setAccount(count);
        mCurStep.setPassword(password);
        mCurStep.setOnNextActionListener(this);
        if(isChange){
            mCurStep.afterChangeInit();
        }
        mVfp.setInAnimation(this, R.anim.activity_open_enter);
        mVfp.setOutAnimation(this, R.anim.activity_open_exit);
        mVfp.showNext();
    }


    public void back() {
        if (mCurStepIndex <= 1) {
            finish();
            return;
        }
        if(mCodeStep != null && mCodeStep.getTimer() != null){
            mCodeStep.getTimer().cancel();
        }
        mCurStepIndex--;
        mCurStep = initStep();
        mCurStep.setOnNextActionListener(this);
        mVfp.setInAnimation(this, R.anim.activity_close_enter);
        mVfp.setOutAnimation(this, R.anim.activity_close_exit);
        mVfp.showPrevious();
    }

}
