package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/23.
 */
public interface IPromotionModel {

    Call<JsonArrayInfo<PromotionEntity>> getPromotion(Map<String, Object> map, Callback<JsonArrayInfo<PromotionEntity>> callback);

    Call<JsonInfo<PromotionEntity>> getPromotionDetail(Map<String, Object> map, Callback<JsonInfo<PromotionEntity>> callback);
}
