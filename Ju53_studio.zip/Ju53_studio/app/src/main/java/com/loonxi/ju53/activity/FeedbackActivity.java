package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.presenters.FeedbackPresenter;
import com.loonxi.ju53.utils.SoftInputUtil;
import com.loonxi.ju53.views.IFeedbackView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by Xuzue on 2016/2/19.
 */
public class FeedbackActivity extends ActionBarActivity implements View.OnClickListener, IFeedbackView {

    @ViewInject(R.id.feedback_layout_edit)
    private LinearLayout mLayoutEdit;
    @ViewInject(R.id.feedback_layout_success)
    private RelativeLayout mLayoutSuccess;
    @ViewInject(R.id.feedback_edt_phone)
    private EditText mEdtPhone;
    @ViewInject(R.id.feedback_edt_content)
    private EditText mEdtContent;
    @ViewInject(R.id.feedback_tv_nums)
    private TextView mTvNums;
    @ViewInject(R.id.feedback_tv_commit)
    private TextView mTvCommit;

    private FeedbackPresenter mPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
    }

    @Override
    public void initView() {
        setTitle(R.string.feedback_title);

    }

    @Override
    public void initContent() {
        mPresenter = new FeedbackPresenter(this);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mTvCommit.setOnClickListener(this);
        mEdtPhone.addTextChangedListener(new MyTextWatcher());
        mEdtContent.addTextChangedListener(new MyTextWatcher());
    }

    @Override
    public void onFeedbackSuccess() {
        success();
    }

    @Override
    public void onFeedbackFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    /**
     * 提交成功后更新UI
     */
    private void success(){
        mLayoutEdit.setVisibility(View.GONE);
        mLayoutSuccess.setVisibility(View.VISIBLE);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    private class MyTextWatcher implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            int numPhone = mEdtPhone.getText().length();
            int numContent = mEdtContent.getText().length();
            mTvCommit.setEnabled((numPhone > 0 && numContent > 0) ? true : false);
            mTvNums.setText(numContent + " / 200");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.feedback_tv_commit:
                SoftInputUtil.closeKeybord(mEdtPhone, mContext);
                SoftInputUtil.closeKeybord(mEdtContent, mContext);
                mPresenter.feedback(mEdtPhone.getText().toString(), mEdtContent.getText().toString());
                break;
        }
    }


}
