package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.DeveloperDialogAdapter;
import com.loonxi.ju53.adapter.SearchHistroyHotAdapter;
import com.loonxi.ju53.adapter.SearchHistroyRecentAdapter;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.FlowLayoutItem;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.presenters.SearchPresenter;
import com.loonxi.ju53.utils.ArrayUtil;
import com.loonxi.ju53.utils.FlowLayoutUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.SoftInputUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ISearchHistoryView;
import com.loonxi.ju53.widgets.DeleteEditText;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.FlowLinearLayout;
import com.loonxi.ju53.widgets.dialog.DeviceInfoDialog;
import com.loonxi.ju53.widgets.dialog.ListDialog;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/6.
 */
public class SearchHistoryActivity extends BaseActivity implements View.OnClickListener, AdapterView.OnItemClickListener, ISearchHistoryView {

    @ViewInject(R.id.search_history_layout_title)
    private LinearLayout mLayoutTitle;
    @ViewInject(R.id.search_history_tv_title)
    private DeleteEditText mTvTitle;
    @ViewInject(R.id.search_history_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.search_history_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.search_history_layout_recently)
    private LinearLayout mLayoutRecently;
    @ViewInject(R.id.search_history_flv_recently)
    private FixedListView mFlvRecent;
    @ViewInject(R.id.search_history_layout_clear)
    private LinearLayout mLayoutRecentClear;
    @ViewInject(R.id.search_history_btn_clear)
    private Button mBtnClear;
    @ViewInject(R.id.search_history_layout_nohistory)
    private LinearLayout mLayoutRecentNodata;
    @ViewInject(R.id.search_history_layout_hot)
    private LinearLayout mLayoutHot;
    @ViewInject(R.id.search_history_layout_nohot)
    private LinearLayout mLayoutHotNodata;
    @ViewInject(R.id.search_history_flowlayout_hot)
    private FlowLinearLayout mLayoutFlowhot;

    private ListDialog mListDialog;
    private DeviceInfoDialog mDeviceDialog;
    private DeveloperDialogAdapter mDeveloperAdapter;
    private List<String> mDeveloperList = new ArrayList<>();

    private SearchHistroyRecentAdapter mRecentAdapter;
    private SearchHistroyHotAdapter mHotAdapter;

    private List<String> hotList = new ArrayList<>();

    private SearchPresenter mPresenter;
    private View.OnClickListener mLableClickListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_history);
        x.view().inject(this);
        initViews();
        initContent();
        setListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SoftInputUtil.openKeybord(mTvTitle, mContext);
    }

    private void initViews() {

    }

    private void initContent() {
        mPresenter = new SearchPresenter(this);
        testRecentData();
        initDeveloperData();
        mHotAdapter = new SearchHistroyHotAdapter(mContext, hotList);
        mDeveloperAdapter = new DeveloperDialogAdapter(mContext, mDeveloperList);
        mPresenter.getHotSearch();
    }

    private void setListener() {
        mLayoutRight.setOnClickListener(this);
        mBtnClear.setOnClickListener(this);
        mTvTitle.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    search(mTvTitle.getText().toString());
                    return true;
                }
                return false;
            }
        });
        mLableClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object object = v.getTag();
                if (object == null || mContext == null) {
                    return;
                }
                FlowLayoutItem itemInfor = (FlowLayoutItem) object;
                int position = itemInfor.getPosition();
                String name = itemInfor.getName();
                Intent intent = new Intent(mContext, SearchActivity.class);
                intent.putExtra("key", name);
                startActivity(intent);
                hiddenKeyboard();
            }
        };
    }

    private void setFlvEmptyView() {
        mFlvRecent.setEmptyView(mLayoutRecentNodata);
        mLayoutRecentClear.setVisibility(View.GONE);
    }

    private void initDeveloperData() {
        String[] datas = getResources().getStringArray(R.array.developer_model);
        mDeveloperList.clear();
        if (!ArrayUtil.isEmpty(datas)) {
            for (int i = 0; i < datas.length; i++) {
                mDeveloperList.add(datas[i]);
            }
        }
    }

    private void testRecentData() {
        List<String> recentList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            recentList.add("历史记录" + i);
        }
        mRecentAdapter = new SearchHistroyRecentAdapter(mContext, recentList);
        mFlvRecent.setAdapter(mRecentAdapter);
        mLayoutRecentClear.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_history_layout_right:
                search(mTvTitle.getText().toString());
                break;
            case R.id.search_history_btn_clear:

                break;
        }
    }

    /**
     * 搜索
     *
     * @param key
     */
    private void search(String key) {
        if (StringUtil.isEmpty(key)) {
            showToast(R.string.search_key_null);
            return;
        }
        if (BaseApplication.isDeveloper && AppConst.DEVELOPER_TAG.equals(key)) {
            developer();
        } else {
            hiddenKeyboard();
            Intent intent = new Intent(mContext, SearchActivity.class);
            intent.putExtra("key", key);
            startActivity(intent);
        }
    }

    /**
     * 开发者模式
     */
    private void developer() {
        mListDialog = new ListDialog(mContext, "开发者模式", mDeveloperAdapter, new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0://设备信息
                        mDeviceDialog = new DeviceInfoDialog(mContext);
                        mDeviceDialog.show();
                        break;
                    case 1://开发环境
                        Request.changeBaseUrl(ApiConst.URL_ROOT_LOCAL_DEV);
                        NewRequest.changeBaseUrl(ApiConst.URL_ROOT_LOCAL_DEV_PHP);
                        AppConst.PIC_HEAD = AppConst.PIC_HEAD_LOCAL;
                        showToast(R.string.change_local_dev);
                        break;
                    case 2://测试环境
                        Request.changeBaseUrl(ApiConst.URL_ROOT_LOCAL_TEST);
                        NewRequest.changeBaseUrl(ApiConst.URL_ROOT_LOCAL_TEST_PHP);
                        AppConst.PIC_HEAD = AppConst.PIC_HEAD_LOCAL;
                        showToast(R.string.change_local_test);
                        break;
                    case 3://线上环境:8080
                        Request.changeBaseUrl(ApiConst.URL_ROOT_OUTER_80);
                        NewRequest.changeBaseUrl(ApiConst.URL_ROOT_OUTER_DOMAIN_PHP);
                        AppConst.PIC_HEAD = AppConst.PIC_HEAD_OUTER;
                        showToast(R.string.change_outer);
                        break;
                    case 4://线上环境:8085
                        Request.changeBaseUrl(ApiConst.URL_ROOT_OUTER_85);
                        NewRequest.changeBaseUrl(ApiConst.URL_ROOT_OUTER_DOMAIN_PHP);
                        AppConst.PIC_HEAD = AppConst.PIC_HEAD_OUTER;
                        showToast(R.string.change_outer);
                        break;
                    case 5://线上环境:域名
                        Request.changeBaseUrl(ApiConst.URL_ROOT_OUTER_DOMAIN);
                        NewRequest.changeBaseUrl(ApiConst.URL_ROOT_OUTER_DOMAIN_PHP);
                        AppConst.PIC_HEAD = AppConst.PIC_HEAD_OUTER;
                        showToast(R.string.change_outer);
                        break;
                }
                clearCookie();
                mListDialog.dismiss();
            }
        });
        mListDialog.show();
    }

    private void clearCookie() {
        LoginUtil.logout(BaseApplication.instance, false);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        search(hotList.get(position));
    }

    @Override
    public void onGetHotSearchSuccess(List<String> keys) {
        hotList.clear();
        if (!ListUtil.isEmpty(keys)) {
            hotList.addAll(keys);
        }
        FlowLayoutUtil.generateLable(mContext, hotList, mLayoutFlowhot, mLableClickListener, 20, 15);
    }

    @Override
    public void onGetHotSearchFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }
}
