package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.fragment.SortFragment;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.StringUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Xuzue on 2015/12/24.
 */
public class SortMenuAdapter extends BaseObjectListAdapter<SortEntity> {

    private SortFragment mFragment;
    private Map<Integer, Boolean> checkMap = new HashMap<>();
    private int mFirstShowPosition = -1;
    private String mFirstCheckCategory;

    public SortMenuAdapter(Context context, SortFragment fragment, List<SortEntity> datas, String firstCheckCategory) {
        super(context, datas);
        mFragment = fragment;
        mFirstCheckCategory = firstCheckCategory;
        int index = getFirstCheckPosition();
        if(index < 0){
            mFirstShowPosition = 0;
        }
        initCheckMap(mFirstShowPosition);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_sort_menu, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_sort_menu_layout_root);
            holder.mTv = (TextView) convertView.findViewById(R.id.listitem_sort_menu_tv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final SortEntity sort = get(position);
        holder.mTv.setText(sort.getName());

        boolean checked = checkMap.get(position);
        holder.mLayoutRoot.setSelected(checked);
        holder.mTv.setSelected(checked);

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkMap.get(position)) {
                    return;
                }
                initCheckMap(position);
                notifyDataSetChanged();
                mFragment.getSortById(sort.getPid() + "");
            }
        });

        return convertView;
    }

    public int getFirstCheckPosition() {
        int index = -1;
        if (!StringUtil.isEmpty(mFirstCheckCategory) && !ListUtil.isEmpty(mDatas)) {
            for (int i = 0; i < mDatas.size(); i++) {
                String pid = mDatas.get(i).getPid() + "";
                if (mFirstCheckCategory.equals(pid)) {
                     index = i;
                    break;
                }
            }
        }
        return index;
    }

    private void initCheckMap(int checkPosition) {
        if (checkPosition < 0) {
            return;
        }
        for (int i = 0; i < getCount(); i++) {
            if (i == checkPosition) {
                checkMap.put(i, true);
            } else {
                checkMap.put(i, false);
            }
        }
    }

    public static class ViewHolder {
        public LinearLayout mLayoutRoot;
        public TextView mTv;
    }
}
