package com.loonxi.ju53.manager;

import android.content.Context;
import android.graphics.drawable.Drawable;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.DisplayUtil;

/**
 * Created by Xuzue on 2016/3/17.
 */
public class HomeManager {

    /**
     * 设置底部按钮样式
     * @param mContext
     * @param position
     * @return
     */
    public static Drawable generateButton(Context mContext, int position){
        int width_one = DisplayUtil.dip2px(20, DisplayUtil.getScreenDensity(mContext));
        int width_two = DisplayUtil.dip2px(20, DisplayUtil.getScreenDensity(mContext));
        int width_three = DisplayUtil.dip2px(22, DisplayUtil.getScreenDensity(mContext));
        int height_one = DisplayUtil.dip2px(20, DisplayUtil.getScreenDensity(mContext));
        int height_two = DisplayUtil.dip2px(19, DisplayUtil.getScreenDensity(mContext));

        int btn_home_width = width_one;
        int btn_home_height = height_one;
        int btn_sort_width = width_three;
        int btn_sort_height = height_two;
        int btn_promotion_width = width_two;
        int btn_promotion_height = height_one;
        int btn_cart_width = width_one;
        int btn_cart_height = height_one;
        int btn_mine_width = width_one;
        int btn_mine_height = height_one;

        Drawable d_home = mContext.getResources().getDrawable(R.drawable.main_menu_home);
        Drawable d_sort = mContext.getResources().getDrawable(R.drawable.main_menu_sort);
        Drawable d_promotion = mContext.getResources().getDrawable(R.drawable.main_menu_promotion);
        Drawable d_shopping = mContext.getResources().getDrawable(R.drawable.main_menu_shopping);
        Drawable d_mine = mContext.getResources().getDrawable(R.drawable.main_menu_mine);
        Drawable d_store = mContext.getResources().getDrawable(R.drawable.main_menu_store);
        d_home.setBounds(0, 0, btn_home_width, btn_home_height);
        d_sort.setBounds(0, 0, btn_sort_width, btn_sort_height);
        d_promotion.setBounds(0, 0, btn_promotion_width, btn_promotion_height);
        d_shopping.setBounds(0, 0, btn_cart_width, btn_cart_height);
        d_mine.setBounds(0, 0, btn_mine_width, btn_mine_height);
        d_store.setBounds(0, 0, btn_mine_width, btn_mine_height);

        switch (position){
            case 1:
                return d_home;
            case 2:
                return d_sort;
            case 3:
                return d_promotion;
            case 4:
                return d_shopping;
            case 5:
                return d_mine;
            case 6:
                return d_store;
        }
        return null;
    }

}
