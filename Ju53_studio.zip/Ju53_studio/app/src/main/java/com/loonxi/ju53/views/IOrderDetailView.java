package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * Created by Xuzue on 2016/1/25.
 */
public interface IOrderDetailView extends IBaseView {
    void onGetOrderDetailSuccess(OrderDetailEntity jsonInfo);
    void onGetOrderDetailFailed(int apiErrorCode, String message);
    void onConfirmOrderSuccess(BaseJsonInfo jsonInfo);
    void onConfirmOrderFailed(int apiErrorCode, String message);
    void onPayOrderSuccess(AliPayEntity entity);
    void onPayOrderFailed(int apiErrorCode, String message);
    void getTransOrderSuccess(LogisticsEntity logisticsEntity);
    void getTransOrderFailure(int apiErrorCode, String message);
    void onCloseOrderSuccess();
    void onCloseOrderFailed(int apiErrorCode, String message);
}
