package com.loonxi.ju53.fragment;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CashAccountActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.presenters.CashAccountSetPresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ICashAccountSettingView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
@ContentView(R.layout.fragment_cash_account_set)
public class CashAccountSetFragment extends BaseSafeFragment<ICashAccountSettingView, CashAccountSetPresenter> implements ICashAccountSettingView, View.OnClickListener {


    @ViewInject(R.id.cash_account_set_tv_account)
    private EditText mTvAccount;
    @ViewInject(R.id.cash_account_set_tv_name)
    private EditText mTvName;
    @ViewInject(R.id.cash_account_set_tv_finish)
    private TextView mTvFinish;


    @Override
    protected CashAccountSetPresenter createPresenter(ICashAccountSettingView iCashAccountSettingView) {
        return new CashAccountSetPresenter(this);
    }

    @Override
    public void initView() {
        if (getActivity() != null) {
            ((CashAccountActivity) getActivity()).setTitle(true);
        }
    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        mTvFinish.setOnClickListener(this);
    }

    @Override
    public void bandAccountSuccess() {
        showToast("恭喜您，绑定成功！");
        back();
    }

    /**
     * 回退
     */
    private void back() {
        if (getFragmentManager() != null) {
            getFragmentManager().popBackStack();
        }
    }

    @Override
    public void bandAccountFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cash_account_set_tv_finish:
                band();
                break;
        }
    }

    /**
     * 绑定银行卡
     */
    private void band() {
        String account = mTvAccount.getText().toString();
        String name = mTvName.getText().toString();
        if (StringUtil.isEmpty(account)) {
            showToast("请填写支付宝账号");
            return;
        }
        if (StringUtil.isEmpty(name)) {
            showToast("请填写姓名");
            return;
        }
        if (mPresenter != null) {
            mPresenter.bandCashAccount(account, name);
        }
    }
}
