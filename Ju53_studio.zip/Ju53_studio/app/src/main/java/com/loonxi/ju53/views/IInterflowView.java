package com.loonxi.ju53.views;

/**
 * Created by Xuzue on 2016/2/25.
 */
public interface IInterflowView {
    void onGetInterflowDetailSuccess(Object object);
    void onGetInterflowDetailFailed(int apiErrorCode, String message);
}
