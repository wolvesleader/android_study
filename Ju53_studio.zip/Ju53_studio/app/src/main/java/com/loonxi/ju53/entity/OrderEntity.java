package com.loonxi.ju53.entity;


import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * "订单实体"
 * Created by Xuzue on 2016/1/7.
 */
public class OrderEntity implements Parcelable {

    private long pid;
    private long userId;
    /**
     * 供应商id
     */
    private long supplierId;
    /**
     * 订单id
     */
    private String orderId;
    /**
     * 订单类型
     */
    private int orderType;
    /**
     * 供应商名称
     */
    private String customName;
    private String categoryId;
    private String purchaseId;
    /**
     * 商品名称
     */
    private String title;
    private String stockjson;
    /**
     * 数量
     */
    private int orderNum;
    /**
     * 运费
     */
    private double freight;
    /**
     * 订单总金额
     */
    private double orderSum;
    /**
     * 优惠前的订单总金额
     */
    private double oldOrderSum;
    private int cycles;
    /**
     * 付款方式
     */
    private int payMode;
    private double paid;
    private int showstate;
    /**
     * 买家备注
     */
    private String notes;
    /**
     * 卖家备注
     */
    private String remark;
    /**
     * 订单状态 0-已下单,1-已付款,6-已发货,7-已确认收货,-1-撤销,10买方已评,11卖方已评,12双方已评
     */
    private int state;
    private long createTime;
    private long updateTime;
    /**
     * 单个商品的有关信息
     */
    private List<OrderUnitEntity> attrs;
    private int is_returned;
    private int is_backed;
    private int evaluated;
    private String payId;
    /**
     * 申请退款是订单的状态
     */
    private int formerState;

    public long getPid() {
        return pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(long supplierId) {
        this.supplierId = supplierId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getOrderType() {
        return orderType;
    }

    public void setOrderType(int orderType) {
        this.orderType = orderType;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(String purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStockjson() {
        return stockjson;
    }

    public void setStockjson(String stockjson) {
        this.stockjson = stockjson;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }

    public double getOrderSum() {
        return orderSum;
    }

    public void setOrderSum(double orderSum) {
        this.orderSum = orderSum;
    }

    public double getOldOrderSum() {
        return oldOrderSum;
    }

    public void setOldOrderSum(double oldOrderSum) {
        this.oldOrderSum = oldOrderSum;
    }

    public int getCycles() {
        return cycles;
    }

    public void setCycles(int cycles) {
        this.cycles = cycles;
    }

    public int getPayMode() {
        return payMode;
    }

    public void setPayMode(int payMode) {
        this.payMode = payMode;
    }

    public double getPaid() {
        return paid;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public int getShowstate() {
        return showstate;
    }

    public void setShowstate(int showstate) {
        this.showstate = showstate;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public List<OrderUnitEntity> getAttrs() {
        return attrs;
    }

    public void setAttrs(List<OrderUnitEntity> attrs) {
        this.attrs = attrs;
    }

    public int getIs_returned() {
        return is_returned;
    }

    public void setIs_returned(int is_returned) {
        this.is_returned = is_returned;
    }

    public int getIs_backed() {
        return is_backed;
    }

    public void setIs_backed(int is_backed) {
        this.is_backed = is_backed;
    }

    public int getEvaluated() {
        return evaluated;
    }

    public void setEvaluated(int evaluated) {
        this.evaluated = evaluated;
    }

    public String getPayId() {
        return payId;
    }

    public void setPayId(String payId) {
        this.payId = payId;
    }

    public int getFormerState() {
        return formerState;
    }

    public void setFormerState(int formerState) {
        this.formerState = formerState;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(pid);
        dest.writeLong(userId);
        dest.writeLong(supplierId);
        dest.writeString(orderId);
        dest.writeInt(orderType);
        dest.writeString(customName);
        dest.writeString(categoryId);
        dest.writeString(purchaseId);
        dest.writeString(title);
        dest.writeString(stockjson);
        dest.writeInt(orderNum);
        dest.writeDouble(freight);
        dest.writeDouble(orderSum);
        dest.writeDouble(oldOrderSum);
        dest.writeInt(cycles);
        dest.writeInt(payMode);
        dest.writeDouble(paid);
        dest.writeInt(showstate);
        dest.writeString(notes);
        dest.writeString(remark);
        dest.writeInt(state);
        dest.writeLong(createTime);
        dest.writeLong(updateTime);
        dest.writeList(attrs);
        dest.writeInt(is_returned);
        dest.writeInt(is_backed);
        dest.writeInt(evaluated);
        dest.writeString(payId);
        dest.writeInt(formerState);
    }

    public static final Parcelable.Creator<OrderEntity> CREATOR = new Parcelable.Creator<OrderEntity>() {
        @Override
        public OrderEntity createFromParcel(Parcel source) {
            OrderEntity order = new OrderEntity();
            order.setPid(source.readLong());
            order.setUserId(source.readLong());
            order.setSupplierId(source.readLong());
            order.setOrderId(source.readString());
            order.setOrderType(source.readInt());
            order.setCustomName(source.readString());
            order.setCategoryId(source.readString());
            order.setPurchaseId(source.readString());
            order.setTitle(source.readString());
            order.setStockjson(source.readString());
            order.setOrderNum(source.readInt());
            order.setFreight(source.readDouble());
            order.setOrderSum(source.readDouble());
            order.setOldOrderSum(source.readDouble());
            order.setCycles(source.readInt());
            order.setPayMode(source.readInt());
            order.setPaid(source.readDouble());
            order.setShowstate(source.readInt());
            order.setNotes(source.readString());
            order.setRemark(source.readString());
            order.setState(source.readInt());
            order.setCreateTime(source.readLong());
            order.setUpdateTime(source.readLong());
            order.setAttrs(source.readArrayList(Thread.currentThread().getContextClassLoader()));
            order.setIs_returned(source.readInt());
            order.setIs_backed(source.readInt());
            order.setEvaluated(source.readInt());
            order.setPayId(source.readString());
            order.setFormerState(source.readInt());
            return order;
        }

        @Override
        public OrderEntity[] newArray(int size) {
            return new OrderEntity[size];
        }

    };
}
