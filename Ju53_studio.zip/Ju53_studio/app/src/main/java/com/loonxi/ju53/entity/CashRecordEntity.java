package com.loonxi.ju53.entity;

/**
 * 提现记录
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashRecordEntity {
    private String applytime;//申请时间
    private String account_name;//转入账号名称
    private String account;//转入账号
    private String state;//申请状态(0-待处理,1-转账失败,2-转账成功,-1-删除)
    private String applied;//申请转账金额
    private String create_time;//处理时间
    private String notes;//备注


    public String getApplytime() {
        return applytime;
    }

    public void setApplytime(String applytime) {
        this.applytime = applytime;
    }

    public String getApplied() {
        return applied;
    }

    public void setApplied(String applied) {
        this.applied = applied;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDealTime() {
        return create_time;
    }

    public void setDealTime(String deal_time) {
        this.create_time = deal_time;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
