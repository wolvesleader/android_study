package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.FreightRule;
import com.loonxi.ju53.entity.OrderCreateEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderFreightEntity;
import com.loonxi.ju53.entity.SaleOrderDetailEntity;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.QueryMap;

/**
 * Created by Xuzue on 2016/1/18.
 */
public interface OrderService {
    /**
     * 获取运费模板
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/selectFreightsRule")
    Call<JsonArrayInfo<FreightRule>> getFreightRule(@FieldMap Map<String, Object> map);

    /**
     * 获取进货订单运费
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/getOrdersFreight")
    Call<JsonArrayInfo<OrderFreightEntity>> getOrdersFreight(@FieldMap Map<String, Object> map);


    /**
     * 获取进货订单列表
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/getOrders")
    Call<JsonArrayInfo<OrderEntity>> getOrders(@FieldMap Map<String, Object> map);

    /**
     * 获取订单列表（退款）
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/backedOrders")
    Call<JsonArrayInfo<OrderEntity>> getBackOrders(@FieldMap Map<String, Object> map);

    /**
     * 创建订单
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/createOrders")
    Call<OrderCreateEntity> createOrders(@FieldMap Map<String, Object> map);

    /**
     * 获取订单详情
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/getOrderById")
    Call<OrderDetailEntity> getOrderById(@FieldMap Map<String, Object> map);

    /**
     * 确认收货
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/sureOrders")
    Call<BaseJsonInfo> confirmOrder(@FieldMap Map<String, Object> map);

    /**
     * 申请退款
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/createRefunds")
    Call<BaseJsonInfo> createRefunds(@FieldMap Map<String, Object> map);

    /**
     * 修改/撤销退款申请
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateRefunds")
    Call<BaseJsonInfo> updateRefunds(@FieldMap Map<String, Object> map);

    /**
     * 付款
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("core/user/pay/alipayApp")
    Call<AliPayEntity> payOrder(@FieldMap Map<String, Object> map);

    /**
     * 关闭订单
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/closeOrder")
    Call<BaseJsonInfo> closeOrder(@FieldMap Map<String, Object> map);

    /**
     * 获得进货订单数（5种状态的订单数）
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/orderNum")
    Call<JsonInfo<String>> getBuyOrderNum(@FieldMap Map<String, Object> map);

    /**
     * 获得订单总数（分销订单、进货订单）
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Order/count")
    Call<JsonInfo<String>> getOrderTotalNum(@FieldMap Map<String, Object> map);


    /**
     * 获取分销订单
     *
     * @return
     */
    @FormUrlEncoded
    @POST("Order/DistributionOrder")
    Call<JsonArrayInfo<SaleOrderEntity>> getSaleOrders(@FieldMap Map<String, Object> map);

//    @GET("Order/DistributionOrder")
//    Call<JsonArrayInfo<SaleOrderEntity>> getSaleOrders(@QueryMap Map<String, Object> map);

    /**
     * 获取分销订单详情
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Order/DistriOrderDetail")
    Call<JsonInfo<SaleOrderDetailEntity>> getSaleOrderDetail(@FieldMap Map<String, Object> map);
}
