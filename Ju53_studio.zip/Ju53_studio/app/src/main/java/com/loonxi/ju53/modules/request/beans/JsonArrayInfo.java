package com.loonxi.ju53.modules.request.beans;

import java.io.Serializable;
import java.util.List;

/**
 * 返回的包含flag, message, data数据的json用该类解析
 * Created by Xuzue on 2015/12/16.
 */
public class JsonArrayInfo<T> implements Serializable{
    private int flag;
    private String message;
    private List<T> data;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }
}
