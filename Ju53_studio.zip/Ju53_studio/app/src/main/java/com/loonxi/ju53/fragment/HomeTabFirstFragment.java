package com.loonxi.ju53.fragment;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.HomeTabFirstRecycleAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.entity.MainBannderEntity;
import com.loonxi.ju53.entity.MainListEntity;
import com.loonxi.ju53.presenters.HomeTabFirstPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.IHomeTabView;
import com.loonxi.ju53.widgets.CycleViewPager;
import com.loonxi.ju53.widgets.ViewFactory;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yingjiafeng on 2016/6/1.
 */
@ContentView(R.layout.fragment_tab_first_child)
public class HomeTabFirstFragment extends BaseSafeFragment<IHomeTabView, HomeTabFirstPresenter> implements IHomeTabView {
    @ViewInject(R.id.fragment_home_recyclerView)
    private UltimateRecyclerView mUltimateRecyclerView;
    @ViewInject(R.id.fragment_home_iv_top)
    private ImageView mIvTotop;
    private static final int PUSH_START_PAGE = 1;
    private int mCurrentPage = PUSH_START_PAGE;
    @ViewInject(R.id.empty_net_layout_root)
    private RelativeLayout empty_net_layout_root;
    private CycleViewPager mViewPager;
    LinearLayout ll_haitao, ll_characteristic;
    HomeTabFirstRecycleAdapter homeTabFirstRecycleAdapter;

    @Override
    protected HomeTabFirstPresenter createPresenter(IHomeTabView iHomeTabView) {
        return new HomeTabFirstPresenter(this);
    }

    @Override
    public void initView() {
        empty_net_layout_root.setVisibility(View.GONE);
        //获取顶部数据
        mPresenter.getTopListData();
        initRecyclerView();
        //设置header
        setHeader();
        mPresenter.getHotActivity(mCurrentPage);

    }

    private void setHeader() {
        if (mInflater == null) {
            return;
        }
        View headView = mInflater.inflate(R.layout.include_home_tab_first_view, null, false);
        mViewPager = (CycleViewPager) getFragmentManager().findFragmentById(R.id.fragment_home_head_cycleviewpager);
        ll_haitao = (LinearLayout) headView.findViewById(R.id.ll_haitao);
        ll_characteristic = (LinearLayout) headView.findViewById(R.id.ll_characteristic);
        mUltimateRecyclerView.setNormalHeader(headView);

    }


    private List<String> mRecommends = new ArrayList<>();//推荐宝贝

    private void initRecyclerView() {
        //线性布局
        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity);
        mUltimateRecyclerView.setLayoutManager(layoutManager);
        //TODO 加载更多操作
        mUltimateRecyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
            @Override
            public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                Log.e("loadMore", "loadMore" + itemsCount);
            }
        });
        mUltimateRecyclerView.enableLoadmore();
        //TODO 下拉刷新
        mUltimateRecyclerView.setDefaultOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (mPresenter != null) {
                    mCurrentPage = PUSH_START_PAGE;
                    mPresenter.getTopListData();
                    mPresenter.getHotActivity(mCurrentPage);
                    // mPresenter.getHotActivity(1);

                }
            }
        });
        mRecommends.add("1");
        mRecommends.add("2");
        mRecommends.add("3");
        mRecommends.add("4");
        mRecommends.add("5");
        homeTabFirstRecycleAdapter = new HomeTabFirstRecycleAdapter(mContext, mRecommends);
        mUltimateRecyclerView.setAdapter(homeTabFirstRecycleAdapter);


    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {

    }

    @Override
    public void getTopListData(MainBannderEntity data) {
        if (data != null && data.getData() != null) {
            empty_net_layout_root.setVisibility(View.GONE);
        }

        MainBannderEntity.DataEntity dataEntity = data.getData();
        if (dataEntity == null) {
            empty_net_layout_root.setVisibility(View.VISIBLE);
            return;
        }
        //设置bannder
        if (dataEntity.getBanner() != null && dataEntity.getBanner().size() > 0) {
            ArrayList<IndexEntity> enityList = new ArrayList<>();
            //转换数据
            for (int i = 0; i < dataEntity.getBanner().size(); i++) {
                IndexEntity entity = new IndexEntity();
                entity.setImgUrl(dataEntity.getBanner().get(i).getImg_url());
                enityList.add(entity);
            }
            setCycleViewPager(enityList);
        }
        //设置海淘馆
        if (dataEntity.getCategory() != null && dataEntity.getCategory().size() > 0) {
            mPresenter.setHaiTaoIcon(ll_haitao, mActivity, dataEntity.getCategory());
        }
        //设置频道
        if (dataEntity.getFeature() != null && dataEntity.getFeature().size() > 0) {
            mPresenter.setPinDaoList(ll_characteristic, mActivity, dataEntity.getFeature());
        }
        if (homeTabFirstRecycleAdapter != null) {
            homeTabFirstRecycleAdapter.notifyDataSetChanged();
        }

    }

    @Override
    public void getTopListDataFaile(int apiErrorCode, String message) {
        empty_net_layout_root.setVisibility(View.VISIBLE);

    }

    @Override
    public void getHotActivity(MainListEntity data)
    {
        //获取主界面数据
      

    }


    @Override
    public void getHotActivityFaile(int apiErrorCode, String message) {

    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();

    }

    private List<ImageView> mBannersImgs = new ArrayList<>();

    /**
     * 设置banner
     *
     * @param banners
     */
    private void setCycleViewPager(List<IndexEntity> banners) {
        if (ListUtil.isEmpty(banners)) {
            return;
        }
        mBannersImgs.clear();
        mBannersImgs.add(ViewFactory.getImageView(mContext, banners.get(banners.size() - 1) == null ? "" : banners.get(banners.size() - 1).getImgUrl()));
        for (int i = 0; i < banners.size(); i++) {
            mBannersImgs.add(ViewFactory.getImageView(mContext, banners.get(i) == null ? "" : banners.get(i).getImgUrl()));
        }
        mBannersImgs.add(ViewFactory.getImageView(mContext, banners.get(0) == null ? "" : banners.get(0).getImgUrl()));
        mViewPager.setCycle(true);
        mViewPager.setData(mBannersImgs, banners, new MyImageCycleViewListener());
        mViewPager.setWheel(true);
        mViewPager.setTime(3000);
    }

    private class MyImageCycleViewListener implements CycleViewPager.ImageCycleViewListener {

        @Override
        public void onImageClick(IndexEntity info, int position, View imageView) {

        }
    }


}
