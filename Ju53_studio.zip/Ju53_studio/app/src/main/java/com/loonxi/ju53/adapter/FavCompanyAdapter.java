package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/5.
 */
public class FavCompanyAdapter extends BaseObjectListAdapter<SupplierEntity> {

    public FavCompanyAdapter(Context context, List<SupplierEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_fav_company, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_fav_company_layout_root);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_fav_company_head);
            holder.mTvName = (TextView) convertView.findViewById(R.id.listitem_fav_company_name);
            holder.mTvSales = (TextView) convertView.findViewById(R.id.listitem_fav_company_nums);
            holder.mTvStars = (TextView) convertView.findViewById(R.id.listitem_fav_company_stars);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final SupplierEntity company = get(position);
        if (StringUtil.isEmpty(company.getPicPath())) {
            Glide.with(mContext).load(R.drawable.icon_head).into(holder.mIvHead);
        } else {
            Glide.with(mContext).load(AppConst.PIC_HEAD + company.getPicPath() + AppConst.PIC_SIZE_80).into(holder.mIvHead);
        }
        holder.mTvName.setText(company.getName());
        holder.mTvSales.setText(mContext.getResources().getString(R.string.fav_company_nums) + company.getNum() + "件");
        holder.mTvStars.setText("满意率" + (StringUtil.isEmpty(company.getScore()) ? "" : company.getScore()) + "%");

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", company.getUserId() + "");
                intent.putExtra("userName", company.getName());
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvHead;
        TextView mTvName;
        TextView mTvSales;
        TextView mTvStars;
    }
}
