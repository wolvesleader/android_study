package com.loonxi.ju53.modules.request.beans;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2016/1/5.
 */
public class BaseJsonInfo implements Parcelable {
    private int flag;
    private String message;

    public BaseJsonInfo(){

    }

    protected BaseJsonInfo(Parcel in) {
        flag = in.readInt();
        message = in.readString();
    }

    public static final Creator<BaseJsonInfo> CREATOR = new Creator<BaseJsonInfo>() {
        @Override
        public BaseJsonInfo createFromParcel(Parcel in) {
            return new BaseJsonInfo(in);
        }

        @Override
        public BaseJsonInfo[] newArray(int size) {
            return new BaseJsonInfo[size];
        }
    };

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(flag);
        dest.writeString(message);
    }
}
