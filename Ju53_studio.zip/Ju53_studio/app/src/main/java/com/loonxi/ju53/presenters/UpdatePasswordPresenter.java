package com.loonxi.ju53.presenters;

import android.text.TextUtils;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.VerifyCodeEntity;
import com.loonxi.ju53.models.impl.UpdatePasswordModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IRegistCodeView;
import com.loonxi.ju53.views.IRegistPhoneView;
import com.loonxi.ju53.views.IUpdatePasswordView;

import retrofit.Retrofit;

/**
 * "更新密码"presenter
 * Created by laojiaqi on 2016/2/17.
 */
public class UpdatePasswordPresenter extends BasePresenter<IUpdatePasswordView> {
    private IUpdatePasswordView mView;
    private UpdatePasswordModel mModel;

    public UpdatePasswordPresenter(IUpdatePasswordView view) {
        super(view);
        mView = getView();
        mModel = new UpdatePasswordModel();
    }


    /**
     * 更新_登录_密码：记得密码情况
     *
     * @param newPassword
     * @param oldPassword
     */
    public void updateLoginPassword(String newPassword, String oldPassword) {
        if (TextUtils.isEmpty(newPassword) || TextUtils.isEmpty(oldPassword)) {
            return;
        }
        mModel.updateLoginPassword(newPassword, oldPassword, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onUpdatePasswordSuccess(data.getMessage());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onUpdatePasswordFailure(message);
                }
            }
        });
    }


    /**
     * 更新_支付_密码：记得密码情况
     *
     * @param newCashPassword
     * @param oldCashPassword
     */
    public void updatePayPassword(String newCashPassword, String oldCashPassword) {
        if (TextUtils.isEmpty(newCashPassword) || TextUtils.isEmpty(oldCashPassword)) {
            return;
        }
        mModel.updatePayPassword(newCashPassword, oldCashPassword, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onUpdatePasswordSuccess(data.getMessage());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onUpdatePasswordFailure(message);
                }
            }
        });
    }


    /**
     * 获得_登录密码_验证码
     *
     * @param mobile
     */
    public void getLoginPasswordVerifyCode(String mobile) {
        if (TextUtils.isEmpty(mobile)) {
            return;
        }
        mModel.getLoginPasswordVerifyCode(mobile, new Callback<VerifyCodeEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, VerifyCodeEntity data) {

            }

            @Override
            public void onSuccess(VerifyCodeEntity data, Retrofit retrofit) {
                if (mView == null || data == null) {
                    return;
                }
                ToastUtil.showShortToast(data.getMessage());
                ((IRegistPhoneView) mView).onGetCodeSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                ((IRegistPhoneView) mView).onGetCodeFailed(apiErrorCode, message);
                ToastUtil.showShortToast(message);
            }
        });
    }


    /**
     * 获得_支付密码_验证码
     *
     * @param mobile
     */
    public void getPayPasswordVerifyCode(String mobile, String password) {
        if (TextUtils.isEmpty(mobile) || TextUtils.isEmpty(password)) {
            return;
        }
        mModel.getLoginPasswordVerifyCode(mobile, new Callback<VerifyCodeEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, VerifyCodeEntity data) {

            }

            @Override
            public void onSuccess(VerifyCodeEntity data, Retrofit retrofit) {
                if (mView == null || data == null) {
                    return;
                }
                ToastUtil.showShortToast(data.getMessage());
                ((IRegistPhoneView) mView).onGetCodeSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                ((IRegistPhoneView) mView).onGetCodeFailed(apiErrorCode, message);
                ToastUtil.showShortToast(message);
            }
        });
    }


    /**
     * 验证_登录密码_验证码
     *
     * @param mobile
     */
    public void checkLoginPasswordVerifyCode(String mobile, String verifyCode) {
        if (TextUtils.isEmpty(mobile) || TextUtils.isEmpty(verifyCode)) {
            return;
        }
        mModel.checkLoginPasswordVerifyCode(mobile, verifyCode, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                ((IRegistCodeView) mView).onVerifyCodeSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                ((IRegistCodeView) mView).onVerifyCodeFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 忘记密码_重置_登录密码
     *
     * @param newPassword
     * @param mobile
     */
    public void resetLoginPassword(String newPassword, String mobile) {
        if (TextUtils.isEmpty(newPassword) || TextUtils.isEmpty(mobile)) {
            return;
        }
        mModel.resetLoginPassword(newPassword, mobile, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onUpdatePasswordSuccess(data.getMessage());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onUpdatePasswordFailure(message);
                }
            }
        });
    }


    /**
     * 忘记密码_重置_登录密码
     *
     * @param newCashPassword
     * @param mobile
     */
    public void resetPayPassword(String newCashPassword, String mobile) {
        if (TextUtils.isEmpty(newCashPassword) || TextUtils.isEmpty(mobile)) {
            return;
        }
        mModel.resetPayPassword(newCashPassword, mobile, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onUpdatePasswordSuccess(data.getMessage());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onUpdatePasswordFailure(message);
                }
            }
        });
    }


    /**
     * 验证登入密码
     *
     * @param loginPassword
     */
    public void checkLoginPassword(final String loginPassword) {
        if (TextUtils.isEmpty(loginPassword)) {
            return;
        }
        mModel.checkLoginPassword(loginPassword, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onUpdatePasswordSuccess(loginPassword);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onUpdatePasswordFailure(message);
                }
            }
        });
    }


    /**
     * 退出登录
     */
    public void logout() {
        mModel.logout(new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {

            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
            }
        });
    }


}
