package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.PaySuccessEntity;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by XuZue on 2016/5/27 0027.
 */
public class OrderPaySuccessActivity extends ActionBarActivity implements View.OnClickListener {

    @ViewInject(R.id.order_pay_success_tv_name)
    private TextView mTvPersonName;
    @ViewInject(R.id.order_pay_success_tv_tel)
    private TextView mTvPersonTel;
    @ViewInject(R.id.order_pay_success_tv_address)
    private TextView mTvPersonAddress;
    @ViewInject(R.id.order_pay_success_tv_money)
    private TextView mTvPersonMoney;
    @ViewInject(R.id.order_pay_success_tv_to_orderdetail)
    private TextView mTvPersonToDetail;
    @ViewInject(R.id.order_pay_success_tv_to_home)
    private TextView mTvPersonToHome;

    private PaySuccessEntity mPaySuccess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_pay_success);
    }

    @Override
    public void initView() {
        setTitle("支付成功");
    }

    @Override
    public void initContent() {
        mPaySuccess = getIntent().getParcelableExtra("successEntity");
        if (mPaySuccess == null) {
            return;
        }
        mTvPersonName.setText(getResources().getString(R.string.order_confirm_title_name) + mPaySuccess.getName());
        mTvPersonTel.setText(mPaySuccess.getTel());
        mTvPersonAddress.setText(getResources().getString(R.string.order_confirm_title_address) + mPaySuccess.getAddress());
        mTvPersonMoney.setText("¥ " + (StringUtil.isEmpty(mPaySuccess.getMoney()) ? "0.00" : mPaySuccess.getMoney()));
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mTvPersonToDetail.setOnClickListener(this);
        mTvPersonToHome.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
            case R.id.order_pay_success_tv_to_orderdetail:
                OrderEntity orderEntity = new OrderEntity();
                orderEntity.setOrderId(mPaySuccess == null ? "" : mPaySuccess.getOrderId());
                Intent intent = new Intent(mContext, OrderDetailActivity.class);
                intent.putExtra("order", orderEntity);
                startActivity(intent);
                break;
            case R.id.order_pay_success_tv_to_home:
                gotoMainActivity(MainActivity.RESET_POPWINDOW);
                break;

        }
    }
}
