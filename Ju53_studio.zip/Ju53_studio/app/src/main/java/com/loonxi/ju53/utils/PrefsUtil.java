package com.loonxi.ju53.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;


/**
 * 偏好设置工具类
 */
public class PrefsUtil {

    private static SharedPreferences mSharedPreferences;

    private static void init(Context context){
        if(mSharedPreferences == null){
            mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        }
    }

    /**
     * 设置布尔值
     * @param context
     * @param key
     * @param value
     */
    public static void setSharedBooleanData(Context context, String key, boolean value){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().putBoolean(key, value).commit();
    }

    /**
     * 获取布尔值
     * @param context
     * @param key
     * @param defaultValue
     * @return
     */
    public static boolean getSharedBooleanData(Context context, String key, boolean defaultValue){
        if(mSharedPreferences == null){
            init(context);
        }
        return mSharedPreferences.getBoolean(key, defaultValue);
    }

    /**
     * 获取布尔值
     * @param context
     * @param key
     * @return
     */
    public static boolean getSharedBooleanData(Context context, String key){
        if(mSharedPreferences == null){
            init(context);
        }
        return getSharedBooleanData(context, key, false);
    }

    /**
     * 设置int数值
     * @param context
     * @param key
     * @param value
     */
    public static void setSharedIntData(Context context, String key, int value){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().putInt(key, value).commit();
    }

    /**
     * 获取int数据
     * @param context
     * @param key
     * @return
     */
    public static int getSharedIntData(Context context, String key){
        if(mSharedPreferences == null){
            init(context);
        }
        return getSharedIntData(context, key, -1);
    }

    /**
     * 获取int数据
     * @param context
     * @param key
     * @param defaultValue
     * @return
     */
    public static int getSharedIntData(Context context, String key, int defaultValue){
        if(mSharedPreferences == null){
            init(context);
        }
        return mSharedPreferences.getInt(key, defaultValue);
    }

    /**
     * 设置float数据
     * @param context
     * @param key
     * @param value
     */
    public static void setSharedFloatData(Context context, String key, float value){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().putFloat(key, value).commit();
    }

    /**
     * 获取float数据
     * @param context
     * @param key
     * @return
     */
    public static float getSharedFloatData(Context context, String key){
        if(mSharedPreferences == null){
            init(context);
        }
        return getSharedFloatData(context, key, -1f);
    }

    /**
     * 获取float数据
     * @param context
     * @param key
     * @param defaultValue
     * @return
     */
    public static float getSharedFloatData(Context context, String key, float defaultValue){
        if(mSharedPreferences == null){
            init(context);
        }
        return mSharedPreferences.getFloat(key, defaultValue);
    }

    /**
     * 设置long数据
     * @param context
     * @param key
     * @param value
     */
    public static void setSharedLongData(Context context, String key, long value){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().putLong(key, value).commit();
    }

    /**
     * 获取long数据
     * @param context
     * @param key
     * @return
     */
    public static long getSharedLongData(Context context, String key){
        if(mSharedPreferences == null){
            init(context);
        }
        return getSharedLongData(context, key, -1l);
    }

    /**
     * 获取long数据
     * @param context
     * @param key
     * @param defaultValue
     * @return
     */
    public static long getSharedLongData(Context context, String key, long defaultValue){
        if(mSharedPreferences == null){
            init(context);
        }
        return mSharedPreferences.getLong(key, defaultValue);
    }

    /**
     * 设置String数据
     * @param context
     * @param key
     * @param value
     */
    public static void setSharedStringData(Context context, String key, String value){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().putString(key, value).commit();
    }

    /**
     * 获取String数据
     * @param context
     * @param key
     * @return
     */
    public static String getSharedStringData(Context context, String key){
        if(mSharedPreferences == null){
            init(context);
        }
        return getSharedStringData(context, key, "");
    }

    /**
     * 获取String数据
     * @param context
     * @param key
     * @param defaultValue
     * @return
     */
    public static String getSharedStringData(Context context, String key, String defaultValue){
        if(mSharedPreferences == null){
            init(context);
        }
        return mSharedPreferences.getString(key, defaultValue);
    }

    /**
     * 删除某个键值的数据
     * @param context
     * @param key
     */
    public static void remove(Context context, String key){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().remove(key).commit();
    }

    /**
     * 清空所有偏好设置数据
     * @param context
     */
    public static void clearAll(Context context){
        if(mSharedPreferences == null){
            init(context);
        }
        mSharedPreferences.edit().clear().commit();
    }


}
