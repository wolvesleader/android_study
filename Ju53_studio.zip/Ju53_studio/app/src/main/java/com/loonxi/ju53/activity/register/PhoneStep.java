package com.loonxi.ju53.activity.register;

import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.activity.RegisterActivity;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.presenters.RegisterPresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IRegistPhoneView;
import com.loonxi.ju53.widgets.DeleteEditText;

/**
 * Created by Xuzue on 2016/1/4.
 */
public class PhoneStep extends RegisterStep implements View.OnClickListener, IRegistPhoneView {

    private DeleteEditText mTvPhone;
    private TextView mTvTip;
    private TextView mBtnNext;

    private RegisterPresenter mPresenter;

    public PhoneStep(RegisterActivity activity, Context context, View contentView) {
        super(activity, context, contentView);
        mPresenter = new RegisterPresenter(this);
    }

    @Override
    public void initViews() {
        mTvPhone = (DeleteEditText) findViewById(R.id.include_register_phone_tv_phone);
        mTvTip = (TextView) findViewById(R.id.include_register_phone_tv_tip);
        mBtnNext = (TextView) findViewById(R.id.include_register_phone_btn_next);
        mBtnNext.setEnabled(false);
    }

    @Override
    public void initEvents() {
        mBtnNext.setOnClickListener(this);
        mTvTip.setOnClickListener(this);
        mTvPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mIsChange = true;
                if (StringUtil.isEmpty(mTvPhone.getText().toString())) {
                    mBtnNext.setEnabled(false);
                } else {
                    mBtnNext.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void initContent() {
        mTvTip.setText(Html.fromHtml("注册即为同意<font color=\"#ee0c00\">《JU53在线交易服务条款》</font>"));
    }

    @Override
    public void afterChangeInit() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.include_register_phone_btn_next:
                mPhone = mTvPhone.getText().toString().trim();
                next();
                break;
            case R.id.include_register_phone_tv_tip:
                Intent intent = new Intent(mContext, CommonWebviewActivity.class);
                intent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, ApiConst.PROTOCAL_URL);
                intent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, "服务条款");
                mContext.startActivity(intent);
                break;
        }
    }

    private void next() {
        setMobile(mPhone);
        if (!mIsChange) {
            mOnNextActionListener.next(false);
            return;
        }
        mPresenter.getCheckCode(mPhone);
    }

    @Override
    public void showToast(int resId) {
        ToastUtil.showToast(mContext, resId);
    }

    @Override
    public void onGetCodeSuccess() {
        mOnNextActionListener.next(mIsChange);
        mIsChange = false;
    }

    @Override
    public void onGetCodeFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
