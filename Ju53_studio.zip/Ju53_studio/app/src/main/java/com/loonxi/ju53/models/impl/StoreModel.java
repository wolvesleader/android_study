package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.models.IStoreModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.StoreService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
public class StoreModel implements IStoreModel {

    /**
     * 获取店铺产品列表
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonInfo<StoreDataEntity>> getStoreProducts(Map<String, Object> map, Callback<JsonInfo<StoreDataEntity>> callback) {
        Call<JsonInfo<StoreDataEntity>> call = NewRequest.creatApi(StoreService.class).getStoreProducts(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 下架店铺商品
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> offSaleProduct(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).offSaleProduct(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 上架店铺商品
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> onSaleProduct(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).onSaleStoreProduct(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 删除商品
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> deleteProduct(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).deleteProduct(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 店铺商品移到顶部
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> moveToTop(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).moveToTop(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取店铺详情
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonInfo<StoreDataEntity>> getStoreDetail(Map<String, Object> map, Callback<JsonInfo<StoreDataEntity>> callback) {
        Call<JsonInfo<StoreDataEntity>> call = NewRequest.creatApi(StoreService.class).getStoreDetail(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取店铺基本信息
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonInfo<StoreBaseInfoEntity>> getStoreBaseInfo(Map<String, Object> map, Callback<JsonInfo<StoreBaseInfoEntity>> callback) {
        Call<JsonInfo<StoreBaseInfoEntity>> call = NewRequest.creatApi(StoreService.class).getStoreBaseInfo(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 修改店铺名
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> altStoreName(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).altStoreName(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 修改店铺头像
     *
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> altStoreLOGO(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).altStoreLOGO(map);
        call.enqueue(callback);
        return call;
    }



}
