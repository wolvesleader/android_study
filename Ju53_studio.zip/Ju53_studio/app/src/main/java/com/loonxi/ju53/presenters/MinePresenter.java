package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.models.impl.MineModel;
import com.loonxi.ju53.models.impl.TestModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.views.IMineView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/17.
 */
public class MinePresenter extends BasePresenter<IMineView> {

    private IMineView mView;
    private MineModel mModel;

    public MinePresenter(IMineView mView) {
        super(mView);
        this.mView = getView();
        mModel = new MineModel();
    }

    /**
     * 获取订单数量
     */
    public void getBuyOrderNum(){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getBuyOrderNum(map, new Callback<JsonInfo<String>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<String> data) {

            }

            @Override
            public void onSuccess(JsonInfo<String> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetBuyOrderNumSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onGetBuyOrderNumFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 获取订单总数
     */
    public void getOrderTotalNum(){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getOrderTotalNum(map, new Callback<JsonInfo<String>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<String> data) {

            }

            @Override
            public void onSuccess(JsonInfo<String> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetOrderTotalNumSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onGetOrderTotalNumFailed(apiErrorCode, message);
                }
            }
        });
    }



    public void testPhp(){
        TestModel model = new TestModel();
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        model.testPhp(map, new Callback<Object>() {
            @Override
            public void onOtherFlag(int flag, String message, Object data) {

            }

            @Override
            public void onSuccess(Object data, Retrofit retrofit) {
                LogUtil.mLog().e("success");
                if(mView == null){
                    return;
                }
                mView.testPhpSuccess(data.toString());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                LogUtil.mLog().e("failed");
                if(mView == null){
                    return;
                }
                mView.testPhpFailed(apiErrorCode, message);
            }
        });
    }

    public void testUser(String cookieValue){
        TestModel model = new TestModel();
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("cookieValue", cookieValue);
        model.testUser(map, new Callback<Object>() {
            @Override
            public void onOtherFlag(int flag, String message, Object data) {

            }

            @Override
            public void onSuccess(Object data, Retrofit retrofit) {
                if(data != null) {
                    LogUtil.mLog().e(data.toString());
                }else{
                    LogUtil.mLog().e("empty");
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                LogUtil.mLog().e("error");
            }
        });
    }
}
