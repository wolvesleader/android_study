package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.SendCommentEntity;
import com.loonxi.ju53.models.impl.SendCommentModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.views.ISendCommentView;

import retrofit.Retrofit;

/**
 * 发送评论 presenter
 * Created by laojiaqi on 2016/2/16.
 */
public class SendCommentPresenter extends BasePresenter<ISendCommentView> {

    ISendCommentView iSendCommentView;
    SendCommentModel sendCommentModel = new SendCommentModel();

    public SendCommentPresenter(ISendCommentView view) {
        super(view);
        iSendCommentView = getView();
    }

    public void sendComment(SendCommentEntity sendCommentEntity) {
        sendCommentModel.sendComment(sendCommentEntity, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (iSendCommentView == null) {
                    return;
                }
                iSendCommentView.onSendCommentViewSuccess(data == null ? "" : data.getMessage());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (iSendCommentView == null) {
                    return;
                }
                // iSendCommentView.onSendCommentViewFailure(me);
            }
        });

    }
}
