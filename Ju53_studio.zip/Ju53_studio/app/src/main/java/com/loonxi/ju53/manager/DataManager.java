package com.loonxi.ju53.manager;

/**
 * Created by Xuzue on 2016/1/12.
 */
public class DataManager {
}
