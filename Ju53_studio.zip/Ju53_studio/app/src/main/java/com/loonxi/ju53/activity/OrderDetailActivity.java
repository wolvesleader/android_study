package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.OrderDetailAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.OrderState;
import com.loonxi.ju53.convert.OrderDataConvert;
import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderAddressEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderTime;
import com.loonxi.ju53.entity.PaySuccessEntity;
import com.loonxi.ju53.listener.AlipayListener;
import com.loonxi.ju53.manager.AlipayManager;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.presenters.OrderDetailPresenter;
import com.loonxi.ju53.utils.InterflowUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.TimeUtil;
import com.loonxi.ju53.views.IOrderDetailView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.dialog.PayPasswordDialog;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/21.
 */
public class OrderDetailActivity extends ActionBarActivity implements View.OnClickListener, IOrderDetailView, AlipayListener {

    @ViewInject(R.id.order_detail_layout_root)
    private LinearLayout mLayoutRoot;
    @ViewInject(R.id.order_detail_slv)
    private PullToRefreshScrollView mSlv;
    @ViewInject(R.id.order_detail_tv_status)
    private TextView mTvOrderStatus;
    @ViewInject(R.id.order_detail_layout_personal_info)
    private LinearLayout mLayoutPersonInfo;
    @ViewInject(R.id.order_detail_tv_name)
    private TextView mTvName;
    @ViewInject(R.id.order_detail_tv_tel)
    private TextView mTvTel;
    @ViewInject(R.id.order_detail_tv_address)
    private TextView mTvAddress;
    @ViewInject(R.id.order_detail_flv)
    private FixedListView mFlv;
    @ViewInject(R.id.order_detail_tv_order_no)
    private TextView mTvOrderNo;
    @ViewInject(R.id.order_detail_tv_order_createtime)
    private TextView mTvCreateTime;
    @ViewInject(R.id.order_detail_layout_paytime)
    private LinearLayout mLayoutPayTime;
    @ViewInject(R.id.order_detail_tv_order_paytime)
    private TextView mTvPayTime;
    @ViewInject(R.id.order_detail_layout_sendtime)
    private LinearLayout mLayoutSendTime;
    @ViewInject(R.id.order_detail_tv_order_sendtime)
    private TextView mTvSendTime;
    @ViewInject(R.id.order_detail_layout_confirmtime)
    private LinearLayout mLayoutConfirmTime;
    @ViewInject(R.id.order_detail_tv_order_confirmtime)
    private TextView mTvConfirmTime;
    @ViewInject(R.id.order_detail_layout_bottom)
    private LinearLayout mLayoutBottom;
    @ViewInject(R.id.order_detail_btn_cancel)
    private TextView mBtnCancel;
    @ViewInject(R.id.order_detail_btn_pay)
    private TextView mBtnPay;
    @ViewInject(R.id.order_detail_btn_confirm_received)
    private TextView mBtnConfirmReceived;
    @ViewInject(R.id.order_detail_btn_interflow)
    private TextView mBtnInterflow;
    @ViewInject(R.id.order_detail_btn_refund)
    private TextView mBtnRefund;
    @ViewInject(R.id.order_detail_btn_recommend)
    private TextView mBtnRecommend;

    private OrderDetailAdapter mAdapter;
    private OrderEntity mOrder;
    private OrderDetailEntity mOrderDetail;
    private List<CartEntity> mCarts = new ArrayList<>();
    private OrderDetailPresenter mPresenter;
    private PayPasswordDialog mPasswordDialog;

    public static final int REQUEST_CODE_REFUND = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
    }

    @Override
    public void initView() {
        setTitle(R.string.order_detail_title);
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mPresenter = new OrderDetailPresenter(this);
        mOrder = getIntent().getParcelableExtra("order");
        mPresenter.getOrderById(mOrder);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mBtnCancel.setOnClickListener(this);
        mBtnPay.setOnClickListener(this);
        mBtnInterflow.setOnClickListener(this);
        mBtnConfirmReceived.setOnClickListener(this);
        mBtnRecommend.setOnClickListener(this);
        mSlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getOrderById(mOrder);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
            case R.id.order_detail_btn_cancel:
                if (mOrder != null) {
                    mPresenter.closeOrder(mOrder.getPid() + "");
                }
                break;
            case R.id.order_detail_btn_pay:
                if (mOrder != null) {
                    mPresenter.payOrder(mOrder.getPayId(), mOrder.getOrderId(), mOrder.getUserId() + "", mOrder.getOrderSum());
                }
                break;
            case R.id.order_detail_btn_confirm_received:
                showPayPasswordDialog();
                break;
            case R.id.order_detail_btn_interflow:
                if (mOrder != null) {
                    mPresenter.getOrderTrans(mOrder.getOrderId());
                }
                break;
            case R.id.order_detail_btn_refund:

                break;
            case R.id.order_detail_btn_recommend:
                gotoSendCommentActivity(mOrder);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_REFUND:
                if (resultCode == RESULT_OK) {
                    finish();
                }
                break;
        }

    }

    /**
     * 跳转到“评价”Activity
     *
     * @param orderEntity
     */
    private void gotoSendCommentActivity(OrderEntity orderEntity) {
        if (mContext == null || orderEntity == null || orderEntity.getAttrs() == null) {
            return;
        }
        Intent intent = new Intent(mContext, SendCommentActivity.class);
        intent.putExtra("orderEntity", orderEntity);
        mContext.startActivity(intent);
    }

    /**
     * 设置订单信息
     */
    private void setOrderInfo() {
        if (mOrderDetail == null || mOrderDetail.getOrder() == null) {
            return;
        }
        OrderAddressEntity addressEntity = mOrderDetail.getAddress();
        int state = mOrderDetail.getOrder().getState();
        OrderState.setOrderState(mTvOrderStatus, state);
        String name = addressEntity == null || StringUtil.isEmpty(addressEntity.getContact()) ? "" : addressEntity.getContact();
        String phone = addressEntity == null || StringUtil.isEmpty(addressEntity.getPhones()) ? "" : addressEntity.getPhones();
        String address = addressEntity == null || StringUtil.isEmpty(addressEntity.getReceiveAddress()) ? "" : addressEntity.getReceiveAddress();
        mTvName.setText(getResources().getString(R.string.order_confirm_title_name) + name);
        mTvTel.setText(phone);
        mTvAddress.setText(getResources().getString(R.string.order_confirm_title_address) + address);
        mTvOrderNo.setText(mOrderDetail.getOrder().getOrderId());
        OrderTime time = mOrderDetail.getTime().get(0);
        mTvCreateTime.setText(formatTime(time.getCreateTime()));
        setTime(mOrderDetail.getTime(), state);
        setButton(state);
    }

    /**
     * 设置时间
     *
     * @param times
     * @param state
     */
    private void setTime(List<OrderTime> times, int state) {
        switch (state) {
            case OrderState.PAYED:
                mLayoutPayTime.setVisibility(View.VISIBLE);
                if (!ListUtil.isEmpty(times) && times.size() >= 2) {
                    mTvPayTime.setText(formatTime(times.get(1).getCreateTime()));
                }
                break;
            case OrderState.WAIT_RECEIVE:
                mLayoutPayTime.setVisibility(View.VISIBLE);
                mLayoutSendTime.setVisibility(View.VISIBLE);
                if (!ListUtil.isEmpty(times) && times.size() >= 3) {
                    mTvPayTime.setText(formatTime(times.get(1).getCreateTime()));
                    mTvSendTime.setText(formatTime(times.get(2).getCreateTime()));
                }
                break;
            case OrderState.CONFIRM_RECEIVED:
                mLayoutPayTime.setVisibility(View.VISIBLE);
                mLayoutSendTime.setVisibility(View.VISIBLE);
                mLayoutConfirmTime.setVisibility(View.VISIBLE);
                if (!ListUtil.isEmpty(times) && times.size() >= 4) {
                    mTvPayTime.setText(formatTime(times.get(1).getCreateTime()));
                    mTvSendTime.setText(formatTime(times.get(2).getCreateTime()));
                    mTvConfirmTime.setText(formatTime(times.get(3).getCreateTime()));
                }
                break;
        }
    }

    /**
     * 设置按钮
     *
     * @param state
     */
    private void setButton(int state) {
        switch (state) {
            case OrderState.CANCEL:
                mBtnInterflow.setVisibility(View.VISIBLE);
                break;
            case OrderState.WAIT_PAY:
                mBtnPay.setVisibility(View.VISIBLE);
                mBtnCancel.setVisibility(View.VISIBLE);
                break;
            case OrderState.PAYED:
                mLayoutBottom.setVisibility(View.GONE);
                break;
            case OrderState.WAIT_RECEIVE:
                mBtnConfirmReceived.setVisibility(View.VISIBLE);
                mBtnInterflow.setVisibility(View.VISIBLE);
                break;
            case OrderState.CONFIRM_RECEIVED:
                mBtnRecommend.setVisibility(View.VISIBLE);
                mBtnInterflow.setVisibility(View.VISIBLE);
                break;
        }
    }

    private String formatTime(long time) {
        return TimeUtil.getFormatTimeFromTimestamp(time, "yyyy-MM-dd HH:mm");
    }

    /**
     * 输入支付密码并确认收货
     */
    private void showPayPasswordDialog() {
        mPasswordDialog = new PayPasswordDialog(mContext, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPasswordDialog.hideSoftInput();
                if (mOrderDetail == null || mOrderDetail.getOrder() == null) {
                    return;
                }
                mPresenter.confirmOrder(mOrderDetail.getOrder().getOrderId(), mPasswordDialog.getPassword());
            }
        });
        mPasswordDialog.setDialogAttribute(this, Gravity.BOTTOM);
        mPasswordDialog.show();
    }

    @Override
    public void onGetOrderDetailSuccess(OrderDetailEntity detail) {
        mLayoutRoot.setVisibility(View.VISIBLE);
        mLayoutBottom.setVisibility(View.VISIBLE);
        if (mSlv.isRefreshing()) {
            mSlv.onRefreshComplete();
        }
        mOrderDetail = detail;
        mOrder = mOrderDetail.getOrder();
        mCarts.clear();
        if (detail != null) {
            mCarts.add(OrderDataConvert.orderEntity2CartEntity(detail.getOrder()));
        }
        if (mAdapter == null) {
            mAdapter = new OrderDetailAdapter(mContext, mOrder, mCarts, mPresenter);
            mFlv.setAdapter(mAdapter);
        }
        mAdapter.notifyDataSetChanged();
        setOrderInfo();
    }

    @Override
    public void onGetOrderDetailFailed(int apiErrorCode, String message) {
        if (mSlv.isRefreshing()) {
            mSlv.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void onConfirmOrderSuccess(BaseJsonInfo jsonInfo) {
        LogUtil.mLog().e(jsonInfo.toString());
        if (mPasswordDialog != null && mPasswordDialog.isShowing()) {
            mPasswordDialog.dismiss();
        }
        showToast("收货成功");
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void onConfirmOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onPayOrderSuccess(AliPayEntity entity) {
        String data = entity.getSignData();
        new AlipayManager().pay(this, data, this,
                mOrder == null ? 0 : mOrder.getOrderSum(),
                mOrder == null ? "" : mOrder.getOrderId());
    }

    @Override
    public void onPayOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void getTransOrderSuccess(LogisticsEntity logisticsEntity) {
        InterflowUtil.gotoInterflowActivity(mContext, logisticsEntity);
    }

    @Override
    public void getTransOrderFailure(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onCloseOrderSuccess() {
        showToast(R.string.my_order_colse_success);
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void onCloseOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onAlipaySuccess(double payMoney, String orderId) {
        showToast(R.string.pay_success);
        setResult(RESULT_OK);
        finish();
        toPaySuccess(payMoney, orderId);
    }

    @Override
    public void onAlipayCancel() {
        showToast(R.string.pay_cancel);
    }

    @Override
    public void onAlipayFailed() {
        showToast(R.string.pay_failed);
    }

    @Override
    public void onAlipayConfirming() {
        showToast(R.string.pay_confirming);
    }

    /**
     * 去支付成功页
     */
    private void toPaySuccess(double payMoney, String orderId) {
        PaySuccessEntity paySuccessEntity = new PaySuccessEntity();
        paySuccessEntity.setMoney(payMoney + "");
        paySuccessEntity.setOrderId(orderId);
        Intent intent = new Intent(mContext, OrderPaySuccessActivity.class);
        intent.putExtra("successEntity", paySuccessEntity);
        startActivity(intent);
    }
}
