package com.loonxi.ju53.widgets;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.EditText;

import com.loonxi.ju53.utils.StringUtil;


/**
 * 自定义带删除功能的编辑框
 * @author Administrator
 *
 */
public class DeleteEditText extends EditText implements TextWatcher {

	private Drawable mLeft;
	private Drawable mRight;
	private static int AMEND_LENGTH=5;

	public DeleteEditText(Context context) {
		this(context, null);
	}

	public DeleteEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
		addTextChangedListener(this);
	}

	@Override
	public void setCompoundDrawables(Drawable left, Drawable top,
			Drawable right, Drawable bottom) {
		mLeft = left;
		mRight = right;
		super.setCompoundDrawables(left, top, right, bottom);
	}

	@Override
	protected void onFocusChanged(boolean focused, int direction,
			Rect previouslyFocusedRect) {
		super.onFocusChanged(focused, direction, previouslyFocusedRect);
		if (focused) {
			if (StringUtil.isEmpty(getText().toString())) {
				super.setCompoundDrawables(mLeft, null, null, null);
			} else {
				super.setCompoundDrawables(mLeft, null, mRight, null);
			}
		} else {
			super.setCompoundDrawables(mLeft, null, null, null);
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == 1) {
			if (mRight != null && getCompoundDrawables()[2] != null) {
				Rect rect = mRight.getBounds();
				int i = (int) event.getX();
				if (i > getRight()-getLeft() - rect.width()-AMEND_LENGTH) {
					setText("");
					setFocusable(true);
					setFocusableInTouchMode(true);
					requestFocus();
					event.setAction(MotionEvent.ACTION_CANCEL);
				}
			}
		}
		return super.onTouchEvent(event);
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		mLeft = null;
		mRight = null;
	}

	@Override
	public void onTextChanged(CharSequence s, int paramInt1, int paramInt2,
			int paramInt3) {
		if (StringUtil.isEmpty(getText().toString()) || !hasFocus()) {
			super.setCompoundDrawables(mLeft, null, null, null);
		} else {
			super.setCompoundDrawables(mLeft, null, mRight, null);
		}

	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {

	}

	@Override
	public void afterTextChanged(Editable s) {

	}

}
