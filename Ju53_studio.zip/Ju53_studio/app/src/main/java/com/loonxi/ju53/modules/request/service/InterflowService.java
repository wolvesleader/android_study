package com.loonxi.ju53.modules.request.service;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/2/25.
 */
public interface InterflowService {
    @FormUrlEncoded
    @POST("openapi.html")
    Call<Object> getInterflowDetail(@FieldMap Map<String, Object> map);
}
