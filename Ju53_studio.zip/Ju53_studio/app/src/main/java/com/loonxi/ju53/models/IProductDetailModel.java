package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/11.
 */
public interface IProductDetailModel {
    Call<JsonInfo<ProductDetailEntity>> getBaseInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback);
    Call<JsonInfo<ProductDetailEntity>> getDetailInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback);
    Call<Object> addToCart(Map<String, Object> map, Callback<Object> callback);
    Call<ProductAttributeEntity> getSku(Map<String, Object> map, Callback<ProductAttributeEntity> callback);
    Call<TotalCommentEntity> getComments(Map<String, Object> map, Callback<TotalCommentEntity> callback);
    Call<JsonArrayInfo<BaseProductEntity>> getRecommends(Map<String, Object> map, Callback<JsonArrayInfo<BaseProductEntity>> callback);
    Call<BaseJsonInfo> onSaleToJu(Map<String, Object> map, Callback<BaseJsonInfo> callback);
}
