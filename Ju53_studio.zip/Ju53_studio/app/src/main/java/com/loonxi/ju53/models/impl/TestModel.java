package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.service.TestService;
import com.squareup.okhttp.Response;

import java.util.Map;

import retrofit.Call;

/**
 * Created by XuZue on 2016/5/4 0004.
 */
public class TestModel {

    public Call<Object> testPhp(Map<String, Object> map, Callback<Object> callback){
        Call<Object> call = NewRequest.creatApi(TestService.class).testPhp(map);
        call.enqueue(callback);
        return call;
    }

    public Call<Object> testUser(Map<String, Object> map, Callback<Object> callback){
        Call<Object> call = Request.creatApi(TestService.class).testUser(map);
        call.enqueue(callback);
        return call;
    }
}
