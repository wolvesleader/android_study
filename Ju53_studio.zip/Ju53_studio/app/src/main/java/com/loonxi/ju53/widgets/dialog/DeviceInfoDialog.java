package com.loonxi.ju53.widgets.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.PackageUtil;
import com.loonxi.ju53.utils.SpUtil;

/**
 * 设备信息Dialog
 * Created by Xuzue on 2016/4/7.
 */
public class DeviceInfoDialog extends Dialog {

    private TextView mTvContent;
    private ImageView mIvClose;

    private Context mContext;

    public DeviceInfoDialog(Context context) {
        super(context, R.style.cartdialog_style);
        mContext = context;
        setContentView(R.layout.dialog_device_info);
        setCancelable(true);
        initView();
        initContent();
        setListener();

    }

    private void initView() {
        mIvClose = (ImageView) findViewById(R.id.dialog_device_iv_close);
        mTvContent = (TextView) findViewById(R.id.dialog_device_tv_content);
    }

    private void initContent() {
        if(mContext == null){
            return;
        }
        int width = DisplayUtil.getScreenWidth(mContext);
        int height = DisplayUtil.getScreenHeight(mContext);
        float density = DisplayUtil.getScreenDensity(mContext);
        int dpi = DisplayUtil.getDensityDpi(mContext);
        String versionName = PackageUtil.getVersionName(mContext);
        int versionCode = PackageUtil.getVersionCode(mContext);
        String registrationId = SpUtil.getString(mContext, SpUtil.JPUSH_REGISTRATIONID, "");

        StringBuilder sb = new StringBuilder();
        sb.append("width: " + width).append("\n");
        sb.append("height: " + height).append("\n");
        sb.append("density: " + density).append("\n");
        sb.append("dpi: " + dpi).append("\n");
        sb.append("versionName: " + versionName).append("\n");
        sb.append("versionCode: " + versionCode).append("\n");
        sb.append("registrationId: " + registrationId).append("\n");
        mTvContent.setText(sb.toString());
    }

    private void setListener() {
        mIvClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

}
