package com.loonxi.ju53.fragment;

import android.content.Intent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.utils.StringUtil;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

/**
 * Created by Xuzue on 2016/1/12.
 */
@ContentView(R.layout.fragment_product_detail_pic)
public class ProductDetailPicFragment extends BaseFragment{

    @ViewInject(R.id.fragment_product_detail_pic_webview)
    WebView mWebView;

    private String mDetailPic;


    @Override
    public void initView() {
        mWebView.loadDataWithBaseURL("about:blank", mDetailPic, "text/html", "utf-8", null);
    }

    @Override
    public void initContent() {
        WebSettings settings = mWebView.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        mWebView.setWebViewClient(new MyWebviewClient());
    }

    private class MyWebviewClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if(!StringUtil.isEmpty(url)) {
                Intent intent = new Intent(mContext, CommonWebviewActivity.class);
                intent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, "");
                intent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, url);
                getActivity().startActivity(intent);
            }
            return true;
        }
    }

    @Override
    public void setListener() {

    }

    public void setDetailPic(String detail){
        mDetailPic = detail;
    }

}
