package com.loonxi.ju53.utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Xuze on 2015/9/3.
 */
public class MapUtil {

    public static final String DEFAULT_KEY_VALUE_SEPARATOR = ":";
    public static final String DEFAULT_KEY_VALUE_PAIR_SEPARATOR = ",";

    /**
     * 判断是否为空
     *
     * @param map
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> boolean isEmpty(Map<K, V> map) {
        return (map == null || map.size() == 0);
    }

    /**
     * 添加键值对到map中，key不能为空
     *
     * @param map
     * @param key
     * @param value
     * @return
     */
    public static boolean putMapNotEmptyKey(Map<String, String> map, String key, String value) {
        if (map == null || StringUtil.isEmpty(key)) {
            return false;
        }
        map.put(key, value);
        return true;
    }

    /**
     * 添加键值对到map中，key和value都不能为空
     *
     * @param map
     * @param key
     * @param value
     * @return
     */
    public static boolean putMapNotEmptyKeyAndValue(Map<String, String> map, String key, String value) {
        if (map == null || StringUtil.isEmpty(key) || StringUtil.isEmpty(value)) {
            return false;
        }
        map.put(key, value);
        return true;
    }

    /**
     * 添加键值对到map中，key不能为空，若value为空则设为默认值
     *
     * @param map
     * @param key
     * @param value
     * @param defaultValue
     * @return
     */
    public static boolean putMapNotEmptyKeyAndValue(Map<String, String> map, String key, String value, String defaultValue) {
        if (map == null || StringUtil.isEmpty(key) || StringUtil.isEmpty(value)) {
            return false;
        }
        map.put(key, StringUtil.isEmpty(value) ? defaultValue : value);
        return true;
    }

    /**
     * 添加键值对到map中，key不能为空
     *
     * @param map
     * @param key
     * @param value
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> boolean putMapNotNullKey(Map<K, V> map, K key, V value) {
        if (map == null || key == null) {
            return false;
        }
        map.put(key, value);
        return true;
    }

    /**
     * 添加键值对到map中，key和value都不能为空
     *
     * @param map
     * @param key
     * @param value
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> boolean putMapNotNullKeyAndValue(Map<K, V> map, K key, V value) {
        if (map == null || key == null || value == null) {
            return false;
        }
        map.put(key, value);
        return true;
    }

    /**
     * 通过value获取key
     *
     * @param map
     * @param value
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> K getKeyByValue(Map<K, V> map, V value) {
        if (isEmpty(map) || value == null) {
            return null;
        }
        for (Map.Entry entry : map.entrySet()) {
            if (ObjectUtil.isEquals(entry.getValue(), value)) {
                return (K) entry.getKey();
            }
        }
        return null;
    }

    /**
     * 解析键值对，忽略空格
     *
     * @param source
     * @return
     */
    public static Map<String, String> parseKeyAndValue2Map(String source) {
        return parseKeyAndValue2Map(source, DEFAULT_KEY_VALUE_SEPARATOR, DEFAULT_KEY_VALUE_PAIR_SEPARATOR, true);
    }

    /**
     * 解析键值对
     *
     * @param source
     * @param ignoreSpace
     * @return
     */
    public static Map<String, String> parseKeyAndValue2Map(String source, boolean ignoreSpace) {
        return parseKeyAndValue2Map(source, DEFAULT_KEY_VALUE_SEPARATOR, DEFAULT_KEY_VALUE_PAIR_SEPARATOR, ignoreSpace);
    }

    /**
     * 解析键值对
     * parseKeyAndValueToMap("","","",true)=null
     * parseKeyAndValueToMap(null,"","",true)=null
     * parseKeyAndValueToMap("a:b,:","","",true)={(a,b)}
     * parseKeyAndValueToMap("a:b,:d","","",true)={(a,b)}
     * parseKeyAndValueToMap("a:b,c:d","","",true)={(a,b),(c,d)}
     * parseKeyAndValueToMap("a=b, c = d","=",",",true)={(a,b),(c,d)}
     * parseKeyAndValueToMap("a=b, c = d","=",",",false)={(a, b),( c , d)}
     * parseKeyAndValueToMap("a=b, c=d","=", ",", false)={(a,b),( c,d)}
     * parseKeyAndValueToMap("a=b; c=d","=", ";", false)={(a,b),( c,d)}
     * parseKeyAndValueToMap("a=b, c=d", ",", ";", false)={(a=b, c=d)}
     *
     * @param source
     * @param keyValueSeparator
     * @param keyValuePairSeparator
     * @param ignoreSpace
     * @return
     */
    public static Map<String, String> parseKeyAndValue2Map(String source, String keyValueSeparator,
                                                           String keyValuePairSeparator, boolean ignoreSpace) {
        if (StringUtil.isEmpty(source)) {
            return null;
        }
        if (StringUtil.isEmpty(keyValueSeparator)) {
            keyValueSeparator = DEFAULT_KEY_VALUE_SEPARATOR;
        }
        if (StringUtil.isEmpty(keyValuePairSeparator)) {
            keyValuePairSeparator = DEFAULT_KEY_VALUE_PAIR_SEPARATOR;
        }
        String[] separatorArray = source.split(keyValuePairSeparator);
        if (ArrayUtil.isEmpty(separatorArray)) {
            return null;
        }
        int separator = -1;
        Map<String, String> map = new HashMap<String, String>();
        for (String valueEntity : separatorArray) {
            if (!StringUtil.isEmpty(valueEntity)) {
                separator = valueEntity.indexOf(keyValueSeparator);
                if (separator != -1) {
                    if (ignoreSpace) {
                        putMapNotEmptyKey(map, valueEntity.substring(0, separator).trim(),
                                valueEntity.substring(separator).trim());
                    } else {
                        putMapNotEmptyKey(map, valueEntity.substring(0, separator),
                                valueEntity.substring(separator));
                    }
                }
            }
        }
        return map;
    }

    /**
     * 将Map转换成url格式的请求串
     * @param map
     * @return 例如：service=1&mobile=12345678910&version=1.0
     */
    public static String toUrlString(Map<String, Object> map){
        if(isEmpty(map)){
            return null;
        }
        StringBuffer sb = new StringBuffer();
        for(Map.Entry entry : map.entrySet()){
            if(!StringUtil.isEmpty((String)entry.getKey())){
                sb.append("&").append(entry.getKey().toString()).append("=").append(entry.getValue());
            }
        }
        if(sb.length() > 0){
            sb = sb.deleteCharAt(0);
            return sb.toString();
        }
        return null;
    }

    /**
     * 将Map转换成Json
     *
     * @param map
     * @return
     */
    public static String map2Json(Map<String, String> map) {
        if (isEmpty(map)) {
            return null;
        }
        StringBuffer sb = new StringBuffer();
        for (Map.Entry entry : map.entrySet()) {
            if (!StringUtil.isEmpty((String) entry.getKey())) {
                sb.append(",\"").append(entry.getKey().toString())
                        .append("\":\"").append(entry.getValue()).append("\"");
            }
        }
        if (sb.length() > 0) {
            sb = sb.deleteCharAt(0);
            return "{" + sb.toString() + "}";
        }
        return null;
    }

    /**
     * json串转为Map
     * @param json
     * @return
     */
    public static Map<String, String> json2Map(String json){
        Map<String, String> map = new HashMap<>();
        if(StringUtil.isEmpty(json)){
            return map;
        }
        try {
            JSONObject object = new JSONObject(json);
            Iterator it = object.keys();
            while (it.hasNext()){
                String key = String.valueOf(it.next());
                String value = (String) object.get(key);
                map.put(key, value);
            }
            return map;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return map;
    }


    /**
     * 生成有序Map，按key进行升序排列
     */
    public Map<String, String> createOrderMapByKeyAsc(){
        return new TreeMap<>();
    }

    /**
     * 生成有序Map，按key进行降序排列
     */
    public Map<String, String> createOrderMapByKeyDesc(){
        Map<String, String> map = new TreeMap<>(new Comparator<String>() {

            @Override
            public int compare(String lhs, String rhs) {
                return rhs.compareTo(lhs);
            }
        });
        return map;
    }

    /**
     * 将Map按value升序排列
     * @param map
     */
    public void sortMapByValueAsc(Map<String, String> map){
        if(isEmpty(map)){
            return;
        }
        List<Map.Entry<String, String>> list = new ArrayList<Map.Entry<String, String>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
            @Override
            public int compare(Map.Entry<String, String> lhs, Map.Entry<String, String> rhs) {
                return lhs.getValue().compareTo(rhs.getValue());
            }
        });
    }

    /**
     * 将Map按value降序排列
     * @param map
     */
    public void sortMapByValueDesc(Map<String, String> map){
        if(isEmpty(map)){
            return;
        }
        List<Map.Entry<String, String>> list = new ArrayList<Map.Entry<String, String>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
            @Override
            public int compare(Map.Entry<String, String> lhs, Map.Entry<String, String> rhs) {
                return rhs.getValue().compareTo(lhs.getValue());
            }
        });
    }


    /**
     * url参数转换成map
     * @param param
     * @return
     */
    public static Map<String, Object> getUrlParams(String param) {
        Map<String, Object> map = new HashMap<String, Object>(0);
        if (StringUtil.isEmpty(param)) {
            return map;
        }
        String[] params = param.split("&");
        if(params == null){
            return map;
        }
        for (int i = 0; i < params.length; i++) {
            String[] p = params[i].split("=");
            if (p.length == 2) {
                map.put(p[0], p[1]);
            }
        }
        return map;
    }
    /**
     * 支付宝支付的url参数转换成map
     * @param param
     * @return
     */
    public static Map<String, Object> getAlipayUrlParams(String param) {
        Map<String, Object> map = new HashMap<String, Object>(0);
        if (StringUtil.isEmpty(param)) {
            return map;
        }
        String[] params = param.split("&");
        if(params == null){
            return map;
        }
        for (int i = 0; i < params.length; i++) {
            String[] p = params[i].split("=");
            if (p.length == 2) {
                if("sign".equals(p[0])){
                    try {
                        p[1] = URLEncoder.encode(p[1], "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
                map.put(p[0], p[1]);
            }
        }
        return map;
    }

    /**
     * 将map转换成url
     * @param map
     * @return
     */
    public static String getUrlParamsByMap(Map<String, Object> map) {
        if (map == null) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            sb.append(entry.getKey() + "=" + entry.getValue());
            sb.append("&");
        }
        if(sb.length() > 0){
            sb = sb.deleteCharAt(sb.length() - 1);
        }
        String s = sb.toString();
        return s;
    }

}