package com.loonxi.ju53.views;

import android.view.View;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.StoreProductExtraEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

/**
 * Created by Xuzue on 2016/1/11.
 */
public interface IStoreProductDetailView extends IBaseView{
    void onGetBaseInfoSuccess(JsonInfo<ProductDetailEntity> jsonInfo);
    void onGetBaseInfoFailed(int apiErrorCode, String message);
    void onGetDetailSuccess(JsonInfo<ProductDetailEntity> jsonInfo);
    void onGetDetailFailed(int apiErrorCode, String message);
    void offSaleSuccess();
    void offSaleFailed(int apiErrorCode, String message);
    void onSaleSuccess();
    void onSaleFailed(int apiErrorCode, String message);
    void getExtraInfoSuccess(StoreProductExtraEntity extra);
    void getExtraInfoFailed(int apiErrorCode, String message);
}
