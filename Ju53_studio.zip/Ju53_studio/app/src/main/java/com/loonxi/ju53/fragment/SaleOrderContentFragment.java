package com.loonxi.ju53.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MyOrderActivity;
import com.loonxi.ju53.adapter.SaleOrderAdapter;
import com.loonxi.ju53.adapter.SaleOrderChildAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.convert.SaleOrderDataConvert;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.entity.SaleOrderUnitEntity;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.presenters.SaleOrderPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.views.ISaleOrderView;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * 分销订单Fragment
 * Created by Administrator on 2016/1/19.
 */
@ContentView(R.layout.include_sale_order_viewpager)
public class SaleOrderContentFragment extends BaseSafeFragment<ISaleOrderView, SaleOrderPresenter> implements ISaleOrderView, FragmentLifeCircle {

    @ViewInject(R.id.include_sale_order_viewpager_ptr)
    private PullToRefreshListView mPlv;

    private ListView mListView;

    public static final String ARG_PAGE = "page_num";
    private Context mContext;
    private List<SaleOrderEntity> mOrders = new ArrayList<>();
    private SaleOrderAdapter mAdapter;

    private int mCurrentNum;
    private int mCurrentPage = 1;
    private boolean mIsFirstIn = true;//第一次进分销订单列表

    public static SaleOrderContentFragment createContentFragment(int value) {
        SaleOrderContentFragment myOrderContentFragment = new SaleOrderContentFragment();
        WeakReference<SaleOrderContentFragment> refContentFragment = new WeakReference<SaleOrderContentFragment>(myOrderContentFragment);
        Bundle arg = new Bundle();
        arg.putInt(ARG_PAGE, value);
        myOrderContentFragment.setArguments(arg);
        return refContentFragment.get();
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentNum = getArguments().getInt(ARG_PAGE);
        mContext = this.getContext();
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void initView() {
        mListView = mPlv.getRefreshableView();
        mListView.setEmptyView(getEmptyView(R.string.empty_order, AppConst.Empty.ORDER));
        mPlv.setVisibility(View.INVISIBLE);
    }


    @Override
    public void initContent() {
        mAdapter = new SaleOrderAdapter(mContext, mOrders);
        mListView.setAdapter(mAdapter);
        if (mCurrentNum == MyOrderActivity.DEFAULT_DISPLAY_FRAGMENT && mIsFirstIn) {
            LogUtil.mLog().i("initContent");
            mIsFirstIn = false;
            getOrder(mCurrentNum);
        }
    }

    @Override
    public void setListener() {
        mPlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData(true);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                mPresenter.getOrders(mCurrentNum, mCurrentPage, false);
            }
        });
    }

    /**
     * 获取分销订单
     *
     * @param position
     */

    public void getOrder(int position) {
//        LogUtil.mLog().i("currentNum: " + mCurrentNum);
        clearList();
        if (mPresenter != null) {
            if (mPlv != null) {
                mPlv.setVisibility(View.INVISIBLE);
            }
            LogUtil.mLog.e("分销" + position);
        } else {
            mPresenter = createPresenter(SaleOrderContentFragment.this);
            LogUtil.mLog.e("//分销" + position);
        }
        mPresenter.getOrders(position, mCurrentPage, false);
    }

    /**
     * 清除屏幕数据
     */
    private void clearList() {
        mCurrentPage = 1;
        if (mOrders != null) {
            mOrders.clear();
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected SaleOrderPresenter createPresenter(ISaleOrderView iSaleOrderView) {
        return new SaleOrderPresenter(this);
    }

    @Override
    public void onGetOrdersSuccess(JsonArrayInfo<SaleOrderEntity> jsonArrayInfo) {
        if (mPlv != null) {
            mPlv.setVisibility(View.VISIBLE);
            if (mPlv.isRefreshing()) {
                mPlv.onRefreshComplete();
            }
        }
//        LogUtil.mLog().i("page: " + mCurrentPage);
        if (mCurrentPage == 1) {
            mOrders.clear();
        }
        if (jsonArrayInfo != null && !ListUtil.isEmpty(jsonArrayInfo.getData())) {
            mOrders.addAll(jsonArrayInfo.getData());
            mCurrentPage++;
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onGetOrdersFailed(int apiErrorCode, String message) {
        if (mPlv != null) {
            if (mPlv.isRefreshing()) {
                mPlv.onRefreshComplete();
            }
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
//        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void fragmentPause() {
        //TODO 取消网络请求
    }

    @Override
    public void fragmentResume(int position) {
        LogUtil.mLog().i("fragmentResume");
        if(position == mCurrentNum) {
            getOrder(position);
        }
    }

    /**
     * 重新获取订单数据
     *
     * @param showDialog
     */
    private void initData(boolean showDialog) {
        mCurrentPage = 1;
        mPresenter.getOrders(mCurrentNum, mCurrentPage, showDialog);
    }
}
