package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * 总体评价实体
 * Created by Xuzue on 2016/2/23.
 */
public class TotalCommentEntity extends JsonArrayInfo<ProductCommentEntity> implements Parcelable{
    /**
     * 评论数（下划线连接）
     */
    private String num;

    public TotalCommentEntity(){

    }

    protected TotalCommentEntity(Parcel in) {
        num = in.readString();
    }

    public static final Creator<TotalCommentEntity> CREATOR = new Creator<TotalCommentEntity>() {
        @Override
        public TotalCommentEntity createFromParcel(Parcel in) {
            return new TotalCommentEntity(in);
        }

        @Override
        public TotalCommentEntity[] newArray(int size) {
            return new TotalCommentEntity[size];
        }
    };

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(num);
    }
}
