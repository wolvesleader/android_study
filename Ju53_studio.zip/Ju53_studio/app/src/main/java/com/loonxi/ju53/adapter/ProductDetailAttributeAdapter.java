package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Xuzue on 2016/1/12.
 */
public class ProductDetailAttributeAdapter extends BaseObjectListAdapter<Map<String, String>> {

    public ProductDetailAttributeAdapter(Context context, List<Map<String, String>> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if(convertView == null){
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_product_detail_attribute, null);
            holder.mTvKey = (TextView) convertView.findViewById(R.id.listitem_product_detail_attribute_tv_key);
            holder.mTvValue = (TextView) convertView.findViewById(R.id.listitem_product_detail_attribute_tv_value);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }

        Map<String, String> map = get(position);
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        for(Map.Entry<String, String> entry : entrySet){
            holder.mTvKey.setText(entry.getKey());
            holder.mTvValue.setText(StringUtil.unicode2string(entry.getValue()));
        }
        return convertView;
    }

    class ViewHolder{
        TextView mTvKey;
        TextView mTvValue;
    }

}
