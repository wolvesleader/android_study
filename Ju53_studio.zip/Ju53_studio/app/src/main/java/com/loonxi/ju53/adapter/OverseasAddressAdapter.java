package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.entity.AddressEntity;

import java.util.List;

/**
 * 国外地址 adpater
 * Created by laojiaqi on 2016/1/28.
 */
public class OverseasAddressAdapter extends BaseAdapter {


    Context mContext;
    List<AddressEntity> mDataList;

    public OverseasAddressAdapter(Context context, List<AddressEntity> list) {
        this.mContext = context;
        this.mDataList = list;

    }

    @Override
    public int getCount() {
        return mDataList == null ? 0 : mDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        if(convertView==null){
            convertView=View.inflate(mContext, R.layout.listitem_overseas_address,null);
            viewHolder=new ViewHolder();
            viewHolder.name=(TextView)convertView.findViewById(R.id.overseas_address_item_name);
            viewHolder.phone=(TextView)convertView.findViewById(R.id.overseas_address_item_phone);
            viewHolder.street=(TextView)convertView.findViewById(R.id.overseas_address_item_street);
            viewHolder.apartment=(TextView)convertView.findViewById(R.id.overseas_address_item_apartment);
            viewHolder.city_province=(TextView)convertView.findViewById(R.id.overseas_address_item_city_province);
            viewHolder.country=(TextView)convertView.findViewById(R.id.overseas_address_item_country);
            viewHolder.select=(ImageView)convertView.findViewById(R.id.overseas_address_item_select);
            convertView.setTag(viewHolder);
        }else {
            viewHolder=(ViewHolder)convertView.getTag();
        }
        AddressEntity addressEntity=mDataList.get(position);
        //TODO 国内
        int isDefault=addressEntity.getIsDefault();
        if(isDefault==DomesticAddressAdapter.DEFAULT_FLAG){
            String deafultAddressPre=mContext.getResources().getString(R.string.address_default_tag);
            viewHolder.name.setText(deafultAddressPre+addressEntity.getContact());
            viewHolder.select.setVisibility(View.VISIBLE);
        }else{
            viewHolder.name.setText(addressEntity.getContact());
            viewHolder.select.setVisibility(View.GONE);
        }
        viewHolder.phone.setText(addressEntity.getPhones());
        viewHolder.street.setText(addressEntity.getStreetAddress());
        viewHolder.apartment.setText(addressEntity.getUnit());
        viewHolder.city_province.setText(addressEntity.getCity()+","+addressEntity.getProvinceArea());
        viewHolder.country.setText(addressEntity.getAddress());
        viewHolder.phone.setText(addressEntity.getPhones());

        return convertView;
    }

    class ViewHolder
    {
        TextView name;//名字
        TextView street;//街道
        TextView apartment;//详细住址
        TextView city_province;//城市和省份
        TextView country;//国家
        TextView phone;//电话
        ImageView select;//是否select
    }
}
