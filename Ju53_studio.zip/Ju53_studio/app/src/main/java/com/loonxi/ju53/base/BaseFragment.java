package com.loonxi.ju53.base;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.LoginActivity;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.widgets.dialog.LoadingDialog;
import com.umeng.analytics.MobclickAgent;

import org.xutils.DbManager;
import org.xutils.x;


/**
 * Fragment基类
 * Created by Xuzue on 2015/12/17.
 */
public abstract class BaseFragment extends Fragment {
    protected Activity mActivity;
    protected Context mContext;
    protected DbManager mDbManager;
    protected LayoutInflater mInflater;
    protected boolean mDebug = false;
    protected BaseApplication mApplication;
    protected LoadingDialog mLoadingDialog;
    protected LoadingDialog mDimedLoadingDialog;
    protected boolean mInjected = false;

    protected View mEmptyView;
    protected View mNetErrorView;
    protected OnNetWorkListener mNetWorkListener;

    public abstract void initView();

    public abstract void initContent();

    public abstract void setListener();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        MobclickAgent.openActivityDurationTrack(false);//禁止默认的页面统计方式，这样不会再统计相应的Activity
        mActivity = (Activity) context;
        mContext = context;
        mDbManager = BaseApplication.getDbManager();
        mInflater = LayoutInflater.from(mContext);
        mApplication = BaseApplication.instance;
        mLoadingDialog = new LoadingDialog(mContext);
        mDimedLoadingDialog = new LoadingDialog(mContext, true);
        BaseApplication.refWatcher.watch(this);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActivity = null;
        mContext = null;
        mApplication = null;
        mLoadingDialog = null;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mInjected = true;
        return x.view().inject(this, inflater, container);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (!mInjected) {
            x.view().inject(this, this.getView());
        }
        mEmptyView = LayoutInflater.from(mContext).inflate(R.layout.empty_list, null);
        mNetErrorView = LayoutInflater.from(mContext).inflate(R.layout.empty_net, null);
        initView();
        initContent();
        setListener();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public void showLoadingDialog() {
        showLoadingDialog(null, null);
    }

    public void showLoadingDialog(String content) {
        showLoadingDialog(null, content);
    }

    /**
     * 显示LoadingDialog
     *
     * @param listener
     */
    public void showLoadingDialog(DialogInterface.OnDismissListener listener, String content) {
        if (mLoadingDialog == null) {
            mLoadingDialog = new LoadingDialog(BaseApplication.instance);
        }
        if (listener != null) {
            mLoadingDialog.setOnDismissListener(listener);
        } else {
            mLoadingDialog.setOnDismissListener(null);
        }
        if (!StringUtil.isEmpty(content)) {
            mLoadingDialog.setContent(content);
        }
        mLoadingDialog.show();
    }

    /**
     * 隐藏LoadingDialog
     */
    public void dismissLoadingDialog() {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }


    public void showDimedLoadingDialog() {
        if (mDimedLoadingDialog != null) {
            mDimedLoadingDialog.show();
        }
    }

    public void dismissDimedLoadingDialog() {
        if (mDimedLoadingDialog != null && mDimedLoadingDialog.isShowing()) {
            mDimedLoadingDialog.dismiss();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onResume(mContext);
        MobclickAgent.onPageStart(getClass().getSimpleName());
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPause(mContext);
        MobclickAgent.onPageEnd(getClass().getSimpleName());
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void showToast(String text) {
        ToastUtil.showToast(mContext, text);
    }

    public void showToast(int resId) {
        ToastUtil.showToast(mContext, resId);
    }

    /**
     * 获取EmptyView
     *
     * @param resId
     * @param sourceId
     * @return
     */
    public View getEmptyView(int resId, int sourceId) {
        return getEmptyView(resId, sourceId, true);
    }

    /**
     * 获取EmptyView
     *
     * @param resId
     * @param sourceId
     * @param btnIsVisibile
     * @return
     */
    public View getEmptyView(int resId, final int sourceId, boolean btnIsVisibile) {
        if (mEmptyView == null) {
            mEmptyView = LayoutInflater.from(mContext).inflate(R.layout.empty_list, null);
        }
        TextView mTvTip = (TextView) mEmptyView.findViewById(R.id.empty_list_tv_tip);
        TextView mBtnGo = (TextView) mEmptyView.findViewById(R.id.empty_list_btn_go);
        mTvTip.setText(getResources().getString(resId));
        mBtnGo.setVisibility(btnIsVisibile ? View.VISIBLE : View.GONE);
        mBtnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoMainActivity(MainActivity.RESET_POPWINDOW);
            }
        });
        return mEmptyView;
    }


    /**
     * 跳转到主页
     */
    public void gotoMainActivity(String flag) {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, flag);
        mContext.startActivity(intent);
    }

    /**
     * 设置网络未连接的View
     *
     * @param hideView 需隐藏的View
     * @param showView 网络出错的View
     * @param isError  true:显示网络未连接 false:隐藏网络未连接
     */
    public void setNetErrorView(View hideView, View showView, boolean isError) {
        if (hideView == null || showView == null) {
            return;
        }
        hideView.setVisibility(isError ? View.GONE : View.VISIBLE);
        showView.setVisibility(isError ? View.VISIBLE : View.GONE);
        if (showView instanceof ViewStub && mActivity != null) {
            ViewStub mStub = (ViewStub) showView;
            View stubView = mActivity.findViewById(mStub.getInflatedId());
            if (stubView != null) {
                LogUtil.mLog().i("stub find");
                stubView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mNetWorkListener != null) {
                            mNetWorkListener.OnRetry();
                        }
                    }
                });
            }
        }
    }

    /**
     * 错误检查（无视图替换）
     *
     * @param apiErrorCode
     * @param strId
     */
    public void checkError(int apiErrorCode, int strId) {
        checkError(apiErrorCode, getString(strId));
    }

    /**
     * 错误检查（无视图替换）
     *
     * @param apiErrorCode
     * @param message
     */
    public void checkError(int apiErrorCode, String message) {
        checkError(apiErrorCode, message, null, null);
    }

    /**
     * 错误检查有视图替换
     *
     * @param apiErrorCode
     * @param strId
     * @param hideView     替换视图
     */
    public void checkError(int apiErrorCode, int strId, View hideView, View showView) {
        checkError(apiErrorCode, getResources() == null ? "" : getResources().getString(strId), hideView, showView);
    }

    /**
     * 错误检查（有视图替换）
     *
     * @param apiErrorCode
     * @param message
     * @param hideView     替换视图
     */
    protected void checkError(int apiErrorCode, String message, View hideView, View showView) {
        LogUtil.mLog().i(apiErrorCode);
        switch (apiErrorCode) {
            case ApiError.REQUEST_FAILURE:
                if (hideView != null && showView != null && mNetWorkListener != null) {
                    setNetErrorView(hideView, showView, true);
                } else {
                    showToast(R.string.error_disconnect);
                }
                break;
            case ApiError.TIMEOUT:
                showToast(R.string.error_timeout);
                break;
            case ApiError.REQUEST_FAILURE_OFFLINE:
                startActivity(new Intent(mContext, LoginActivity.class));
                break;
            default:
                if(!StringUtil.isEmpty(message)){
                    showToast(message);
                }
                break;

        }
    }

    protected void setOnNetWorkListener(OnNetWorkListener listener) {
        mNetWorkListener = listener;
    }

    public void onNetWorkConnected(){
    }
}
