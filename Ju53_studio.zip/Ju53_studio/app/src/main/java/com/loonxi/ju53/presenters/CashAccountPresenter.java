package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.CashCardEntity;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.models.IFinanceModel;
import com.loonxi.ju53.models.impl.FinanceModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ICashAccountView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashAccountPresenter extends BasePresenter<ICashAccountView> {

    private ICashAccountView mView;
    private IFinanceModel mModel;

    public CashAccountPresenter(ICashAccountView view) {
        super(view);
        mView = getView();
        mModel = new FinanceModel();
    }

    /**
     * 获得提现账户
     */
    public void getCashCount() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.getCashAccount(map, new Callback<JsonArrayInfo<CashCardEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<CashCardEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<CashCardEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.getCashAccountSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.getCashAccountFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 解绑提现账户
     */
    public void unbandCashCount(String pid) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", pid);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.unbandCashAccount(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.unbandAccountSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.unbandAccountFailed(apiErrorCode, message);
                }
            }
        });
    }

}
