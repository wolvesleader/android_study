package com.loonxi.ju53.presenters;

import android.text.TextUtils;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.MessageArrayEntity;
import com.loonxi.ju53.entity.MessageEntity;
import com.loonxi.ju53.models.impl.MessageModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.views.IMessageView;

import retrofit.Retrofit;

/**
 * “消息”presenter
 * Created by laojiaqi on 2016/2/2.
 */
public class MessagePresenter extends BasePresenter<IMessageView> {

    private IMessageView mView;
    private MessageModel mModel;

    public MessagePresenter(IMessageView view) {
        super(view);
        mView = getView();
        mModel = new MessageModel();
    }

    /**
     * 获得信息
     */
    public void getMessage() {
        mModel.getMessage(new Callback<MessageArrayEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, MessageArrayEntity data) {

            }

            @Override
            public void onSuccess(MessageArrayEntity data, Retrofit retrofit) {
                mView.getMessageSuccess(data == null ? null : data.getMessageList());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.getMessageFailure(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 设置已读标记
     *
     * @param messageEntity
     */
    public void setReadFlag(MessageEntity messageEntity) {
        if (messageEntity == null) {
            return;
        }
        mModel.setReadFlag(new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {

            }

            @Override
            public void onFailed(int apiErrorCode, String message) {

            }
        }, messageEntity.getPid());

    }

    /**
     * 获得物流单号
     *
     * @param messageEntity
     */
    public void getOrderTrans(MessageEntity messageEntity) {
        if (messageEntity == null || TextUtils.isEmpty(messageEntity.getJointId())) {
            return;
        }
        mModel.getLogistics(messageEntity.getJointId(), new Callback<JsonInfo<LogisticsEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<LogisticsEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<LogisticsEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.getTransOrderSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.getTransOrderFailure(apiErrorCode, message);
                }
            }
        });
    }
}
