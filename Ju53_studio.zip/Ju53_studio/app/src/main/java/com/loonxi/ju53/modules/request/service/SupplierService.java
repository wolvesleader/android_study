package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/2/18.
 */
public interface SupplierService {
    /**
     * 获取供应商信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("supplier/display")
    Call<JsonInfo<SupplierEntity>> getSupplierInfo(@FieldMap Map<String, Object> map);
}
