package com.loonxi.ju53.utils;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.entity.FlowLayoutItem;
import com.loonxi.ju53.widgets.FlowLinearLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/3/2.
 */
public class FlowLayoutUtil {

    public static int DEFAULT_POSITION = -1;
    public static String DEFAULT_NAME = "";

    public static int SELECTED_DRAWABLE = R.drawable.btn_red;
    public static int UNSELECTED_DRAWABLE = R.drawable.btn_gray;
    public static int LACK_GOODS_DRAWABLE = R.drawable.background_red40;

    public static int UNSELECTED_TEXT_COLOR = R.color.black;
    public static int SELECTED_TEXT_COLOR = R.color.white;

    private static List<String> mLabels = new ArrayList<>();

    /**
     * 初始化标签文字内容
     */
    private static void setLableData(List<String> labels) {
        mLabels.clear();
        if (ListUtil.isEmpty(labels)) {
            return;
        }
        mLabels.addAll(labels);
    }

    /**
     * 生成标签页
     *
     * @param context
     * @param labels
     * @param mLayoutLable
     * @param mLableClickListener
     */
    public static void generateLable(Context context, List<String> labels, FlowLinearLayout mLayoutLable, View.OnClickListener mLableClickListener) {
        generateLable(context, labels, mLayoutLable, mLableClickListener, 20, 2, false);
    }

    public static void generateLable(Context context, List<String> labels, FlowLinearLayout mLayoutLable, View.OnClickListener mLableClickListener, boolean checkFirst) {
        generateLable(context, labels, mLayoutLable, mLableClickListener, 20, 2, checkFirst);
    }

    public static void generateLable(Context context, List<String> labels, FlowLinearLayout mLayoutLable, View.OnClickListener mLableClickListener, int right, int bottom) {
        generateLable(context, labels, mLayoutLable, mLableClickListener, right, bottom, false);
    }

    /**
     * 生成标签页
     *
     * @param context
     * @param labels
     * @param mLayoutLable
     * @param mLableClickListener
     * @param right               标签之间right间距
     * @param bottom              标签之间bottom间距
     * @param checkFirst          是否选中第一个
     */
    public static void generateLable(Context context, List<String> labels, FlowLinearLayout mLayoutLable, View.OnClickListener mLableClickListener,
                                     int right, int bottom, boolean checkFirst) {
        setLableData(labels);
        if (mLayoutLable != null && mLayoutLable.getChildCount() > 0) {
            mLayoutLable.removeAllViews();
        }
        for (int i = 0; i < mLabels.size(); i++) {
            TextView tv = addTextView(context, mLabels.get(i), checkFirst && i == 0 ? true : false, right, bottom);
            tv.setOnClickListener(mLableClickListener);
            addInfoToView(mLabels.get(i), tv, mLayoutLable);
            mLayoutLable.addView(tv);
        }
    }


    /**
     * 复原item未点击状态
     *
     * @param viewGroup
     * @param position
     */
    public static void resetView(Context mContext, ViewGroup viewGroup, int position) {
        if (viewGroup == null || position <= DEFAULT_POSITION || position > viewGroup.getChildCount() - 1) {
            return;
        }
        TextView child = (TextView) viewGroup.getChildAt(position);
        if (child != null) {
            child.setBackgroundResource(UNSELECTED_DRAWABLE);
            child.setTextColor(mContext.getResources().getColor(UNSELECTED_TEXT_COLOR));
        }
    }

    /**
     * 设置item点击状态
     *
     * @param viewGroup
     * @param position
     */
    public static void setView(Context mContext, ViewGroup viewGroup, int position) {
        if (viewGroup == null || position <= DEFAULT_POSITION || position > viewGroup.getChildCount() - 1) {
            return;
        }
        TextView child = (TextView) viewGroup.getChildAt(position);
        if (child != null) {
            child.setBackgroundResource(SELECTED_DRAWABLE);
            child.setTextColor(mContext.getResources().getColor(SELECTED_TEXT_COLOR));
        }
    }

    /**
     * 为每个item添加信息
     *
     * @param value
     * @param textView
     * @param viewGroup
     */
    public static void addInfoToView(String value, TextView textView, ViewGroup viewGroup) {
        FlowLayoutItem itemInfor = new FlowLayoutItem();
        itemInfor.setName(value);
        itemInfor.setPosition(viewGroup.getChildCount());
        textView.setTag(itemInfor);
    }

    public static TextView addTextView(Context mContext, String text) {
        return addTextView(mContext, text, false);
    }

    public static TextView addTextView(Context mContext, String text, boolean isChecked) {
        return addTextView(mContext, text, isChecked, 20, 2);
    }

    public static TextView addTextView(Context mContext, String text, boolean isChecked, int right, int bottom) {
        ViewGroup.MarginLayoutParams lp = new ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(2, 2, right, bottom);
        TextView textView = new TextView(mContext);
        textView.setBackgroundResource(isChecked ? SELECTED_DRAWABLE : UNSELECTED_DRAWABLE);
        textView.setTextColor(mContext.getResources().getColor(isChecked ? SELECTED_TEXT_COLOR : UNSELECTED_TEXT_COLOR));
        if (text != null && text.length() >= 2) {
            textView.setPadding(20, 1, 20, 1);
        } else {
            textView.setPadding(1, 1, 1, 1);
        }
        textView.setGravity(Gravity.CENTER);
        textView.setText(text);
        textView.setLayoutParams(lp);
        textView.setTag(text);
        return textView;
    }
}
