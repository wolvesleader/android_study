package com.loonxi.ju53.activity.register;

import android.content.Context;
import android.content.DialogInterface;
import android.view.View;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.RegisterActivity;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.utils.NetUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.widgets.dialog.LoadingDialog;

/**
 * Created by Xuzue on 2016/1/4.
 */
public abstract class RegisterStep {
    protected BaseApplication mApplication;
    protected RegisterActivity mActivity;
    protected LoadingDialog mLoadingDialog;

    protected Context mContext;
    protected View mContentRootView;
    protected onNextActionListener mOnNextActionListener;
    protected boolean mIsChange = true;

    protected String mPhone;
    protected String mCode;
    protected String mAccount;
    protected String mPassword;


    public RegisterStep(RegisterActivity activity, Context context, View contentView) {
        mApplication = BaseApplication.getInstance();
        mActivity = activity;
        mContext = context;
        mContentRootView = contentView;
        mLoadingDialog = new LoadingDialog(mContext);
        initViews();
        initEvents();
        initContent();
    }


    public abstract void initViews();

    public abstract void initEvents();

    public abstract void initContent();

    /**
     * 修改后初始化
     */
    public abstract void afterChangeInit();

    public View findViewById(int id) {
        return mContentRootView.findViewById(id);
    }

    public String getMobile() {
        return mPhone;
    }

    public void setMobile(String mMobile) {
        this.mPhone = mMobile;
    }

    public String getCode() {
        return mCode;
    }

    public void setCode(String mCode) {
        this.mCode = mCode;
    }

    public String getAccount() {
        return mAccount;
    }

    public void setAccount(String mAccount) {
        this.mAccount = mAccount;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String mPassword) {
        this.mPassword = mPassword;
    }

    public void setOnNextActionListener(onNextActionListener listener) {
        mOnNextActionListener = listener;
    }

    public interface onNextActionListener {
        void next(boolean isChange);
    }

    public void checkError(int apiErrorCode, int strId) {
        checkError(apiErrorCode, mContext.getResources().getString(strId));
    }

    protected void checkError(int apiErrorCode, String message) {
        switch (apiErrorCode) {
            case ApiError.REQUEST_FAILURE:
                if (NetUtil.isConnected(mContext)) {
                    ToastUtil.showToast(mContext, R.string.error_timeout);
                } else {
                    ToastUtil.showToast(mContext, R.string.error_disconnect);
                }
                break;
            default:
                ToastUtil.showToast(mContext, message);
                break;

        }
    }

    public void showLoadingDialog() {
        if (mLoadingDialog != null && !mLoadingDialog.isShowing()) {
            mLoadingDialog.show();
        }
    }

    /**
     * 隐藏LoadingDialog
     */
    public void dismissLoadingDialog() {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }
}
