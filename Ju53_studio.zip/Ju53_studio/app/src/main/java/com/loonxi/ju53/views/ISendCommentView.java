package com.loonxi.ju53.views;

/**
 * 发送评论接口
 * Created by laojiaqi on 2016/2/16.
 */
public interface ISendCommentView {
    public void onSendCommentViewSuccess(String string);
    public void onSendCommentViewFailure(String string);
}
