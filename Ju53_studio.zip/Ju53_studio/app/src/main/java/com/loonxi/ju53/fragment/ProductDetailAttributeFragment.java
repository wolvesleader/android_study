package com.loonxi.ju53.fragment;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.ProductDetailAttributeAdapter;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.widgets.FixedListView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Xuzue on 2016/1/12.
 */
@ContentView(R.layout.fragment_product_detail_attribute)
public class ProductDetailAttributeFragment extends BaseFragment {

    @ViewInject(R.id.fragment_product_detail_attribute_flv)
    private FixedListView mFlv;

    private ProductDetailAttributeAdapter mAdapter;
    private List<Map<String, String>> mDatas = new ArrayList<>();

    @Override
    public void initView() {

    }

    @Override
    public void initContent() {
        mAdapter = new ProductDetailAttributeAdapter(mContext, mDatas);
        mFlv.setAdapter(mAdapter);
    }

    @Override
    public void setListener() {

    }

    public void setData(Map<String, String> data){
        mDatas.clear();
        Set<Map.Entry<String, String>> entrySet = data.entrySet();
        for(Map.Entry<String, String> entry : entrySet){
            Map<String, String> map = new HashMap<>();
            map.put(entry.getKey(), entry.getValue());
            mDatas.add(map);
        }
    }
}
