package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.SaleOrderDetailEntity;

/**
 * Created by XuZue on 2016/5/12 0012.
 */
public interface ISaleOrderDetailView extends IBaseView {
    void onGetOrderDetailSuccess(SaleOrderDetailEntity detailEntity);

    void onGetOrderDetailFailed(int apiErrorCode, String message);

}
