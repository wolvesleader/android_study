package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.RegistAuthEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/5.
 */
public interface IRegistModel {
    Call<BaseJsonInfo> getCheckCode(Map<String, Object> map, Callback<BaseJsonInfo> callback);
    Call<BaseJsonInfo> checkCodeIsCorrect(Map<String, Object> map, Callback<BaseJsonInfo> callback);
    Call<RegistAuthEntity> auth(Map<String, Object> map, Callback<RegistAuthEntity> callback);
}
