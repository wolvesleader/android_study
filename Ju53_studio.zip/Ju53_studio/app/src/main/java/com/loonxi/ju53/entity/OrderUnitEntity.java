package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2016/1/18.
 */
public class OrderUnitEntity implements Parcelable {

    private long pid;
    /**
     * 订单id
     */
    private String orderId;
    /**
     * 商品id
     */
    private String productId;
    /**
     * 商品名称
     */
    private String productName;
    /**
     * 库存id
     */
    private long attributeId;
    /**
     * 属性
     */
    private String attribute;
    /**
     * 商品数量
     */
    private String value;
    /**
     * 图片
     */
    private String picture;
    /**
     * 商品价格
     */
    private double price;
    private double attriprice;
    private double realprice;
    /**
     * 商品原价
     */
    private double originalPrice;
    private int moneyCounp;
    private int isCancel;
    private int isBackedFreight;

    /**
     * 退款状态(0-未退款,1-已申请,2-不同意退款,3-同意退款(实际已退款),4-退款结束(确认收货会把退款结束掉）,5.退款修改-1-取消退款　6同意退款实未退7退货退款时的卖家同意退货 8.退货退款时买家退回货物)
     */
    private int isBacked;
    private double backAmount;
    /**
     * 退款id
     */
    private String refundsId;
    private String applybackNum;
    private long createTime;
    private long updateTime;
    private String customName;

    public long getPid() {
        return pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public long getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(long attributeId) {
        this.attributeId = attributeId;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getAttriprice() {
        return attriprice;
    }

    public void setAttriprice(double attriprice) {
        this.attriprice = attriprice;
    }

    public double getRealprice() {
        return realprice;
    }

    public void setRealprice(double realprice) {
        this.realprice = realprice;
    }

    public double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public int getMoneyCounp() {
        return moneyCounp;
    }

    public void setMoneyCounp(int moneyCounp) {
        this.moneyCounp = moneyCounp;
    }

    public int getIsCancel() {
        return isCancel;
    }

    public void setIsCancel(int isCancel) {
        this.isCancel = isCancel;
    }

    public int getIsBackedFreight() {
        return isBackedFreight;
    }

    public void setIsBackedFreight(int isBackedFreight) {
        this.isBackedFreight = isBackedFreight;
    }

    public int getIsBacked() {
        return isBacked;
    }

    public void setIsBacked(int isBacked) {
        this.isBacked = isBacked;
    }

    public double getBackAmount() {
        return backAmount;
    }

    public void setBackAmount(double backAmount) {
        this.backAmount = backAmount;
    }

    public String getRefundsId() {
        return refundsId;
    }

    public void setRefundsId(String refundsId) {
        this.refundsId = refundsId;
    }

    public String getApplybackNum() {
        return applybackNum;
    }

    public void setApplybackNum(String applybackNum) {
        this.applybackNum = applybackNum;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(pid);
        dest.writeString(orderId);
        dest.writeString(productId);
        dest.writeString(productName);
        dest.writeLong(attributeId);
        dest.writeString(attribute);
        dest.writeString(value);
        dest.writeString(picture);
        dest.writeDouble(price);
        dest.writeDouble(attriprice);
        dest.writeDouble(realprice);
        dest.writeDouble(originalPrice);
        dest.writeInt(moneyCounp);
        dest.writeInt(isCancel);
        dest.writeInt(isBackedFreight);
        dest.writeInt(isBacked);
        dest.writeDouble(backAmount);
        dest.writeString(refundsId);
        dest.writeString(applybackNum);
        dest.writeLong(createTime);
        dest.writeLong(updateTime);
        dest.writeString(customName);
    }

    public static final Parcelable.Creator<OrderUnitEntity> CREATOR = new Parcelable.Creator<OrderUnitEntity>(){

        @Override
        public OrderUnitEntity createFromParcel(Parcel source) {
            OrderUnitEntity unit = new OrderUnitEntity();
            unit.setPid(source.readLong());
            unit.setOrderId(source.readString());
            unit.setProductId(source.readString());
            unit.setProductName(source.readString());
            unit.setAttributeId(source.readLong());
            unit.setAttribute(source.readString());
            unit.setValue(source.readString());
            unit.setPicture(source.readString());
            unit.setPrice(source.readDouble());
            unit.setAttriprice(source.readDouble());
            unit.setRealprice(source.readDouble());
            unit.setOriginalPrice(source.readDouble());
            unit.setMoneyCounp(source.readInt());
            unit.setIsCancel(source.readInt());
            unit.setIsBackedFreight(source.readInt());
            unit.setIsBacked(source.readInt());
            unit.setBackAmount(source.readDouble());
            unit.setRefundsId(source.readString());
            unit.setApplybackNum(source.readString());
            unit.setCreateTime(source.readLong());
            unit.setUpdateTime(source.readLong());
            unit.setCustomName(source.readString());
            return unit;
        }

        @Override
        public OrderUnitEntity[] newArray(int size) {
            return new OrderUnitEntity[size];
        }
    };
}
