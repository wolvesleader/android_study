package com.loonxi.ju53.constants;

/**
 * js与Android交互有关常量
 * Created by XuZue on 2016/6/2 0002.
 */
public class JsConst {

    /**
     * 去分销
     */
    public class Commision {
        public static final int LOGIN_OFF = 0;//未登录
        public static final int ONSALE_FAILED = -1;//上架失败
        public static final int ONSALE_SUCCESS = 1;//上架成功
    }

}
