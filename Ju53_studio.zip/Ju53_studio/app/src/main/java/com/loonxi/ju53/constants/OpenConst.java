package com.loonxi.ju53.constants;

/**
 * 集成第三方所需常量
 * Created by Xuzue on 2016/4/5.
 */
public class OpenConst {

    /**
     * 友盟key
     */
    public static final String UMENG_APPKEY = "c2d40c6a779ad805a9b26a69";
}
