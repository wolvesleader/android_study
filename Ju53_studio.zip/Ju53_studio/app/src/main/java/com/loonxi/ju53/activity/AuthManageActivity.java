package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.widgets.ActionBar;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;

import org.xutils.view.annotation.ViewInject;

import java.util.Map;

/**
 * Created by Xuzue on 2016/4/12.
 */
public class AuthManageActivity extends ActionBarActivity implements View.OnClickListener {

    @ViewInject(R.id.auth_btn_sina)
    private TextView mTvSina;
    @ViewInject(R.id.auth_btn_weixin)
    private TextView mTvWeixin;
    @ViewInject(R.id.auth_btn_wxcircle)
    private TextView mTvWXCircle;
    @ViewInject(R.id.auth_btn_qq)
    private TextView mTvQq;
    @ViewInject(R.id.auth_btn_qzone)
    private TextView mTvQzone;

    private UMShareAPI mShareAPI;
    private SHARE_MEDIA mPlatform;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_manage);
    }

    @Override
    public void initView() {
        setTitle("授权管理");
    }

    @Override
    public void initContent() {
        mShareAPI = UMShareAPI.get(this);
        restBtnText(SHARE_MEDIA.SINA);
        restBtnText(SHARE_MEDIA.WEIXIN);
        restBtnText(SHARE_MEDIA.WEIXIN_CIRCLE);
        restBtnText(SHARE_MEDIA.QQ);
        restBtnText(SHARE_MEDIA.QZONE);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mTvSina.setOnClickListener(this);
        mTvWeixin.setOnClickListener(this);
        mTvWXCircle.setOnClickListener(this);
        mTvQq.setOnClickListener(this);
        mTvQzone.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.auth_btn_sina:
                mPlatform = SHARE_MEDIA.SINA;
                authOrDelAuth();
                break;
            case R.id.auth_btn_weixin:
                mPlatform = SHARE_MEDIA.WEIXIN;
                authOrDelAuth();
                break;
            case R.id.auth_btn_wxcircle:
                mPlatform = SHARE_MEDIA.WEIXIN_CIRCLE;
                authOrDelAuth();
                break;
            case R.id.auth_btn_qq:
                mPlatform = SHARE_MEDIA.QQ;
                authOrDelAuth();
                break;
            case R.id.auth_btn_qzone:
                mPlatform = SHARE_MEDIA.QZONE;
                authOrDelAuth();
                break;
        }
    }

    private void restBtnText(final SHARE_MEDIA mPlatform) {
        TextView mTv = null;
        switch (mPlatform) {
            case SINA:
                mTv = mTvSina;
                break;
            case WEIXIN:
                mTv = mTvWeixin;
                break;
            case WEIXIN_CIRCLE:
                mTv = mTvWXCircle;
                break;
            case QQ:
                mTv = mTvQq;
                break;
            case QZONE:
                mTv = mTvQzone;
                break;
        }
        if (mTv == null || mShareAPI == null) {
            return;
        }
        final TextView finalMTv = mTv;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mShareAPI.isAuthorize(AuthManageActivity.this, mPlatform)) {
                    finalMTv.setText("取消授权");
                } else {
                    finalMTv.setText("授权");
                }
            }
        });

    }

    private void authOrDelAuth() {
        if (mShareAPI.isAuthorize(this, mPlatform)) {
            mShareAPI.deleteOauth(this, mPlatform, umAuthListener);
        } else {
            mShareAPI.doOauthVerify(this, mPlatform, umAuthListener);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mShareAPI.onActivityResult(requestCode, resultCode, data);
    }

    private UMAuthListener umAuthListener = new UMAuthListener() {
        @Override
        public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {
            if (mShareAPI.isAuthorize(AuthManageActivity.this, share_media)) {
                showToast(share_media + "授权成功");
            } else {
                showToast(share_media + "取消授权成功");
            }
            restBtnText(share_media);
        }

        @Override
        public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
            if (!mShareAPI.isAuthorize(AuthManageActivity.this, share_media)) {
                showToast(share_media + "授权失败");
            } else {
                showToast(share_media + "取消授权失败");
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA share_media, int i) {
            if (!mShareAPI.isAuthorize(AuthManageActivity.this, share_media)) {
                showToast(share_media + "授权取消");
            } else {
                showToast(share_media + "取消授权取消");
            }
        }
    };
}
