package com.loonxi.ju53.modules.request;

/**
 * 请求结果的异常信息
 * Created by Xuzue on 2015/12/16.
 */
public class ApiError extends Exception {
    private int flag;
    private String message;

    public ApiError(int flag) {
        this.flag = flag;
    }

    public ApiError(String message) {
        super(message);
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }


    @Override
    public String getMessage() {
        return message;
    }


    /**
     * 请求成功
     */
    public static final int REQUEST_SUCCESS = 1;
    /**
     * 请求失败
     */
    public static final int REQUEST_FAILURE = 30000;
    /**
     * 请求失败-未登录
     */
    public static final int REQUEST_FAILURE_OFFLINE = -1;
    /**
     * 请求失败-余额不足
     */
    public static final int REQUEST_FAILURE_LACK_MONEY = 2;
    /**
     * 请求失败-错误信息
     */
    public static final int REQUEST_FAILURE_INCORRECT_INFO = 0;
    /**
     * 请求失败-个人信息不完善
     */
    public static final int REQUEST_FAILURE_LACK_PERSON_INFO = -2;
    /**
     * 网络未连接
     */
    public static final int DISCONNECT = 30001;
    /**
     * 连接超时
     */
    public static final int TIMEOUT = 30002;
    /**
     * HTTP错误
     */
    public static final int HTTP = 30003;
    /**
     * json转换出错
     */
    public static final int CONVERSION = 30004;


    /**
     * 空结果
     */
    public static final int NULL = 10003;
    /**
     * 未知错误
     */
    public static final int UNEXPECTED = 10004;
    /**
     * 接口页面不存在
     */
    public static final int PAGE_NOT_FOUND = 10005;
    /**
     * 连接数据库出错
     */
    public static final int CONNECT_DB_ERROR = 10006;
    /**
     * PHP程序出错
     */
    public static final int PHP_CODE_ERROR = 10007;
    /**
     * 禁止使用GET方式获取数据
     */
    public static final int UNSUPPORT_GET = 10008;
    /**
     * 需要传的参数为空或不存在
     */
    public static final int PARAMETAR_ERROR = 10009;

}
