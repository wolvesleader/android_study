package com.loonxi.ju53.modules.open;


import android.content.Context;

import com.loonxi.ju53.modules.open.beans.OpenUserInfo;
import com.loonxi.ju53.modules.open.beans.QQUserInfo;
import com.loonxi.ju53.modules.open.beans.TqqUserInfo;
import com.loonxi.ju53.modules.open.beans.WechatUserInfo;
import com.loonxi.ju53.modules.open.beans.WeiboUserInfo;


/**
 * 获取分享内容的工具类
 *
 * @author Administrator
 */
public class OpenApiUtil {

    private static volatile OpenApiUtil instance;

    public static OpenApiUtil getInstance() {
        if (instance == null) {
            synchronized (OpenApiUtil.class) {
                if (instance == null) {
                    instance = new OpenApiUtil();
                }
            }
        }
        return instance;
    }


    public static void saveQQUserInfo(Context context, QQUserInfo userInfo) {
        OpenApiPrefs.putString(context, OpenApiConst.Tencent.QQ_NAME, userInfo.getNickname());
        OpenApiPrefs.putString(context, OpenApiConst.Tencent.QQ_AVATAR, userInfo.getFigureurl_qq_2());
        OpenApiPrefs.putInt(context, OpenApiConst.Tencent.QQ_GENDER, "男".equals(userInfo.getGender()) ? 1 : 2);
    }

    public static void saveTQQUserInfo(Context context, TqqUserInfo userInfo) {
        OpenApiPrefs.putString(context, OpenApiConst.TencenWeibo.TQQ_NAME, userInfo.getData().getName());
        OpenApiPrefs.putString(context, OpenApiConst.TencenWeibo.TQQ_AVATAR, userInfo.getData().getHead());
        OpenApiPrefs.putInt(context, OpenApiConst.TencenWeibo.TQQ_GENDER, userInfo.getData().getSex());
    }

    public static void saveWeiboUserInfo(Context context, WeiboUserInfo userInfo) {
        OpenApiPrefs.putString(context, OpenApiConst.Sina.NAME, userInfo.getName());
        OpenApiPrefs.putString(context, OpenApiConst.Sina.AVATAR, userInfo.getAvatar_large());
        OpenApiPrefs.putInt(context, OpenApiConst.Sina.GENDER, "m".equals(userInfo.getGender()) ? 1 : 2);
    }

    public static void saveWechatUserInfo(Context context, WechatUserInfo userInfo) {
        OpenApiPrefs.putString(context, OpenApiConst.Wechat.NAME, userInfo.getNickname());
        OpenApiPrefs.putString(context, OpenApiConst.Wechat.AVATAR, userInfo.getHeadimgurl());
        OpenApiPrefs.putInt(context, OpenApiConst.Wechat.GENDER, userInfo.getSex());
    }

    public static void saveOpenUserInfo(Context context, OpenUserInfo userInfo){
        if(userInfo instanceof WechatUserInfo){
            saveWechatUserInfo(context, (WechatUserInfo) userInfo);
        } else if(userInfo instanceof QQUserInfo){
            saveQQUserInfo(context, (QQUserInfo) userInfo);
        } else if(userInfo instanceof TqqUserInfo){
            saveTQQUserInfo(context, (TqqUserInfo) userInfo);
        } else if(userInfo instanceof WeiboUserInfo){
            saveWeiboUserInfo(context, (WeiboUserInfo) userInfo);
        }
    }

    public static void clearQQUserInfo(Context context) {
        OpenApiPrefs.remove(context, OpenApiConst.Tencent.QQ_AVATAR);
        OpenApiPrefs.remove(context, OpenApiConst.Tencent.QQ_GENDER);
        OpenApiPrefs.remove(context, OpenApiConst.Tencent.QQ_NAME);
    }

    public static void clearTQQUserInfo(Context context) {
        OpenApiPrefs.remove(context, OpenApiConst.TencenWeibo.TQQ_AVATAR);
        OpenApiPrefs.remove(context, OpenApiConst.TencenWeibo.TQQ_NAME);
        OpenApiPrefs.remove(context, OpenApiConst.TencenWeibo.TQQ_GENDER);
    }

    public static void clearWeiboUserInfo(Context context) {
        OpenApiPrefs.remove(context, OpenApiConst.Sina.NAME);
        OpenApiPrefs.remove(context, OpenApiConst.Sina.AVATAR);
        OpenApiPrefs.remove(context, OpenApiConst.Sina.GENDER);
    }

    public static void clearWechatUserInfo(Context context) {
        OpenApiPrefs.remove(context, OpenApiConst.Wechat.NAME);
        OpenApiPrefs.remove(context, OpenApiConst.Wechat.AVATAR);
        OpenApiPrefs.remove(context, OpenApiConst.Wechat.GENDER);
    }

    public static void clearAllInfo(Context context) {
        clearQQUserInfo(context);
        clearTQQUserInfo(context);
        clearWechatUserInfo(context);
        clearWeiboUserInfo(context);
    }

}
