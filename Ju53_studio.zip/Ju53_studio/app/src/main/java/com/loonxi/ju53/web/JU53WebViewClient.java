package com.loonxi.ju53.web;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.Logger;

public abstract class JU53WebViewClient extends WebViewClient {
    private Context context;
    private Activity activity;

    public JU53WebViewClient(Context context) {
        this.context = context;
        this.activity = (Activity) context;
    }

    public JU53WebViewClient(Fragment fragment) {
        this.context = fragment.getActivity();
        this.activity = fragment.getActivity();
    }

    @Override
    public void onReceivedError(WebView view, int errorCode,
                                String description, String failingUrl) {
        Logger.e(errorCode + "\n" + description + "\n" + failingUrl);
        view.loadUrl("file:///android_asset/networkerror.htm");
        super.onReceivedError(view, errorCode, description, failingUrl);
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url.startsWith("tel:")) {//电话
            IntentUtil.intentToDial(context,
                    url.substring(url.indexOf(":") + 1, url.length()));
        } else {
//            new BrowserDialog(context, url).show();
            view.loadUrl(url);
        }
        return true;
    }

    public abstract void preLoading(WebView view, String url);
}
