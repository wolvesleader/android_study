package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.SearchAdapter;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.presenters.SearchPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ISearchView;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * "搜索"activity
 * Created by Xuzue on 2016/1/5.
 */
public class SearchActivity extends BaseActivity implements View.OnClickListener, ISearchView, OnNetWorkListener {

    @ViewInject(R.id.search_layout_data)
    private LinearLayout mLayoutData;
    @ViewInject(R.id.search_stub)
    private ViewStub mStub;
    @ViewInject(R.id.search_layout_left)
    private LinearLayout mLayoutLeft;
    private LinearLayout mLayoutTitle;
    @ViewInject(R.id.search_edt_title)
    private TextView mEdtTitle;
    @ViewInject(R.id.search_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.search_iv_right)
    private ImageView mIvRight;
    @ViewInject(R.id.search_layout_general)
    private LinearLayout mLayoutGeneral;
    @ViewInject(R.id.search_tv_title_general)
    private TextView mTvTitleGeneral;
    @ViewInject(R.id.search_layout_sales)
    private LinearLayout mLayoutSales;
    @ViewInject(R.id.search_tv_title_sales)
    private TextView mTvTitleSales;
    @ViewInject(R.id.search_layout_price)
    private LinearLayout mLayoutPrice;
    @ViewInject(R.id.search_tv_title_price)
    private TextView mTvTitlePrice;
    @ViewInject(R.id.search_iv_order_price)
    private ImageView mIvOrderPrice;
    @ViewInject(R.id.search_plv)
    private PullToRefreshListView mPlv;

    private SearchAdapter mAdapter;
    private ListView mListView;

    private SearchPresenter mPresenter;
    private List<BaseProductEntity> mSearchData = new ArrayList<>();
    private int mCurrentSearchType = SearchPresenter.SEARCH_BY_NO;
    private String mKey;
    private String mCategoryId;
    private boolean mIsOrderPriceDesc = false;
    private int mCurrentPage = 1;
    private boolean mIsSort = false;//是否来自分类

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        x.view().inject(this);
        initViews();
        initContent();
        setListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initViews() {
        mListView = mPlv.getRefreshableView();
        mPlv.setEmptyView(getEmptyView(R.string.empty_search, AppConst.Empty.SERRCH));
        mPlv.setVisibility(View.INVISIBLE);
    }

    private void initContent() {
        mKey = getIntent().getStringExtra("key");
        mCategoryId = getIntent().getStringExtra("categoryId");
        mIsSort = getIntent().getBooleanExtra("isSort", false);
        mEdtTitle.setBackgroundResource(R.color.app_bg);
        if (!mIsSort && !StringUtil.isEmpty(mKey)) {
            mEdtTitle.setText(mKey);
        }
        mPresenter = new SearchPresenter(this);
        onClick(mLayoutGeneral);
    }

    private void setListener() {
        setOnNetWorkListener(this);
        mLayoutLeft.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
        mEdtTitle.setOnClickListener(this);
        mLayoutGeneral.setOnClickListener(this);
        mLayoutSales.setOnClickListener(this);
        mLayoutPrice.setOnClickListener(this);
        mPlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
                if(mIsSort){
                    mPresenter.getSortSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
                }else{
                    mPresenter.getSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
                }
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                if(mIsSort){
                    mPresenter.getSortSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
                }else{
                    mPresenter.getSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
                }
            }
        });
    }

    /**
     * 数据初始化
     */
    private void initData() {
        mCurrentPage = 1;
//        mSearchData.clear();
//        if (mPlv != null) {
//            mPlv.setVisibility(View.INVISIBLE);
//        }
//        if (mAdapter != null) {
//            mAdapter.notifyDataSetChanged();
//        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_layout_left:
            case R.id.search_edt_title:
                finish();
                break;
            case R.id.search_layout_right:
                ActionBarRightPopupWindow.show(mContext, mIvRight);
                break;
            case R.id.search_layout_general:
                if (mCurrentSearchType == SearchPresenter.SEARCH_BY_GENERAL) {
                    return;
                }
                initData();
                mIsOrderPriceDesc = false;
                mCurrentSearchType = SearchPresenter.SEARCH_BY_GENERAL;
                setTitlePriceImg();
                mTvTitleGeneral.setSelected(true);
                mTvTitleSales.setSelected(false);
                mTvTitlePrice.setSelected(false);
                requestSearch();
                break;
            case R.id.search_layout_sales:
                if (mCurrentSearchType == SearchPresenter.SEARCH_BY_SALES) {
                    return;
                }
                initData();
                mIsOrderPriceDesc = false;
                mCurrentSearchType = SearchPresenter.SEARCH_BY_SALES;
                setTitlePriceImg();
                mTvTitleGeneral.setSelected(false);
                mTvTitleSales.setSelected(true);
                mTvTitlePrice.setSelected(false);
                requestSearch();
                break;
            case R.id.search_layout_price:
                initData();
                mCurrentSearchType = mIsOrderPriceDesc ? SearchPresenter.SEARCH_BY_PRICE_DESC : SearchPresenter.SEARCH_BY_PRICE_AESC;
                setTitlePriceImg();
                mIsOrderPriceDesc = !mIsOrderPriceDesc;
                mTvTitleGeneral.setSelected(false);
                mTvTitleSales.setSelected(false);
                mTvTitlePrice.setSelected(true);
                requestSearch();
                break;
        }
    }

    /**
     * 请求搜索
     */
    private void requestSearch() {
        if (mPlv != null) {
            mPlv.setVisibility(View.INVISIBLE);
        }
        if (mIsSort) {
            mPresenter.getSortSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
        } else {
            mPresenter.getSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
        }
    }

    private void setTitlePriceImg() {
        if (mCurrentSearchType == SearchPresenter.SEARCH_BY_PRICE_DESC) {
            mIvOrderPrice.setImageResource(R.drawable.search_triangle_desc);
        } else if (mCurrentSearchType == SearchPresenter.SEARCH_BY_PRICE_AESC) {
            mIvOrderPrice.setImageResource(R.drawable.search_triangle_aesc);
        } else {
            mIvOrderPrice.setImageResource(R.drawable.search_triangle_default);
        }
    }

    @Override
    public void onSearchSuccess(JsonArrayInfo<BaseProductEntity> jsonArrayInfo) {
        setNetErrorView(mLayoutData, mStub, false);
        if (mPlv != null) {
            mPlv.setVisibility(View.VISIBLE);
            if (mPlv.isRefreshing()) {
                mPlv.onRefreshComplete();
            }
        }
        if(mCurrentPage == 1){
            mSearchData.clear();
        }
        mSearchData.addAll(jsonArrayInfo.getData());
        if (!ListUtil.isEmpty(jsonArrayInfo.getData())) {
            mCurrentPage++;
        }
        if (mAdapter == null) {
            mAdapter = new SearchAdapter(mContext, mSearchData);
            mListView.setAdapter(mAdapter);
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onSearchFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message, mLayoutData, mStub);
        if (mPlv != null) {
            mPlv.setVisibility(View.VISIBLE);
            if (mPlv.isRefreshing()) {
                mPlv.onRefreshComplete();
            }
        }
    }

    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {
        LogUtil.mLog().i("retry");
        mPresenter.getSearchList(mKey, mCategoryId, mCurrentSearchType, mCurrentPage);
    }
}
