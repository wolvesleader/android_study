package com.loonxi.ju53.fragment.accountSafe;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.presenters.UpdatePasswordPresenter;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.views.IUpdatePasswordView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * "账户安全"显示界面
 * Created by laojiaqi on 2016/2/17.
 */
public class AccountSafeMainFragment extends BaseSafeFragment<IUpdatePasswordView, UpdatePasswordPresenter> implements View.OnClickListener, IUpdatePasswordView {

    public static final String ACCOUNT_TYPE_FRAGMENT = "account_safe_type";
    @ViewInject(R.id.fragment_account_safe_name_text)
    private TextView mNameText;
    @ViewInject(R.id.fragment_account_safe_mobile_text)
    private TextView mMobileText;
    @ViewInject(R.id.fragment_account_safe_update_login_password)
    private LinearLayout mUpdateLoginLayout;
    @ViewInject(R.id.fragment_account_safe_update_pay_password)
    private LinearLayout mUpdatePayLayout;
    @ViewInject(R.id.fragment_account_safe_action_bar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_account_safe_logout)
    private TextView mLogoutText;

    private Context mContext;
    private String mName;
    private String mMobile;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account_safe_main, null);
        x.view().inject(view);
        mContext = getActivity();
        return view;
    }

    @Override
    public void initView() {
        mActionBar.setTitle(R.string.account_safe_title);
    }

    @Override
    public void initContent() {
        setInfo();
    }

    @Override
    public void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mUpdateLoginLayout.setOnClickListener(this);
        mUpdatePayLayout.setOnClickListener(this);
        mLogoutText.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.fragment_account_safe_update_login_password:
                goToUpdateLoginPassword(AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD);
                break;
            case R.id.fragment_account_safe_update_pay_password:
                goToUpdateLoginPassword(AccountSafeTypeFragment.UPDATE_PAY_PASSWORD);
                break;
            case R.id.fragment_account_safe_logout:
                logout();
                break;
        }
    }

    private void goBack() {
        if (mContext != null) {
            ((Activity) mContext).finish();
        }
    }

    /**
     * 登出
     */
    private void logout() {
        mPresenter.logout();
        gotoMainActivity();
        SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_MINE, SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, ""));
        SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_CART, SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, ""));
        SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_STORE, SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, ""));
        LoginUtil.logout(mContext);
    }


    /**
     * 跳转到“修改密码”
     */
    private void goToUpdateLoginPassword(int flag) {
        FragmentManager fm = getFragmentManager();
        if (fm.findFragmentByTag(ACCOUNT_TYPE_FRAGMENT) != null) {
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        AccountSafeTypeFragment accountSafeTypeFragment = new AccountSafeTypeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, flag);
        accountSafeTypeFragment.setArguments(bundle);
        ft.replace(R.id.fragment_account_safe_container, accountSafeTypeFragment, "account_safe_type");
        ft.addToBackStack("accountSafeMainFragment");
        ft.commitAllowingStateLoss();
    }


    private void setInfo() {
        if (mContext == null) {
            return;
        }
        mName = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_NAME);
        mMobile = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_MOBILE);
        mNameText.setText(mName);
        mMobileText.setText(mMobile);
    }

    private void gotoMainActivity() {
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_ACCOUNT_LOGIN_PASSWORD);
        getActivity().startActivity(intent);
    }

    @Override
    protected UpdatePasswordPresenter createPresenter(IUpdatePasswordView iUpdatePasswordView) {
        return new UpdatePasswordPresenter(this);
    }

    @Override
    public void onUpdatePasswordSuccess(String message) {

    }

    @Override
    public void onUpdatePasswordFailure(String message) {

    }
}
