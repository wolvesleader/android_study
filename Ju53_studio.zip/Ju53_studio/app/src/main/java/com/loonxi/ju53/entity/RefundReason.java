package com.loonxi.ju53.entity;

import java.io.Serializable;

/**
 * 退款原因
 * Created by Xuzue on 2016/1/27.
 */
public class RefundReason implements Serializable {
    private String reason;
    private int code;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getPickerViewText(){
        return reason;
    }
}
