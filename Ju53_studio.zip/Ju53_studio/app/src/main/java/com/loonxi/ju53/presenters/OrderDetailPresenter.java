package com.loonxi.ju53.presenters;

import android.text.TextUtils;

import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.models.IOrderModel;
import com.loonxi.ju53.models.impl.MessageModel;
import com.loonxi.ju53.models.impl.OrderModel;
import com.loonxi.ju53.modules.open.alipay.Base64;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IOrderDetailView;
import com.loonxi.ju53.views.IRefundView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import retrofit.Retrofit;

/**
 * 订单详情presenter
 * Created by Xuzue on 2016/1/25.
 */
public class OrderDetailPresenter {
    private IOrderDetailView mDetailView;
    private IRefundView mRefundView;
    private IOrderModel mModel;
    private MessageModel mMessageModel;

    public OrderDetailPresenter(IOrderDetailView mView) {
        this.mDetailView = mView;
        mModel = new OrderModel();
        mMessageModel = new MessageModel();
    }

    public OrderDetailPresenter(IRefundView mRefundView) {
        this.mRefundView = mRefundView;
        mModel = new OrderModel();
        mMessageModel = new MessageModel();
    }


    /**
     * 查询订单详情
     *
     * @param order
     */
    public void getOrderById(OrderEntity order) {
        if (order == null || StringUtil.isEmpty(order.getOrderId())) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("orderId", order.getOrderId());
        if (mDetailView != null) {
            mDetailView.startAsyncTask();
        }
        mModel.getOrderById(map, new Callback<OrderDetailEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, OrderDetailEntity data) {

            }

            @Override
            public void onSuccess(OrderDetailEntity data, Retrofit retrofit) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onGetOrderDetailSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onGetOrderDetailFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 付款
     *
     * @param payId
     * @param orderId
     * @param userId
     * @param orderSum
     */
    public void payOrder(String payId, String orderId, String userId, double orderSum) {
        if (StringUtil.isEmpty(payId) || StringUtil.isEmpty(orderId) || StringUtil.isEmpty(userId)) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        String payIdStr = payId + "_" + orderId + "_" + userId;
        map.put("payId", payIdStr);
        map.put("payMoney", orderSum + "");
        mDetailView.startAsyncTask();
        mModel.payOrder(map, new Callback<AliPayEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, AliPayEntity data) {

            }

            @Override
            public void onSuccess(AliPayEntity data, Retrofit retrofit) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onPayOrderSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onPayOrderFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 确认收货
     *
     * @param orderId
     */
    public void confirmOrder(String orderId, String payPassword) {
        if (StringUtil.isEmpty(orderId) || StringUtil.isEmpty(payPassword)) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("orderId", orderId);
        map.put("cashPassword", payPassword);
        if (mDetailView != null) {
            mDetailView.startAsyncTask();
        }
        mModel.sureOrder(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onConfirmOrderSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onConfirmOrderFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 申请退款
     *
     * @param attrId
     * @param orderId
     * @param backapply
     * @param productId
     * @param reason
     * @param notes
     * @param applyType
     * @param orderState
     */
    public void refund(String attrId, String orderId, String backapply, String productId,
                       final int reason, String notes, int applyType, int orderState) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        JSONObject refundsObject = new JSONObject();
        JSONObject object = new JSONObject();
        try {
            object.put("attrId", attrId);
            object.put("orderId", orderId);
            object.put("backapply", backapply);
            object.put("productId", productId);
            object.put("reason", reason + "");
            object.put("notes", notes);
            object.put("applyType", applyType + "");
            object.put("orderState", orderState + "");
            refundsObject.put("refunds", object);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        map.put("refunds", Base64.encode(refundsObject.toString().getBytes()));
        if (mRefundView != null) {
            mRefundView.startAsyncTask();
        }
        mModel.createRefunds(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mRefundView == null) {
                    return;
                }
                mRefundView.endAsyncTask();
                mRefundView.onRefundSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mRefundView == null) {
                    return;
                }
                mRefundView.endAsyncTask();
                mRefundView.onRefundFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 修改/撤销退款
     *
     * @param attrId
     * @param orderId
     * @param backapply
     * @param productId
     * @param reason
     * @param notes
     * @param applyType
     * @param orderState
     */
    public void updateRefund(String attrId, String orderId, String backapply, String productId,
                             final int reason, String notes, int applyType, int orderState,
                             String pid, boolean isCancel) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        JSONObject refundsObject = new JSONObject();
        JSONObject object = new JSONObject();
        try {
            object.put("attrId", attrId);
            object.put("orderId", orderId);
            object.put("backapply", backapply);
            object.put("productId", productId);
            object.put("reason", reason + "");
            object.put("notes", notes);
            object.put("applyType", applyType + "");
            object.put("orderState", orderState + "");
            object.put("pid", pid);
            object.put("state", isCancel ? -1 : 4);
            refundsObject.put("refunds", object);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        map.put("refunds", Base64.encode(refundsObject.toString().getBytes()));
        if (mRefundView != null) {
            mRefundView.startAsyncTask();
        }
        mModel.updateRefunds(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mRefundView == null) {
                    return;
                }
                mRefundView.endAsyncTask();
                mRefundView.onRefundSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mRefundView == null) {
                    return;
                }
                mRefundView.endAsyncTask();
                mRefundView.onRefundFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 获得物流单号
     * @param orderId
     */
    public void getOrderTrans(String orderId){
        if(TextUtils.isEmpty(orderId)){
            return;
        }
        mMessageModel.getLogistics(orderId, new Callback<JsonInfo<LogisticsEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<LogisticsEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<LogisticsEntity> data, Retrofit retrofit) {
                if (mDetailView != null) {
                    mDetailView.getTransOrderSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mDetailView != null) {
                    mDetailView.getTransOrderFailure(apiErrorCode, message);
                }
            }
        });
    }


    /**
     * 关闭订单
     * @param pid
     */
    public void closeOrder(String pid){
        if(StringUtil.isEmpty(pid)){
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", pid);
        if(mDetailView != null){
            mDetailView.startAsyncTask();
        }
        mModel.closeOrder(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onCloseOrderSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.endAsyncTask();
                mDetailView.onCloseOrderFailed(apiErrorCode, message);
            }
        });
    }
}
