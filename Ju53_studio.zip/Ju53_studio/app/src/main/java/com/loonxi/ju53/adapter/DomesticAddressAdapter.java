package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.entity.AddressEntity;

import java.util.List;

/**
 *
 * Created by Administrator on 2016/1/25.
 */
public class DomesticAddressAdapter extends BaseAdapter {

    public static final int DEFAULT_FLAG=1;
    Context mContext;
    List<AddressEntity> mDataList;

    public DomesticAddressAdapter(Context context, List<AddressEntity> list) {
        this.mContext = context;
        this.mDataList = list;

    }

    @Override
    public int getCount() {
        return mDataList == null ? 0 : mDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        if(convertView==null){
            convertView=View.inflate(mContext, R.layout.listitem_domestic_address,null);
            viewHolder=new ViewHolder();
            viewHolder.edit=(TextView)convertView.findViewById(R.id.address_item_edit);
            viewHolder.name=(TextView)convertView.findViewById(R.id.address_item_name);
            viewHolder.phone=(TextView)convertView.findViewById(R.id.address_item_phone);
            viewHolder.address=(TextView)convertView.findViewById(R.id.address_item_detail_address);
            viewHolder.select=(ImageView)convertView.findViewById(R.id.address_item_select);
            convertView.setTag(viewHolder);
        }else {
           viewHolder=(ViewHolder)convertView.getTag();
        }
        AddressEntity addressEntity=mDataList.get(position);
        //TODO 国内
        String name=addressEntity.getContact();
        int isDefault=addressEntity.getIsDefault();
        String defaultAddressPre=mContext.getResources().getString(R.string.address_default_tag);
        viewHolder.name.setText(isDefault==DEFAULT_FLAG?defaultAddressPre+name:name);
        viewHolder.address.setText(addressEntity.getAddress()+addressEntity.getDetailAddress());
        viewHolder.phone.setText(addressEntity.getPhones());
        if(isDefault==DEFAULT_FLAG){
            viewHolder.select.setVisibility(View.VISIBLE);
        }else {
            viewHolder.select.setVisibility(View.GONE);
        }
        return convertView;
    }

    class ViewHolder
    {
        TextView edit;//编辑Text
        TextView name;//名字
        TextView phone;//电话号码
        TextView address;//详细地址
        ImageView select;//是否选中
    }
}
