package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 活动单品
 * Created by Xuzue on 2016/2/25.
 */
public class PromotionProductEntity implements Parcelable {
    /**
     *
     */
    private int id;

    /**
     *  活动主表ID
     */
    private int acId;

    /**
     *  产品ID
     */
    private String productId;

    /**
     *  产品名称
     */
    private String productName;

    /**
     *  产品主图
     */
    private String productPic;

    /**
     *  价格
     */
    private double price;

    /**
     *  是否推送（标心）0.不推送，1.推送
     */
    private boolean isPush;

    /**
     *  排序
     */
    private int sort;
    /**
     * 销量
     */
    private int sold;


    protected PromotionProductEntity(Parcel in) {
        id = in.readInt();
        acId = in.readInt();
        productId = in.readString();
        productName = in.readString();
        productPic = in.readString();
        price = in.readDouble();
        isPush = in.readByte() != 0;
        sort = in.readInt();
        sold = in.readInt();
    }

    public static final Creator<PromotionProductEntity> CREATOR = new Creator<PromotionProductEntity>() {
        @Override
        public PromotionProductEntity createFromParcel(Parcel in) {
            return new PromotionProductEntity(in);
        }

        @Override
        public PromotionProductEntity[] newArray(int size) {
            return new PromotionProductEntity[size];
        }
    };

    public int getAcId() {
        return acId;
    }

    public void setAcId(int acId) {
        this.acId = acId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPic() {
        return productPic;
    }

    public void setProductPic(String productPic) {
        this.productPic = productPic;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean getIsPush() {
        return isPush;
    }

    public void setIsPush(boolean isPush) {
        this.isPush = isPush;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(acId);
        dest.writeString(productId);
        dest.writeString(productName);
        dest.writeString(productPic);
        dest.writeDouble(price);
        dest.writeByte((byte) (isPush ? 1 : 0));
        dest.writeInt(sort);
        dest.writeInt(sold);
    }
}
