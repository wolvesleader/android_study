package com.loonxi.ju53.constants;

import android.content.Context;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;

/**
 * 退款详情状态
 * (0-申请退款,1-不同意退款,2-同意退款（且已退款）,3-退款结束,4.退款修改-1取消申请退款，
 * 5.买家同意退款但未退款 7退货退款时的卖家同意退货 8.退货退款时买家退回货物)
 * Created by Xuzue on 2016/1/27.
 */
public class RefundDetailState {
    public static final int CANCEL = -1;
    public static final int APPLYED = 0;
    public static final int DENIED = 1;
    public static final int AGREED_REFUNED = 2;
    public static final int FINISH = 3;
    public static final int MODIFY = 4;
    public static final int AGREED_NO_REFUNED = 5;
    public static final int AGREED_REFUNED_GOODS = 7;
    public static final int GOODS_BACK = 8;


    public static void setRefundDetailState(TextView tv, int state){
        Context context = BaseApplication.instance;
        if(tv == null){
            return;
        }
        switch (state){
            case APPLYED:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_modify));
                break;
            case DENIED:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_denied));
                break;
            case AGREED_REFUNED:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_finish));
                break;
            case FINISH:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_finish));
                break;
            case MODIFY:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_modify));
                break;
            case CANCEL:
//                tv.setText(context.getResources().getString(R.string.refund_detail_state_cancel));
                break;
            case AGREED_NO_REFUNED:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_finish));
                break;
            case AGREED_REFUNED_GOODS:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_agree_refund_goods));
                break;
            case GOODS_BACK:
                tv.setText(context.getResources().getString(R.string.refund_detail_state_goods_back));
                break;
        }
    }
}
