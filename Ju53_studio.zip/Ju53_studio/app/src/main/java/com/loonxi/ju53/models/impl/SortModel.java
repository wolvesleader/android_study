package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.models.ISortModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.service.SortService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/25.
 */
public class SortModel implements ISortModel {

    @Override
    public Call<JsonArrayInfo<SortEntity>> getSorts(Map<String, Object> map, Callback<JsonArrayInfo<SortEntity>> callback) {
        Call<JsonArrayInfo<SortEntity>> call = Request.creatApi(SortService.class).getSorts(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<SortEntity>> getSortById(Map<String, Object> map, Callback<JsonArrayInfo<SortEntity>> callback) {
        Call<JsonArrayInfo<SortEntity>> call = Request.creatApi(SortService.class).getSortById(map);
        call.enqueue(callback);
        return call;
    }

}
