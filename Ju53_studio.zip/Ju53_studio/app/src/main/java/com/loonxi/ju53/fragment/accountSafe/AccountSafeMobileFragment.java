package com.loonxi.ju53.fragment.accountSafe;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.presenters.UpdatePasswordPresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IUpdatePasswordView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.DeleteEditText;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * 输入手机号
 * Created by laojiaqi on 2016/2/19.
 */
public class AccountSafeMobileFragment extends BaseSafeFragment<IUpdatePasswordView, UpdatePasswordPresenter> implements View.OnClickListener, IUpdatePasswordView {

    public static final String TAG = "AccountSafeLoginPasswordFragment";
    @ViewInject(R.id.fragment_account_safe_input_mobile_next)
    private TextView mNext;
    @ViewInject(R.id.fragment_account_safe_input_mobile_edit)
    private DeleteEditText mEditText;
    @ViewInject(R.id.fragment_account_safe_input_mobile_action_bar)
    private ActionBar mActionBar;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account_safe_input_mobile, null);
        x.view().inject(view);
        return view;
    }

    @Override
    public void initView() {
        mActionBar.setTitle(R.string.account_safe_login_title);
        mNext.setEnabled(false);
    }

    @Override
    public void initContent() {
    }

    @Override
    public void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mNext.setOnClickListener(this);
        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (StringUtil.isEmpty(s.toString())) {
                    mNext.setEnabled(false);
                } else {
                    mNext.setEnabled(true);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fragment_account_safe_input_mobile_next:
                next();
                break;
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
        }
    }

    private void goBack() {
        getActivity().finish();
    }

    /**
     * 下一步
     */
    private void next() {
        String mobile = mEditText.getText().toString();
        gotoVerifyCodeFragment(mobile, AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD);
    }


    @Override
    public void onUpdatePasswordSuccess(String loginPassword) {

    }

    private void gotoVerifyCodeFragment(String mobile, int flag) {
        FragmentManager fm = getFragmentManager();
        if (fm.findFragmentByTag(AccountSafeLoginPasswordFragment.TAG) != null) {
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        ft.addToBackStack("accountSafeTypeFragment");
        AccountSafeVerifyCodeFragment accountSafeVerifyCodeFragment = new AccountSafeVerifyCodeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, flag);//类别
        bundle.putString(AccountSafeLoginPasswordFragment.LOGIN_MOBILE_FLAG, mobile);
        accountSafeVerifyCodeFragment.setArguments(bundle);
        ft.add(R.id.fragment_account_safe_container, accountSafeVerifyCodeFragment, AccountSafeLoginPasswordFragment.TAG);
        ft.commitAllowingStateLoss();
    }

    @Override
    public void onUpdatePasswordFailure(String message) {
    }

    @Override
    protected UpdatePasswordPresenter createPresenter(IUpdatePasswordView iUpdatePasswordView) {
        return new UpdatePasswordPresenter(this);
    }
}
