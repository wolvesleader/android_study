package com.loonxi.ju53.manager;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;

/**
 * Created by XuZue on 2016/5/19 0019.
 */
public class StoreManager {

    public static void saveStoreBaseInfo(String logo, String name){
        SpUtil.putString(BaseApplication.instance, SpUtil.STORE_LOGO, logo);
        SpUtil.putString(BaseApplication.instance, SpUtil.STORE_NAME, name);
    }

    public static void setStoreBaseInfo(ImageView mIvLogo, TextView mTvName){
        if(mIvLogo != null && mTvName != null){
            String userName = SpUtil.getString(BaseApplication.instance, SpUtil.ACCOUNT_USER_NAME, "");
            String logoStr = SpUtil.getString(BaseApplication.instance, SpUtil.STORE_LOGO, "");
            String nameStr = SpUtil.getString(BaseApplication.instance, SpUtil.STORE_NAME, "");
            if(StringUtil.isEmpty(nameStr)){
                mTvName.setText(userName + "的聚小店");
            }else{
                mTvName.setText(nameStr);
            }
            if(StringUtil.isEmpty(logoStr)){
                Uri uri = Uri.parse("android.resource://com.loonxi.ju53/drawable/store_logo");
                Glide.with(BaseApplication.instance).load(uri).into(mIvLogo);
            }else{
                Glide.with(BaseApplication.instance).load(AppConst.PIC_HEAD + logoStr).into(mIvLogo);
            }
        }
    }

    public static void sendBroad(Context context) {
        if(context == null){
            return;
        }
        Intent intent = new Intent();
        intent.setAction(AppConst.Action.ACTION_STORE_ALT_BASEINFO);
        context.sendBroadcast(intent);
    }
}
