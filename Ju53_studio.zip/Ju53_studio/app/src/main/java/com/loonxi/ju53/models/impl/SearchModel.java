package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.models.ISearchModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.service.SearchService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/6.
 */
public class SearchModel implements ISearchModel {

    @Override
    public Call<JsonArrayInfo<BaseProductEntity>> getSearchList(Map<String, Object> map, Callback<JsonArrayInfo<BaseProductEntity>> callback) {
        Call<JsonArrayInfo<BaseProductEntity>> call = Request.creatApi(SearchService.class).getSearchProductList(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<BaseProductEntity>> getSortSearchList(Map<String, Object> map, Callback<JsonArrayInfo<BaseProductEntity>> callback) {
        Call<JsonArrayInfo<BaseProductEntity>> call = Request.creatApi(SearchService.class).getSortSearchProductList(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<String>> getHotSearch(Map<String, Object> map, Callback<JsonArrayInfo<String>> callback) {
        Call<JsonArrayInfo<String>> call = Request.creatApi(SearchService.class).getHotSearch(map);
        call.enqueue(callback);
        return call;
    }

}
