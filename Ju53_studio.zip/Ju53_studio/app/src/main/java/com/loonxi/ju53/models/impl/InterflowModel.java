package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.service.InterflowService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/25.
 */
public class InterflowModel {

    public Call<Object> getInterflowDetail(Map<String, Object> map, Callback<Object> callback){
        Call<Object> call = Request.creatApi(InterflowService.class, ApiConst.TRANS_DETAIL_URL).getInterflowDetail(map);
        call.enqueue(callback);
        return call;
    }
}
