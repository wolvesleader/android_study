package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.models.IFinanceModel;
import com.loonxi.ju53.models.impl.FinanceModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ICashAccountSettingView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashAccountSetPresenter extends BasePresenter<ICashAccountSettingView> {

    private ICashAccountSettingView mView;
    private IFinanceModel mModel;

    public CashAccountSetPresenter(ICashAccountSettingView view) {
        super(view);
        mView = getView();
        mModel = new FinanceModel();
    }

    /**
     * 绑定提现账户
     */
    public void bandCashAccount(String account, String name) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("account", account);
        map.put("account_name", name);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.bandCashAccount(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.bandAccountSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.bandAccountFailed(apiErrorCode, message);
                }
            }
        });
    }
}
