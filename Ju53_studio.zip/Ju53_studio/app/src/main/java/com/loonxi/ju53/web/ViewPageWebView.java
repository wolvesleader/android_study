package com.loonxi.ju53.web;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

/**
 * Created by laojiaqi on 2016/5/24.
 */
public class ViewPageWebView extends WebView  {

    ViewGroup  scrollViewGroup;
    public ViewPageWebView(Context context) {
        super(context);
        init();
    }


    private void init()
    {
        setVerticalScrollBarEnabled(false); //垂直不显示
        setHorizontalScrollBarEnabled(false);//水平不显示
        setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
    }

    public ViewPageWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ViewPageWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }
    //手指按下的点为(x1, y1)手指离开屏幕的点为(x2, y2)
  float x1,y1;

    public  void  setScrollView(ViewGroup scrollView)
    {
        this.scrollViewGroup=scrollView;
            this.scrollViewGroup.setOnTouchListener(new OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event)
                {
                    if(event.getAction() == MotionEvent.ACTION_MOVE) {
                        //当手指离开的时候
                        if(event.getY() - y1 > 50) {
                            //判断X坐标差值在20内
                            if (Math.abs(x1-event.getX())<40)
                                if (scrollViewGroup!=null)
                                {
                                    scrollViewGroup.setEnabled(true);
                                }


                        }
                    }
                    return false;
                }
            });

    }

        @Override
        public boolean onTouchEvent(MotionEvent event)
        {
                //，直接监听点击事件
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    //当手指按下的时候
                    x1=event.getX();
                    y1=event.getY();
                    if (scrollViewGroup!=null)
                        scrollViewGroup.setEnabled(false);
                }
                if(event.getAction() == MotionEvent.ACTION_MOVE) {
                    if(event.getY() - y1 > 50) {
                        //判断X坐标差值在20内
                        if (Math.abs(x1-event.getX())<40)
                            if (scrollViewGroup!=null)
                                scrollViewGroup.setEnabled(true);

                    }
                }

            return super.onTouchEvent(event);
        }




    public boolean canScrollHor(int direction) {
        final int offset = computeHorizontalScrollOffset();
        final int range = computeHorizontalScrollRange() - computeHorizontalScrollExtent();
        if (range == 0) return false;
        if (direction < 0) {
            return offset > 0;
        } else {
            return offset < range - 1;
        }
    }




    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        //滑动的距离<10 开启父控件的enable
        Log.e("t", "测试滑动的高度onScrollChanged" + t);
        if (t<10)
        {
            if (scrollViewGroup!=null)
            {
                scrollViewGroup.setEnabled(true);
            }

        }else {
            if (scrollViewGroup!=null)
            {
                scrollViewGroup.setEnabled(false);
            }
        }

    }




}
