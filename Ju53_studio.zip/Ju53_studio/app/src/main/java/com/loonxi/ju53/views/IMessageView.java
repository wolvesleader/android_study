package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.MessageEntity;

import java.util.List;

/**
 * 消息接口
 * Created by laojiaqi on 2016/2/2.
 */
public interface IMessageView {

    public void getMessageSuccess(List<MessageEntity> messageEntityList);

    public void getMessageFailure(int code,String message);

    public void getTransOrderSuccess(LogisticsEntity logisticsEntity);

    public void getTransOrderFailure(int code,String message);

}
