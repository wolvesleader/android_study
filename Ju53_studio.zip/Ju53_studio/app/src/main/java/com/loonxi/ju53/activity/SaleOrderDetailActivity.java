package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.OrderDetailAdapter;
import com.loonxi.ju53.adapter.SaleOrderDetailAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.OrderState;
import com.loonxi.ju53.convert.OrderDataConvert;
import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderAddressEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderTime;
import com.loonxi.ju53.entity.SaleOrderDetailAddress;
import com.loonxi.ju53.entity.SaleOrderDetailEntity;
import com.loonxi.ju53.entity.SaleOrderDetailTime;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.listener.AlipayListener;
import com.loonxi.ju53.manager.AlipayManager;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.presenters.OrderDetailPresenter;
import com.loonxi.ju53.presenters.SaleOrderDetailPresenter;
import com.loonxi.ju53.utils.InterflowUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.TimeUtil;
import com.loonxi.ju53.views.IOrderDetailView;
import com.loonxi.ju53.views.ISaleOrderDetailView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.dialog.PayPasswordDialog;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 分销订单详情
 * Created by Xuzue on 2016/1/21.
 */
public class SaleOrderDetailActivity extends ActionBarActivity implements View.OnClickListener, ISaleOrderDetailView {

    @ViewInject(R.id.sale_order_detail_layout_root)
    private LinearLayout mLayoutRoot;
    @ViewInject(R.id.sale_order_detail_slv)
    private PullToRefreshScrollView mSlv;
    @ViewInject(R.id.sale_order_detail_tv_status)
    private TextView mTvOrderStatus;
    @ViewInject(R.id.sale_order_detail_layout_personal_info)
    private LinearLayout mLayoutPersonInfo;
    @ViewInject(R.id.sale_order_detail_tv_name)
    private TextView mTvName;
    @ViewInject(R.id.sale_order_detail_tv_tel)
    private TextView mTvTel;
    @ViewInject(R.id.sale_order_detail_tv_address)
    private TextView mTvAddress;
    @ViewInject(R.id.sale_order_detail_flv)
    private FixedListView mFlv;
    @ViewInject(R.id.sale_order_detail_tv_order_no)
    private TextView mTvOrderNo;
    @ViewInject(R.id.sale_order_detail_tv_order_createtime)
    private TextView mTvCreateTime;
    @ViewInject(R.id.sale_order_detail_layout_paytime)
    private LinearLayout mLayoutPayTime;
    @ViewInject(R.id.sale_order_detail_tv_order_paytime)
    private TextView mTvPayTime;
    @ViewInject(R.id.sale_order_detail_layout_sendtime)
    private LinearLayout mLayoutSendTime;
    @ViewInject(R.id.sale_order_detail_tv_order_sendtime)
    private TextView mTvSendTime;
    @ViewInject(R.id.sale_order_detail_layout_confirmtime)
    private LinearLayout mLayoutConfirmTime;
    @ViewInject(R.id.sale_order_detail_tv_order_confirmtime)
    private TextView mTvConfirmTime;


    private SaleOrderDetailPresenter mPresenter;
    private SaleOrderDetailAdapter mAdapter;
    private SaleOrderDetailEntity mOrderDetail;
    private String mOrderId;
    private String mOrderState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale_order_detail);
    }

    @Override
    public void initView() {
        setTitle(R.string.order_detail_title);
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mOrderId = getIntent().getStringExtra("orderId");
        mOrderState = getIntent().getStringExtra("state");
        mPresenter = new SaleOrderDetailPresenter(this);
        mPresenter.getSaleOrderDetail(mOrderId, mOrderState, true);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mSlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getSaleOrderDetail(mOrderId, mOrderState, false);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getSaleOrderDetail(mOrderId, mOrderState, false);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
        }
    }

    /**
     * 设置订单信息
     */
    private void setOrderInfo() {
        if (mOrderDetail == null || mOrderDetail.getOrder() == null) {
            return;
        }
        SaleOrderEntity order = mOrderDetail.getOrder();
        SaleOrderDetailTime time = mOrderDetail.getTime();
        SaleOrderDetailAddress addressEntity = mOrderDetail.getAddress();
        String state = order.getState();
        if (!StringUtil.isEmpty(state)) {
            OrderState.setOrderState(mTvOrderStatus, Integer.parseInt(state));
        }
        String name = addressEntity == null || StringUtil.isEmpty(addressEntity.getReceiveName()) ? "" : addressEntity.getReceiveName();
        String phone = addressEntity == null || StringUtil.isEmpty(addressEntity.getMobile()) ? "" : addressEntity.getMobile();
        String address = addressEntity == null || StringUtil.isEmpty(addressEntity.getReceiveAddress()) ? ""
                : addressEntity.getReceiveAddress().replace("&nbsp;", " ");
        mTvName.setText(getResources().getString(R.string.order_confirm_title_name) + name);
        mTvTel.setText(phone);
        mTvAddress.setText(getResources().getString(R.string.order_confirm_title_address) + address);
        mTvOrderNo.setText(order.getOrderId());
        if (time != null) {
            mTvCreateTime.setText(time.getCreateTime());
            setTime(mOrderDetail.getTime(), StringUtil.isEmpty(state) ? OrderState.ERROR : Integer.parseInt(state));
        }
    }

    /**
     * 设置时间
     *
     * @param times
     * @param state
     */
    private void setTime(SaleOrderDetailTime times, int state) {
        if (times == null) {
            return;
        }
        if (!StringUtil.isEmpty(times.getPayTime())) {
            mLayoutPayTime.setVisibility(View.VISIBLE);
            mTvPayTime.setText(times.getPayTime());
        }
        if (!StringUtil.isEmpty(times.getShippingTime())) {
            mLayoutSendTime.setVisibility(View.VISIBLE);
            mTvSendTime.setText(times.getShippingTime());
        }
        if (!StringUtil.isEmpty(times.getReceiveTime())) {
            mLayoutConfirmTime.setVisibility(View.VISIBLE);
            mTvConfirmTime.setText(times.getReceiveTime());
        }
    }

    @Override
    public void onGetOrderDetailSuccess(SaleOrderDetailEntity detail) {
        mLayoutRoot.setVisibility(View.VISIBLE);
        if (mSlv.isRefreshing()) {
            mSlv.onRefreshComplete();
        }
        mOrderDetail = detail;
        if (detail == null) {
            return;
        }
        if (mAdapter == null) {
            List<SaleOrderEntity> list = new ArrayList<>();
            list.add(detail.getOrder());
            mAdapter = new SaleOrderDetailAdapter(mContext, list);
            mFlv.setAdapter(mAdapter);
        }
        mAdapter.notifyDataSetChanged();
        setOrderInfo();
    }

    @Override
    public void onGetOrderDetailFailed(int apiErrorCode, String message) {
        if (mSlv.isRefreshing()) {
            mSlv.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

}
