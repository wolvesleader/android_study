package com.loonxi.ju53.manager;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.utils.ImageUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.PackageUtil;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;

/**
 * 通知管理类
 *
 * @author Administrator
 */
public class NotifyManager {

    /**
     * 传入上下文
     */
    private Context mContext;

    /**
     * 通知管理类
     */
    public NotificationManager nm;

    /**
     * 普通通知
     */
    public static int NOTIFY_COMMON = 101;
    /**
     * 软件更新
     */
    public static int NOTIFY_UPDATE = 102;


    /**
     * 显示提醒通知
     *
     * @param context
     */

    public NotifyManager(Context context) {
        if (context == null) {
            return;
        }
        this.mContext = context;
        nm = (NotificationManager) context
                .getSystemService(Context.NOTIFICATION_SERVICE);
    }

    /**
     * 普通通知
     * @param title
     * @param content
     */
    public void showCommonNotify(String title, String content) {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent contentIntent = PendingIntent.getActivity(mContext,
                PendingIntent.FLAG_CANCEL_CURRENT, intent,
                PendingIntent.FLAG_CANCEL_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext);
        if (android.os.Build.VERSION.SDK_INT < 21) {
            builder.setSmallIcon(R.drawable.ic_launcher);
        } else {
            builder.setSmallIcon(R.drawable.ic_launcher_21);
        }
        builder.setLargeIcon(ImageUtil.getBitmapById(mContext, R.drawable.ic_launcher));
        builder.setAutoCancel(true);
        builder.setContentTitle(StringUtil.isEmpty(title) ? PackageUtil.getPackageName(mContext) : title);
        builder.setContentText(StringUtil.isEmpty(content) ? "" : content);
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setDefaults(Notification.DEFAULT_VIBRATE);
        builder.setContentIntent(contentIntent);
        if (nm != null) {
            nm.notify(NOTIFY_COMMON, builder.build());
        }
    }

    /**
     * 版本更新通知
     */
    public void showSoftwareUpdate(String version, String content,
                                   boolean audio, boolean vibrator) {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("version", version);
        intent.putExtra("content", content);
        intent.putExtra("isPushMsg", true);
        PendingIntent contentIntent = PendingIntent.getActivity(mContext,
                PendingIntent.FLAG_CANCEL_CURRENT, intent,
                PendingIntent.FLAG_CANCEL_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext);
        if (android.os.Build.VERSION.SDK_INT < 21) {
            builder.setSmallIcon(R.drawable.ic_launcher);
        } else {
            builder.setSmallIcon(R.drawable.ic_launcher);
        }
        builder.setAutoCancel(true);
        builder.setTicker("版本更新");
        builder.setContentTitle("版本更新");
        builder.setContentText("JU53有新版本"
                + (StringUtil.isEmpty(version) ? "" : version)
                + "啦，点击更新~");
        if (audio) {
            builder.setDefaults(Notification.DEFAULT_SOUND);
        }
        if (vibrator) {
            builder.setDefaults(Notification.DEFAULT_VIBRATE);
        }
        builder.setContentIntent(contentIntent);
        if (nm != null) {
            nm.notify(NOTIFY_UPDATE, builder.build());
        }
    }

    public void removeNotify(int notifyId) {
        if (nm != null) {
            nm.cancel(notifyId);
        }
    }

    /**
     * 判断Activity是否在栈顶
     *
     * @return
     */
    public boolean isTop() {
        if (mContext == null) {
            return false;
        }
        ActivityManager manager = (ActivityManager) mContext
                .getSystemService(Context.ACTIVITY_SERVICE);
        List<RunningTaskInfo> infos = manager.getRunningTasks(1000);
        if (ListUtil.isEmpty(infos)) {
            return false;
        }
        RunningTaskInfo info = infos.get(0);
        if (mContext.getPackageName().equals(info.topActivity.getPackageName())) {
            return true;
        }
        return false;
    }
}
