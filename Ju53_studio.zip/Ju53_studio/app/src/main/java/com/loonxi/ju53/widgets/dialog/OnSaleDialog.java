package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.listener.UmengAuthListener;
import com.loonxi.ju53.listener.UmengShareListener;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;

import java.util.Map;

/**
 * 一键上架Dialog
 * Created by Xuzue on 2016/4/5.
 */
public class OnSaleDialog extends Dialog implements View.OnClickListener {

    private ImageView mIvClose;
    private RelativeLayout mlayoutJu;
    private RelativeLayout mLayoutTb;
    private ImageView mIvJu;
    private ImageView mIvJuCheck;
    private ImageView mIvTb;
    private ImageView mIvTbCheck;
    private TextView mTvJu;
    private TextView mTvTb;
    private TextView mTvOnsale;

    private Context mContext;
    private boolean mTbEnable = true;//上架到淘宝是否可用
    private boolean mJuChecked = false;
    private boolean mTbChecked = false;

    private OnSaleCheckListener mCheckListener;

    public OnSaleDialog(Context context, boolean tbEnable, OnSaleCheckListener listener) {
        super(context, R.style.cartdialog_style);
        init(context, tbEnable, listener);
    }


    private void init(Context context, boolean tbEnable, OnSaleCheckListener listener) {
        if (context == null) {
            return;
        }
        mContext = context;
        mTbEnable = tbEnable;
        mCheckListener = listener;
        setContentView(R.layout.dialog_onsale);
        setCancelable(true);
        initView();
        initContent();
        setListener();
    }

    private void initView() {
        mIvClose = (ImageView) findViewById(R.id.dialog_onsale_iv_close);
        mlayoutJu = (RelativeLayout) findViewById(R.id.dialog_onsale_layout_juxiaodian);
        mLayoutTb = (RelativeLayout) findViewById(R.id.dialog_onsale_layout_taobao);
        mIvJu = (ImageView) findViewById(R.id.dialog_onsale_iv_ju);
        mIvJuCheck = (ImageView) findViewById(R.id.dialog_onsale_iv_checkju);
        mIvTb = (ImageView) findViewById(R.id.dialog_onsale_iv_tb);
        mIvTbCheck = (ImageView) findViewById(R.id.dialog_onsale_iv_checktb);
        mTvJu = (TextView) findViewById(R.id.dialog_onsale_tv_ju);
        mTvTb = (TextView) findViewById(R.id.dialog_onsale_tv_tb);
        mTvOnsale = (TextView) findViewById(R.id.dialog_onsale_tv_onsale);
    }

    private void initContent() {
        checkJu(true);
        checkTb(false);
    }

    private void setListener() {
        mIvClose.setOnClickListener(this);
        mlayoutJu.setOnClickListener(this);
        mLayoutTb.setOnClickListener(this);
        mTvOnsale.setOnClickListener(this);
    }

    public void setDialogAttribute(Activity activity, int gravity) {
        if (activity == null) {
            return;
        }
        Display display = activity.getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = (int) display.getWidth();
        lp.gravity = gravity;
        getWindow().setAttributes(lp);
    }

    @Override
    public void onClick(View v) {
        if (mContext == null) {
            return;
        }
        switch (v.getId()) {
            case R.id.dialog_onsale_iv_close:
                dismiss();
                break;
            case R.id.dialog_onsale_layout_juxiaodian:
                checkJu(!mJuChecked);
                break;
            case R.id.dialog_onsale_layout_taobao:
                if(!mTbEnable){
                    ToastUtil.showShortToast("该商品暂不支持一键上架到淘宝");
                    return;
                }else{
                    checkTb(!mTbChecked);
                }
                break;
            case R.id.dialog_onsale_tv_onsale:
                if (!mJuChecked && !mTbChecked) {
                    ToastUtil.showShortToast("请至少选择一个上架平台");
                    return;
                }
                if (mCheckListener != null) {
                    mCheckListener.checkResult(mJuChecked, mTbChecked);
                }
                dismiss();
                break;
        }
    }

    private void checkJu(boolean check) {
        mJuChecked = check;
        mlayoutJu.setSelected(mJuChecked);
        mIvJuCheck.setVisibility(mJuChecked ? View.VISIBLE : View.INVISIBLE);
        mTvJu.setSelected(mJuChecked);
    }

    private void checkTb(boolean check) {
        if(!mTbEnable){
            return;
        }
        mTbChecked = check;
        mLayoutTb.setSelected(mTbChecked);
        mIvTbCheck.setVisibility(mTbChecked ? View.VISIBLE : View.INVISIBLE);
        mTvTb.setSelected(mTbChecked);
    }

    public interface OnSaleCheckListener {
        void checkResult(boolean checkedJu, boolean checkedTb);
    }
}
