package com.loonxi.ju53.presenters;

import android.view.View;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.StoreProductExtraEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.models.IProductDetailModel;
import com.loonxi.ju53.models.IStoreProductDetailModel;
import com.loonxi.ju53.models.impl.FavModel;
import com.loonxi.ju53.models.impl.ProductDetailModel;
import com.loonxi.ju53.models.impl.StoreProductDetailModel;
import com.loonxi.ju53.models.impl.SupplierModel;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IProductDetailView;
import com.loonxi.ju53.views.IStoreProductDetailView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/1/11.
 */
public class StoreProductDetailPresenter extends BasePresenter<IStoreProductDetailView> {

    IStoreProductDetailModel mModel;
    IStoreProductDetailView mView;

    public StoreProductDetailPresenter(IStoreProductDetailView view) {
        super(view);
        mView = getView();
        mModel = new StoreProductDetailModel();
    }


    /**
     * 获取产品基本信息
     *
     * @param productId
     */
    public void getProductBaseInfo(String productId) {
        if (mView != null) {
            mView.startAsyncTask();
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", productId);
        mModel.getBaseInfo(map, new Callback<JsonInfo<ProductDetailEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<ProductDetailEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<ProductDetailEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetBaseInfoSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetBaseInfoFailed(apiErrorCode, message);

            }
        });
    }

    /**
     * 获取图文详情
     *
     * @param productId
     */
    public void getProductDetailInfo(String productId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", productId);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.getDetailInfo(map, new Callback<JsonInfo<ProductDetailEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<ProductDetailEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<ProductDetailEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetDetailSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetDetailFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 获取额外信息（发货地、上下架状态）
     *
     * @param productId
     */
    public void getExtraInfo(String productId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productId);
        mModel.getExtraInfo(map, new Callback<JsonInfo<StoreProductExtraEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<StoreProductExtraEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<StoreProductExtraEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.getExtraInfoSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.getExtraInfoFailed(apiErrorCode, message);
                }
            }
        });

    }

    /**
     * 下架商品
     *
     * @param productId
     */
    public void offSale(String productId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productId);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.offSale(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.offSaleSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.offSaleFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 上架
     *
     * @param productId
     */
    public void onSale(String productId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productId);
//        map.put("product_id", productId);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.onSale(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onSaleSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onSaleFailed(apiErrorCode, message);
                }
            }
        });

    }

}
