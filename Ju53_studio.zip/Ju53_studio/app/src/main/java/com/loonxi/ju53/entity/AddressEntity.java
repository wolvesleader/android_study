package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.fragment.address.DisplayAddressFragment;

/**
 * 收货地址bean
 * Created by Administrator on 2016/1/25.
 */
public class AddressEntity implements Parcelable {

    String pid;
    String address; //地址
    String detailAddress;//详细地址
    String contact; //姓名
    String phones;  //电话
    String zip;
    int isOverseas; //是否是海外 1.海外;0,国内
    String streetAddress; //街道
    String city;  //城市
    String provinceArea;//
    String unit;
    int isDefault;//1 默认；0 非默认
    String regionId;

    public AddressEntity(){

    }

    protected AddressEntity(Parcel in) {
        pid = in.readString();
        address = in.readString();
        detailAddress = in.readString();
        contact = in.readString();
        phones = in.readString();
        zip = in.readString();
        isOverseas = in.readInt();
        streetAddress = in.readString();
        city = in.readString();
        provinceArea = in.readString();
        unit = in.readString();
        isDefault = in.readInt();
        regionId = in.readString();
    }

    public static final Creator<AddressEntity> CREATOR = new Creator<AddressEntity>() {
        @Override
        public AddressEntity createFromParcel(Parcel in) {
            return new AddressEntity(in);
        }

        @Override
        public AddressEntity[] newArray(int size) {
            return new AddressEntity[size];
        }
    };

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDetailAddress() {
        return detailAddress;
    }

    public void setDetailAddress(String detailAddress) {
        this.detailAddress = detailAddress;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhones() {
        return phones;
    }

    public void setPhones(String phones) {
        this.phones = phones;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public int getIsOverseas() {
        return isOverseas;
    }

    public void setIsOverseas(int isOverseas) {
        this.isOverseas = isOverseas;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvinceArea() {
        return provinceArea;
    }

    public void setProvinceArea(String provinceArea) {
        this.provinceArea = provinceArea;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(int isDefault) {
        this.isDefault = isDefault;
    }

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    @Override
    public String toString() {
        return "AddressEntity{" +
                "pid='" + pid + '\'' +
                ", address='" + address + '\'' +
                ", detailAddress='" + detailAddress + '\'' +
                ", contact='" + contact + '\'' +
                ", phones='" + phones + '\'' +
                ", zip='" + zip + '\'' +
                ", isOverseas=" + isOverseas +
                ", streetAddress='" + streetAddress + '\'' +
                ", city='" + city + '\'' +
                ", provinceArea='" + provinceArea + '\'' +
                ", unit='" + unit + '\'' +
                ", isDefault=" + isDefault +
                ", regionId='" + regionId + '\'' +
                '}';
    }

    public String getCompleteAddress() {
        if (isOverseas == DisplayAddressFragment.ADDRESS_DOMESTIC_FLAG) {
            return address + detailAddress;
        } else {
            return streetAddress + unit + city + provinceArea + address;
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(pid);
        dest.writeString(address);
        dest.writeString(detailAddress);
        dest.writeString(contact);
        dest.writeString(phones);
        dest.writeString(zip);
        dest.writeInt(isOverseas);
        dest.writeString(streetAddress);
        dest.writeString(city);
        dest.writeString(provinceArea);
        dest.writeString(unit);
        dest.writeInt(isDefault);
        dest.writeString(regionId);
    }
}
