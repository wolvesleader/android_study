package com.loonxi.ju53.listener;

import com.loonxi.ju53.entity.OrderEntity;

/**
 * Created by Xuzue on 2016/1/29.
 */
public interface OrderContentListener {
    void showPayConfirmDialog(OrderEntity order);
}
