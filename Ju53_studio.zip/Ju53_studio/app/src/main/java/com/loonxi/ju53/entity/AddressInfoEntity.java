package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 地址选择 单个entity
 * Created by Administrator on 2016/1/26.
 */
public class AddressInfoEntity implements Parcelable {
    private String regionId;
    private String regionName;
    private List<AddressInfoEntity> list;//下级区域
    private String parent;//上级区域

    public AddressInfoEntity() {

    }

    protected AddressInfoEntity(Parcel in) {
        regionId = in.readString();
        regionName = in.readString();
        list = in.createTypedArrayList(AddressInfoEntity.CREATOR);
        parent = in.readString();
    }

    public static final Creator<AddressInfoEntity> CREATOR = new Creator<AddressInfoEntity>() {
        @Override
        public AddressInfoEntity createFromParcel(Parcel in) {
            return new AddressInfoEntity(in);
        }

        @Override
        public AddressInfoEntity[] newArray(int size) {
            return new AddressInfoEntity[size];
        }
    };

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public List<AddressInfoEntity> getList() {
        return list;
    }

    public void setList(List<AddressInfoEntity> list) {
        this.list = list;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    @Override
    public String toString() {
        return "AddressInfoEntity{" +
                "regionId='" + regionId + '\'' +
                ", regionName='" + regionName + '\'' +
                ", list=" + list +
                ", parent='" + parent + '\'' +
                '}';
    }

    //这个用来显示在PickerView上面的字符串,PickerView会通过反射获取getPickerViewText方法显示出来。
    public String getPickerViewText() {
        //这里还可以判断文字超长截断再提供显示
        return regionName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(regionId);
        dest.writeString(regionName);
        dest.writeTypedList(list);
        dest.writeString(parent);
    }
}
