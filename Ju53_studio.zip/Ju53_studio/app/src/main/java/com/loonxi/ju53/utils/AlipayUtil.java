package com.loonxi.ju53.utils;

import java.util.Map;

/**
 * Created by Xuzue on 2016/2/18.
 */
public class AlipayUtil {

    public static String convertSign(String mPayInfo){
        String payInfo = "";
        if(StringUtil.isEmpty(mPayInfo)){
            return payInfo;
        }
        Map<String, Object> map = MapUtil.getAlipayUrlParams(mPayInfo);
        return MapUtil.getUrlParamsByMap(map);
    }
}
