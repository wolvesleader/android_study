package com.loonxi.ju53.entity;

import java.util.List;

/**
 * Created by XuZue on 2016/5/10 0010.
 */
public class CashRecordInfo {
    private String count;
    private List<CashRecordEntity> list;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public List<CashRecordEntity> getList() {
        return list;
    }

    public void setList(List<CashRecordEntity> list) {
        this.list = list;
    }
}
