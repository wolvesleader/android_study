package com.loonxi.ju53.views;

/**
 * Created by Xuzue on 2016/2/17.
 */
public interface IMineView {
    void onGetBuyOrderNumSuccess(String nums);

    void onGetBuyOrderNumFailed(int apiErrorCode, String message);

    void onGetOrderTotalNumSuccess(String nums);

    void onGetOrderTotalNumFailed(int apiErrorCode, String message);

    void testPhpSuccess(String content);

    void testPhpFailed(int apiErrorCode, String message);
}
