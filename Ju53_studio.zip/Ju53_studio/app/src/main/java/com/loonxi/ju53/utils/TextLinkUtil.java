package com.loonxi.ju53.utils;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Xuze on 2015/9/4.
 */
public class TextLinkUtil {


    /**
     * 文本添加超链接
     * @param textView
     * @param text
     */
    public static void addTextLink(TextView textView, CharSequence text){
        addTextLink(textView, text, null);
    }

    /**
     * 文本添加超链接
     * @param textView
     * @param text
     * @param listener
     */
    public static void addTextLink(TextView textView, CharSequence text, View.OnClickListener listener){
        addTextLink(textView, text, -1, listener);
    }

    /**
     * 文本添加超链接
     * @param textView
     * @param text
     * @param color
     */
    public static void addTextLink(TextView textView, CharSequence text, int color){
        addTextLink(textView, text, color, null);
    }

    /**
     * 文本添加超链接
     * @param textView
     * @param text
     * @param color
     * @param listener
     */
    public static void addTextLink(TextView textView, CharSequence text, int color, View.OnClickListener listener){
        addTextLink(textView, text, color, 0, text.length(), listener, true);
    }

    /**
     * 文本添加超链接
     * @param textView 文本控件
     * @param text 文本内容
     * @param color 文本颜色
     * @param start 开始位置
     * @param end 结束位置
     * @param listener 点击监听事件
     * @param showUnderline 是否添加下划线
     */
    public static void addTextLink(TextView textView, CharSequence text, int color, int start, int end,
                                   View.OnClickListener listener, boolean showUnderline){
        if(textView == null){
            return;
        }
        if(StringUtil.isEmpty(text + "")){
            textView.setText(text);
            return;
        }
        if(start < 0 || start > text.length() || start > end || end > text.length()){
            textView.setText(text);
            return;
        }
        SpannableString sp = new SpannableString(text);
        sp.setSpan(new IntentSpan(listener, showUnderline), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if(color > 0){
            sp.setSpan(new ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        textView.setText(sp);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public static class IntentSpan extends ClickableSpan {
        private View.OnClickListener mListener;
        private boolean mShowUnderline;

        public IntentSpan(View.OnClickListener listener, boolean showUnderline) {
            mListener = listener;
            mShowUnderline = showUnderline;
        }

        @Override
        public void onClick(View view) {
            if(mListener != null){
                mListener.onClick(view);
            }
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            super.updateDrawState(ds);
            ds.setUnderlineText(mShowUnderline);
        }
    }
}
