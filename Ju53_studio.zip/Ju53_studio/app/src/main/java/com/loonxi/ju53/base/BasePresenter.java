package com.loonxi.ju53.base;

import java.lang.ref.WeakReference;

/**
 *  Presenter基类
 * Created by Administrator on 2016/1/20.
 */
public class BasePresenter<T> {

    protected WeakReference<T> mRefView;

    public BasePresenter(T view) {
        mRefView = new WeakReference<T>(view);
    }


    /**
     * 返回View
     *
     * @return 返回View的软引用
     */
    protected T getView() {
        return mRefView.get();
    }

    /**
     * 是否已被回收
     *
     * @return true代表已回收
     */
    protected boolean isGc() {
        if (mRefView.get() == null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 解除对View的引用
     */
    protected void detachView(){
        if(mRefView!=null){
            mRefView.clear();
            mRefView=null;
        }
    }


}
