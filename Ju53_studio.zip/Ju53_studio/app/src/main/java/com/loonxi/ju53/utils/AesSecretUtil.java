package com.loonxi.ju53.utils;

import android.util.Base64;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;


public class AesSecretUtil {

    private static String aesKey = "LONGXIWWWJU53COM";

    private static String secretType = "AES";

    private static int aesSize = 256;

    /**
     * aes加密工具
     */
    private static Cipher aesEncryptCipher = null;

    /**
     * aes解密工具
     */
    private static Cipher aesDecryptCipher = null;

    static {
        try {
            //Key key = getAESKey(aesKey.getBytes());
        	Key key = generateKey(aesKey); 
            aesEncryptCipher = Cipher.getInstance(secretType);
            aesEncryptCipher.init(Cipher.ENCRYPT_MODE, key);
            aesDecryptCipher = Cipher.getInstance(secretType);
            aesDecryptCipher.init(Cipher.DECRYPT_MODE, key);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 加密字节数组
     *
     * @param arrB 需加密的字节数组
     * @return 加密后的字节数组
     * @throws Exception
     */
    public static byte[] aesEncrypt(byte[] arrB) throws Exception {
        return aesEncryptCipher.doFinal(arrB);
    }

    /**
     * 加密字符串(返回16进制)
     *
     * @param strIn 需加密的字符串
     * @return 加密后的字符串
     * @throws Exception
     */
    public static String aesEncryptModeOx(String strIn) throws Exception {
        return SecretUtil.byteArr2HexStr(aesEncrypt(strIn.getBytes()));
    }

    /**
     * 加密字符串(返回16进制)
     *
     * @param strIn 需加密的字符串
     * @return 加密后的字符串
     * @throws Exception
     */
    public static String aesEncryptModeBase64(String strIn) throws Exception {
        return Base64.encodeToString(aesEncrypt(strIn.getBytes()), Base64.DEFAULT);
    }

    /**
     * 解密字节数组
     *
     * @param arrB 需解密的字节数组
     * @return 解密后的字节数组
     * @throws Exception
     */
    public static byte[] aesDecrypt(byte[] arrB) throws Exception {
        return aesDecryptCipher.doFinal(arrB);
    }

    /**
     * 解密字符串
     *
     * @param strIn 需解密的字符串
     * @return 解密后的字符串
     * @throws Exception
     */
    public static String aesDecryptModeOx(String strIn) throws Exception {
        try {
            return new String(aesDecrypt(SecretUtil.hexStr2ByteArr(strIn)));
        } catch (Exception e) {
            return "";
        }
    }
    /**
     * 解密字符串
     *
     * @param strIn 需解密的字符串
     * @return 解密后的字符串
     * @throws Exception
     */
    public static String aesDecryptModeBase64(String strIn) throws Exception {
        try {
            return new String(aesDecrypt(Base64.decode(strIn, Base64.DEFAULT)));
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * 从指定字符串生成密钥，密钥所需的字节数组长度为8位 不足8位时后面补0，超出8位只取前8位
     *
     * @param arrBTmp 构成该字符串的字节数组
     * @return 生成的密钥
     * @throws NoSuchAlgorithmException
     * @throws Exception
     */
    private static Key getAESKey(byte[] arrBTmp) throws NoSuchAlgorithmException {
        KeyGenerator keygen = KeyGenerator.getInstance("AES");
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(arrBTmp);
        keygen.init(aesSize, random);
        return keygen.generateKey();
    }

    
    private static Key generateKey(String key)throws Exception{ 
        try{            
            SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES"); 
            return keySpec; 
        }catch(Exception e){ 
            e.printStackTrace(); 
            throw e; 
        } 
 
    }
    public static void main(String[] args) {
        String szSrc = "13958189251";
        //System.out.println("加密前的字符串:" + szSrc.length());
        try {
            String src = aesEncryptModeOx(szSrc);
            System.out.println("加密后的字符串:" + new String(src));
            String text = aesDecryptModeOx("4e0fe9fb3a8705955c351f1b93f456f0");
            System.out.println("解密后的字符串:" + text);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
