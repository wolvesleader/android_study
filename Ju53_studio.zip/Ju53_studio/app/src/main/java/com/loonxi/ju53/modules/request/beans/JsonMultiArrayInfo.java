package com.loonxi.ju53.modules.request.beans;

import java.io.Serializable;
import java.util.List;

/**
 * 返回的包含flag, message, datas数组的json用该类解析
 * Created by Xuzue on 2015/12/18.
 */
public class JsonMultiArrayInfo<T> implements Serializable{
    private int flag;
    private String message;
    private List<List<T>> datas;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<List<T>> getDatas() {
        return datas;
    }

    public void setDatas(List<List<T>> datas) {
        this.datas = datas;
    }
}
