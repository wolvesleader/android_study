package com.loonxi.ju53.activity;

import com.umeng.socialize.media.WBShareCallBackActivity;


public class WBShareActivity extends WBShareCallBackActivity{
}
