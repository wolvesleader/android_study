package com.loonxi.ju53.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.AccountSafeActivity;
import com.loonxi.ju53.activity.AddressActivity;
import com.loonxi.ju53.activity.AgentActivity;
import com.loonxi.ju53.activity.CartActivity;
import com.loonxi.ju53.activity.FavActivity;
import com.loonxi.ju53.activity.FinanceActivity;
import com.loonxi.ju53.activity.MessageActivity;
import com.loonxi.ju53.activity.MyOrderActivity;
import com.loonxi.ju53.activity.SettingActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.manager.FileManager;
import com.loonxi.ju53.presenters.MinePresenter;
import com.loonxi.ju53.utils.ArrayUtil;
import com.loonxi.ju53.utils.FileImageUpload;
import com.loonxi.ju53.utils.ImageUtil;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.PicDialogCallback;
import com.loonxi.ju53.utils.PicDialogUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IMineView;
import com.loonxi.ju53.widgets.RoundImageView;
import com.loonxi.ju53.widgets.dialog.UploadPicDialog;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * “我的”fragment
 * Created by Xuzue on 2015/12/17.
 */

@ContentView(R.layout.fragment_mine)
public class MineFragment extends BaseSafeFragment<IMineView, MinePresenter> implements View.OnClickListener, IMineView, FragmentLifeCircle {

    @ViewInject(R.id.fragment_mine_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.fragment_mine_iv_head)
    private RoundImageView mIvHead;
    @ViewInject(R.id.fragment_mine_tv_nick)
    private TextView mTvNick;
    @ViewInject(R.id.fragment_mine_layout_message)
    private RelativeLayout mMessageLayout;

    @ViewInject(R.id.fragment_mine_layout_all_order)
    private LinearLayout mLayoutAllOrder;
    @ViewInject(R.id.fragment_mine_layout_dfk)
    private RelativeLayout mLayoutDfk;
    @ViewInject(R.id.fragment_mine_layout_dfk_num)
    private RelativeLayout mLayoutDfkNum;
    @ViewInject(R.id.fragment_mine_tv_dfk_num)
    private TextView mTvDfkNum;
    @ViewInject(R.id.fragment_mine_layout_dfh)
    private RelativeLayout mLayoutDfh;
    @ViewInject(R.id.fragment_mine_layout_dfh_num)
    private RelativeLayout mLayoutDfhNum;
    @ViewInject(R.id.fragment_mine_tv_dfh_num)
    private TextView mTvDfhNum;
    @ViewInject(R.id.fragment_mine_layout_dsh)
    private RelativeLayout mLayoutDsh;
    @ViewInject(R.id.fragment_mine_layout_dsh_num)
    private RelativeLayout mLayoutDshNum;
    @ViewInject(R.id.fragment_mine_tv_dsh_num)
    private TextView mTvDshNum;
    @ViewInject(R.id.fragment_mine_layout_dpj)
    private RelativeLayout mLayoutDpj;
    @ViewInject(R.id.fragment_mine_layout_dpj_num)
    private RelativeLayout mLayoutDpjNum;
    @ViewInject(R.id.fragment_mine_tv_dpj_num)
    private TextView mTvDpjNum;
    @ViewInject(R.id.fragment_mine_layout_tk)
    private RelativeLayout mLayoutTk;
    @ViewInject(R.id.fragment_mine_layout_tk_num)
    private RelativeLayout mLayoutTkNum;
    @ViewInject(R.id.fragment_mine_tv_tk_num)
    private TextView mTvTkNum;

    @ViewInject(R.id.fragment_mine_layout_order_onsale)
    private LinearLayout mLayoutOrderOnsale;
    @ViewInject(R.id.fragment_mine_tv_order_onsale)
    private TextView mTvSaleOrderNum;
    @ViewInject(R.id.fragment_mine_tv_order_buy)
    private TextView mTvBuyOrderNum;
    @ViewInject(R.id.fragment_mine_layout_order_buy)
    private LinearLayout mLayoutOrderBuy;
    @ViewInject(R.id.fragment_mine_layout_finance)
    private LinearLayout mLayoutFinance;
    @ViewInject(R.id.fragment_mine_layout_cart)
    private LinearLayout mLayoutCartManage;
    @ViewInject(R.id.fragment_mine_layout_product)
    private LinearLayout mLayoutProductManage;
    @ViewInject(R.id.fragment_mine_layout_fav)
    private LinearLayout mLayoutFav;
    @ViewInject(R.id.fragment_mine_layout_address)
    private LinearLayout mLayoutAddress;
    @ViewInject(R.id.fragment_mine_layout_setting)
    private LinearLayout mLayoutSetting;
    @ViewInject(R.id.fragment_mine_layout_account)
    private LinearLayout mLayoutAccount;

    private static int TYPE_NUM = 5;
    private volatile List<Integer> mNumList = new ArrayList<Integer>();
    private UploadPicDialog mUploadPicDialog;
    private String mPicPath = "";
    private String mPicName = "";


    @Override
    public void initView() {

    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        mLayoutAllOrder.setOnClickListener(this);
//        mIvHead.setOnClickListener(this);
        mLayoutDfh.setOnClickListener(this);
        mLayoutDsh.setOnClickListener(this);
        mLayoutDfk.setOnClickListener(this);
        mLayoutDpj.setOnClickListener(this);
        mLayoutTk.setOnClickListener(this);
        mMessageLayout.setOnClickListener(this);
        mLayoutFinance.setOnClickListener(this);
        mLayoutCartManage.setOnClickListener(this);
        mLayoutProductManage.setOnClickListener(this);
        mLayoutFav.setOnClickListener(this);
        mLayoutAddress.setOnClickListener(this);
        mLayoutSetting.setOnClickListener(this);
        mLayoutAccount.setOnClickListener(this);
        mLayoutOrderOnsale.setOnClickListener(this);
        mLayoutOrderBuy.setOnClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getOrderTotalNum();
//                mPresenter.testPhp();
//                mPresenter.testUser("0144a7afac31a592b9500fe28f878105");
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.mLog.e("mine resume");
        String currentUserId = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, "");
        String latestUserId = SpUtil.getString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_MINE, "");
        if (!StringUtil.isEmpty(latestUserId) && !latestUserId.equals(currentUserId)) {
//            initNumList();
//            displayNum();
            SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_MINE, currentUserId);
        }
        setPersonalInfo();
        if (LoginUtil.isLoginNew() && mPresenter != null) {
            mPresenter.getOrderTotalNum();
        }
    }

    /**
     * 设置个人信息
     */
    private void setPersonalInfo() {
        String name = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_NAME, "");
        String head = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_HEAD, "");
        mTvNick.setText(name);
        if (!isDetached() && mContext != null) {
            if(!StringUtil.isEmpty(head)){
                Glide.with(mContext).load(AppConst.PIC_HEAD + head + AppConst.PIC_SIZE_80).into(mIvHead);
            }else{
                Uri uri = Uri.parse("android.resource://com.loonxi.ju53/drawable/icon_head");
                Glide.with(mContext).load(uri).into(mIvHead);
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fragment_mine_iv_head:
                mPicName = System.currentTimeMillis() + ".png";
                mUploadPicDialog = new UploadPicDialog(getActivity(), mContext, "修改头像", FileManager.initCameraFolder(), mPicName);
                mUploadPicDialog.setDialogAttribute(getActivity(), Gravity.BOTTOM);
                mUploadPicDialog.show();
                break;
            case R.id.fragment_mine_layout_all_order:
                startActivity(new Intent(mContext, MyOrderActivity.class));
                break;
            case R.id.fragment_mine_layout_dfk:
                gotoOrderDetail(MyOrderActivity.ORDER_DFK_INDEX);
                break;
            case R.id.fragment_mine_layout_dfh:
                gotoOrderDetail(MyOrderActivity.ORDER_DFH_INDEX);
                break;
            case R.id.fragment_mine_layout_dsh:
                gotoOrderDetail(MyOrderActivity.ORDER_DSH_INDEX);
                break;
            case R.id.fragment_mine_layout_dpj:
                gotoOrderDetail(MyOrderActivity.ORDER_DPJ_INDEX);
                break;
            case R.id.fragment_mine_layout_tk:
                gotoOrderDetail(MyOrderActivity.ORDER_TK_INDEX);
                break;
            case R.id.fragment_mine_layout_message:
                MessageActivity.gotoMessageActivity(mContext);
                break;
            case R.id.fragment_mine_tv_nick:
                break;
            case R.id.fragment_mine_layout_finance:
                startActivity(new Intent(mContext, FinanceActivity.class));
                break;
            case R.id.fragment_mine_layout_cart:
                startActivity(new Intent(mContext, CartActivity.class));
                break;
            case R.id.fragment_mine_layout_product:
                startActivity(new Intent(mContext, AgentActivity.class));
                break;
            case R.id.fragment_mine_layout_fav:
                startActivity(new Intent(mContext, FavActivity.class));
                break;
            case R.id.fragment_mine_layout_address:
                startActivity(new Intent(mContext, AddressActivity.class));
                break;
            case R.id.fragment_mine_layout_setting:
                startActivity(new Intent(mContext, SettingActivity.class));
                break;
            case R.id.fragment_mine_layout_account:
                gotoAccountSafeActivity();
                break;
            case R.id.fragment_mine_layout_order_onsale://分销订单
                gotoOrderDetail(0, false);
                break;
            case R.id.fragment_mine_layout_order_buy://进货订单
                gotoOrderDetail(0, true);
                break;
        }
    }


    /**
     * 跳转到“账户安全”
     */
    private void gotoAccountSafeActivity() {
        if (mContext == null) {
            return;
        }
        Intent intent = new Intent(mContext, AccountSafeActivity.class);
        intent.putExtra(AccountSafeActivity.FROM_TYPE, AccountSafeActivity.FROM_MINE_FRAGMENT);
        startActivity(intent);
    }

    /**
     * 隐藏数字
     */
    private void hiddenNumLayout() {
        mLayoutDfkNum.setVisibility(View.GONE);
        mLayoutDfhNum.setVisibility(View.GONE);
        mLayoutDshNum.setVisibility(View.GONE);
        mLayoutDpjNum.setVisibility(View.GONE);
        mLayoutTkNum.setVisibility(View.GONE);
    }

    /**
     * 进入分类订单详情
     *
     * @param fragmentIndex
     */
    private void gotoOrderDetail(int fragmentIndex) {
        if (mContext == null) {
            return;
        }
        Intent intent = new Intent(mContext, MyOrderActivity.class);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_FRAGMENT_FLAG, fragmentIndex);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_ORDER_BUY, true);
        startActivity(intent);
    }

    private void gotoOrderDetail(int fragmentIndex, boolean isBuyOrder) {
        if (mContext == null) {
            return;
        }
        Intent intent = new Intent(mContext, MyOrderActivity.class);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_FRAGMENT_FLAG, fragmentIndex);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_ORDER_BUY, isBuyOrder);
        startActivity(intent);
    }


    /**
     * 各类订单数置0
     */
    private void initNumList() {
        if (mNumList != null) {
            mNumList.clear();
        }
        for (int i = 0; i < TYPE_NUM; i++) {
            mNumList.add(0);
        }
    }

    /**
     * 设置各类订单数
     *
     * @param nums
     */
    private void initNumList(String nums) {
        if (StringUtil.isEmpty(nums)) {
            return;
        }
        initNumList();
        String[] numArray = nums.split("_");
        if (ArrayUtil.isEmpty(numArray) || numArray.length < 5) {
            return;
        }
        for (int i = 0; i < numArray.length; i++) {
            mNumList.set(i, Integer.parseInt(numArray[i]));
        }
    }

    /**
     * 展示（待付款，待发货，待收货，待评价，退款）数字
     */
    private void displayNum() {
        if (mNumList == null || mNumList.size() < 5) {
            return;
        }
        //1.待付款
        int value = mNumList.get(0);
        if (value > 0) {
            mLayoutDfkNum.setVisibility(View.VISIBLE);
            mTvDfkNum.setText(value + "");
        } else {
            mLayoutDfkNum.setVisibility(View.GONE);
        }
        //2.待发货
        value = mNumList.get(1);
        if (value > 0) {
            mLayoutDfhNum.setVisibility(View.VISIBLE);
            mTvDfhNum.setText(value + "");
        } else {
            mLayoutDfhNum.setVisibility(View.GONE);
        }
        //3.待收货
        value = mNumList.get(2);
        if (value > 0) {
            mLayoutDshNum.setVisibility(View.VISIBLE);
            mTvDshNum.setText(value + "");
        } else {
            mLayoutDshNum.setVisibility(View.GONE);
        }
        //4.待评价
        value = mNumList.get(3);
        if (value > 0) {
            mLayoutDpjNum.setVisibility(View.VISIBLE);
            mTvDpjNum.setText(value + "");
        } else {
            mLayoutDpjNum.setVisibility(View.GONE);
        }
        //5.退款
        value = mNumList.get(4);
        if (value > 0) {
            mLayoutTkNum.setVisibility(View.VISIBLE);
            mTvTkNum.setText(value + "");
        } else {
            mLayoutTkNum.setVisibility(View.GONE);
        }

    }

    /**
     * 设置进货单、分销单总数
     *
     * @param nums
     */
    private void setOrderTotalNum(String nums) {
        if (StringUtil.isEmpty(nums)) {
            return;
        }
        String[] numArray = nums.split("_");
        if (ArrayUtil.isEmpty(numArray) || numArray.length < 2) {
            return;
        }
        mTvSaleOrderNum.setText(numArray[0] + "");
        mTvBuyOrderNum.setText(numArray[1] + "");

    }

    @Override
    public void fragmentPause() {
    }

    @Override
    public void fragmentResume(int position) {
        LogUtil.mLog.e("mine fragmentResume");
        if (LoginUtil.isLoginNew() && mPresenter != null) {
            mPresenter.getOrderTotalNum();
        }
    }

    @Override
    public void onGetBuyOrderNumSuccess(String nums) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        initNumList(nums);
        displayNum();
    }

    @Override
    public void onGetBuyOrderNumFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
    }

    @Override
    public void onGetOrderTotalNumSuccess(String nums) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        setOrderTotalNum(nums);
    }

    @Override
    public void onGetOrderTotalNumFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void testPhpSuccess(String content) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
    }

    @Override
    public void testPhpFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
    }

    @Override
    protected MinePresenter createPresenter(IMineView iMineView) {
        return new MinePresenter(this);
    }

    @Override
    public void onNetWorkConnected() {
        super.onNetWorkConnected();
        if (mPresenter != null) {
            mPresenter.getOrderTotalNum();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == IntentUtil.REQUEST_CODE_CAMERA || requestCode == IntentUtil.REQUEST_CODE_ALBUM) {
            PicDialogCallback callback = new PicDialogCallback(getActivity(), requestCode, resultCode,
                    data, FileManager.initCameraFolder() + mPicName);
            Bundle b = callback.onPicResult();
            if (b == null) {
                return;
            }
            mPicPath = b.getString(PicDialogUtil.ActivityResult.DATA_PATH);
            if (!StringUtil.isEmpty(mPicPath) && new File(mPicPath).exists()) {
//                IntentUtil.startPhotoZoom(getActivity(), Uri.fromFile(new File(mPicPath)));
                Bitmap bitmap = ImageUtil.getBitmapByPath(mContext, mPicPath);
                String newPicPath = FileManager.initImgFolder() + "store_head.jpg";
                boolean isSuccess = ImageUtil.compressImage(bitmap, newPicPath, ApiConst.Common.MINI_PIC_MAX_SIZE);
                if (isSuccess) {
                    uploadPic(new File(newPicPath));
                } else {
                    showToast("头像保存失败，请重试");
                }
            }
        } else if (requestCode == IntentUtil.REQUEST_CODE_CROP) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Bitmap bitmap = data.getParcelableExtra("data");
                String newPicPath = FileManager.initImgFolder() + "store_head.jpg";
                boolean isSuccess = ImageUtil.compressImage(bitmap, newPicPath, ApiConst.Common.MINI_PIC_MAX_SIZE);
                if (isSuccess) {
//                    showToast("头像保存成功");
                    uploadPic(new File(newPicPath));
                } else {
                    showToast("头像保存失败，请重试");
                }
            } else {
                showToast("取消操作");
            }
        }
    }


    /**
     * 上传头像
     */
    private void uploadPic(File file) {
        AsyncTask<File, Void, String> uploadTask = new AsyncTask<File, Void, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                showLoadingDialog();
            }

            @Override
            protected String doInBackground(File... params) {
                String url = ApiConst.URL_ROOT_LOCAL_DEV_PHP + ApiConst.URL_UPLOAD_PIC_USER_HEAD;
                String result = FileImageUpload.uploadFile(params[0], url);
                return result;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                dismissLoadingDialog();
                dealResult(s);
            }
        };
        uploadTask.execute(file);
    }

    /**
     * 上传图片结果处理
     *
     * @param result
     */
    private void dealResult(String result) {
        if (!StringUtil.isEmpty(result)) {
            LogUtil.mLog().e(result);
            try {
                JSONObject object = new JSONObject(result);
                String flag = object.optString("flag");
                String message = object.optString("message");
                String newUrl = object.optString("data");
                if ("0".equals(flag)) {
                    showToast(message);
                } else if ("1".equals(flag)) {
                    showToast("上传成功");
                    if (!StringUtil.isEmpty(newUrl)) {
                        Glide.with(mContext).load(AppConst.PIC_HEAD + newUrl).into(mIvHead);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
                showToast("上传失败");
            }
        } else {
            showToast("上传失败");
        }
    }

}
