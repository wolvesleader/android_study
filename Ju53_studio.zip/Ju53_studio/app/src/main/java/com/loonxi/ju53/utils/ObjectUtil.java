package com.loonxi.ju53.utils;

/**
 * Created by Xuzue on 2015/9/1.
 */
public class ObjectUtil {

    /**
     * 比较是否相等
     * @param actual
     * @param expected
     * @return
     */
    public static boolean isEquals(Object actual, Object expected){
        return actual == null ? expected == null : actual.equals(expected);
    }

    /**
     * long数组转换为Long数组
     * @param source
     * @return
     */
    public static Long[] transformLongArray(long[] source){
        Long[] dest = new Long[source.length];
        for(int i = 0; i < source.length; i++){
            dest[i] = source[i];
        }
        return dest;
    }

    /**
     * Long数组转换为long数组
     * @param source
     * @return
     */
    public static long[] transformLongArray(Long[] source){
        long[] dest = new long[source.length];
        for(int i = 0; i < source.length; i++){
            dest[i] = source[i];
        }
        return dest;
    }

    /**
     * int数组转换为Integer数组
     * @param source
     * @return
     */
    public static Integer[] transformIntArray(int[] source){
        Integer[] dest = new Integer[source.length];
        for (int i = 0; i < source.length; i++){
            dest[i] = source[i];
        }
        return dest;
    }

    /**
     * Integer数组转换为int数组
     * @param source
     * @return
     */
    public static int[] transformIntArray(Integer[] source){
        int[] dest = new int[source.length];
        for (int i = 0; i < source.length; i++){
            dest[i] = source[i];
        }
        return dest;
    }



}
