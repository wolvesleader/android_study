package com.loonxi.ju53.database;

import com.loonxi.ju53.utils.Logger;

import org.xutils.DbManager;
import org.xutils.ex.DbException;

/**
 * 数据库更新辅助类
 * Created by Xuzue on 2015/12/16.
 */
public class DBUpdateHelper {

    public static void onUpgrade(DbManager db, int oldVersion, int newVersion) {
        try {
            switch (oldVersion) {
                case 1:
                    Logger.i("alter table home_entity");
                    db.execNonQuery("ALTER TABLE home_entity ADD COLUMN demo TEXT");
                    break;
            }
        } catch (DbException e) {
            e.printStackTrace();
        }
    }

}
