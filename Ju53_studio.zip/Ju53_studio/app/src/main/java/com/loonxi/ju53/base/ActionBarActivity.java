package com.loonxi.ju53.base;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.x;

/**
 * Created by Xuzue on 2015/12/17.
 */
public abstract class ActionBarActivity extends BaseActivity {


    private View mViewParent;
    private LinearLayout mLayoutContent;
    private ActionBar mActionBar;
    private View mViewContent;

    public abstract void initView();
    public abstract void initContent();
    public abstract void setListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mViewParent = LayoutInflater.from(this).inflate(R.layout.activity_actionbar, null);
        mLayoutContent = (LinearLayout) mViewParent.findViewById(R.id.actionbar_content);
        mActionBar = (ActionBar) mViewParent.findViewById(R.id.actionbar);
    }

    @Override
    public void setContentView(int layoutResID) {
        mViewContent = LayoutInflater.from(this).inflate(layoutResID, null);
        mLayoutContent.addView(mViewContent, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        super.setContentView(mViewParent);
        x.view().inject(this, mViewParent);
        initView();
        setListener();
        initContent();
    }

    @Override
    public void setContentView(View view) {
        mViewContent = view;
        mLayoutContent.addView(mViewContent);
        super.setContentView(mViewParent);
        x.view().inject(this, mViewParent);
        initView();
        setListener();
        initContent();
    }

    @Override
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        mViewContent = view;
        mLayoutContent.addView(view, params);
        super.setContentView(mViewParent, params);
        x.view().inject(this, mViewParent);
        initView();
        setListener();
        initContent();
    }

    protected void setBackgroundColorResource(int resId){
        mActionBar.setBackgroundColorResource(resId);
    }

    protected void setLeftImageResource(int resId){
        mActionBar.setLeftImageResource(resId);
    }

    protected void setLeftImageDrawable(Drawable drawable){
        mActionBar.setLeftImageDrawable(drawable);
    }

    protected void setLeftImageBitmap(Bitmap bitmap){
        mActionBar.setLeftImageBitmap(bitmap);
    }

    protected void setLeftWidth(int width){
        mActionBar.setLeftWidth(width);
    }

    protected void setLeftVisibility(int visibility){
        mActionBar.setLeftVisibility(visibility);
    }

    protected void setLeftImgVisibility(int visibility){
        mActionBar.setLeftImgVisibility(visibility);
    }

    protected void setLeftText(int resId){
        mActionBar.setLeftText(resId);
    }

    protected void setLeftText(String text){
        mActionBar.setLeftText(text);
    }

    protected void setLeftTextSize(int size){

    }

    protected void setLeftTextVisibility(int visibility){
        mActionBar.setLeftTextVisibility(visibility);
    }

    protected ImageView getLeftImage(){
        return mActionBar.getLeftImage();
    }

    protected LinearLayout getLeftLayout(){
        return mActionBar.getLeftLayout();
    }

    protected void setTitle(String title){
        mActionBar.setTitle(title);
    }

    public void setTitle(int resId){
        mActionBar.setTitle(resId);
    }

    protected void setTitleSize(float size){
        mActionBar.setTitleSize(size);
    }

    protected void setTitlecolor(int color){
        mActionBar.setTitleColor(color);
    }

    protected void setTitleVisibility(int visibility){
        mActionBar.setTitleVisibility(visibility);
    }

    protected void setTitleImgVisibility(int visibility){
        mActionBar.setTitleImgVisibility(visibility);
    }

    protected void setTitleImgResource(int resId){
        mActionBar.setTitleImgResource(resId);
    }

    protected void setTitleImgDrawable(Drawable drawable){
        mActionBar.setTitleImgDrawable(drawable);
    }

    protected TextView getTitleTextView(){
        return mActionBar.getTitleTextView();
    }

    protected LinearLayout getTitleLayout(){ return mActionBar.getTitleLayout();}

    protected void setMiddleVisibility(int visibility){
        mActionBar.setMiddleVisibility(visibility);
    }

    protected void setMiddleImageVisibility(int visibility){
        mActionBar.setMiddleImageVisibility(visibility);
    }

    protected void setMiddleTextVisibility(int visibility){
        mActionBar.setMiddleTextViewVisibility(visibility);
    }

    protected void setMiddleImageResource(int resId){
        mActionBar.setMiddleImageResource(resId);
    }

    protected void setMiddleImageDrawable(Drawable drawable){
        mActionBar.setMiddleImageDrawable(drawable);
    }

    protected void setMiddleImageBitmap(Bitmap bitmap){
        mActionBar.setMiddleImageBitmap(bitmap);
    }

    protected void setMiddleText(String text){
        mActionBar.setMiddleText(text);
    }

    protected void setMiddleText(int resId){
        mActionBar.setMiddleText(resId);
    }

    protected LinearLayout getMiddleLayout(){
        return mActionBar.getMiddleLayout();
    }

    protected ImageView getMiddleImage(){
        return mActionBar.getMiddleImage();
    }

    protected TextView getMiddleTextView(){
        return mActionBar.getMiddleTextView();
    }

    protected void setRightVisibility(int visibility){
        mActionBar.setRightVisibility(visibility);
    }

    protected void setRightTextVisibility(int visibility){
        mActionBar.setRightTextVisibility(visibility);
    }

    protected void setRightImageResource(int resId){
        mActionBar.setRightImageResource(resId);
    }

    protected void setRightImageDrawable(Drawable drawable){
        mActionBar.setRightImageDrawable(drawable);
    }

    protected void setRightImageBitmap(Bitmap bitmap){
        mActionBar.setRightImageBitmap(bitmap);
    }

    protected void setRightText(String text){
        mActionBar.setRightText(text);
    }

    protected void setRightText(int resId){
        mActionBar.setRightText(resId);
    }

    protected LinearLayout getRightLayout(){
        return mActionBar.getRightLayout();
    }

    protected ImageView getRightImage(){
        return mActionBar.getRightImage();
    }

    protected TextView getRightTextView(){
        return mActionBar.getRightTextView();
    }

    protected void setLineVisibility(int visibility){
        mActionBar.setLineVisibility(visibility);
    }

    protected void setOnLeftClickListener(View.OnClickListener listener){
        mActionBar.setOnLeftClickListener(listener);
    }

    protected void setOnTitleClickListener(View.OnClickListener listener){
        mActionBar.setOnTitleClickListener(listener);
    }

    protected void setOnMiddleClickListener(View.OnClickListener listener){
        mActionBar.setOnMiddleClickListener(listener);
    }

    protected void setOnRightClickListener(View.OnClickListener listener){
        mActionBar.setOnRightClickListener(listener);
    }


}
