package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.fragment.CashAccountFragment;
import com.loonxi.ju53.presenters.CashAccountSetPresenter;
import com.loonxi.ju53.widgets.ActionBar;

/**
 * 提现账户
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashAccountActivity extends ActionBarActivity implements View.OnClickListener {

    private boolean mHasCashing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cash_account);
    }

    @Override
    public void initView() {

    }

    @Override
    public void initContent() {
        mHasCashing = getIntent().getBooleanExtra("hasCashing", false);
        showAccountFragment();
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case ActionBar.LEFT_CLICK_ID:
                back();
                break;
        }
    }

    private void back() {
        if(getSupportFragmentManager() != null && getSupportFragmentManager().getBackStackEntryCount() > 0){
            getSupportFragmentManager().popBackStack();
        }else {
            finish();
        }
    }

    private void showAccountFragment(){
        CashAccountFragment mAccountFragment = new CashAccountFragment();
        Bundle b = new Bundle();
        b.putBoolean("hasCashing", mHasCashing);
        mAccountFragment.setArguments(b);
        FragmentTransaction mTransaction = getSupportFragmentManager().beginTransaction();
        mTransaction.add(R.id.cash_account_container, mAccountFragment);
        mTransaction.commitAllowingStateLoss();

    }

    public void setTitle(boolean isBack){
        setTitle(isBack ? "设置提现账户" : "提现账户");
    }

    @Override
    public void onBackPressed() {
        back();
    }
}
