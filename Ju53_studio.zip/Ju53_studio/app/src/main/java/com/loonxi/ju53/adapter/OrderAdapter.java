package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.OrderDetailActivity;
import com.loonxi.ju53.activity.RefundActivity;
import com.loonxi.ju53.activity.SendCommentActivity;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.OrderState;
import com.loonxi.ju53.convert.OrderDataConvert;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.fragment.MyOrderContentFragment;
import com.loonxi.ju53.listener.OrderContentListener;
import com.loonxi.ju53.presenters.OrderPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.widgets.FixedListView;

import java.util.List;

/**
 * "进货订单adapter"
 * Created by Xuzue on 2016/1/7.
 */
public class OrderAdapter extends BaseObjectListAdapter<OrderEntity> {

    private OrderPresenter mPresenter;
    private OrderContentListener mListener;
    private int mCurrentNum;
    private MyOrderContentFragment mFragment;

    public OrderAdapter(Context context, MyOrderContentFragment fragment, int currentNum, List<OrderEntity> datas, OrderPresenter presenter, OrderContentListener listener) {
        super(context, datas);
        mPresenter = presenter;
        mListener = listener;
        mCurrentNum = currentNum;
        mFragment = fragment;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_order_parent, null);
            holder.mLayoutCompany = (LinearLayout) convertView.findViewById(R.id.listitem_order_parent_layout_company);
            holder.mTvCompanyName = (TextView) convertView.findViewById(R.id.listitem_order_parent_tv_company);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_order_parent_tv_status);
            holder.mFlv = (FixedListView) convertView.findViewById(R.id.listitem_order_parent_flv);
            holder.mTvTotal = (TextView) convertView.findViewById(R.id.listitem_order_parent_tv_total);
            holder.mLayoutBottom = (LinearLayout) convertView.findViewById(R.id.listitem_order_parent_layout_bottom);
            holder.mBtnPay = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_pay);
            holder.mBtnCancel = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_cancel);
            holder.mBtnConfirmReceived = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_confirm_received);
            holder.mBtnRefund = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_refund);
            holder.mBtnInterflow = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_interflow);
            holder.mBtnRecommend = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_recommend);
            holder.mBtnView = (TextView) convertView.findViewById(R.id.listitem_order_parent_btn_view);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        OrderEntity order = get(position);
        holder.mTvCompanyName.setText(order.getCustomName());
        setStatus(holder, order);
        setButton(holder, order.getState(), order.getFormerState());
        Spanned total = Html.fromHtml("共" + order.getOrderNum() + "件商品合计: <font color=\"#ee0c00\">¥" + order.getOrderSum() + "</font> (含运费" + order.getFreight() + "元)");
        holder.mTvTotal.setText(total);

        OrderChildAdapter childAdapter = new OrderChildAdapter(mContext, mFragment, mCurrentNum == 5 ? true : false, order, order.getAttrs());
        holder.mFlv.setAdapter(childAdapter);
        setListener(holder, order, position);
        return convertView;
    }

    /**
     * @param holder
     * @param state 订单目前状态
     * @param formerState 申请退款是订单的状态
     */
    private void setButton(ViewHolder holder, int state, int formerState) {
        if (holder == null) {
            return;
        }
        switch (state) {
            case OrderState.WAIT_PAY:
                holder.mBtnPay.setVisibility(View.VISIBLE);
                holder.mBtnCancel.setVisibility(View.VISIBLE);
                holder.mBtnRecommend.setVisibility(View.GONE);
                holder.mBtnConfirmReceived.setVisibility(View.GONE);
                holder.mBtnRefund.setVisibility(View.GONE);
                holder.mBtnInterflow.setVisibility(View.GONE);
                holder.mBtnView.setVisibility(View.GONE);
                break;
            case OrderState.CANCEL:
                holder.mBtnPay.setVisibility(View.GONE);
                holder.mBtnCancel.setVisibility(View.GONE);
                holder.mBtnRecommend.setVisibility(View.GONE);
                holder.mBtnConfirmReceived.setVisibility(View.GONE);
                holder.mBtnRefund.setVisibility(View.GONE);
                if(mCurrentNum == 5 && formerState == OrderState.PAYED){
                    holder.mBtnInterflow.setVisibility(View.GONE);
                    holder.mBtnView.setVisibility(View.VISIBLE);
                }else {
                    holder.mBtnInterflow.setVisibility(View.VISIBLE);
                    holder.mBtnView.setVisibility(View.GONE);
                }
                break;
            case OrderState.PAYED:
                holder.mBtnPay.setVisibility(View.GONE);
                holder.mBtnCancel.setVisibility(View.GONE);
                holder.mBtnRecommend.setVisibility(View.GONE);
                holder.mBtnConfirmReceived.setVisibility(View.GONE);
                holder.mBtnRefund.setVisibility(View.GONE);
                holder.mBtnInterflow.setVisibility(View.GONE);
                holder.mBtnView.setVisibility(View.VISIBLE);
                break;
            case OrderState.WAIT_RECEIVE:
                holder.mBtnPay.setVisibility(View.GONE);
                holder.mBtnCancel.setVisibility(View.GONE);
                holder.mBtnRecommend.setVisibility(View.GONE);
                holder.mBtnConfirmReceived.setVisibility(View.VISIBLE);
                holder.mBtnRefund.setVisibility(View.GONE);
                holder.mBtnInterflow.setVisibility(View.VISIBLE);
                holder.mBtnView.setVisibility(View.GONE);
                break;
            case OrderState.CONFIRM_RECEIVED:
                holder.mBtnPay.setVisibility(View.GONE);
                holder.mBtnCancel.setVisibility(View.GONE);
                holder.mBtnRecommend.setVisibility(View.VISIBLE);
                holder.mBtnConfirmReceived.setVisibility(View.GONE);
                holder.mBtnRefund.setVisibility(View.GONE);
                holder.mBtnInterflow.setVisibility(View.VISIBLE);
                holder.mBtnView.setVisibility(View.GONE);
                break;
            case OrderState.RECOMMENDS_BUYER:
            case OrderState.RECOMMENDS_SALER:
            case OrderState.RECOMMENDS_BOTH:
                holder.mBtnPay.setVisibility(View.GONE);
                holder.mBtnCancel.setVisibility(View.GONE);
                holder.mBtnRecommend.setVisibility(View.GONE);
                holder.mBtnConfirmReceived.setVisibility(View.GONE);
                holder.mBtnRefund.setVisibility(View.GONE);
                holder.mBtnInterflow.setVisibility(View.GONE);
                holder.mBtnView.setVisibility(View.GONE);
                break;
        }
    }

    /**
     * 设置状态
     *
     * @param holder
     * @param order
     */
    private void setStatus(ViewHolder holder, OrderEntity order) {
        if (holder == null || order == null) {
            return;
        }
        int status = order.getState();
//        if (mCurrentNum == 5) {//退款
//            holder.mTvStatus.setText("");
//        } else {
//            OrderState.setOrderState(holder.mTvStatus, status);
//        }
        OrderState.setOrderState(holder.mTvStatus, status);
    }

    private void setListener(ViewHolder holder, final OrderEntity order, final int position) {
        if (holder == null || order == null) {
            return;
        }
        holder.mLayoutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", order.getSupplierId() + "");
                intent.putExtra("userName", order.getCustomName());
                mContext.startActivity(intent);
            }
        });
        //付款
        holder.mBtnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPresenter.payOrder(order.getPayId(), order.getOrderId(), order.getUserId() + "", order.getOrderSum());
            }
        });
        //关闭订单
        holder.mBtnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPresenter.closeOrder(order.getPid() + "");
            }
        });
        //查看物流
        holder.mBtnInterflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPresenter.getOrderTrans(order.getOrderId());
            }
        });
        //退款
        holder.mBtnRefund.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, RefundActivity.class);
                OrderUnitEntity unit = ListUtil.isEmpty(order.getAttrs()) ? null : order.getAttrs().get(position);
                intent.putExtra("orderEntity", order);
                intent.putExtra("orderUnitEntity", unit);
                intent.putExtra("product", OrderDataConvert.orderUnitEntity2BaseProductEntity(unit));
                mFragment.startActivityForResult(intent, MyOrderContentFragment.REQUEST_CODE_REFUND);
            }
        });
        //评价
        holder.mBtnRecommend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              gotoSendCommentActivity(order);
            }
        });
        //确认收货
        holder.mBtnConfirmReceived.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.showPayConfirmDialog(order);
                }
            }
        });
        //查看
        holder.mBtnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, OrderDetailActivity.class);
                intent.putExtra("order", order);
                mFragment.startActivityForResult(intent, MyOrderContentFragment.REQUEST_CODE_ORDER_DETAIL);
            }
        });
    }


    /**
     * 跳转到“评价”Activity
     * @param orderEntity
     */
    private void gotoSendCommentActivity(OrderEntity orderEntity){
        if(mContext==null || orderEntity==null||orderEntity.getAttrs()==null){
            return;
        }
        Intent intent=new Intent(mContext, SendCommentActivity.class);
        intent.putExtra("orderEntity",orderEntity);
        mContext.startActivity(intent);
    }

    class ViewHolder {
        LinearLayout mLayoutCompany;
        TextView mTvCompanyName;
        TextView mTvStatus;
        FixedListView mFlv;
        TextView mTvTotal;
        LinearLayout mLayoutBottom;
        TextView mBtnPay;
        TextView mBtnCancel;
        TextView mBtnConfirmReceived;
        TextView mBtnRecommend;
        TextView mBtnRefund;
        TextView mBtnInterflow;
        TextView mBtnView;
    }
}
