package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.jungly.gridpasswordview.GridPasswordView;
import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.listener.OnGridPasswordViewListener;
import com.loonxi.ju53.utils.SoftInputUtil;
import com.loonxi.ju53.widgets.ActionBar;

/**
 * 输入密码Dialog
 * Created by Xuzue on 2016/1/25.
 */
public class PayPasswordDialog extends Dialog {

    private Context mContext;
    private ActionBar mActionBar;
    private GridPasswordView mPasswordView;
    private EditText mEdtPsw;
    private TextView mBtnConfirm;
    private OnGridPasswordViewListener mListener;
    private View.OnClickListener mClickListener;


    public PayPasswordDialog(Context context, OnGridPasswordViewListener listener) {
        super(context, R.style.cartdialog_style);
        mContext = context;
        mListener = listener;
        init();
    }

    public PayPasswordDialog(Context context, View.OnClickListener listener) {
        super(context, R.style.cartdialog_style);
        mContext = context;
        mClickListener = listener;
        init();
    }

    private void init(){
        setContentView(R.layout.dialog_pay_password);
        setCancelable(true);
        initView();
    }

    private void initView() {
        mActionBar = (ActionBar) findViewById(R.id.dialog_pay_password_actionbar);
        mPasswordView = (GridPasswordView) findViewById(R.id.dialog_pay_password_gpv);
        mEdtPsw = (EditText) findViewById(R.id.dialog_pay_password_edt);
        mBtnConfirm = (TextView) findViewById(R.id.dialog_pay_password_btn_confirm);
        mBtnConfirm.setEnabled(false);
        mEdtPsw.requestFocus();
        SoftInputUtil.openKeybord(mEdtPsw, BaseApplication.instance);
        mActionBar.setTitle(R.string.order_detail_input_psw);
        mActionBar.setOnLeftClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideSoftInput();
                dismiss();
            }
        });
        mEdtPsw.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    mBtnConfirm.setEnabled(true);
                } else {
                    mBtnConfirm.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        mPasswordView.setOnPasswordChangedListener(new GridPasswordView.OnPasswordChangedListener() {
            @Override
            public void onTextChanged(String psw) {
                if (mListener != null) {
                    mListener.textChanged(psw);
                }
            }

            @Override
            public void onInputFinish(String psw) {
                if (mListener != null) {
                    mListener.inputFinish(psw);
                }
            }
        });
        mBtnConfirm.setOnClickListener(mClickListener);
    }

    /**
     * 获取输入的密码
     * @return
     */
    public String getPassword(){
        return mEdtPsw.getText().toString();
    }

    /**
     * 隐藏键盘
     */
    public void hideSoftInput(){
        SoftInputUtil.closeKeybord(mEdtPsw, mContext);
    }

    /**
     * 设置dialog属性（宽度，对齐方式等）
     *
     * @param activity
     * @param gravity
     */
    public void setDialogAttribute(Activity activity, int gravity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = (int) display.getWidth();
        lp.gravity = gravity;
        getWindow().setAttributes(lp);
    }
}
