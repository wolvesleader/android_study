package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.RegistAuthEntity;
import com.loonxi.ju53.models.IRegistModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.service.AccountService;
import com.loonxi.ju53.utils.Logger;
import com.loonxi.ju53.utils.MapUtil;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/5.
 */
public class RegisterModel implements IRegistModel{



    @Override
    public Call<BaseJsonInfo> getCheckCode(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Logger.i("url:" + MapUtil.toUrlString(map));
        Call<BaseJsonInfo> call = Request.creatApi(AccountService.class).getCheckCode(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> checkCodeIsCorrect(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(AccountService.class).verifyCode(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<RegistAuthEntity> auth(Map<String, Object> map, Callback<RegistAuthEntity> callback) {
        Call<RegistAuthEntity> call = Request.creatApi(AccountService.class).auth(map);
        call.enqueue(callback);
        return call;
    }


}
