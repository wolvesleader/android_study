package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.OrderConfirmActivity;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.widgets.FixedListView;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class OrderConfirmAdapter extends BaseObjectListAdapter<CartEntity> {

    private OrderConfirmActivity mActivity;

    public OrderConfirmAdapter(Context context, List<CartEntity> datas) {
        super(context, datas);
        mActivity = (OrderConfirmActivity)context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_order_confirm_parent, null);
            holder.mLayoutCompany = (LinearLayout) convertView.findViewById(R.id.listitem_order_confirm_parent_layout_company);
            holder.mTvCompanyName = (TextView) convertView.findViewById(R.id.listitem_order_confirm_parent_tv_company);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_order_confirm_parent_tv_status);
            holder.mFlv = (FixedListView) convertView.findViewById(R.id.listitem_order_confirm_parent_flv);
            holder.mLayoutFreight = (LinearLayout) convertView.findViewById(R.id.listitem_order_confirm_parent_layout_freight);
            holder.mTvFreight = (TextView) convertView.findViewById(R.id.listitem_order_confirm_parent_tv_freight);
            holder.mTvNotes = (EditText) convertView.findViewById(R.id.listitem_order_confirm_parent_edt_notes);
            holder.mTvTotal = (TextView) convertView.findViewById(R.id.listitem_order_confirm_parent_tv_total);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        CartEntity cart = get(position);
        holder.mTvCompanyName.setText(cart.getUserName());
        Spanned total = Html.fromHtml("共" + cart.getTotalCount() + "件商品合计: <font color=\"#ee0c00\">¥" + cart.getTotalFee() + "</font> (含运费" + cart.getTotalFreight() + "元)");
        holder.mTvTotal.setText(total);
        holder.mTvStatus.setText("");
        OrderConfirmChildAdapter childAdapter = new OrderConfirmChildAdapter(mContext, cart.getList());
        holder.mFlv.setAdapter(childAdapter);
        setListener(holder, cart, position);
        return convertView;
    }

    private void setListener(final ViewHolder holder, final CartEntity cart, final int position) {
        if(holder == null){
            return;
        }
        holder.mLayoutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", cart.getSupperId());
                intent.putExtra("userName", cart.getUserName());
                mContext.startActivity(intent);
            }
        });
        holder.mTvNotes.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(mActivity != null){
//                    mActivity.setCartNotes(position, holder.mTvNotes.getText().toString());
                }
            }
        });
    }

    public static class ViewHolder {
        LinearLayout mLayoutCompany;
        TextView mTvCompanyName;
        TextView mTvStatus;
        FixedListView mFlv;
        LinearLayout mLayoutFreight;
        TextView mTvFreight;
        public EditText mTvNotes;
        TextView mTvTotal;
    }
}
