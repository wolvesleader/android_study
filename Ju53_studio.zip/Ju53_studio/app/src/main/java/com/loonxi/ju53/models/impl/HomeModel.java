package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.entity.IndexJsonInfo;
import com.loonxi.ju53.entity.MainTabEntity;
import com.loonxi.ju53.models.IHomeModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.service.IndexService;
import com.loonxi.ju53.repos.PrefsRepos;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/18.
 */
public class HomeModel implements IHomeModel {
    /**
     * 获取首页内容
     *
     * @param callback
     */
    @Override
    public Call<IndexJsonInfo> getIndexContent(Map<String, Object> map, Callback<IndexJsonInfo> callback) {
        Call<IndexJsonInfo> call = Request.creatApi(IndexService.class, 3).getIndexContent(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取推荐宝贝
     *
     * @param callback
     */
    @Override
    public Call<JsonArrayInfo<IndexEntity>> getRecommends(Map<String, Object> map, Callback<JsonArrayInfo<IndexEntity>> callback) {
        Call<JsonArrayInfo<IndexEntity>> call = Request.creatApi(IndexService.class).getRecommends(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获得版本信息
     *
     * @param callback
     * @return
     */
    @Override
    public Call<GetVersionEntity> getVersion(Callback<GetVersionEntity> callback) {
        if (callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        Call<GetVersionEntity> call = Request.creatApi(IndexService.class).getVersion(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<MainTabEntity>> getMainTab(Callback<JsonArrayInfo<MainTabEntity>> callback) {
        if (callback == null) {
            return null;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap(false);
        //PHP接口使用Neweqeust
        Call<JsonArrayInfo<MainTabEntity>> call = NewRequest.creatApi(IndexService.class).getMainTab(map);
        call.enqueue(callback);
        return call;
    }

}
