package com.loonxi.ju53.utils;

import android.content.Context;
import android.content.Intent;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.entity.LogisticsEntity;

import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Xuzue on 2016/2/25.
 */
public class InterflowUtil {


    /**
     * 查看物流
     *
     * @param mContext
     * @param logisticsEntity
     */
    public static void gotoInterflowActivity(Context mContext, LogisticsEntity logisticsEntity) {
        if (mContext == null) {
            return;
        }
        String url = initUrl(logisticsEntity);
        String title = mContext.getResources().getString(R.string.webview_logistics_title);
        Intent webViewIntent = new Intent(mContext, CommonWebviewActivity.class);
        webViewIntent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, url);
        webViewIntent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, title);
        mContext.startActivity(webViewIntent);
    }

    /**
     * 生成url
     *
     * @param logisticsEntity
     * @return
     */
    private static String initUrl(LogisticsEntity logisticsEntity) {
        Map<String, Object> map = new TreeMap<>();
        map.put("tplid", logisticsEntity == null ? "" : logisticsEntity.getTplcom());
        map.put("transId", logisticsEntity == null ? "" : logisticsEntity.getPostid());
        String temp = MapUtil.toUrlString(map);
        return ApiConst.TRANS_ORDER_URL + temp;
    }
}
