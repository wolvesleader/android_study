package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.List;

/**
 * 订单详情
 * Created by Xuzue on 2016/1/25.
 */
public class OrderDetailEntity extends BaseJsonInfo implements Parcelable {
    private OrderAddressEntity address;
    private List<OrderTime> time;
    private OrderEntity order;

    public OrderDetailEntity(){

    }

    protected OrderDetailEntity(Parcel in) {
        super(in);
        address = in.readParcelable(OrderAddressEntity.class.getClassLoader());
        time = in.createTypedArrayList(OrderTime.CREATOR);
        order = in.readParcelable(OrderEntity.class.getClassLoader());
    }


    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(address, flags);
        dest.writeTypedList(time);
        dest.writeParcelable(order, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<OrderDetailEntity> CREATOR = new Creator<OrderDetailEntity>() {
        @Override
        public OrderDetailEntity createFromParcel(Parcel in) {
            return new OrderDetailEntity(in);
        }

        @Override
        public OrderDetailEntity[] newArray(int size) {
            return new OrderDetailEntity[size];
        }
    };

    public OrderAddressEntity getAddress() {
        return address;
    }

    public void setAddress(OrderAddressEntity address) {
        this.address = address;
    }

    public List<OrderTime> getTime() {
        return time;
    }

    public void setTime(List<OrderTime> time) {
        this.time = time;
    }

    public OrderEntity getOrder() {
        return order;
    }

    public void setOrder(OrderEntity order) {
        this.order = order;
    }

}
