package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.View;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.web.BaseWebView;
import com.loonxi.ju53.widgets.ScrollSwipeRefreshLayout;

/**
 * webView activity
 * Created by Administrator on 2016/1/20.
 */
public class CommonWebviewActivity extends ActionBarActivity {

    private BaseWebView mWebView;
    private ScrollSwipeRefreshLayout mSsr;

    public static String ARG_APP_TOP = "top";
    public static String ARG_URL_VALUE = "URL";//url
    public static String ARG_TITLE_VALUE = "title";//title
    private String mUrl;
    private String mTitle;
    private boolean mIsTop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview_layout);
    }

    @Override
    public void initView() {
        mWebView = (BaseWebView) findViewById(R.id.activity_base_web_view);
        mSsr = (ScrollSwipeRefreshLayout) findViewById(R.id.activity_sp_refresh);
        mIsTop = getIntent().getBooleanExtra(ARG_APP_TOP, true);
        mUrl = getIntent().getStringExtra(ARG_URL_VALUE);
        mTitle = getIntent().getStringExtra(ARG_TITLE_VALUE);
        setTitle(mTitle);
    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        setOnLeftClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        mWebView.setOnWebViewListener(new BaseWebView.onWebViewListener() {
            @Override
            public void onHtmlFinsh() {
                if (mSsr != null && mSsr.isRefreshing()) {
                    mSsr.setRefreshing(false);
                }
            }
        });


        mSsr.setEnabled(false);

//        if (mWebView.getRefreshEnable()) {
//            mSsr.setEnabled(true);
//            mSsr.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//                @Override
//                public void onRefresh() {
//                    mWebView.refResh();
//                }
//            });
//        } else {
//            mSsr.setEnabled(false);
//        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUrl();
    }

    private void loadUrl() {
        if (TextUtils.isEmpty(mUrl)) {
            return;
        }
        mWebView.start(mUrl);
    }

    @Override
    public void onBackPressed() {
        back();
    }

    private void back() {
        if (!mIsTop) {
            Intent intent = new Intent(mContext, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            mContext.startActivity(intent);
        }
        finish();
    }
}
