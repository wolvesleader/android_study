package com.loonxi.ju53.entity;

import java.io.Serializable;

/**
 * Created by Xuzue on 2015/12/17.
 */
public class FileEntity implements Serializable {
    private String date;
    private String size;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
