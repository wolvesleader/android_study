package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.StoreProductExtraEntity;
import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/11.
 */
public interface IStoreProductDetailModel {
    Call<JsonInfo<ProductDetailEntity>> getBaseInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback);

    Call<JsonInfo<ProductDetailEntity>> getDetailInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback);

    Call<BaseJsonInfo> offSale(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> onSale(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<JsonInfo<StoreProductExtraEntity>> getExtraInfo(Map<String, Object> map, Callback<JsonInfo<StoreProductExtraEntity>> callback);
}
