package com.loonxi.ju53.listener;

import android.widget.Toast;

import com.loonxi.ju53.base.BaseApplication;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.Map;

/**
 * 友盟取消授权监听
 * Created by Xuzue on 2016/4/6.
 */
public class UmengDelAuthListener implements UMAuthListener {
    @Override
    public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {
        Toast.makeText(BaseApplication.instance, "取消授权成功", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
        Toast.makeText(BaseApplication.instance, "取消授权失败", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCancel(SHARE_MEDIA share_media, int i) {
        Toast.makeText(BaseApplication.instance, "取消授权取消", Toast.LENGTH_SHORT).show();
    }
}
