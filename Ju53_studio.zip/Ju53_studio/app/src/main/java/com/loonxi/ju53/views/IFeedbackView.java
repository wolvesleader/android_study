package com.loonxi.ju53.views;

/**
 * Created by Xuzue on 2016/2/19.
 */
public interface IFeedbackView extends IBaseView{
    void onFeedbackSuccess();
    void onFeedbackFailed(int apiErrorCode, String message);
}
