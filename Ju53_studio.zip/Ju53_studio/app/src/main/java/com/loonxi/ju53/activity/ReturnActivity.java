package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

/**
 * 退货
 * Created by Xuzue on 2016/1/15.
 */
public class ReturnActivity extends ActionBarActivity implements View.OnClickListener {
    @ViewInject(R.id.return_layout_interflow)
    private LinearLayout mLayoutInterflowCompany;
    @ViewInject(R.id.return_edt_order_no)
    private EditText mEdtInterflowNo;
    @ViewInject(R.id.return_iv_scan)
    private ImageView mIvScan;
    @ViewInject(R.id.return_edt_tel)
    private EditText mEdtTel;
    @ViewInject(R.id.return_edt_description)
    private EditText mEdtDescription;
    @ViewInject(R.id.return_layout_camera)
    private LinearLayout mLayoutCamera;
    @ViewInject(R.id.return_layout_apply)
    private LinearLayout mLayoutApply;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return);
    }

    @Override
    public void initView() {
        setTitle(R.string.return_title);

    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mLayoutInterflowCompany.setOnClickListener(this);
        mIvScan.setOnClickListener(this);
        mLayoutCamera.setOnClickListener(this);
        mLayoutApply.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.return_layout_interflow:

                break;
            case R.id.return_iv_scan:

                break;
            case R.id.return_layout_camera:

                break;
            case R.id.return_layout_apply:

                break;
        }
    }
}
