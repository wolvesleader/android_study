package com.loonxi.ju53.presenters;

import com.loonxi.ju53.models.impl.FeedbackModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IFeedbackView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/19.
 */
public class FeedbackPresenter {
    private IFeedbackView mView;
    private FeedbackModel mModel;

    public FeedbackPresenter(IFeedbackView mView) {
        this.mView = mView;
        mModel = new FeedbackModel();
    }

    /**
     * 提交反馈
     * @param mobile
     * @param content
     */
    public void feedback(String mobile, String content){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("mobile", mobile);
        map.put("suggests", content);
        if(mView != null){
            mView.startAsyncTask();
        }
        mModel.feedback(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.endAsyncTask();
                mView.onFeedbackSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.endAsyncTask();
                mView.onFeedbackFailed(apiErrorCode, message);
            }
        });
    }
}
