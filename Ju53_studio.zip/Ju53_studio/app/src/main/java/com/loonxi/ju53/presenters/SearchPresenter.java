package com.loonxi.ju53.presenters;

import com.loonxi.ju53.R;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.models.ISearchModel;
import com.loonxi.ju53.models.impl.SearchModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ISearchHistoryView;
import com.loonxi.ju53.views.ISearchView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/1/6.
 */
public class SearchPresenter {

    private ISearchModel mModel;
    private ISearchView mView;
    private ISearchHistoryView mHistoryView;

    public static final int SEARCH_BY_NO = 0;//没有排序
    public static final int SEARCH_BY_GENERAL = 1;//综合排序
    public static final int SEARCH_BY_SALES = 2;//按销量排序
    public static final int SEARCH_BY_PRICE_DESC = 3;//价格从高到低排序
    public static final int SEARCH_BY_PRICE_AESC = 4;//价格从低到高排序

    public SearchPresenter(ISearchView mView) {
        this.mView = mView;
        mModel = new SearchModel();
    }

    public SearchPresenter(ISearchHistoryView view) {
        this.mHistoryView = view;
        mModel = new SearchModel();
    }

    /**
     * 搜索产品列表
     *
     * @param key
     * @param categoryId
     * @param searchType
     * @param page
     */
    public void getSearchList(String key, String categoryId, int searchType, int page) {
        if (StringUtil.isEmpty(key)) {
            mView.showToast(R.string.search_key_null);
            return;
        }
        String orderCause = "";
        switch (searchType) {
            case SEARCH_BY_GENERAL:
                orderCause = "1";
                break;
            case SEARCH_BY_SALES:
                orderCause = "sold";
                break;
            case SEARCH_BY_PRICE_DESC:
                orderCause = "price desc";
                break;
            case SEARCH_BY_PRICE_AESC:
                orderCause = "price asc";
                break;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productName", key);
        map.put("page", page + "");
        map.put("orderByClause", orderCause);
        map.put("id", categoryId);
        mModel.getSearchList(map, new Callback<JsonArrayInfo<BaseProductEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<BaseProductEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<BaseProductEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onSearchSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onSearchFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 分类获取产品列表
     *
     * @param key
     * @param searchType
     * @param page
     */
    public void getSortSearchList(String key, String categoryId, int searchType, int page) {
        String orderCause = "";
        switch (searchType) {
            case SEARCH_BY_GENERAL:
                orderCause = "1";
                break;
            case SEARCH_BY_SALES:
                orderCause = "sold";
                break;
            case SEARCH_BY_PRICE_DESC:
                orderCause = "price desc";
                break;
            case SEARCH_BY_PRICE_AESC:
                orderCause = "price asc";
                break;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("name", key);
        map.put("page", page + "");
        map.put("orderByClause", orderCause);
        map.put("id", categoryId);
        mModel.getSortSearchList(map, new Callback<JsonArrayInfo<BaseProductEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<BaseProductEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<BaseProductEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onSearchSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onSearchFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 获取热门搜索
     */
    public void getHotSearch() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getHotSearch(map, new Callback<JsonArrayInfo<String>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<String> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<String> data, Retrofit retrofit) {
                if (mHistoryView == null) {
                    return;
                }
                mHistoryView.onGetHotSearchSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mHistoryView == null) {
                    return;
                }
                mHistoryView.onGetHotSearchFailed(apiErrorCode, message);
            }
        });
    }
}
