package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bigkoo.pickerview.OptionsPickerView;
import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.OrderState;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.entity.RefundEntity;
import com.loonxi.ju53.entity.RefundReason;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.presenters.OrderDetailPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.SoftInputUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IRefundView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;

/**
 * 退款
 * Created by Xuzue on 2016/1/15.
 */
public class RefundActivity extends ActionBarActivity implements View.OnClickListener, IRefundView {

    @ViewInject(R.id.refund_layout_type)
    private LinearLayout mLayoutType;
    @ViewInject(R.id.refund_layout_reason)
    private LinearLayout mLayoutReason;
    @ViewInject(R.id.refund_tv_reason)
    private TextView mTvRefundReason;
    @ViewInject(R.id.refund_edt_money)
    private EditText mEdtMoney;
    @ViewInject(R.id.refund_edt_description)
    private EditText mEdtDescription;
    @ViewInject(R.id.refund_tv_nums)
    private TextView mTvNums;
    @ViewInject(R.id.refund_layout_camera)
    private LinearLayout mLayoutUpload;
    @ViewInject(R.id.refund_iv_picture)
    private ImageView mIvPic;
    @ViewInject(R.id.refund_layout_apply)
    private LinearLayout mLayoutApply;

    private RefundReason mSelectReason;
    private int mEdtDescriptionMax = 0;

    private OptionsPickerView mPickerView;
    private ArrayList<RefundReason> mRefundReason = new ArrayList<>();

    private OrderDetailPresenter mDetailPresenter;
    private OrderEntity mOrderEntity;
    private OrderUnitEntity mOrderUnitEntity;
    private BaseProductEntity mProduct;
    private RefundEntity mOldRefund;//修改申请时
    private double mMaxApply = 0;
    private int applyType = 1;//退款类型 1-仅退款 2-退货退款

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund);
    }

    @Override
    public void initView() {
        setTitle(R.string.refund_title);
    }

    @Override
    public void initContent() {
        mEdtDescriptionMax = getResources().getInteger(R.integer.refund_description_max_nums);
        mDetailPresenter = new OrderDetailPresenter(this);
        mOrderEntity = getIntent().getParcelableExtra("orderEntity");
        mOrderUnitEntity = getIntent().getParcelableExtra("orderUnitEntity");
        mProduct = (BaseProductEntity) getIntent().getSerializableExtra("product");
        mOldRefund = getIntent().getParcelableExtra("refund");
        initReasonView();
        initMaxApply();
        initDescription();
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mLayoutType.setOnClickListener(this);
        mLayoutReason.setOnClickListener(this);
        mLayoutUpload.setOnClickListener(this);
        mLayoutApply.setOnClickListener(this);
        mEdtDescription.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String content = s.toString();
                String nums = StringUtil.isEmpty(content) ? "0" : content.length() + "";
                mTvNums.setText(nums + " / " + mEdtDescriptionMax);
            }
        });
    }

    /**
     * 初始化原因选择view
     */
    private void initReasonView() {
        initReasonData();
        mPickerView = new OptionsPickerView(this);
        mPickerView.setPicker(mRefundReason);
        mPickerView.setCyclic(false);
        mPickerView.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {
            @Override
            public void onOptionsSelect(int options1, int option2, int options3) {
                if (options1 >= 0 && !ListUtil.isEmpty(mRefundReason) && mRefundReason.size() > options1) {
                    mSelectReason = mRefundReason.get(options1);
                    mTvRefundReason.setText(mSelectReason == null ? "" : mSelectReason.getReason());
                }
            }
        });
        if (mOldRefund != null) {
            int code = mOldRefund.getReason();
            mSelectReason = mRefundReason.get(code);
            mTvRefundReason.setText(mSelectReason == null ? "" : mSelectReason.getReason());
            mPickerView.setSelectOptions(code);
        }
    }

    /**
     * 初始化退款金额最大值
     */
    private void initMaxApply() {
        if (mProduct != null && mOrderEntity != null) {
            mMaxApply = mProduct.getPrice() * mProduct.getCount() + mOrderEntity.getFreight();
            if (mOrderEntity.getState() == OrderState.PAYED) {
                mEdtMoney.setEnabled(false);
            } else {
                mEdtMoney.setEnabled(true);
            }
        }
        mEdtMoney.setHint(getResources().getString(R.string.max) + ": " + mMaxApply);
        mEdtMoney.setText(mMaxApply + "");
        if (mOldRefund != null) {
            mEdtMoney.setText(mOldRefund.getBackapply() + "");
        }
        mEdtMoney.setSelection(mEdtMoney.getText().length());
    }

    /**
     * 初始化退款说明
     */
    private void initDescription() {
        if (mOldRefund != null) {
            mEdtDescription.setText(mOldRefund.getNotes());
        }
    }

    /**
     * 初始化退款原因
     */
    private void initReasonData() {
        String[] reasons = getResources().getStringArray(R.array.refund_reason);
        for (int i = 0; i < reasons.length; i++) {
            RefundReason reason = new RefundReason();
            reason.setReason(reasons[i]);
            reason.setCode(i);
            mRefundReason.add(reason);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.refund_layout_type:

                break;
            case R.id.refund_layout_reason:
                SoftInputUtil.closeKeybord(mEdtMoney, mContext);
                SoftInputUtil.closeKeybord(mEdtDescription, mContext);
                if (mPickerView != null && !mPickerView.isShowing()) {
                    mPickerView.show();
                }
                break;
            case R.id.refund_layout_camera:

                break;
            case R.id.refund_layout_apply:
                createApply();
                break;
        }
    }

    /**
     * 提交申请
     */
    private void createApply() {
        if (mOrderEntity == null || mOrderUnitEntity == null || mProduct == null) {
            return;
        }
        String backapply = mEdtMoney.getText().toString();
        String notes = mEdtDescription.getText().toString();
        if (mSelectReason == null) {
            showToast(R.string.refund_reason_hint);
            return;
        }
        if (StringUtil.isEmpty(backapply)) {
            showToast(R.string.refund_money_tip);
            return;
        }
        if (Double.parseDouble(backapply) <= 0) {
            showToast("退款金额应大于0");
            return;
        }
        if (Double.parseDouble(backapply) > mMaxApply) {
            showToast("退款金额不得大于" + mMaxApply + "元");
            return;
        }
        if (mOldRefund != null) {//修改退款
            mDetailPresenter.updateRefund(mOrderUnitEntity.getPid() + "", mOrderEntity.getOrderId(), backapply, mProduct.getProductId(),
                    mSelectReason.getCode(), notes, applyType, mOrderEntity.getState(), mOldRefund.getPid() + "", false);
        } else {//首次申请
            mDetailPresenter.refund(mOrderUnitEntity.getPid() + "", mOrderEntity.getOrderId(), backapply, mProduct.getProductId(),
                    mSelectReason.getCode(), notes, applyType, mOrderEntity.getState());
        }
    }

    @Override
    public void onRefundSuccess(BaseJsonInfo jsonInfo) {
        if (mOldRefund != null) {
            showToast("退款申请修改成功");
        } else {
            showToast("退款申请成功");
        }
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void onRefundFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
