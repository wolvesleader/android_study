package com.loonxi.ju53.modules.open.beans;

import java.io.Serializable;

/**
 * Created by Leo on 2015/9/8.
 */
public class OpenUserInfo implements Serializable {
}
