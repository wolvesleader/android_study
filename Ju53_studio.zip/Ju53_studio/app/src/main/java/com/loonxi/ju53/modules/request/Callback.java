package com.loonxi.ju53.modules.request;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonMultiArrayInfo;

import retrofit.Response;
import retrofit.Retrofit;

/**
 * retrofit网络请求回调
 * Created by Xuzue on 2015/12/16.
 */
public abstract class Callback<T> implements retrofit.Callback<T> {
    @Override
    public void onResponse(Response<T> response, Retrofit retrofit) {
        if (response.code() == 200 && response.body() != null) {
            T t = response.body();
            if (t instanceof BaseJsonInfo) {
                BaseJsonInfo json = (BaseJsonInfo) t;
                if (json != null) {
                    dealResponse(json.getFlag(), json.getMessage(), t, retrofit);
                }
            } else if (t instanceof JsonInfo) {
                JsonInfo json = (JsonInfo) t;
                if (json != null) {
                    dealResponse(json.getFlag(), json.getMessage(), t, retrofit);
                }
            } else if (t instanceof JsonArrayInfo) {
                JsonArrayInfo json = (JsonArrayInfo) t;
                if (json != null) {
                    dealResponse(json.getFlag(), json.getMessage(), t, retrofit);
                }
            } else if (t instanceof JsonMultiArrayInfo) {
                JsonMultiArrayInfo json = (JsonMultiArrayInfo) t;
                if (json != null) {
                    dealResponse(json.getFlag(), json.getMessage(), t, retrofit);
                }
            } else {
                onSuccess((T) response.body(), retrofit);
            }
            return;
        }
        onFailed(ApiError.REQUEST_FAILURE, response.message());
    }

    @Override
    public void onFailure(Throwable t) {
        onFailed(ApiError.REQUEST_FAILURE, t.getMessage());
    }

    private void dealResponse(int flag, String message, T data, Retrofit retrofit) {
        if (flag == ApiError.REQUEST_SUCCESS) {
            onSuccess(data, retrofit);
        } else if (flag == ApiError.REQUEST_FAILURE_INCORRECT_INFO) {
            onFailed(ApiError.REQUEST_FAILURE_INCORRECT_INFO, message);
        } else if (flag == ApiError.REQUEST_FAILURE_OFFLINE) {
            onFailed(ApiError.REQUEST_FAILURE_OFFLINE, message);
        } else {
            onOtherFlag(flag, message, data);
        }
    }


    public abstract void onOtherFlag(int flag, String message, T data);

    public abstract void onSuccess(T data, Retrofit retrofit);

    public abstract void onFailed(int apiErrorCode, String message);

}
