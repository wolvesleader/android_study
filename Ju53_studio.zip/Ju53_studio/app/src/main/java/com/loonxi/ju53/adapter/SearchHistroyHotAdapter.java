package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SearchActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/6.
 */
public class SearchHistroyHotAdapter extends BaseObjectListAdapter<String> {


    public SearchHistroyHotAdapter(Context context, List<String> datas) {
        super(context, datas);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.griditem_search_history_hot, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.griditem_search_history_layout_root);
            holder.mBtnName = (Button) convertView.findViewById(R.id.griditem_search_history_hot_btn);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.mBtnName.setText(get(position));

        holder.mBtnName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SearchActivity.class);
                intent.putExtra("key", holder.mBtnName.getText().toString());
                mContext.startActivity(intent);
            }
        });
        return convertView;

    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        Button mBtnName;
    }
}
