package com.loonxi.ju53.entity;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ShareInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6494328629031520357L;

	@SerializedName("share_wx_message_title")
	private String title;
	@SerializedName("share_wx_timeline_title")
	private String title2;
	@SerializedName("share_wx_message_desc")
	private String content;
	@SerializedName("share_wx_link")
	private String link;
	@SerializedName("share_wx_imgurl")
	private String imgUrl;

	private String imgPath;

	private String aid;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle2() {
		return title2;
	}

	public void setTitle2(String title2) {
		this.title2 = title2;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
}
