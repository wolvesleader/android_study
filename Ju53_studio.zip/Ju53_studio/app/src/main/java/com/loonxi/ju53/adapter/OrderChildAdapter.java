package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.OrderDetailActivity;
import com.loonxi.ju53.activity.RefundDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.constants.RefundState;
import com.loonxi.ju53.convert.OrderDataConvert;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.fragment.MyOrderContentFragment;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class OrderChildAdapter extends BaseObjectListAdapter<OrderUnitEntity> {

    private OrderEntity mOrder;
    private boolean mIsBack;
    private MyOrderContentFragment mFragment;

    public OrderChildAdapter(Context context, MyOrderContentFragment fragment, boolean isBack, OrderEntity order, List<OrderUnitEntity> datas) {
        super(context, datas);
        mFragment = fragment;
        mIsBack = isBack;
        mOrder = order;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_order_child, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_order_child_layout_root);
            holder.mLayoutStatus = (LinearLayout) convertView.findViewById(R.id.listitem_order_child_layout_status);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_order_child_tv_status);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_order_child_iv_head);
            holder.mTvProductName = (TextView) convertView.findViewById(R.id.listitem_order_child_tv_name);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_order_child_tv_price);
            holder.mTvAttribute = (TextView) convertView.findViewById(R.id.listitem_order_child_tv_attribute);
            holder.mTvNum = (TextView) convertView.findViewById(R.id.listitem_order_child_tv_num);
            holder.mDivider = convertView.findViewById(R.id.listitem_order_child_divider);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        OrderUnitEntity unit = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + unit.getPicture() + AppConst.PIC_SIZE_80).into(holder.mIvHead);
        holder.mTvProductName.setText(unit.getProductName());
        holder.mTvPrice.setText("¥ " + unit.getPrice());
        holder.mTvAttribute.setText(unit.getAttribute());
        holder.mTvNum.setText("x " + unit.getValue());
        if(mIsBack){
            holder.mTvStatus.setVisibility(View.VISIBLE);
            setRefundStatus(holder.mTvStatus, unit);
        }else{
            holder.mTvStatus.setVisibility(View.GONE);
        }
        setListener(holder, unit);
        return convertView;
    }

    /**
     * 设置退款状态
     * @param mTvStatus
     * @param unit
     */
    private void setRefundStatus(TextView mTvStatus, OrderUnitEntity unit) {
        RefundState.setRefundState(mTvStatus, unit.getIsBacked());
    }

    private void setListener(ViewHolder holder, final OrderUnitEntity unit) {
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsBack) {//退款
                    Intent intent = new Intent(mContext, RefundDetailActivity.class);
                    intent.putExtra("order", mOrder);
                    intent.putExtra("unit", unit);
                    intent.putExtra("product", OrderDataConvert.orderUnitEntity2BaseProductEntity(unit));
                    mFragment.startActivityForResult(intent, MyOrderContentFragment.REQUEST_CODE_REFUND);
                } else {
                    Intent intent = new Intent(mContext, OrderDetailActivity.class);
                    intent.putExtra("order", mOrder);
                    mFragment.startActivityForResult(intent, MyOrderContentFragment.REQUEST_CODE_ORDER_DETAIL);
                }

            }
        });
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        LinearLayout mLayoutStatus;
        TextView mTvStatus;
        ImageView mIvHead;
        TextView mTvProductName;
        TextView mTvPrice;
        TextView mTvAttribute;
        TextView mTvNum;
        View mDivider;
    }

}
