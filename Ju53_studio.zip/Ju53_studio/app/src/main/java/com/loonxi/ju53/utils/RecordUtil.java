package com.loonxi.ju53.utils;

import android.media.MediaRecorder;
import android.os.Environment;

import java.io.File;
import java.io.IOException;

/**
 * 录音工具类
 * Created by Xuze on 2015/9/5.
 */
public class RecordUtil {

    private MediaRecorder mRecorder = new MediaRecorder();
    /**
     * 录音文件路径
     */
    private static String mPath;
    private static final int SAMPLING_RATE_IN_HZ = 8000;

    public RecordUtil(String path){
        mPath = path;
    }

    /**
     * 开始录音
     * @throws IOException
     */
    public void start() throws IOException {
        String state = Environment.getExternalStorageState();
        if(!state.equals(Environment.MEDIA_MOUNTED)){
            throw new IOException("SD card is not available. It is " + state + ".");
        }
        File directory = new File(mPath).getParentFile();
        if(!directory.exists() && !directory.mkdirs()){
            throw new IOException("Path to file could not be created");
        }
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mRecorder.setAudioSamplingRate(SAMPLING_RATE_IN_HZ);
        mRecorder.setOutputFile(mPath);
        mRecorder.prepare();
        mRecorder.start();
    }

    /**
     * 停止录音
     */
    public void stop(){
        if(mRecorder != null) {
            mRecorder.stop();
            mRecorder.release();
            mRecorder = null;
        }
    }

    /**
     * 获取录音最大分贝
     * @return
     */
    public long getAmplitude(){
        if(mRecorder != null){
            return (mRecorder.getMaxAmplitude());
        }
        return 0;
    }
}
