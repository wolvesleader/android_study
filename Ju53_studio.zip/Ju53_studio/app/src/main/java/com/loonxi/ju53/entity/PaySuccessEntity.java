package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by XuZue on 2016/5/27 0027.
 */
public class PaySuccessEntity implements Parcelable {
    private String name;
    private String tel;
    private String address;
    private String money;
    private String orderId;

    public PaySuccessEntity() {

    }

    protected PaySuccessEntity(Parcel in) {
        name = in.readString();
        tel = in.readString();
        address = in.readString();
        money = in.readString();
        orderId = in.readString();
    }

    public static final Creator<PaySuccessEntity> CREATOR = new Creator<PaySuccessEntity>() {
        @Override
        public PaySuccessEntity createFromParcel(Parcel in) {
            return new PaySuccessEntity(in);
        }

        @Override
        public PaySuccessEntity[] newArray(int size) {
            return new PaySuccessEntity[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(tel);
        dest.writeString(address);
        dest.writeString(money);
        dest.writeString(orderId);
    }
}
