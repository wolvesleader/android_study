package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.activity.PromotionDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.entity.PromotionProductEntity;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshHorizontalScrollView;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/23.
 */
public class PromotionAdapter extends BaseObjectListAdapter<PromotionEntity> {

    public PromotionAdapter(Context context, List<PromotionEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_promotion, null);
            holder.mIvLog = (ImageView) convertView.findViewById(R.id.listitem_promotion_iv);
            holder.mScrollView = (PullToRefreshHorizontalScrollView) convertView.findViewById(R.id.listitem_promotion_ptr);
            holder.mLayoutContainer = (LinearLayout) convertView.findViewById(R.id.listitem_promotion_layout_container);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final PromotionEntity promotion = get(position);
        List<PromotionProductEntity> products = promotion.getList();

        Glide.with(mContext).load(AppConst.PIC_HEAD + promotion.getBanner() + AppConst.PIC_SIZE_250).into(holder.mIvLog);
        holder.mIvLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, PromotionDetailActivity.class);
                intent.putExtra("promotionId", promotion.getId() + "");
                mContext.startActivity(intent);
            }
        });


        LinearLayout layoutContainer = holder.mLayoutContainer;
        layoutContainer.removeAllViews();
        if (!ListUtil.isEmpty(products)) {
            holder.mScrollView.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, DisplayUtil.dip2px(5, DisplayUtil.getScreenDensity(mContext)), 0);
            for (final PromotionProductEntity product : products) {
                View child = mInflater.inflate(R.layout.listitem_promotion_child, null);
                ImageView mIvPic = (ImageView) child.findViewById(R.id.listitem_promotion_child_img);
                TextView mTvName = (TextView) child.findViewById(R.id.listitem_promotion_child_tv_name);
                TextView mTvPrice = (TextView) child.findViewById(R.id.listitem_promotion_child_tv_price);
                TextView mTvSales = (TextView) child.findViewById(R.id.listitem_promotion_child_tv_sales);
                Glide.with(mContext).load(AppConst.PIC_HEAD + product.getProductPic() + AppConst.PIC_SIZE_80).into(mIvPic);
                mTvName.setText(product.getProductName());
                mTvPrice.setText("¥" + product.getPrice());
                mTvSales.setText("已售" + product.getPrice() + "件");
                layoutContainer.addView(child, params);
                child.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(mContext, ProductDetailActivity.class);
                        intent.putExtra("productId", product.getProductId());
                        mContext.startActivity(intent);
                    }
                });
            }
        } else {
            holder.mScrollView.setVisibility(View.GONE);
        }
        return convertView;
    }

    static class ViewHolder {
        ImageView mIvLog;
        PullToRefreshHorizontalScrollView mScrollView;
        LinearLayout mLayoutContainer;
    }

}
