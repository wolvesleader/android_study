package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.CashCardEntity;
import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.entity.CashRecordInfo;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.models.IFinanceModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.FinanceService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class FinanceModel implements IFinanceModel {
    @Override
    public Call<JsonInfo<FinanceEntity>> getFinanceInfo(Map<String, Object> map, Callback<JsonInfo<FinanceEntity>> callback) {
        Call<JsonInfo<FinanceEntity>> call = NewRequest.creatApi(FinanceService.class).getFinanceInfo(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> cashApply(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(FinanceService.class).cashApply(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonInfo<CashRecordInfo>> getCashRecord(Map<String, Object> map, Callback<JsonInfo<CashRecordInfo>> callback) {
        Call<JsonInfo<CashRecordInfo>> call = NewRequest.creatApi(FinanceService.class).cashRecord(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<CashCardEntity>> getCashAccount(Map<String, Object> map, Callback<JsonArrayInfo<CashCardEntity>> callback) {
        Call<JsonArrayInfo<CashCardEntity>> call = NewRequest.creatApi(FinanceService.class).getBandCardInfo(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> bandCashAccount(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(FinanceService.class).bandCashAccount(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> unbandCashAccount(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(FinanceService.class).unbandCashAccount(map);
        call.enqueue(callback);
        return call;
    }
}
