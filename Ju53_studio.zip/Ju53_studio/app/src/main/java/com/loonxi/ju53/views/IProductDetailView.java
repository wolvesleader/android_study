package com.loonxi.ju53.views;

import android.view.View;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

/**
 * Created by Xuzue on 2016/1/11.
 */
public interface IProductDetailView extends IBaseView{
    void showToast(int resId);
    void onGetBaseInfoSuccess(JsonInfo<ProductDetailEntity> jsonInfo);
    void onGetBaseInfoFailed(int apiErrorCode, String message);
    void onGetDetailSuccess(JsonInfo<ProductDetailEntity> jsonInfo);
    void onGetDetailFailed(int apiErrorCode, String message);
    void onAddToCartSuccess(Object object);
    void onAddToCartFailed(int apiErrorCode, String message);
    void onGetSkuSuccess(View view, CartEntity cart, BaseProductEntity product, ProductAttributeEntity attribute);
    void onGetSkuFailed(int apiErrorCode, String message);
    void onFavSuccess(boolean isFav);
    void onFavFailed(int apiErrorCode, String message);
    void onGetRecommendSuccess(SupplierEntity supplier);
    void onGetRecommendFailed(int apiErrorCode, String message);
    void onSaleToJuSuccess();
    void onSaleToJuFailed(int apiErrorCode, String message);
}
