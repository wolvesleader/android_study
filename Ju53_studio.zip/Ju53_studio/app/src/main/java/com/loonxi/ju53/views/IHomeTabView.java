package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.MainBannderEntity;
import com.loonxi.ju53.entity.MainListEntity;

/**
 * Created by laojiaqi on 2016/6/1.
 */
public interface IHomeTabView extends IBaseView
{

    /**
     * 获取主界面上半数据
     */
    void  getTopListData(MainBannderEntity data);
    void getTopListDataFaile(int apiErrorCode, String message);

    /**
     * 获取主界面列表数据
     */
    void  getHotActivity(MainListEntity data);
    void getHotActivityFaile(int apiErrorCode, String message);
}
