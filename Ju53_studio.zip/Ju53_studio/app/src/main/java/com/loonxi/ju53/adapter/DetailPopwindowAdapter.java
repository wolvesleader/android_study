package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.listener.OnPopwindowClickListener;

import java.util.ArrayList;
import java.util.List;

/**
 * 商品详情里的“更多”
 * Created by Xuzue on 2016/1/14.
 */
public class DetailPopwindowAdapter extends BaseObjectListAdapter<String> {

    private List<Integer> mPicData = new ArrayList<>();
    private List<String> mContentData = new ArrayList<>();
    private OnPopwindowClickListener mListener;

    public DetailPopwindowAdapter(Context context, List<Integer> picData, List<String> datas, OnPopwindowClickListener listener) {
        super(context, datas);
        mPicData.clear();
        mContentData.clear();
        mPicData.addAll(picData);
        mContentData.addAll(datas);
        mListener = listener;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_popwindow, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_popwindow_layout_root);
            holder.mIvIcon = (ImageView) convertView.findViewById(R.id.listitem_popwindow_iv);
            holder.mTvContent = (TextView) convertView.findViewById(R.id.listitem_popwindow_tv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.mIvIcon.setImageResource(mPicData.get(position));
        holder.mTvContent.setText(mContentData.get(position));
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mListener != null){
                    mListener.click(get(position), position);
                }
            }
        });
        return convertView;
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvIcon;
        TextView mTvContent;
    }

}
