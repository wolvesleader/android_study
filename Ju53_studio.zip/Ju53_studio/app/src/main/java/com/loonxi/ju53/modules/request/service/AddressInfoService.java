package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.AddressInfoEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 获得地区信息 service
 * Created by Administrator on 2016/1/26.
 */
public interface AddressInfoService {

    /**
     * 获得国内地址信息
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("person/selectAddress")
    Call<JsonArrayInfo<AddressInfoEntity>> getAddressInfo(@FieldMap Map<String, Object> map);

    /**
     * 获得国外地址信息
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("person/selectOverseaAddress")
    Call<JsonInfo<Object>> getOverseasAddressInfo(@FieldMap Map<String, Object> map);

}
