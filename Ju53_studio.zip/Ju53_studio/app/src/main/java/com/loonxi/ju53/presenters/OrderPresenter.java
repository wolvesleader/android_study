package com.loonxi.ju53.presenters;

import android.text.TextUtils;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.models.IOrderModel;
import com.loonxi.ju53.models.impl.MessageModel;
import com.loonxi.ju53.models.impl.OrderModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IOrderView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * 订单列表presenter
 * Created by Xuzue on 2016/1/18.
 */

public class OrderPresenter extends BasePresenter<IOrderView> {
    private IOrderView mView;
    private IOrderModel mModel;
    private MessageModel mMessageModel;

    public OrderPresenter(IOrderView view) {
        super(view);
        this.mView = getView();
        mModel = new OrderModel();
        mMessageModel = new MessageModel();
    }

    /**
     * 查询订单
     *
     * @param position
     */
    public void getOrders(int position, final boolean showLoadingDialog) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        switch (position) {
            case 0:
                break;
            case 1:
                map.put("state", "0");//待付款
                break;
            case 2:
                map.put("state", "1");//待发货
                break;
            case 3:
                map.put("state", "6");//待收货
                break;
            case 4:
                map.put("state", "7");//待评价
                break;
            case 5://退款
                break;
        }
        if (showLoadingDialog) {
            mView.startAsyncTask();
        }
        if (position == 5) {//退款订单
            mModel.getBackOrders(map, new Callback<JsonArrayInfo<OrderEntity>>() {

                @Override
                public void onOtherFlag(int flag, String message, JsonArrayInfo<OrderEntity> data) {

                }

                @Override
                public void onSuccess(JsonArrayInfo<OrderEntity> data, Retrofit retrofit) {
                    if (mView == null) {
                        return;
                    }
                    if (showLoadingDialog) {
                        mView.endAsyncTask();
                    }
                    mView.onGetOrdersSuccess(data);
                }

                @Override
                public void onFailed(int apiErrorCode, String message) {
                    if (mView == null) {
                        return;
                    }
                    if (showLoadingDialog) {
                        mView.endAsyncTask();
                    }
                    mView.onGetOrdersFailed(apiErrorCode, message);
                }
            });
        } else {
            mModel.getOrders(map, new Callback<JsonArrayInfo<OrderEntity>>() {

                @Override
                public void onOtherFlag(int flag, String message, JsonArrayInfo<OrderEntity> data) {

                }

                @Override
                public void onSuccess(JsonArrayInfo<OrderEntity> data, Retrofit retrofit) {
                    if (mView == null) {
                        return;
                    }
                    if (showLoadingDialog) {
                        mView.endAsyncTask();
                    }
                    mView.onGetOrdersSuccess(data);
                }

                @Override
                public void onFailed(int apiErrorCode, String message) {
                    if (mView == null) {
                        return;
                    }
                    if (showLoadingDialog) {
                        mView.endAsyncTask();
                    }
                    mView.onGetOrdersFailed(apiErrorCode, message);
                }
            });
        }

    }

    /**
     * 付款
     *
     * @param payId
     * @param orderId
     * @param userId
     * @param orderSum
     */
    public void payOrder(String payId, final String orderId, String userId, final double orderSum) {
        if (StringUtil.isEmpty(payId) || StringUtil.isEmpty(orderId) || StringUtil.isEmpty(userId)) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        String payIdStr = payId + "_" + orderId + "_" + userId;
        map.put("payId", payIdStr);
        map.put("payMoney", orderSum + "");
        mView.startAsyncTask();
        mModel.payOrder(map, new Callback<AliPayEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, AliPayEntity data) {

            }

            @Override
            public void onSuccess(AliPayEntity data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onPayOrderSuccess(data, orderSum, orderId);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onPayOrderFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 确认收货
     *
     * @param orderId
     */
    public void confirmOrder(String orderId, String payPassword) {
        if (StringUtil.isEmpty(orderId) || StringUtil.isEmpty(payPassword)) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("orderId", orderId);
        map.put("cashPassword", payPassword);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.sureOrder(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onConfirmOrderSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onConfirmOrderFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 获得物流单号
     *
     * @param orderId
     */
    public void getOrderTrans(String orderId) {
        if (TextUtils.isEmpty(orderId)) {
            return;
        }
        mMessageModel.getLogistics(orderId, new Callback<JsonInfo<LogisticsEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<LogisticsEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<LogisticsEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.getTransOrderSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.getTransOrderFailure(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 关闭订单
     * @param pid
     */
    public void closeOrder(String pid){
        if(StringUtil.isEmpty(pid)){
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", pid);
        if(mView != null){
            mView.startAsyncTask();
        }
        mModel.closeOrder(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.endAsyncTask();
                mView.onCloseOrderSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.endAsyncTask();
                mView.onCloseOrderFailed(apiErrorCode, message);
            }
        });
    }
}
