package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.CashCardEntity;
import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.entity.CashRecordInfo;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 分销商资金管理
 * Created by XuZue on 2016/5/5 0005.
 */
public interface FinanceService {

    /**
     * 获取资金信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("finance/GetCashApply")
    Call<JsonInfo<FinanceEntity>> getFinanceInfo(@FieldMap Map<String, Object> map);

    /**
     * 获取卡号绑定信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("finance/Getbindingcard")
    Call<JsonArrayInfo<CashCardEntity>> getBandCardInfo(@FieldMap Map<String, Object> map);

    /**
     * 申请提现
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("finance/CashApply")
    Call<BaseJsonInfo> cashApply(@FieldMap Map<String, Object> map);

    /**
     * 提现记录
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("finance/Applylist")
    Call<JsonInfo<CashRecordInfo>> cashRecord(@FieldMap Map<String, Object> map);

    /**
     * 绑定银行卡账号
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("finance/Bindingcard")
    Call<BaseJsonInfo> bandCashAccount(@FieldMap Map<String, Object> map);


    /**
     * 解绑银行卡账号
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("finance/RemoveCard")
    Call<BaseJsonInfo> unbandCashAccount(@FieldMap Map<String, Object> map);



}
