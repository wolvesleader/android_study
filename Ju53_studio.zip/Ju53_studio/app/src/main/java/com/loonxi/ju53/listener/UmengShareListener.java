package com.loonxi.ju53.listener;

import android.widget.Toast;

import com.loonxi.ju53.base.BaseApplication;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;

/**
 * 友盟分享监听
 * Created by Xuzue on 2016/4/5.
 */
public class UmengShareListener implements UMShareListener {
    @Override
    public void onResult(SHARE_MEDIA platform) {
        Toast.makeText(BaseApplication.instance, platform + "分享成功", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(SHARE_MEDIA platform, Throwable t) {
        Toast.makeText(BaseApplication.instance, platform + "分享失败!\n" + t.getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCancel(SHARE_MEDIA platform) {
        Toast.makeText(BaseApplication.instance, platform + "分享取消", Toast.LENGTH_SHORT).show();
    }
}
