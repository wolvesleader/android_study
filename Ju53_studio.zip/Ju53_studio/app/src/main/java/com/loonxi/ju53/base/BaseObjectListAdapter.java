package com.loonxi.ju53.base;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.loonxi.ju53.utils.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2015/9/6.
 */
public class BaseObjectListAdapter<T> extends BaseAdapter {

    protected Context mContext;
    protected LayoutInflater mInflater;
    protected List<T> mDatas = new ArrayList<T>();

    public BaseObjectListAdapter(Context context, List<T> datas) {
        mContext = context;
        if (context != null) {
            mInflater = LayoutInflater.from(context);
        }
        if (datas != null) {
            mDatas = datas;
        }
    }

    @Override
    public int getCount() {
        return mDatas.size();
    }

    @Override
    public Object getItem(int i) {
        return mDatas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        return null;
    }

    public T get(int position) {
        return mDatas.get(position);
    }

    public List<T> getDatas() {
        return mDatas;
    }

    public void showToast(String text) {
        ToastUtil.showToast(mContext, text);
    }

    public void showToast(String text, boolean isLong) {
        ToastUtil.showToast(mContext, text, isLong);
    }

    public void showToast(int resId, String text) {
        ToastUtil.showToast(mContext, resId, text);
    }
}
