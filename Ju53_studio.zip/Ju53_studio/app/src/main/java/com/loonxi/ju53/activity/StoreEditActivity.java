package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.manager.StoreManager;
import com.loonxi.ju53.presenters.StoreEditPresenter;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IStoreEditView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreEditActivity extends ActionBarActivity implements View.OnClickListener, IStoreEditView {

    @ViewInject(R.id.store_edit_content)
    private EditText mTvContent;

    private StoreEditPresenter mPresenter;
    private String mStoreName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_edit);
    }

    @Override
    public void initView() {
        setTitle("修改店铺名称");
        setRightVisibility(View.VISIBLE);
        setRightTextVisibility(View.VISIBLE);
        setRightText("保存");
    }

    @Override
    public void initContent() {
        mPresenter = new StoreEditPresenter(this);
        mStoreName = getIntent().getStringExtra("name");
        mTvContent.setText(mStoreName);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                altName();
                break;
        }
    }

    /**
     * 修改店铺名称
     */
    private void altName() {
        String name = mTvContent.getText().toString();
        if (StringUtil.isEmpty(name)) {
            showToast(R.string.store_alt_name_empty);
            return;
        }
        mPresenter.altStoreName(name);
    }

    @Override
    public void altNameSuccess() {
        showToast(R.string.store_alt_name_success);
        StoreManager.sendBroad(mContext);
        StoreManager.saveStoreBaseInfo(SpUtil.getString(BaseApplication.instance, SpUtil.STORE_LOGO, ""), mTvContent.getText().toString());
        Intent data = new Intent();
        data.putExtra("name", mTvContent.getText().toString());
        setResult(RESULT_OK, data);
        finish();
    }


    @Override
    public void altNameFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
