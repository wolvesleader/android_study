package com.loonxi.ju53.presenters;

import com.loonxi.ju53.R;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.FreightRule;
import com.loonxi.ju53.entity.OrderCreateEntity;
import com.loonxi.ju53.entity.OrderFreightEntity;
import com.loonxi.ju53.models.IOrderModel;
import com.loonxi.ju53.models.impl.OrderModel;
import com.loonxi.ju53.modules.open.alipay.Base64;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.NumberUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IOrderConfirmView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import retrofit.Retrofit;

/**
 * 确认订单presenter
 * Created by Xuzue on 2016/1/18.
 */
public class OrderConfirmPresenter {

    private IOrderConfirmView mView;
    private IOrderModel mModel;

    public OrderConfirmPresenter(IOrderConfirmView mView) {
        this.mView = mView;
        mModel = new OrderModel();
    }


    /**
     * 获取所有店铺所有产品总数
     *
     * @param carts
     * @return
     */
    public int getTotalCount(List<CartEntity> carts) {
        int count = 0;
        if (ListUtil.isEmpty(carts)) {
            return count;
        }
        for (CartEntity cart : carts) {
            count += cart.getTotalCount();
        }
        return count;
    }

    /**
     * 获取所有店铺所有产品的总费用（包括运费）
     *
     * @param carts
     * @return
     */
    public double getTotalFee(List<CartEntity> carts) {
        double total = 0;
        if (ListUtil.isEmpty(carts)) {
            return total;
        }
        for (CartEntity cart : carts) {
            total += cart.getTotalFee();
        }
        return NumberUtil.double2Decimal(total);
    }

    public void updateDataAfterGetFreights(List<CartEntity> carts, List<OrderFreightEntity> results) {
        if (ListUtil.isEmpty(carts) || ListUtil.isEmpty(results)) {
            return;
        }
        for (int i = 0; i < carts.size(); i++) {
            if (carts.get(i) instanceof CartEntity) {
                CartEntity cart = carts.get(i);
                double totalFee = 0;
                double totalFreight = 0;
                int totalCount = 0;
                if (cart == null) {
                    continue;
                }
                for (OrderFreightEntity result : results) {
                    if (result == null) {
                        continue;
                    }
                    String supplierId = result.getSupplierId();
                    if (!StringUtil.isEmpty(supplierId) && supplierId.equals(cart.getSupperId())) {
                        totalFreight = result.getFreight();
                        break;
                    }
                }
                List<BaseProductEntity> products = cart.getList();
                if (ListUtil.isEmpty(products)) {
                    continue;
                }
                for (int j = 0; j < products.size(); j++) {
                    BaseProductEntity product = products.get(j);
                    totalFee += product.getPrice() * product.getCount();
                    totalCount += product.getCount();
                }
                totalFreight = NumberUtil.double2Decimal(totalFreight);
                totalFee = NumberUtil.double2Decimal(totalFee);
                cart.setTotalFreight(totalFreight);
                cart.setTotalFee(NumberUtil.double2Decimal(totalFee + totalFreight));
                cart.setTotalCount(totalCount);
            }
        }
    }

    /**
     * 获取运费模板成功后，更新数据
     *
     * @param carts
     * @param rules
     */
    public void updateDataAfterGetFreight(List<CartEntity> carts, List<FreightRule> rules) {
        if (ListUtil.isEmpty(carts) || ListUtil.isEmpty(rules)) {
            return;
        }
        for (int i = 0; i < carts.size(); i++) {
            if (carts.get(i) instanceof CartEntity) {
                CartEntity cart = carts.get(i);
                double totalFee = 0;
                double totalFreight = 0;
                int totalCount = 0;
                List<BaseProductEntity> products = cart.getList();
                if (ListUtil.isEmpty(products)) {
                    continue;
                }
                for (int j = 0; j < products.size(); j++) {
                    BaseProductEntity product = products.get(j);
                    for (FreightRule freight : rules) {
                        if (freight.getFreightId() == product.getFreightId()) {
                            product.setFreightRule(freight);
                            double oneFreight = calculateFreight(product, freight);
                            cart.getList().get(j).setFreight(oneFreight);
                            cart.getList().get(j).setFreightId(freight.getFreightId());
                            cart.getList().get(j).setWeight(product.getWeight());
                            LogUtil.mLog().i("weight " + j + " " + product.getWeight());
                            totalFreight += oneFreight;
                            break;
                        }
                    }
                    totalFee += product.getPrice() * product.getCount();
                    totalCount += product.getCount();
                }
                totalFreight = NumberUtil.double2Decimal(totalFreight);
                totalFee = NumberUtil.double2Decimal(totalFee);
                cart.setTotalFreight(totalFreight);
                cart.setTotalFee(NumberUtil.double2Decimal(totalFee + totalFreight));
                cart.setTotalCount(totalCount);
            }
        }
    }

    /**
     * 计算某产品的运费
     *
     * @param product
     * @param rule
     * @return
     */
    private double calculateFreight(BaseProductEntity product, FreightRule rule) {
        double fee = 0;
        if (product == null || rule == null) {
            return fee;
        }
        double count = 0;
        if ("0".equals(rule.getUnit())) {//按个数计费
            count = product.getCount();
        } else if ("1".equals(rule.getUnit())) {//按重量计费
            count = product.getCount() * product.getWeight();
        }
        double start = rule.getStart();
        double plus = rule.getPlus();
        double freightPlus = rule.getFreightPlus();
        double freight = rule.getFreight();
        if (count <= start) {
            fee = freight;
        } else {
            int num = ((count - start) % plus == 0) ? ((int) ((count - start) / plus)) : ((int) ((count - start) / plus) + 1);
            fee = freight + num * freightPlus;
        }
        return fee;
    }

    /**
     * 获取默认收货地址
     *
     * @param isOversea
     */
    public void getDefaultAddress(boolean isOversea) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("isOversea", isOversea ? "1" : "0");
        mView.startAsyncTask();
        mModel.getDefaultAddress(map, new Callback<JsonInfo<AddressEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<AddressEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<AddressEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetDefaultAddressSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetDefaultAddressFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 获取运费模板
     *
     * @param freights
     * @param addressId
     */
    public void getFreightRule(String freights, String addressId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("freights", freights);
        map.put("region", addressId);
        mModel.getFreightRule(map, new Callback<JsonArrayInfo<FreightRule>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<FreightRule> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<FreightRule> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetFreightRuleSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetFreightRuleFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 获取订单运费
     *
     * @param regionId
     * @param carts
     */
    public void getOrderFreight(String regionId, List<CartEntity> carts) {
        String attrs = "";
        try {
            JSONArray outArray = new JSONArray();
            for (CartEntity cart : carts) {
                if (cart == null || ListUtil.isEmpty(cart.getList())) {
                    continue;
                }
                JSONArray array = new JSONArray();
                for (BaseProductEntity product : cart.getList()) {
                    JSONObject object = new JSONObject();
                    object.put("value", product.getCount());
                    object.put("supId", cart.getSupperId());
                    object.put("productId", product.getProductId());
                    object.put("freightId", product.getFreightId() + "");
                    object.put("weight", product.getWeight());
                    array.put(object);
                }
                outArray.put(array);
            }
            attrs = outArray.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("region", regionId);
        map.put("attrs", Base64.encode(attrs.getBytes()));
        mModel.getSupplierFreight(map, new Callback<JsonArrayInfo<OrderFreightEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<OrderFreightEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<OrderFreightEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetSupplierFreightSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetSupplierFrgightFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 提交订单
     *
     * @param carts
     * @param addressEntity
     * @param isCart        是否是购物车
     * @param isMerage      是否是合并付款
     */
    public void createOrder(List<CartEntity> carts, AddressEntity addressEntity, boolean isCart, boolean isMerage, String region) {
        if (ListUtil.isEmpty(carts)) {
            LogUtil.mLog().i("订单空");
            return;
        }
        if (addressEntity == null || StringUtil.isEmpty(addressEntity.getPid())) {
            mView.showToast(R.string.order_confirm_address_empty);
            return;
        }
        String attrs = "";
        try {
            JSONArray outArray = new JSONArray();
            for (CartEntity cart : carts) {
                if (ListUtil.isEmpty(cart.getList())) {
                    continue;
                }
                JSONArray array = new JSONArray();
                for (BaseProductEntity product : cart.getList()) {
                    JSONObject object = new JSONObject();
                    object.put("value", product.getCount());
                    object.put("supId", cart.getSupperId());
                    object.put("freights", product.getFreight());
                    object.put("productId", product.getProductId());
                    object.put("attributeId", product.getStockid());
                    object.put("picture", product.getPicture());
                    object.put("notes", cart.getNotes());
                    object.put("freightId", product.getFreightId() + "");
                    object.put("weight", product.getWeight());
                    array.put(object);
                }
                outArray.put(array);
            }
            attrs = outArray.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("addressId", addressEntity.getPid());
        map.put("region", region);
        map.put("isCart", isMerage ? "1" : "0");//是否是合并付款   注意：这两个参数名，不能互换
        map.put("isMerge", isCart ? "1" : "0");//是否是购物车
        map.put("attrs", Base64.encode(attrs.getBytes()));
        mView.startAsyncTask();
        mModel.createOrder(map, new Callback<OrderCreateEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, OrderCreateEntity data) {

            }

            @Override
            public void onSuccess(OrderCreateEntity data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                if (data != null) {
                    if (data.getFlag() == 1) {
                        mView.onCreateOrderSuccess(data);
                    } else {
                        onFailed(data.getFlag(), data.getMessage());
                    }
                }

            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onCreateOrderFailed(apiErrorCode, message);
                LogUtil.mLog().e("failed");
            }
        });
    }
}
