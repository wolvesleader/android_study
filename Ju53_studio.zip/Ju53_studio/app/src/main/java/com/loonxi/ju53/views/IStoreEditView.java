package com.loonxi.ju53.views;

import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public interface IStoreEditView extends IBaseView{
    void altNameSuccess();
    void altNameFailed(int apiErrorCode, String message);
}
