package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.List;
import java.util.Map;

/**
 * 产品属性(颜色、尺码)
 * Created by Xuzue on 2015/12/26.
 */
public class ProductAttributeEntity extends BaseJsonInfo implements Parcelable {
    private String skuProp;
    private int totalStock;
    private Map<String, List<StockEntity>> skuName;

    public ProductAttributeEntity(){

    }

    protected ProductAttributeEntity(Parcel in) {
        super(in);
        skuProp = in.readString();
        totalStock = in.readInt();
        skuName = in.readHashMap(Thread.currentThread().getContextClassLoader());
    }


    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(skuProp);
        dest.writeInt(totalStock);
        dest.writeMap(skuName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ProductAttributeEntity> CREATOR = new Creator<ProductAttributeEntity>() {
        @Override
        public ProductAttributeEntity createFromParcel(Parcel in) {
            return new ProductAttributeEntity(in);
        }

        @Override
        public ProductAttributeEntity[] newArray(int size) {
            return new ProductAttributeEntity[size];
        }
    };

    public int getTotalStock() {
        return totalStock;
    }

    public void setTotalStock(int totalStock) {
        this.totalStock = totalStock;
    }

    public String getSkuProp() {
        return skuProp;
    }

    public void setSkuProp(String skuProp) {
        this.skuProp = skuProp;
    }

    public Map<String, List<StockEntity>> getSkuName() {
        return skuName;
    }

    public void setSkuName(Map<String, List<StockEntity>> skuName) {
        this.skuName = skuName;
    }

}
