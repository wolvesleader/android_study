package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.listener.OnUpdateCartViewListener;
import com.loonxi.ju53.presenters.ShoppingPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.Logger;
import com.loonxi.ju53.utils.MapUtil;
import com.loonxi.ju53.widgets.FixedListView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Xuzue on 2015/12/26.
 */
public class ShoppingAdapter extends BaseObjectListAdapter<CartEntity> {

    private ShoppingPresenter mPresenter;
    private boolean mIsEditAll = false;//是否是编辑所有
    private boolean mIsCheckAll = false;//是否全选
    private Map<String, Boolean> mEditMap = new HashMap<>();
    private ShoppingChildAdapter mCurrentChildAdapter;
    private OnUpdateCartViewListener mListener;


    public ShoppingAdapter(Context context, List<CartEntity> datas, OnUpdateCartViewListener listener, ShoppingPresenter presenter) {
        super(context, datas);
        mPresenter = presenter;
        mEditMap = mPresenter.getEditCompanyMap();
        mListener = listener;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_shopping_parent, null);
            holder.mLayoutCheckCompany = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_parent_layout_check);
            holder.mCbx = (CheckBox) convertView.findViewById(R.id.listitem_shopping_parent_cbx);
            holder.mLayoutCompany = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_parent_layout_company);
            holder.mTvCompanyName = (TextView) convertView.findViewById(R.id.listitem_shopping_parent_tv_company);
            holder.mLayoutEdit = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_parent_layout_operate);
            holder.mTvEdit = (TextView) convertView.findViewById(R.id.listitem_shopping_parent_tv_edit);
            holder.mSlv = (FixedListView) convertView.findViewById(R.id.listitem_shopping_parent_slv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final CartEntity cart = get(position);
        final boolean isEditItem = (MapUtil.isEmpty(mEditMap) || cart == null) ? false : mEditMap.get(cart.getSupperId());

        holder.mTvCompanyName.setText(cart.getUserName());
        if (mIsEditAll) {
            holder.mLayoutEdit.setVisibility(View.INVISIBLE);
        } else {
            holder.mLayoutEdit.setVisibility(View.VISIBLE);
            holder.mTvEdit.setText(isEditItem ? R.string.finish : R.string.edit);
        }

        List<BaseProductEntity> products = cart.getList();
        if (!ListUtil.isEmpty(products)) {
            holder.mSlv.setVisibility(View.VISIBLE);
            mCurrentChildAdapter = (ShoppingChildAdapter) holder.mSlv.getAdapter();
            mCurrentChildAdapter = new ShoppingChildAdapter(mContext, position, cart, products, mListener, mPresenter, holder);
            mCurrentChildAdapter.setIsEditAll(mIsEditAll);
            holder.mSlv.setAdapter(mCurrentChildAdapter);
            mCurrentChildAdapter.setOnRightItemClickListener(new ShoppingChildAdapter.onRightItemClickListener() {
                @Override
                public void onRightItemClick(View v, int position) {
                    showToast("删除" + position);
                }
            });
        } else {
            holder.mSlv.setVisibility(View.GONE);
        }
        holder.mCbx.clearFocus();
        holder.mCbx.setClickable(false);
        holder.mCbx.setChecked(mIsCheckAll || mPresenter.getCheckCompanyMap().get(cart.getSupperId()));

        LogUtil.mLog().i(cart.getSupperId() + " " + mIsCheckAll + " " + mPresenter.getCheckCompanyMap().get(cart.getSupperId()));

        setListener(holder, cart);

        return convertView;
    }

    /**
     * 事件监听
     *
     * @param holder
     * @param cart
     */
    private void setListener(ViewHolder holder, final CartEntity cart) {
        if (holder == null) {
            return;
        }
        final FixedListView slv = holder.mSlv;
        final TextView tv = holder.mTvEdit;
        final CheckBox cbx = holder.mCbx;

        holder.mLayoutCheckCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbx.setChecked(cbx.isChecked() ? false : true);
                mPresenter.updateDataAfterCheckCompany(cart, cbx.isChecked());
                ShoppingChildAdapter childAdapter = (ShoppingChildAdapter) slv.getAdapter();
                childAdapter.notifyDataSetChanged();
                if (mListener != null) {
                    mListener.updateBottomView();
                }
            }
        });
        holder.mLayoutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", cart.getSupperId());
                intent.putExtra("userName", cart.getUserName());
                mContext.startActivity(intent);
            }
        });
        holder.mLayoutEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final boolean isEditItem = (MapUtil.isEmpty(mEditMap) || cart == null) ? false : mEditMap.get(cart.getSupperId());
                mPresenter.updateDataAfterEditCompany(cart, !isEditItem);
                ShoppingChildAdapter childAdapter = (ShoppingChildAdapter) slv.getAdapter();
                childAdapter.setIsEditItem(isEditItem ? false : true);
                childAdapter.notifyDataSetChanged();
                tv.setText(isEditItem ? R.string.edit : R.string.finish);
            }
        });
    }


    /**
     * 删除某个产品
     *
     * @param holder
     * @param view
     * @param position
     * @param isCheckAll4Company
     */
    public void deleteProductView(ViewHolder holder, View view, int position, boolean isCheckAll4Company) {
        if (holder == null || view == null) {
            return;
        }
        holder.mCbx = (CheckBox) view.findViewById(R.id.listitem_shopping_parent_cbx);
        holder.mCbx.setChecked(isCheckAll4Company);
        notifyDataSetChanged();
        Logger.i("remove company position:" + position + " 剩余：" + getDatas().size());
        if (!ListUtil.isEmpty(getDatas())) {
            for (CartEntity cart : getDatas()) {
                if (!ListUtil.isEmpty(cart.getList())) {
                    for (BaseProductEntity product : cart.getList()) {
                        LogUtil.mLog().i(product.getProductName());
                    }
                } else {
                    LogUtil.mLog().i(cart.getSupperId() + " no product");
                }
            }
        }
    }

    public class ViewHolder {
        LinearLayout mLayoutCheckCompany;
        CheckBox mCbx;
        LinearLayout mLayoutCompany;
        TextView mTvCompanyName;
        LinearLayout mLayoutEdit;
        TextView mTvEdit;
        FixedListView mSlv;
    }


    public void setIsEditAll(boolean isEidtAll) {
        mIsEditAll = isEidtAll;
    }

    public boolean getIsEditAll() {
        return mIsEditAll;
    }

    public void setIsCheckAll(boolean isCheckAll) {
        mIsCheckAll = isCheckAll;
    }

    public boolean getIsCheckAll() {
        return mIsCheckAll;
    }

}
