package com.loonxi.ju53.utils;

import android.text.TextUtils;
import android.util.Log;

import java.util.HashMap;

/**
 * Created by butterfly on 2015/8/28.
 */
public class LogUtil {

    private static boolean FLAG = true;
    public static final String TAG = "LogUtil";
    private static final int LEVEL = Log.VERBOSE;
    private static HashMap<String, LogUtil> sLoggerTable = new HashMap<String, LogUtil>();
    private static String mClassName;
    public static  volatile LogUtil mLog;
    public static LogUtil oLog;

    private static final String XUZUE = "@X@";
    private static final String OTHER = "@O@";

    private LogUtil(String name){
        mClassName = name;
    }

    private static LogUtil getLogger(String className){
        LogUtil classLogger = sLoggerTable.get(className);
        if(classLogger == null){
            classLogger = new LogUtil(className);
            sLoggerTable.put(className, classLogger);
        }
        return classLogger;
    }

    public static void enableLogger(boolean enable){
        FLAG = enable;
    }

    public static LogUtil mLog(){
        if(mLog == null){
            synchronized (LogUtil.class){
                if(mLog == null){
                    mLog = new LogUtil(XUZUE);
                }
            }
        }
        return mLog;
    }
    public static LogUtil oLog(){
        if(oLog == null){
            oLog = new LogUtil(OTHER);
        }
        return oLog;
    }

    /**
     * Get The Current Function Name
     *
     * @return
     */
    private String getFunctionName() {
        StackTraceElement[] sts = Thread.currentThread().getStackTrace();
        if (sts == null) {
            return null;
        }
        for (StackTraceElement st : sts) {
            if (st.isNativeMethod()) {
                continue;
            }
            if (st.getClassName().equals(Thread.class.getName())) {
                continue;
            }
            if (st.getClassName().equals(this.getClass().getName())) {
                continue;
            }
            return "[ " + Thread.currentThread().getName() + ": "
                    + st.getFileName() + ":" + st.getLineNumber() + " "
                    + st.getMethodName() + " ]";
        }
        return null;
    }

    /**
     * The Log Level:i
     *
     * @param str
     */
    public void i(Object str) {
        if (FLAG) {
            if (LEVEL <= Log.INFO) {
                String name = getFunctionName();
                if (name != null) {
                    Log.i(TAG, name + " - " + str);
                } else {
                    Log.i(TAG, str.toString());
                }
            }
        }
    }

    /**
     * The Log Level:d
     *
     * @param str
     */
    public void d(Object str) {
        if (FLAG) {
            if (LEVEL <= Log.DEBUG) {
                String name = getFunctionName();
                if (name != null) {
                    Log.d(TAG, name + " - " + str);
                } else {
                    Log.d(TAG, str.toString());
                }
            }
        }
    }

    /**
     * The Log Level:V
     *
     * @param str
     */
    public void v(Object str) {
        if (FLAG) {
            if (LEVEL <= Log.VERBOSE) {
                String name = getFunctionName();
                if (name != null) {
                    Log.v(TAG, name + " - " + str);
                } else {
                    Log.v(TAG, str.toString());
                }
            }
        }
    }

    /**
     * The Log Level:w
     *
     * @param str
     */
    public void w(Object str) {
        if (FLAG) {
            if (LEVEL <= Log.WARN) {
                String name = getFunctionName();
                if (name != null) {
                    Log.w(TAG, name + " - " + str);
                } else {
                    Log.w(TAG, str.toString());
                }
            }
        }
    }

    /**
     * The Log Level:e
     *
     * @param str
     */
    public void e(Object str) {
        if (FLAG) {
            if (LEVEL <= Log.ERROR) {
                String name = getFunctionName();
                if (name != null) {
                    Log.e(TAG, name + " - " + str);
                } else {
                    Log.e(TAG, str.toString());
                }
            }
        }
    }

    /**
     * The Log Level:e
     *
     * @param ex
     */
    public void e(Exception ex) {
        if (FLAG) {
            if (LEVEL <= Log.ERROR) {
                Log.e(TAG, "error", ex);
            }
        }
    }

    /**
     * The Log Level:e
     *
     * @param log
     * @param tr
     */
    public void e(String log, Throwable tr) {
        if (FLAG) {
            String line = getFunctionName();
            Log.e(TAG, "{Thread:" + Thread.currentThread().getName() + "}"
                    + "[" + mClassName + line + ":] " + log + "\n", tr);
        }
    }

    public void println(Object str){
        if(FLAG){
            String name = getFunctionName();
            if(TextUtils.isEmpty(name)){
                System.out.println(str);
            } else{
                System.out.println(name + " -> " + str);
            }
        }
    }

}
