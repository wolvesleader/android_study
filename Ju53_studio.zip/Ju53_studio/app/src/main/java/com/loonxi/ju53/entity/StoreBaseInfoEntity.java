package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * 店铺基本信息（名称、LOGO等）
 * Created by XuZue on 2016/5/9 0009.
 */
public class StoreBaseInfoEntity extends BaseJsonInfo implements Parcelable{
    private String store_id;
    private String user_id;
    private String store_name;
    private String store_logo;
    private String created_at;
    private String updated_at;
    private String show_url;//分享链接
    private String share_title;//分享标题
    private String share_content;//分享内容

    public StoreBaseInfoEntity(){

    }

    protected StoreBaseInfoEntity(Parcel in) {
        super(in);
        store_id = in.readString();
        user_id = in.readString();
        store_name = in.readString();
        store_logo = in.readString();
        created_at = in.readString();
        updated_at = in.readString();
        show_url = in.readString();
        share_title = in.readString();
        share_content = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(store_id);
        dest.writeString(user_id);
        dest.writeString(store_name);
        dest.writeString(store_logo);
        dest.writeString(created_at);
        dest.writeString(updated_at);
        dest.writeString(show_url);
        dest.writeString(share_title);
        dest.writeString(share_content);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<StoreBaseInfoEntity> CREATOR = new Creator<StoreBaseInfoEntity>() {
        @Override
        public StoreBaseInfoEntity createFromParcel(Parcel in) {
            return new StoreBaseInfoEntity(in);
        }

        @Override
        public StoreBaseInfoEntity[] newArray(int size) {
            return new StoreBaseInfoEntity[size];
        }
    };

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getStore_name() {
        return store_name;
    }

    public void setStore_name(String store_name) {
        this.store_name = store_name;
    }

    public String getStore_logo() {
        return store_logo;
    }

    public void setStore_logo(String store_logo) {
        this.store_logo = store_logo;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getShow_url() {
        return show_url;
    }

    public void setShow_url(String show_url) {
        this.show_url = show_url;
    }

    public String getShare_title() {
        return share_title;
    }

    public void setShare_title(String share_title) {
        this.share_title = share_title;
    }

    public String getShare_content() {
        return share_content;
    }

    public void setShare_content(String share_content) {
        this.share_content = share_content;
    }
}
