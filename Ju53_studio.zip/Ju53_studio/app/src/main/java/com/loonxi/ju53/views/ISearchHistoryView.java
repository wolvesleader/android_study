package com.loonxi.ju53.views;

import java.util.List;

/**
 * Created by Xuzue on 2016/2/20.
 */
public interface ISearchHistoryView {
    void onGetHotSearchSuccess(List<String> keys);
    void onGetHotSearchFailed(int apiErrorCode, String message);
}
