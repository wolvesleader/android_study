package com.loonxi.ju53.utils.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.utils.StringUtil;

/**
 * 系统进程类
 * Created by Xuzue on 2015/9/9.
 */
public class ProcessInfo implements Parcelable{
    /**
     * 进程pid
     */
    private String pid;
    /**
     * 进程uid
     */
    private String uid;
    /**
     * 可用内存大小
     */
    private String memorySize;
    /**
     * 进程名
     */
    private String processName;
    /**
     * 进程中运行的所有apk名
     */
    private String[] pkgList;

    public ProcessInfo(){

    }

    protected ProcessInfo(Parcel in) {
        pid = in.readString();
        uid = in.readString();
        memorySize = in.readString();
        processName = in.readString();
        pkgList = in.createStringArray();
    }

    public static final Creator<ProcessInfo> CREATOR = new Creator<ProcessInfo>() {
        @Override
        public ProcessInfo createFromParcel(Parcel in) {
            return new ProcessInfo(in);
        }

        @Override
        public ProcessInfo[] newArray(int size) {
            return new ProcessInfo[size];
        }
    };

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getMemorySize() {
        return memorySize;
    }

    public void setMemorySize(String memorySize) {
        this.memorySize = memorySize;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String[] getPkgList() {
        return pkgList;
    }

    public void setPkgList(String[] pkgList) {
        this.pkgList = pkgList;
    }

    public String parseToString(){
        String pkgStr = "";
        if(pkgList != null){
            for(int i = 0; i < pkgList.length; i++){
                pkgStr += "/" + pkgList[i];
            }
        }
        if(!StringUtil.isEmpty(pkgStr)){
            pkgStr = pkgStr.substring(1);
        }
        return "[pid:" + pid + ", uid:" + uid + ", memorySize:" + memorySize +
                ", processName:" + processName + ", pkgList:" + pkgStr + "]";
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(pid);
        dest.writeString(uid);
        dest.writeString(memorySize);
        dest.writeString(processName);
        dest.writeStringArray(pkgList);
    }
}
