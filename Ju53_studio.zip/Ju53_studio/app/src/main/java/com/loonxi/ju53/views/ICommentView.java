package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.TotalCommentEntity;

/**
 * Created by Xuzue on 2016/2/22.
 */
public interface ICommentView {
    void onGetCommentsSuccess(TotalCommentEntity comment);
    void onGetCommentsFailed(int apiErrorCode, String message);
}
