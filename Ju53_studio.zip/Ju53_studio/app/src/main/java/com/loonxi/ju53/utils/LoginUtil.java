package com.loonxi.ju53.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.loonxi.ju53.activity.LoginActivity;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.modules.cookie.PersistentCookieStore;

import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

/**
 * 登入工具类
 * Created by laojiaqi on 2016/1/29.
 */
public class LoginUtil {

    private static boolean FIRST_LOGIN_FLAG = true;
    private static boolean IS_LOGIN_FLAG = false;

    /**
     * 判断是否登入
     *
     * @return
     */
    public static boolean isLoginNew() {
        String version = PackageUtil.getVersionName(BaseApplication.instance);
        if (VersionUtil.compareVersion(version, "2.0") > 0) {
            return isLoginUidu();
        } else {
            return isLoginCookie();
        }
    }


    public static boolean isLoginCookie() {
        if (FIRST_LOGIN_FLAG) {
            FIRST_LOGIN_FLAG = false;
            CookieManager cookieManager = new CookieManager(new PersistentCookieStore(BaseApplication.instance), CookiePolicy.ACCEPT_ALL);
            try {
                URI uri = new URI(ApiConst.URL_ROOT);
                List<HttpCookie> list = cookieManager.getCookieStore().get(uri);
                if (list.size() > 0) {
                    IS_LOGIN_FLAG = true;
                    return IS_LOGIN_FLAG;
                } else {
                    IS_LOGIN_FLAG = false;
                }
            } catch (URISyntaxException e) {
                IS_LOGIN_FLAG = false;
                e.printStackTrace();
            }
            return IS_LOGIN_FLAG;
        } else {
            return IS_LOGIN_FLAG;
        }
    }


    public static boolean isLoginUidu() {
        if (FIRST_LOGIN_FLAG) {
            FIRST_LOGIN_FLAG = false;
            String userId = SpUtil.getString(BaseApplication.instance, SpUtil.ACCOUNT_USER_ID);
            if (!StringUtil.isEmpty(userId)) {
                IS_LOGIN_FLAG = true;
                return true;
            } else {
                IS_LOGIN_FLAG = false;
                return false;
            }
        } else {
            return IS_LOGIN_FLAG;
        }
    }

    /**
     * 设置登入标志
     *
     * @param value
     * @return
     */
    public static void setLoginFlag(boolean value) {
        IS_LOGIN_FLAG = value;
    }

    /**
     * 退出登入
     */
    public static void clearCookies() {
        PersistentCookieStore p = new PersistentCookieStore(BaseApplication.instance);
        p.removeAll();
    }

    /**
     * 进行登入
     *
     * @param context
     * @param flag
     */
    public static void gotoLogin(Context context, int flag) {
        Intent intent = new Intent(context, LoginActivity.class);
        intent.putExtra(LoginActivity.LOGIN_TYPE, flag);
        context.startActivity(intent);
    }


    /**
     * 进行登入
     *
     * @param context
     */
    public static void gotoLogin(Context context) {
        Intent intent = new Intent(context, LoginActivity.class);
        context.startActivity(intent);
    }

    public static void logout(Context context) {
        logout(context, true);
    }

    /**
     * 登出(1.清除cooki;2.重置内存中的状态 3.结束“账户与安全”activity)
     *
     * @param context
     */
    public static void logout(Context context, boolean needFinish) {
        if (context == null) {
            return;
        }
        IS_LOGIN_FLAG = false;
        SpUtil.putString(BaseApplication.instance, SpUtil.ACCOUNT_USER_ID, "");
        PersistentCookieStore persistentCookieStore = new PersistentCookieStore(BaseApplication.instance);
        persistentCookieStore.removeAll();
        if (needFinish) {
            ((Activity) context).finish();
        }
    }

}
