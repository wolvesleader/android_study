package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.AddressInfoEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.AddressInfoService;
import com.loonxi.ju53.modules.request.service.CreateOrUpdateAddressService;
import com.loonxi.ju53.repos.PrefsRepos;

import java.util.Map;

import retrofit.Call;

/**
 * 获得、保存、修改（国内国外） 所有地区信息 model
 * Created by laojiaqi on 2016/1/26.
 */
public class OperateAddressModel {

    /**
     * 获得所有国内区域信息
     *
     * @param callback
     * @return
     */
    public Call<JsonArrayInfo<AddressInfoEntity>> getAddressInfoEntity(Callback<JsonArrayInfo<AddressInfoEntity>> callback) {

        Call<JsonArrayInfo<AddressInfoEntity>> call = Request.creatApi(AddressInfoService.class).getAddressInfo(PrefsRepos.getDefaultMap());
        call.enqueue(callback);
        return call;
    }

    /**
     * 保存地址信息 国内
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> saveAddress(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        if (map == null || map.size() == 0) {
            return null;
        }
        Call<BaseJsonInfo> call = Request.creatApi(CreateOrUpdateAddressService.class).createAddress(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 修改地址信息 国内
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> updateAddress(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        if (map == null || map.size() == 0) {
            return null;
        }
        Call<BaseJsonInfo> call = Request.creatApi(CreateOrUpdateAddressService.class).updateAddress(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 获得所有国外区域信息
     *
     * @param callback
     * @return
     */
    public Call<JsonInfo<Object>> getOverseasAddressInfoEntity(Callback<JsonInfo<Object>> callback) {
        Call<JsonInfo<Object>> call = Request.creatApi(AddressInfoService.class).getOverseasAddressInfo(PrefsRepos.getDefaultMap());
        call.enqueue(callback);
        return call;
    }


    /**
     * 保存地址信息 国外
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> saveOverseaAddress(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        if (map == null || map.size() == 0) {
            return null;
        }
        Call<BaseJsonInfo> call = Request.creatApi(CreateOrUpdateAddressService.class).createOverSeasAddress(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 修改地址信息 国外
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> updateOverseasAddress(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        if (map == null || map.size() == 0) {
            return null;
        }
        Call<BaseJsonInfo> call = Request.creatApi(CreateOrUpdateAddressService.class).updateOverseasAddress(map);
        call.enqueue(callback);
        return call;
    }

}
