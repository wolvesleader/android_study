package com.loonxi.ju53.base;

import android.os.Bundle;

/**
 * 实现MVP模式的Fragment都继承该类,V代表回调的接口,T代表具体的Presenter类
 * Created by Administrator on 2016/1/21.
 */
public abstract class BaseSafeFragment<V,T extends BasePresenter<V>> extends BaseFragment {

    protected T mPresenter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPresenter= createPresenter((V) this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mPresenter.detachView();
    }

    protected abstract T createPresenter(V v);
}
