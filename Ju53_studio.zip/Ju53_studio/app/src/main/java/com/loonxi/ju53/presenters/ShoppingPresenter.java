package com.loonxi.ju53.presenters;

import android.view.View;

import com.loonxi.ju53.R;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartCheckEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.models.IShoppingModel;
import com.loonxi.ju53.models.impl.ShoppingModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.IShoppingView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2015/12/30.
 */
public class ShoppingPresenter {
    private IShoppingModel mModel;
    private IShoppingView mView;

    public ShoppingPresenter(IShoppingView mView) {
        this.mView = mView;
        mModel = new ShoppingModel();
    }


    //////////////////////////////////////内存数据处理/////////////////////////////////////

    public Map<String, Boolean> getEditCompanyMap() {
        return mModel._getEditCompanyMap();
    }

    public Map<String, Boolean> getCheckCompanyMap() {
        return mModel._getCheckCompanyMap();
    }

    public Map<String, Boolean> getCheckProductMap() {
        return mModel._getCheckProductMap();
    }

    public List<CartCheckEntity> getCheckProductList() {
        return mModel._getCheckProductList();
    }

    public int getProductTotalNums() {
        return mModel._getProductTotalNums();
    }

    public List<CartEntity> getCarts() {
        return mModel._getCarts();
    }

    public String getCheckFreightIds() {
        return mModel._getCheckFreightIds();
    }

    /**
     * 是否选中了店铺下的所有产品
     *
     * @param cart
     * @param isCheckProduct
     * @return
     */
    public boolean isCheckAllProduct4Company(CartEntity cart, boolean isCheckProduct) {
        return mModel._isCheckAllProduct4Company(cart, isCheckProduct);
    }

    /**
     * 购物车中是否存在某个产品
     *
     * @param cart
     * @param stockId
     * @return
     */
    public boolean productIsExist(CartEntity cart, String stockId) {
        return mModel._productIsExist(cart, stockId);
    }

    public double getCheckPrice() {
        return mModel._getCheckPrice();
    }

    public String getCheckStockId() {
        return mModel._getCheckStockId();
    }

    public int getCheckProductNums() {
        return mModel._getCheckProductList().size();
    }

    /**
     * 初始化map
     *
     * @param carts
     */
    public void initData(List<CartEntity> carts) {
        initData(carts, true);
    }

    public void initData(List<CartEntity> carts, boolean changeEdit) {
        mModel._initData(carts, changeEdit);
    }

    /**
     * 全选/全不选
     *
     * @param isCheckAll
     */
    public void checkAll(boolean isCheckAll) {
        mModel._updateDataAfterCheckAll(isCheckAll);
    }


    /**
     * 全编辑
     *
     * @param isCheckAll
     */
    public void editAll(boolean isCheckAll) {
        mModel._updateDataAfterEditAll(isCheckAll);
    }

    /**
     * 编辑某个店铺
     *
     * @param cart
     * @param isEdit
     */
    public void updateDataAfterEditCompany(CartEntity cart, boolean isEdit) {
        mModel._updateDataAfterEditCompany(cart, isEdit);
    }


    /**
     * 选择/取消选择单个产品
     *
     * @param cart
     * @param product
     * @param isChecked
     */
    public void updateDataAfterCheckProduct(CartEntity cart, BaseProductEntity product, boolean isChecked) {
        mModel._updateDataAfterCheckProduct(cart, product, isChecked);
    }

    /**
     * 选择/取消选择店铺
     *
     * @param cart
     * @param isChecked
     */
    public void updateDataAfterCheckCompany(CartEntity cart, boolean isChecked) {
        mModel._updateDataAfterCheckCompany(cart, isChecked);
    }

    /**
     * 删除单个产品
     *
     * @param cart
     * @param product
     */
    public void updateDataAfterDeleteOneProduct(CartEntity cart, BaseProductEntity product) {
        mModel._updateDataAfterDeleteOneProduct(cart, product);
    }

    /**
     * 删除多个产品
     *
     * @param carts
     */
    public void updataDataAfterDeleteMultiProducts(List<CartCheckEntity> carts) {
        mModel._updateDataAfterDeleteMultiProduct(carts);
    }

    /**
     * 修改购物车产品的数量
     *
     * @param parentIndex
     * @param productIndex
     * @param nums
     */
    public void updateDataAfterAltCartNums(int parentIndex, int productIndex, int nums) {
        mModel._updateDataAfterAltCartNums(parentIndex, productIndex, nums);
    }

    /**
     * 修改购物车产品的属性(修改后，购物车中存在相同的stockId，则删除此产品)
     *
     * @param cart
     * @param product
     * @param color
     * @param size
     */
    public void updateDataAfterAltCartAttribute(CartEntity cart, BaseProductEntity product, String color, String size, boolean checkProduct) {
        mModel._updateDataAfterAltCartAttribute(cart.getSupperId(), product, color, size, checkProduct);
    }


    /////////////////////////////////////////从后台拉取数据///////////////////////////////////////////////

    /**
     * 获取购物车所有信息
     *
     *
     */
    public void getCartsData(boolean isPull) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        if(!isPull && mView != null) {
            mView.startAsyncTask();
        }
        mModel.getCarts(map, new Callback<JsonArrayInfo<CartEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<CartEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<CartEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetCartsSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetCartsFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 删除多个产品
     *
     * @param carts
     */
    public void deleteMultiProducts(final List<CartCheckEntity> carts) {
        if (ListUtil.isEmpty(carts)) {
            return;
        }
        StringBuffer sb = new StringBuffer();
        sb.append("[");
        for (CartCheckEntity check : carts) {
            CartEntity cart = new CartEntity();
            cart.setSupperId(check.getSupperId());
            cart.setUserName(check.getCompanyName());
            BaseProductEntity product = check;
            sb.append("\"" + product.getPid() + "\",");
        }
        if (sb.length() > 1) {
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append("]");
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", sb.toString());
        mView.startAsyncTask();
        mModel.deleteProduct(map, new Callback<JsonArrayInfo<CartEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<CartEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<CartEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onDeleteMultiProductsSuccess(carts);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onDeleteMultiProductsFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 删除购物车单个产品
     *
     * @param cart
     * @param product
     */
    public void deleteOneProduct(final CartEntity cart, final BaseProductEntity product) {
        StringBuffer sb = new StringBuffer();
        sb.append("[");
        sb.append("\"" + product.getPid() + "\"");
        sb.append("]");
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", sb.toString());
        mView.startAsyncTask();
        mModel.deleteProduct(map, new Callback<JsonArrayInfo<CartEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<CartEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<CartEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onDeleteOneProductSuccess(cart, product);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onDeleteOneProductFailed(apiErrorCode, message);

            }
        });
    }

    /**
     * 获取库存信息
     *
     * @param view
     * @param cart
     * @param product
     */
    public void getSku(final View view, final CartEntity cart, final BaseProductEntity product) {
        if (product == null) {
            mView.showToast(R.string.shopping_null);
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", product.getProductId());
        mView.startAsyncTask();
        mModel.getSku(map, new Callback<ProductAttributeEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, ProductAttributeEntity data) {

            }

            @Override
            public void onSuccess(ProductAttributeEntity data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetSkuSuccess(view, cart, product, data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetSkuFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 修改购物车产品属性
     *
     * @param pid
     * @param attributeColor
     * @param attributeMula
     * @param stockId
     * @param count
     */
    public void altCartAttribute(String pid, String attributeColor, String attributeMula, String stockId, int count) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();

        JSONArray array = new JSONArray();
        JSONObject object = new JSONObject();
        try {
            object.put("pid", pid);
            object.put("attrbuteColor", attributeColor);
            object.put("attrbuteMula", attributeMula);
            object.put("stockId", stockId);
            object.put("count", count + "");
            array.put(object);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        map.put("carts", array.toString());
        mModel.updateCart(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onUpdateCartSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onUpdateCartFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 移至收藏夹
     * @param checks
     */
    public void moveToFav(final List<CartCheckEntity> checks) {
        if (ListUtil.isEmpty(checks)) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        JSONArray array = new JSONArray();
        for (BaseProductEntity check : checks) {
            JSONObject object = new JSONObject();
            try {
                object.put("pid", check.getPid());
                object.put("productId", check.getProductId());
                array.put(object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        map.put("targets", array.toString());
        mModel.moveToFav(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onMoveToFavSuccess(checks);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.onMoveToFavFailed(apiErrorCode, message);
            }
        });
    }

}
