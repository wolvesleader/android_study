package com.loonxi.ju53.views;

/**
 * 新建、修改 收货地址 回调接口
 * Created by Administrator on 2016/1/27.
 */
public interface IUpdateAddressView {

    public void updateAddressSuccess();

    public void updateAddressFailure(String message);
}
