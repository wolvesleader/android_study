package com.loonxi.ju53.views;

/**
 * Created by Xuzue on 2016/1/5.
 */
public interface IRegistCodeView extends IBaseView{
    void showToast(int resId);
    void onVerifyCodeSuccess();
    void onVerifyCodeFailed(int apiErrorCode, String message);
}
