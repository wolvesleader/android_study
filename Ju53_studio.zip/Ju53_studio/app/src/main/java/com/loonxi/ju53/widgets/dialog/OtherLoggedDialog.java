package com.loonxi.ju53.widgets.dialog;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MainActivity;

/**
 * Created by butterfly on 2015/8/29.
 */
public class OtherLoggedDialog extends BaseDialog {

    private TextView mTvContent;
    private Button mBtnOk;
    private Button mBtnCancle;

    public OtherLoggedDialog(final Context context) {
        super(context);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        View v = LayoutInflater.from(context).inflate(R.layout.dialog_btn, null);
        addView(v);
        setTitle(context.getResources().getString(R.string.tip));
        mTvContent = (TextView) findViewById(R.id.dialog_tv_content);
        mBtnOk = (Button) findViewById(R.id.dialog_btn_ok);
        mBtnCancle = (Button) findViewById(R.id.dialog_btn_cancle);
        mTvContent.setText("该账号已在其他设备登录，是否重新登录?");
        mBtnOk.setText("重新登录");
        mBtnCancle.setText(context.getResources().getString(R.string.tip));
        mBtnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
                Intent intent = new Intent(context, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(intent);

            }
        });
        mBtnCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
                Intent intent = new Intent(context, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(intent);

            }
        });
    }
}
