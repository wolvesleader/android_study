package com.loonxi.ju53.utils;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.File;
import java.util.List;

/**
 * Created by Xuze on 2015/9/4.
 */
public class IntentUtil {

    public static final int REQUEST_CODE_ALBUM = 9001;
    public static final int REQUEST_CODE_CAMERA = 9002;
    public static final int REQUEST_CODE_CROP = 9003;

    public static final String[] HTML = new String[]{".htm", ".html", ".jsp", ".php"};
    public static final String[] IMAGE = new String[]{".jpg", ".png", ".gif", ".jpeg", ".bmp"};
    public static final String[] AUDIO = new String[]{".mp3", ".wav", ".ogg", ".midi"};
    public static final String[] VIDEO = new String[]{".mp4", ".rmvb", ".avi", ".flv"};
    public static final String[] APK = new String[]{".apk"};
    public static final String[] TEXT = new String[]{".txt", ".java", ".c", ".cpp", ".py", ".xml", ".json", ".log"};
    public static final String[] CHM = new String[]{".chm"};
    public static final String[] WORD = new String[]{".doc", ".docx"};
    public static final String[] EXCEL = new String[]{".xls", ".xlsx"};
    public static final String[] PPT = new String[]{".ppt", ".pptx"};
    public static final String[] PDF = new String[]{".pdf"};


    /**
     * 跳转到相册
     * @param activity
     * @return
     */
    public static boolean intentToAlbum(Activity activity){
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        activity.startActivityForResult(intent, REQUEST_CODE_ALBUM);
        return true;
    }

    /**
     * 跳转到相机
     * @param activity
     * @param context
     * @param savePath 存储路径，以/结尾
     * @param saveName 不包含路径
     * @return
     */
    public static boolean intentToCamera(Activity activity, Context context, String savePath, String saveName){
        if(context == null || StringUtil.isEmpty(savePath) || StringUtil.isEmpty(saveName)){
            return false;
        }
        File fileDir = FileUtil.createDirFile(context, savePath);
        if(fileDir == null){
            return false;
        }
        File file = FileUtil.createNewFile(context, savePath + saveName);
        if(file == null){
            return false;
        }
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
        activity.startActivityForResult(intent, REQUEST_CODE_CAMERA);
        return true;
    }


    /**
     * 裁剪图片
     * @param activity
     * @param uri
     */
    public static void startPhotoZoom(Activity activity, Uri uri) {
        if(activity == null || uri == null){
            return;
        }
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1);//裁剪框比例
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 80);//输出图片大小
        intent.putExtra("outputY", 80);
        intent.putExtra("scale", true);
        intent.putExtra("noFaceDetection", true);
        intent.putExtra("return-data", true);
        activity.startActivityForResult(intent, REQUEST_CODE_CROP);
    }

    /**
     * 跳转到浏览器
     * @param context
     * @param uri
     * @return
     */
    public static boolean intentToBrowser(Context context, String uri){
        return intentToView(context, uri);
    }

    /**
     * 跳转到地图
     * @param context
     * @param uri
     * @return
     */
    public static boolean intentToMap(Context context, String uri){
        return intentToView(context, uri);
    }

    /**
     * 跳转到View
     * @param context
     * @param uri
     * @return
     */
    public static boolean intentToView(Context context, String uri){
        if(context == null || StringUtil.isEmpty(uri)){
            return false;
        }
        Uri u = Uri.parse(uri);
        Intent intent = new Intent(Intent.ACTION_VIEW, u);
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开拨打电话界面
     * @param context
     * @param phoneNumber
     * @return
     */
    public static boolean intentToDial(Context context, String phoneNumber){
        if(context == null || StringUtil.isEmpty(phoneNumber)){
            return false;
        }
        Uri uri = Uri.parse("tel:" + phoneNumber);
        Intent intent = new Intent(Intent.ACTION_DIAL, uri);
        context.startActivity(intent);
        return true;
    }

    /**
     * 直接拨打电话
     * @param context
     * @param phoneNumber
     * @return
     */
    public static boolean intentToCall(Context context, String phoneNumber){
        if(context == null || StringUtil.isEmpty(phoneNumber)){
            return false;
        }
        Uri uri = Uri.parse("tel:" + phoneNumber);
        Intent intent = new Intent(Intent.ACTION_CALL, uri);
        context.startActivity(intent);
        return true;
    }

    /**
     * 发送短信
     * @param context
     * @param phoneNumber
     * @param smsBody
     * @return
     */
    public static boolean intentToSms(Context context, String phoneNumber, String smsBody){
        if(context == null || StringUtil.isEmpty(phoneNumber)){
            return false;
        }
        Uri uri = Uri.parse("smsto:" + phoneNumber);
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra("sms_body", StringUtil.isEmpty(smsBody) ? "" : smsBody);
        context.startActivity(intent);
        return true;
    }

    /**
     * 发送彩信
     * @param context
     * @param phoneNumber
     * @param subject
     * @param content
     * @param url
     * @return
     */
    public static boolean intentToImageSms(Context context, String phoneNumber, String subject, String content, String url){
        if(content == null || StringUtil.isEmpty(phoneNumber)){
            return false;
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(url));
        intent.putExtra("subject", subject);
        intent.putExtra("address", phoneNumber);
        intent.putExtra("sms_body", content);
        intent.setType("image/*");
        intent.setClassName("com.android.mms", "com.android.mms.ui.ComposeMessageActivity");
        context.startActivity(intent);
        return true;
    }

    /**
     * 发送邮件
     * @param context
     * @param emailAddress
     * @param subject
     * @param emailBody
     * @return
     */
    public static boolean intentToEmail(Context context, String emailAddress, String subject, String emailBody){
        if(context == null || StringUtil.isEmpty(emailAddress)){
            return false;
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailAddress});
        intent.putExtra(Intent.EXTRA_SUBJECT, StringUtil.isEmpty(subject) ? "" : subject);
        intent.putExtra(Intent.EXTRA_TEXT, StringUtil.isEmpty(emailBody) ? "" : emailBody);
        context.startActivity(Intent.createChooser(intent, "请选择邮件发送软件"));
        return true;
    }

    /**
     * 在应用市场打开应用详情
     * @param context
     * @param packageName
     * @return
     */
    public static boolean intentToDetailMarket(Context context, String packageName){
        if(context == null || StringUtil.isEmpty(packageName)){
            return false;
        }
        try{
            String str = "market://details?id=" + packageName;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(str));
            context.startActivity(intent);
            return true;
        }catch (Exception e){

        }
        return false;
    }

    /**
     * 根据包名打开应用程序
     * @param context
     * @param packageName
     * @return
     */
    public static boolean intentToApp(Context context, String packageName){
        if(context == null || StringUtil.isEmpty(packageName)){
            return false;
        }
        PackageManager manager = context.getPackageManager();
        if(manager == null){
            return false;
        }
        Intent intent = manager.getLaunchIntentForPackage(packageName);
        context.startActivity(intent);
        return true;
    }

    /**
     * 根据包名、类名打开应用程序
     * @param context
     * @param packageName 例如：com.example.mydemo
     * @param className 例如：com.example.mydemo.activity.MyActivity
     * @return
     */
    public static boolean intentToApp(Context context, String packageName, String className){
        if(context == null || StringUtil.isEmpty(packageName) || StringUtil.isEmpty(className)){
            return false;
        }
        ComponentName cn = new ComponentName(packageName, className);
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setComponent(cn);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return true;
    }

    /**
     * 回到桌面
     * @param context
     * @return
     */
    public static boolean intentToHome(Context context){
        if(context == null){
            return false;
        }
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开不带参数的activity
     * @param context
     * @param cls 例如：MainActivity.class
     * @return
     */
    public static boolean intentCommonActivity(Context context, Class cls){
        if(context == null || cls == null){
            return false;
        }
        Intent intent = new Intent();
        intent.setClass(context, cls);
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开html文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openHtmlFile(Context context, File file){
        if(context == null || !checkFileEndings(file, HTML)){
            return false;
        }
        Uri uri = Uri.parse(file.toString()).buildUpon().encodedAuthority("com.android.htmlfileprovider")
                .scheme("content").encodedPath(file.toString()).build();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setType("text/html");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开图片
     * @param context
     * @param file
     * @return
     */
    public static boolean openImageFile(Context context, File file){
        if(context == null || !checkFileEndings(file, IMAGE)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "image/*");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开pdf文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openPdfFile(Context context, File file){
        if(context == null || !checkFileEndings(file, PDF)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "application/pdf");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开文本文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openTextFile(Context context, File file){
        if(context == null || !checkFileEndings(file, TEXT)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "text/plain");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开word文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openWordFile(Context context, File file){
        if(context == null || !checkFileEndings(file, WORD)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "application/msword");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开excel文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openExcelFile(Context context, File file){
        if(context == null || !checkFileEndings(file, EXCEL)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "application/vnd.ms-excel");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开ppt文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openPPTFile(Context context, File file){
        if(context == null || !checkFileEndings(file, PPT)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "application/vnd.ms-powerpoint");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开apk文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openApkFile(Context context, File file){
        if(context == null || !checkFileEndings(file, EXCEL)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开音频文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openAudioFile(Context context, File file){
        if(context == null || !checkFileEndings(file, AUDIO)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setDataAndType(uri, "audio/*");
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        context.startActivity(intent);
        return true;
    }

    /**
     * 打开视频文件
     * @param context
     * @param file
     * @return
     */
    public static boolean openVideoFile(Context context, File file){
        if(context == null || !checkFileEndings(file, VIDEO)){
            return false;
        }
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setDataAndType(uri, "video/*");
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        context.startActivity(intent);
        return true;
    }

    /**
     * 检查文件后缀名
     * @param file
     * @param fileEndings
     * @return
     */
    public static boolean checkFileEndings(File file, String... fileEndings){
        if(file == null || !file.exists() || ArrayUtil.isEmpty(fileEndings)){
            return false;
        }
        for(String ends : fileEndings){
            if(file.getPath().toLowerCase().endsWith(ends)){
                return true;
            }
        }
        return false;
    }

    /**
     * 是否有activity可以响应这个intent
     * @param context
     * @param intent
     * @return
     */
    public static boolean isIntentSafe(Context context, Intent intent){
        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(intent, 0);
        return activities.size() > 0;
    }
}