package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.IntentUtil;


/**
 * 自定义上传图片Dialog
 * @author Administrator
 *
 */
public class PicDialog extends BaseDialog implements
		View.OnClickListener {

	private Activity mActivity;
	private TextView mTvCamera;
	private TextView mTvAlbum;

	private String mDirPath;
	private String mPicName;

	/**
	 * @param activity
	 * @param context
	 * @param dirPath 存储路径，以/结尾
	 * @param picName 不包含路径
	 */
	public PicDialog(Activity activity, Context context, String dirPath,
					 String picName) {
		super(context);
		View v = LayoutInflater.from(context)
				.inflate(R.layout.dialog_pic, null);
		addView(v);
		setTitle(context.getResources().getString(R.string.upload_pic));
		mTvCamera = (TextView) findViewById(R.id.dialog_pic_tv_camera);
		mTvAlbum = (TextView) findViewById(R.id.dialog_pic_tv_album);
		mTvCamera.setOnClickListener(this);
		mTvAlbum.setOnClickListener(this);
		mActivity = activity;
		mDirPath = dirPath;
		mPicName = picName;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.dialog_pic_tv_camera:
			IntentUtil.intentToCamera(mActivity, getContext(), mDirPath,
					mPicName);
			break;

		case R.id.dialog_pic_tv_album:
			IntentUtil.intentToAlbum(mActivity);
			break;
		}
		dismiss();
	}
}
