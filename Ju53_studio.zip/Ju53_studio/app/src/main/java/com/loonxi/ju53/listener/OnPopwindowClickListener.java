package com.loonxi.ju53.listener;

/**
 * Created by Xuzue on 2016/1/28.
 */
public interface OnPopwindowClickListener {
    void click(String data, int position);
}
