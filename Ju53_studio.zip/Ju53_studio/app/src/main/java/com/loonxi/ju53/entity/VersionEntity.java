package com.loonxi.ju53.entity;

import java.io.Serializable;

/**
 * 版本信息实体
 * Created by Xuzue on 2015/12/17.
 */
public class VersionEntity implements Serializable {
    private String version;
    private int type;
    private String url;
    private String remark;
    private FileEntity fileInfo;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public FileEntity getFileInfo() {
        return fileInfo;
    }

    public void setFileInfo(FileEntity fileInfo) {
        this.fileInfo = fileInfo;
    }
}
