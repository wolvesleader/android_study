package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/1/11.
 */
public interface ProductService {

    /**
     * 获取产品基本信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("item/getItemDetails")
    Call<JsonInfo<ProductDetailEntity>> getBaseInfo(@FieldMap Map<String, Object> map);

    /**
     * 获得库存/属性信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("item/getSku")
    Call<ProductAttributeEntity> getSku(@FieldMap Map<String, Object> map);

    /**
     * 获取产品详情（基本信息+图文详情）
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("item/getItemDesc")
    Call<JsonInfo<ProductDetailEntity>> getDetailInfo(@FieldMap Map<String, Object> map);

    /**
     * 加入购物车
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/addCart")
    Call<Object> addToCart(@FieldMap Map<String, Object> map);

    /**
     * 获取同店推荐
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("item/push")
    Call<JsonArrayInfo<BaseProductEntity>> getRecommends(@FieldMap Map<String, Object> map);
}
