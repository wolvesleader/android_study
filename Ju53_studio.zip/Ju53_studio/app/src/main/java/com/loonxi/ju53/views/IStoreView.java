package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.StockEntity;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
public interface IStoreView extends IBaseView{
    void onGetStoreProductSuccess(StoreDataEntity store);
    void onGetStoreProductFailed(int apiErrorCode, String message);
    void onSaleSuccess();
    void onSaleFailed(int apiErrorCode, String message);
    void offSaleSuccess();
    void offSaleFailed(int apiErrorCode, String message);
    void deleteProductSuccess();
    void deleteProductFailed(int apiErrorCode, String message);
    void moveToTopSuccess();
    void moveToTopFailed(int apiErrorCode, String message);
    void getBaseInfoSuccess(StoreBaseInfoEntity storeBaseInfo);
    void getBaseInfoFailed(int apiErrorCode, String message);
}
