package com.loonxi.ju53.base;

import android.os.Bundle;

/**
 * "BaseActivity" 加了软引用
 * Created by laojiaqi on 2016/2/2.
 */
public abstract class BaseSafeActivity<V,T extends BasePresenter<V>> extends  BaseActivity  {
    protected T mPresenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPresenter= createPresenter((V)this);
    }

    protected abstract T createPresenter(V v);
}
