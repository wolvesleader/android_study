package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 订单地址
 * Created by Xuzue on 2016/1/26.
 */
public class OrderAddressEntity implements Parcelable {
    private int pid;
    private long userId;
    private String orderId;
    private String receiveAddress;
    private String contact;
    private String phones;
    private String zip;
    private int isSent;
    private long createTime;
    private long updateTime;

    protected OrderAddressEntity(Parcel in) {
        pid = in.readInt();
        userId = in.readLong();
        orderId = in.readString();
        receiveAddress = in.readString();
        contact = in.readString();
        phones = in.readString();
        zip = in.readString();
        isSent = in.readInt();
        createTime = in.readLong();
        updateTime = in.readLong();
    }

    public static final Creator<OrderAddressEntity> CREATOR = new Creator<OrderAddressEntity>() {
        @Override
        public OrderAddressEntity createFromParcel(Parcel in) {
            return new OrderAddressEntity(in);
        }

        @Override
        public OrderAddressEntity[] newArray(int size) {
            return new OrderAddressEntity[size];
        }
    };

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getReceiveAddress() {
        return receiveAddress;
    }

    public void setReceiveAddress(String receiveAddress) {
        this.receiveAddress = receiveAddress;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhones() {
        return phones;
    }

    public void setPhones(String phones) {
        this.phones = phones;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public int getIsSent() {
        return isSent;
    }

    public void setIsSent(int isSent) {
        this.isSent = isSent;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(pid);
        dest.writeLong(userId);
        dest.writeString(orderId);
        dest.writeString(receiveAddress);
        dest.writeString(contact);
        dest.writeString(phones);
        dest.writeString(zip);
        dest.writeInt(isSent);
        dest.writeLong(createTime);
        dest.writeLong(updateTime);
    }
}
