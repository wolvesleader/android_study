package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.RegistAuthEntity;

/**
 * Created by Xuzue on 2016/1/5.
 */
public interface IRegistAuthView extends IBaseView{
    void showToast(int resId);
    void onAuthSuccess(RegistAuthEntity authEntity);
    void onAuthFailed(int apiErrorCode, String message);
}
