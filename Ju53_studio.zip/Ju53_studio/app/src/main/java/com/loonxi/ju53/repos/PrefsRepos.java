package com.loonxi.ju53.repos;

import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.utils.AESUtil;
import com.loonxi.ju53.utils.AesSecretUtil;
import com.loonxi.ju53.utils.ChannelUtil;
import com.loonxi.ju53.utils.PackageUtil;
import com.loonxi.ju53.utils.PrefsUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Xuzue on 2015/12/17.
 */
public class PrefsRepos {


    private static String getUserId() {
        String userId = SpUtil.getString(BaseApplication.instance, SpUtil.ACCOUNT_USER_ID, "");
        String uidu = userId;
        if (!StringUtil.isEmpty(userId)) {
            try {
                uidu = AesSecretUtil.aesEncryptModeBase64(userId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return uidu;
    }

    /**
     * 接口请求默认字段（无序Map）
     *
     * @return
     */
    public static Map<String, Object> getDefaultMap() {
        return getDefaultMap(ChannelUtil.getChannelId());
    }

    public static Map<String, Object> getDefaultMap(boolean needLogin) {
        return getDefalutMap(ChannelUtil.getChannelId(), needLogin);
    }

    /**
     * 接口请求默认字段（无序Map）
     *
     * @param requestType
     * @return
     */
    public static Map<String, Object> getDefaultMap(String requestType) {
        return getDefalutMap(requestType, true);
    }

    public static Map<String, Object> getDefalutMap(String requestType, boolean needLogin) {
        Map<String, Object> map = new HashMap<>();
        map.put("requestType", requestType);
        map.put("version", PackageUtil.getVersionName(BaseApplication.instance));
        map.put("imei", SpUtil.getString(BaseApplication.getInstance(), SpUtil.IMEI));
        map.put("marketType", ChannelUtil.getChannelId());
        map.put("uidu", getUserId());
        map.put("needLogin", needLogin ? 1 : 0);
        return map;
    }


    /**
     * 接口请求默认字段（无序Map）
     *
     * @return
     */
    public static Map<String, Object> getObjectMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("requestType", ChannelUtil.getChannelId());
        map.put("version", PackageUtil.getVersionName(BaseApplication.instance));
        map.put("imei", SpUtil.getString(BaseApplication.getInstance(), SpUtil.IMEI));
        map.put("marketType", ChannelUtil.getChannelId());
        map.put("uidu", getUserId());
        return map;
    }


    /**
     * 接口请求默认字段（按key升序排列的有序Map）
     *
     * @return
     */
    public static Map<String, Object> getDefaultOrderedMap() {
        Map<String, Object> map = new TreeMap<>();
        map.put("requestType", ChannelUtil.getChannelId());
        map.put("version", PackageUtil.getVersionName(BaseApplication.instance));
        map.put("imei", SpUtil.getString(BaseApplication.getInstance(), SpUtil.IMEI));
        map.put("marketType", ChannelUtil.getChannelId());
        return map;
    }

    public static String getRequestType() {
        return PrefsUtil.getSharedStringData(BaseApplication.instance, AppConst.PrefKey.PREF_REQ_TYPE);
    }

    public static void setRequestType(String type) {
        PrefsUtil.setSharedStringData(BaseApplication.instance, AppConst.PrefKey.PREF_REQ_TYPE, type);
    }
}
