package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.AddressInfoEntity;

import java.util.List;

/**
 * 地址信息（国内） 回调接口
 * Created by Administrator on 2016/1/26.
 */
public interface IAddressInfoView {
    public void getAddressInfoSuccess(List<AddressInfoEntity> dataList);

    public void getAddressInfoFailure(String message);
}
