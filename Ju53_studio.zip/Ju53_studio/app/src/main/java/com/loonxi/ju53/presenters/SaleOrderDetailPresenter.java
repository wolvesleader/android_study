package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.SaleOrderDetailEntity;
import com.loonxi.ju53.models.IOrderModel;
import com.loonxi.ju53.models.IStoreModel;
import com.loonxi.ju53.models.impl.OrderModel;
import com.loonxi.ju53.models.impl.StoreModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ISaleOrderDetailView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/12 0012.
 */
public class SaleOrderDetailPresenter {
    private ISaleOrderDetailView mView;
    private IOrderModel mModel;

    public SaleOrderDetailPresenter(ISaleOrderDetailView mView) {
        this.mView = mView;
        mModel = new OrderModel();
    }

    /**
     * 查询分销订单详情
     * @param orderId
     */
    public void getSaleOrderDetail(String orderId, String state, boolean showDialog) {
        if (StringUtil.isEmpty(orderId)) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("orderid", orderId);
        map.put("state", state);
        if (showDialog && mView != null) {
            mView.startAsyncTask();
        }
        mModel.getSaleOrderDetail(map, new Callback<JsonInfo<SaleOrderDetailEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<SaleOrderDetailEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<SaleOrderDetailEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onGetOrderDetailSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onGetOrderDetailFailed(apiErrorCode, message);
                }
            }
        });
    }
}
