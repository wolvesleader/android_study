package com.loonxi.ju53.convert;

import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.entity.SaleOrderUnitEntity;
import com.loonxi.ju53.utils.ListUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by XuZue on 2016/5/12 0012.
 */
public class SaleOrderDataConvert {

    public static List<SaleOrderUnitEntity> getSaleOrderUnitFromSaleOrderEntity(List<SaleOrderEntity> orders){
        List<SaleOrderUnitEntity> units = new ArrayList<>();
        if(ListUtil.isEmpty(orders)){
            return units;
        }
        for(int i = 0 ;i < orders.size(); i++){
            SaleOrderEntity order = orders.get(i);
            if(order != null){
                if(!ListUtil.isEmpty(order.getAttr())){
                    units.addAll(order.getAttr());
                }
            }
        }
        return units;
    }
}
