package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * 资金信息
 * Created by XuZue on 2016/5/5 0005.
 */
public class FinanceEntity implements Parcelable {
    private String balance;//可提现
    private String frozen;//提现中
    private String total;//累计收入
    private String total_out;//已提现
    private String bd_card;//是否绑定提现账户 1:绑定 0：未绑定
    private String pid;//绑定银行卡的pid
    private String account_name;//绑定银行卡的姓名
    private String account;//绑定银行卡的账号
    private String helpurl;//帮助链接
    private double floor;//提现最低金额

    public FinanceEntity() {

    }

    protected FinanceEntity(Parcel in) {
        balance = in.readString();
        frozen = in.readString();
        total = in.readString();
        total_out = in.readString();
        bd_card = in.readString();
        pid = in.readString();
        account_name = in.readString();
        account = in.readString();
        helpurl = in.readString();
        floor = in.readDouble();
    }

    public static final Creator<FinanceEntity> CREATOR = new Creator<FinanceEntity>() {
        @Override
        public FinanceEntity createFromParcel(Parcel in) {
            return new FinanceEntity(in);
        }

        @Override
        public FinanceEntity[] newArray(int size) {
            return new FinanceEntity[size];
        }
    };

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getFrozen() {
        return frozen;
    }

    public void setFrozen(String frozen) {
        this.frozen = frozen;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTotal_out() {
        return total_out;
    }

    public void setTotal_out(String total_out) {
        this.total_out = total_out;
    }

    public String getState() {
        return bd_card;
    }

    public void setState(String state) {
        this.bd_card = state;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getHelpurl() {
        return helpurl;
    }

    public void setHelpurl(String helpurl) {
        this.helpurl = helpurl;
    }

    public double getFloor() {
        return floor;
    }

    public void setFloor(double floor) {
        this.floor = floor;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(balance);
        dest.writeString(frozen);
        dest.writeString(total);
        dest.writeString(total_out);
        dest.writeString(bd_card);
        dest.writeString(pid);
        dest.writeString(account_name);
        dest.writeString(account);
        dest.writeString(helpurl);
        dest.writeDouble(floor);
    }
}
