package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 评论service
 * Created by laojiaqi on 2016/2/16.
 */
public interface CommentService {

    /**
     * 发送评论
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/tradeRate")
    Call<BaseJsonInfo> sendMessage(@FieldMap Map<String, Object> map);


    /**
     * 获取评论
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("item/showTradeRate")
    Call<TotalCommentEntity> getComments(@FieldMap Map<String, Object> map);

}
