package com.loonxi.ju53.presenters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.entity.MainBannderEntity;
import com.loonxi.ju53.models.impl.HomeTabFirstModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.views.IHomeTabView;

import org.xutils.common.util.DensityUtil;

import java.util.List;
import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by laojiaqi on 2016/6/1.
 */
public class HomeTabFirstPresenter extends BasePresenter<IHomeTabView> {
    private IHomeTabView iHomeTabView;
    private HomeTabFirstModel homeTabFirstModel;

    public HomeTabFirstPresenter(IHomeTabView view) {
        super(view);
        iHomeTabView=getView();
        homeTabFirstModel=new HomeTabFirstModel();
    }

    /**
     * 设置频道列表
     * @param ll_characteristic
     * @param mActivity
     * @param feature
     */
   public  void  setPinDaoList(LinearLayout ll_characteristic, Activity mActivity, List<MainBannderEntity.DataEntity.FeatureEntity> feature)
   {
       if (feature==null ||feature.size()==0)
       {
           return;
       }
       ll_characteristic.removeAllViews();
       //设置频道文字
       TextView textView=new TextView(mActivity);
       textView.setTextSize(17);
       textView.setPadding(DensityUtil.dip2px(10), DensityUtil.dip2px(10), 0, DensityUtil.dip2px(10));
       textView.setText("特色频道");
       textView.setTextColor(Color.BLACK);
       textView.getPaint().setFakeBoldText(true);
       LinearLayout  pindaoLinearLayout=new LinearLayout(mActivity);
       pindaoLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
       pindaoLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, DisplayUtil.getGeometricHeight(mActivity, 460)));
       //设置左边右边的列表
       LinearLayout leftLayout=new LinearLayout(mActivity);
       leftLayout.setOrientation(LinearLayout.VERTICAL);
       LinearLayout.LayoutParams  left_params=new LinearLayout.LayoutParams( LinearLayout.LayoutParams.MATCH_PARENT,
               LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
       left_params.setMargins(0, 0, 5, 0);
       //设置子view
       ImageView left_top_view=new ImageView(mActivity);
       left_top_view.setScaleType(ImageView.ScaleType.CENTER_CROP);
       left_top_view.setBackgroundColor(Color.RED);
           //设置左边上面图片
          // Glide.with(mActivity).load(AppConst.PIC_HEAD + featureEntity.getImg_url() ).into(left_top_view);
       LinearLayout.LayoutParams left_top_params= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,DisplayUtil.getGeometricHeight(mActivity,240));
       left_top_view.setLayoutParams(left_top_params);
       left_top_params.setMargins(0,0,0,5);
       leftLayout.addView(left_top_view);
       //左边底部图片
       LinearLayout.LayoutParams left_bottom_params= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,DisplayUtil.getGeometricHeight(mActivity,210));
       ImageView left_bottom_view=new ImageView(mActivity);
       left_bottom_view.setBackgroundColor(Color.GREEN);
       left_bottom_view.setLayoutParams(left_bottom_params);
       leftLayout.setLayoutParams(left_params);
       leftLayout.addView(left_bottom_view);
       //设置右边列表
       LinearLayout rightLayout=new LinearLayout(mActivity);
       rightLayout.setOrientation(LinearLayout.VERTICAL);
       LinearLayout.LayoutParams  right_params=new LinearLayout.LayoutParams( LinearLayout.LayoutParams.MATCH_PARENT,
               LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
       rightLayout.setLayoutParams(right_params);
       ImageView right_top_view=new ImageView(mActivity);
       right_top_view.setScaleType(ImageView.ScaleType.CENTER_CROP);
       right_top_view.setBackgroundColor(Color.YELLOW);
       LinearLayout.LayoutParams right_top_params= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,DisplayUtil.getGeometricHeight(mActivity,210));
       right_top_params.setMargins(0,0,0,5);
       right_top_view.setLayoutParams(right_top_params);
       rightLayout.addView(right_top_view);
       ImageView right_bottom_view=new ImageView(mActivity);
       right_bottom_view.setScaleType(ImageView.ScaleType.CENTER_CROP);
       right_bottom_view.setBackgroundColor(Color.BLUE);
       LinearLayout.LayoutParams right_bottom_params= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,DisplayUtil.getGeometricHeight(mActivity,240));
       right_bottom_view.setLayoutParams(right_bottom_params);
       rightLayout.addView(right_bottom_view);
       pindaoLinearLayout.addView(leftLayout);
       pindaoLinearLayout.addView(rightLayout);
       ll_characteristic.addView(textView);
       ll_characteristic.addView(pindaoLinearLayout);
   }
    /**
     *设置海涛馆
     */
    public void setHaiTaoIcon(LinearLayout ll_haitao, final Context context,List<MainBannderEntity.DataEntity.CategoryEntity> categoryEntityList) {
       if (categoryEntityList==null || categoryEntityList.size()==0)
       {
           return;
       }
        //设置左边最大图片
        ll_haitao.removeAllViews();
        ll_haitao.setBackgroundColor(Color.parseColor("#D8D8D8"));
        int height=  DisplayUtil.getGeometricHeight(context, 401);
        int width=DisplayUtil.getGeometricWidth(context, 287);
        LinearLayout left_linearLayout=new LinearLayout(context);

        LinearLayout.LayoutParams  params= new LinearLayout.LayoutParams(width,height );
        params.setMargins(0, 0, 1, 1);
        left_linearLayout.setLayoutParams(params);

        //设置imageView
        ImageView left_imageView=new ImageView(context);
        left_imageView.setBackgroundColor(Color.BLUE);
        left_imageView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        left_imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        left_linearLayout.addView(left_imageView);
        ll_haitao.addView(left_linearLayout);
        //设置中间的item
        LinearLayout middle_linearLayout=new LinearLayout(context);
        middle_linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams middle_params= new LinearLayout.LayoutParams((DisplayUtil.getScreenWidth(context)-width)/2, height);
        middle_params.setMargins(0, 0, 1, 1);
        middle_linearLayout.setLayoutParams(middle_params);
        ImageView middle_imageView=new ImageView(context);
        LinearLayout.LayoutParams middle_image= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,height/2);
        middle_image.setMargins(0,0,0,1);
        middle_imageView.setLayoutParams(middle_image);
        middle_imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        middle_linearLayout.addView(middle_imageView);
        //底部的Image
        ImageView middle_botton_imageView=new ImageView(context);
        middle_botton_imageView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,height/2));
        middle_botton_imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        middle_linearLayout.addView(middle_botton_imageView);
        ll_haitao.addView(middle_linearLayout);

        //设置最右边的item
        LinearLayout right_linearLayout=new LinearLayout(context);
        right_linearLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams  right_params= new LinearLayout.LayoutParams((DisplayUtil.getScreenWidth(context)-width)/2, height);
        right_params.setMargins(0, 0, 1, 1);
        right_linearLayout.setLayoutParams(right_params);
        ImageView right_imageView=new ImageView(context);
        LinearLayout.LayoutParams right_image_params=  new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,height/2);
        right_image_params.setMargins(0,0,0,1);
        right_imageView.setLayoutParams(right_image_params);
        right_imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        right_linearLayout.addView(right_imageView);
        //底部的Image
        ImageView  right_botton_imageView=new ImageView(context);
        right_botton_imageView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height / 2));
        right_botton_imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        right_linearLayout.addView(right_botton_imageView);
        ll_haitao.addView(right_linearLayout);
            for (int i = 0; i < categoryEntityList.size(); i++) {
                final MainBannderEntity.DataEntity.CategoryEntity entity=    categoryEntityList.get(i);
                if (i==0)
                {
                    //左边的大图
                    Glide.with(context).load(AppConst.PIC_HEAD + entity.getImg_url() ).into(left_imageView);
                    left_imageView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context, CommonWebviewActivity.class);
                            intent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, entity.getImg_link());
                            intent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, "团购测试");
                            context.startActivity(intent);
                        }
                    });
                }
                if (i==1)
                {
                    Glide.with(context).load(AppConst.PIC_HEAD + entity.getImg_url() ).into(middle_imageView);
                }
                if (i==2)
                {
                    Glide.with(context).load(AppConst.PIC_HEAD + entity.getImg_url() ).into(middle_botton_imageView);
                }
                if (i==3)
                {
                    Glide.with(context).load(AppConst.PIC_HEAD + entity.getImg_url() ).into(right_imageView);
                }
                if (i==4)
                {
                    Glide.with(context).load(AppConst.PIC_HEAD + entity.getImg_url() ).into(right_botton_imageView);
                }
            }
    }

    /**
     * 获取主界面列表数据
     */
      public  void  getHotActivity(int page)
      {
          iHomeTabView.startAsyncTask();
          Map<String, Object> map = PrefsRepos.getDefaultMap();
//          homeTabFirstModel.getHotActivity(map, new Callback<JsonArrayInfo<AgentProductEntity>>() {
//              @Override
//              public void onOtherFlag(int flag, String message, JsonArrayInfo<AgentProductEntity> data) {
//
//              }
//
//              @Override
//              public void onSuccess(JsonArrayInfo<AgentProductEntity> data, Retrofit retrofit)
//              {
////                  iHomeTabView.getHotActivity();
//              }
//
//              @Override
//              public void onFailed(int apiErrorCode, String message)
//              {
//                  iHomeTabView.getHotActivityFaile(apiErrorCode,message);
//              }
//          });
      }

    /**
     * bannder
     * 列表
     * 特色频道
     */
    public  void getTopListData()
    {
        Map<String, Object> map = PrefsRepos.getDefaultMap(false);

        homeTabFirstModel.getTopListData(map, new Callback<MainBannderEntity>() {
            @Override
            public void onOtherFlag(int flag, String message, MainBannderEntity data) {

            }

            @Override
            public void onSuccess(MainBannderEntity data, Retrofit retrofit) {
                iHomeTabView.endAsyncTask();
                iHomeTabView.getTopListData(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                iHomeTabView.endAsyncTask();
                iHomeTabView.getTopListDataFaile(apiErrorCode,message);
            }
        });

    }





}
