package com.loonxi.ju53.views;

/**
 * Created by Xuzue on 2016/1/5.
 */
public interface IRegistPhoneView extends IBaseView{
    void showToast(int resId);
    void onGetCodeSuccess();
    void onGetCodeFailed(int apiErrorCode, String message);
}
