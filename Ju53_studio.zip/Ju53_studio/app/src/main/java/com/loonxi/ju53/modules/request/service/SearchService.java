package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/1/6.
 */
public interface SearchService {

    /**
     * 搜索商品
     *
     * @param map
     */
    @FormUrlEncoded
    @POST("index/search")
    Call<JsonArrayInfo<BaseProductEntity>> getSearchProductList(@FieldMap Map<String, Object> map);


    /**
     * 搜索分类下的商品
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("nav/navList")
    Call<JsonArrayInfo<BaseProductEntity>> getSortSearchProductList(@FieldMap Map<String, Object> map);


    /**
     * 获得热门搜索
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("search/keyWords")
    Call<JsonArrayInfo<String>> getHotSearch(@FieldMap Map<String, Object> map);


}
