package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.RefundEntity;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/2/16.
 */
public interface RefundService {
    /**
     * 获取退款详情
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/backingOrders")
    Call<JsonInfo<RefundEntity>> getRefundDetail(@FieldMap Map<String, Object> map);

}
