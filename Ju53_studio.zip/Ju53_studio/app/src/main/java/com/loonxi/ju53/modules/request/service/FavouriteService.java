package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.FavEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/2/17.
 */
public interface FavouriteService {

    /**
     * 收藏/取消收藏产品/店铺
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/doCollect")
    Call<BaseJsonInfo> fav(@FieldMap Map<String, Object> map);

    /**
     * 收藏列表
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/showCollect")
    Call<JsonInfo<FavEntity>> getFavList(@FieldMap Map<String, Object> map);

}
