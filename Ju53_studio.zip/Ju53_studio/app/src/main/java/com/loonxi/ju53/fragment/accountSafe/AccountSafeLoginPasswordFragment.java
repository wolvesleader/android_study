package com.loonxi.ju53.fragment.accountSafe;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.presenters.UpdatePasswordPresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IUpdatePasswordView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.DeleteEditText;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * "输入登录密码"
 * Created by laojiaqi on 2016/2/18.
 */
public class AccountSafeLoginPasswordFragment extends BaseSafeFragment<IUpdatePasswordView, UpdatePasswordPresenter> implements View.OnClickListener, IUpdatePasswordView {

    public static final String TAG = "AccountSafeLoginPasswordFragment";
    public static final String LOGIN_PASS_WORD_FLAG = "loginPassword";
    public static final String LOGIN_MOBILE_FLAG = "mobile";
    @ViewInject(R.id.fragment_account_safe_input_login_password_next)
    private TextView mNext;
    @ViewInject(R.id.fragment_account_safe_input_login_password_edit)
    private DeleteEditText mEditText;
    @ViewInject(R.id.fragment_account_safe_input_login_password_action_bar)
    private ActionBar mActionBar;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account_safe_input_login_password, null);
        x.view().inject(view);
        return view;
    }

    @Override
    public void initView() {
        mActionBar.setTitle(R.string.account_safe_pay_title);
    }

    @Override
    public void initContent() {
    }

    @Override
    public void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mNext.setOnClickListener(this);
        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (StringUtil.isEmpty(s.toString())) {
                    mNext.setEnabled(false);
                } else {
                    mNext.setEnabled(true);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fragment_account_safe_input_login_password_next:
                checkLoginPassword();
                break;
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
        }
    }

    private void goBack() {
        getFragmentManager().popBackStack();
    }

    /**
     * 验证登录密码
     */
    private void checkLoginPassword() {
        String password = mEditText.getText().toString();
        if (TextUtils.isEmpty(password)) {
            return;
        }
        mPresenter.checkLoginPassword(password);

    }

    @Override
    public void onUpdatePasswordSuccess(String loginPassword) {
        //验证成功,跳转到验证码界面
        gotoVerifyCodeFragment(loginPassword, AccountSafeTypeFragment.UPDATE_PAY_PASSWORD);
    }

    private void gotoVerifyCodeFragment(String loginPassword, int flag) {
        FragmentManager fm = getFragmentManager();
        if (fm.findFragmentByTag(AccountSafeLoginPasswordFragment.TAG) != null) {
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        ft.addToBackStack("accountSafeTypeFragment");
        AccountSafeVerifyCodeFragment accountSafeVerifyCodeFragment = new AccountSafeVerifyCodeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, flag);//类别
        bundle.putString(LOGIN_PASS_WORD_FLAG, loginPassword);
        accountSafeVerifyCodeFragment.setArguments(bundle);
        ft.add(R.id.fragment_account_safe_container, accountSafeVerifyCodeFragment, AccountSafeLoginPasswordFragment.TAG);
        ft.commitAllowingStateLoss();


    }

    @Override
    public void onUpdatePasswordFailure(String message) {
        //验证失败
        if (!TextUtils.isEmpty(message)) {
            ToastUtil.showShortToast(message);
        }
    }

    @Override
    protected UpdatePasswordPresenter createPresenter(IUpdatePasswordView iUpdatePasswordView) {
        return new UpdatePasswordPresenter(this);
    }
}
