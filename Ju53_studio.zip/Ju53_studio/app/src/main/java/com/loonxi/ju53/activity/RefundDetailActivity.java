package com.loonxi.ju53.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.RefundDetailState;
import com.loonxi.ju53.convert.RefundDataConvert;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.entity.RefundEntity;
import com.loonxi.ju53.entity.RefundReason;
import com.loonxi.ju53.presenters.RefundDetailPresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.TimeUtil;
import com.loonxi.ju53.views.IRefundDetailView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.dialog.BtnDialog;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/15.
 */
public class RefundDetailActivity extends ActionBarActivity implements View.OnClickListener, IRefundDetailView {
    @ViewInject(R.id.refund_detail_layout_root)
    private LinearLayout mLayoutRoot;
    @ViewInject(R.id.refund_detail_tv_status)
    private TextView mTvStatus;
    @ViewInject(R.id.refund_detail_layout_rules_applying)
    private LinearLayout mLayoutRulesApplying;
    @ViewInject(R.id.refund_detail_tv_rules_applying_deadline)
    private TextView mTvApplyingDeadline;
    @ViewInject(R.id.refund_detail_layout_rules_agreed)
    private LinearLayout mLayoutRulesAgreed;
    @ViewInject(R.id.refund_detail_tv_rules_agreed_deadline)
    private TextView mTvAgreedDeadline;
    @ViewInject(R.id.refund_detail_tv_rules_backaddress)
    private TextView mTvAgreedBackadress;
    @ViewInject(R.id.refund_detail_layout_rules_denied)
    private LinearLayout mLayoutDenied;
    @ViewInject(R.id.refund_detail_tv_rules_denied_reason)
    private TextView mTvDeniedReason;
    @ViewInject(R.id.refund_detail_tv_rules_denied_description)
    private TextView mTvDeniedDescription;
    @ViewInject(R.id.refund_detail_tv_rules_denied_tips)
    private TextView mTvDeniedTips;
    @ViewInject(R.id.refund_detail_layout_rules_finish)
    private LinearLayout mLayoutFinish;
    @ViewInject(R.id.refund_detail_tv_rules_finish)
    private TextView mTvFinish;
    @ViewInject(R.id.refund_detail_layout_operate)
    private LinearLayout mLayoutOperate;
    @ViewInject(R.id.refund_detail_btn_alt)
    private TextView mBtnAlt;
    @ViewInject(R.id.refund_detail_btn_cancel)
    private TextView mBtnCancel;
    @ViewInject(R.id.refund_detail_tv_company)
    private TextView mTvCompany;
    @ViewInject(R.id.refund_detail_tv_type)
    private TextView mTvType;
    @ViewInject(R.id.refund_detail_tv_money)
    private TextView mTvMoney;
    @ViewInject(R.id.refund_detail_tv_reason)
    private TextView mTvReason;
    @ViewInject(R.id.refund_detail_tv_description)
    private TextView mTvDescription;
    @ViewInject(R.id.refund_detail_tv_no)
    private TextView mTvNo;
    @ViewInject(R.id.refund_detail_tv_applytime)
    private TextView mTvApplyTime;

    private OrderEntity mOrder;
    private OrderUnitEntity mUnit;
    private BaseProductEntity mProduct;

    private RefundDetailPresenter mPresenter;
    private RefundEntity mRefund;

    private List<RefundReason> mRefundReason = new ArrayList<>();
    private BtnDialog mBtnDialog;

    private static final int REQUEST_CODE_REFUND = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund_detail);
    }

    @Override
    public void initView() {
        setTitle(R.string.refund_detail);
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mPresenter = new RefundDetailPresenter(this);
        mOrder = getIntent().getParcelableExtra("order");
        mUnit = getIntent().getParcelableExtra("unit");
        mProduct = (BaseProductEntity) getIntent().getSerializableExtra("product");
        initReasonData();
        mPresenter.getRefundDetail(mOrder, mUnit);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mBtnAlt.setOnClickListener(this);
        mBtnCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
            case R.id.refund_detail_btn_alt:
                altApply();
                break;
            case R.id.refund_detail_btn_cancel:
                cancelApply();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_REFUND:
                if (resultCode == RESULT_OK) {
                    finish();
                }
                break;
        }
    }

    /**
     * 修改退款
     */
    private void altApply() {
        if (mUnit == null) {
            return;
        }
        Intent intent = new Intent(mContext, RefundActivity.class);
        intent.putExtra("orderEntity", mOrder);
        intent.putExtra("orderUnitEntity", mUnit);
        intent.putExtra("product", mProduct);
        intent.putExtra("refund", mRefund);
        startActivityForResult(intent, REQUEST_CODE_REFUND);
    }

    /**
     * 撤销退款
     */
    private void cancelApply() {
        mBtnDialog = new BtnDialog(mContext, "", "确定取消退款申请吗？", "", "",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mBtnDialog.dismiss();
                        if (mOrder == null || mUnit == null || mProduct == null || mRefund == null) {
                            return;
                        }
                        mPresenter.updateRefund(mUnit.getPid() + "", mOrder.getOrderId(), mRefund.getBackapply() + "", mProduct.getProductId(),
                                mRefund.getReason(), mRefund.getNotes(), 0, mOrder.getState(), mRefund.getPid() + "", true);
                    }
                },
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mBtnDialog.dismiss();
                    }
                });
        mBtnDialog.show();
    }

    /**
     * 设置退款信息
     *
     * @param refund
     */
    private void setRefundInfo(RefundEntity refund) {
        if (refund == null) {
            return;
        }
        int refundState = refund.getState();
        String remainTime = StringUtil.isEmpty(refund.getRemainTime()) ? "" : refund.getRemainTime();
        Spanned applyDeadline = Html.fromHtml("超过<font color=\"#ee0c00\">" + remainTime + "</font>则申请达成并退款。");
        Spanned agreeDeadline = Html.fromHtml("剩余<font color=\"#ee0c00\">" + remainTime + "</font>逾期未退申请将自动关闭。");
        Spanned deniedDeadline = Html.fromHtml("您可以修改退款申请后再次发起，卖家会重新处理。<br/>如果您未响应，超过<font color=\"#ee0c00\">" + remainTime + "</font>则申请自动撤销。");
        RefundDetailState.setRefundDetailState(mTvStatus, refundState);
        if (refundState == RefundDetailState.APPLYED || refundState == RefundDetailState.MODIFY) {//等待卖家同意、退款修改
            mLayoutRulesApplying.setVisibility(View.VISIBLE);
            mTvApplyingDeadline.setText(applyDeadline);
            mLayoutOperate.setVisibility(View.VISIBLE);
        } else if (refundState == RefundDetailState.AGREED_REFUNED || refundState == RefundDetailState.AGREED_NO_REFUNED) {//卖家同意退款
            mLayoutFinish.setVisibility(View.VISIBLE);
            mTvFinish.setText("¥ " + refund.getBackapply());
        } else if (refundState == RefundDetailState.DENIED) {//卖家拒绝
            mLayoutDenied.setVisibility(View.VISIBLE);
            mLayoutOperate.setVisibility(View.VISIBLE);
            setResuseReason(refund.getReplyReason());
            mTvDeniedDescription.setText(refund.getReply());
            mTvDeniedTips.setText(deniedDeadline);
        } else if (refundState == RefundDetailState.FINISH) {//退款完成
            mLayoutFinish.setVisibility(View.VISIBLE);
            mTvFinish.setText("¥ " + refund.getBacked());
        }
        mTvCompany.setText(refund.getCustomName());
        mTvType.setText(refund.getApplyType() == 1 ? "仅退款" : "退货退款");
        mTvMoney.setText("¥ " + refund.getBackapply() + "");
        mTvReason.setText(RefundDataConvert.reasonCode2String(refund.getReason()));
        mTvDescription.setText(refund.getNotes());
        mTvNo.setText(refund.getPaymentId());
        mTvApplyTime.setText(TimeUtil.getFormatTimeFromTimestamp(refund.getCreateTime(), "yyyy-MM-dd HH:mm"));
    }

    /**
     * 设置拒绝理由
     * @param code
     */
    private void setResuseReason(int code){
        if(code >= 0 && mRefundReason.size() >= code + 1){
            mTvDeniedReason.setText(mRefundReason.get(code).getReason());
        }
    }

    /**
     * 初始化卖家拒绝退款原因
     */
    private void initReasonData() {
        String[] reasons = getResources().getStringArray(R.array.refuse_reason);
        for (int i = 0; i < reasons.length; i++) {
            RefundReason reason = new RefundReason();
            reason.setReason(reasons[i]);
            reason.setCode(i);
            mRefundReason.add(reason);
        }
    }

    @Override
    public void onGetRefundDetailSuccess(RefundEntity refund) {
        mLayoutRoot.setVisibility(View.VISIBLE);
        mRefund = refund;
        setRefundInfo(refund);
    }

    @Override
    public void onGetRefundDetailFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onUpdateRefundSuccess() {
        setResult(Activity.RESULT_OK);
        showToast("撤销退款成功");
        finish();
    }

    @Override
    public void onUpdateRefundFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
