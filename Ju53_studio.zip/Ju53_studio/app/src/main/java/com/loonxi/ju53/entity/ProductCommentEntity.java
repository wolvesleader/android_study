package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 商品评价 entity
 * Created by laojiaqi on 2016/2/16.
 */
public class ProductCommentEntity implements Parcelable{
    double productPrice;//价格
    String productSpec;//规格
    String content;//评价内容
    String productId;//商品ID
    int score;//货品质量
    String productName;//商品名称
    String userName;//评价用户名
    String level;//级别
    long created;//创建时间

    public ProductCommentEntity() {
    }

    protected ProductCommentEntity(Parcel in) {
        productPrice = in.readDouble();
        productSpec = in.readString();
        content = in.readString();
        productId = in.readString();
        score = in.readInt();
        productName = in.readString();
        userName = in.readString();
        level = in.readString();
        created = in.readLong();
    }

    public static final Creator<ProductCommentEntity> CREATOR = new Creator<ProductCommentEntity>() {
        @Override
        public ProductCommentEntity createFromParcel(Parcel in) {
            return new ProductCommentEntity(in);
        }

        @Override
        public ProductCommentEntity[] newArray(int size) {
            return new ProductCommentEntity[size];
        }
    };

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductSpec() {
        return productSpec;
    }

    public void setProductSpec(String productSpec) {
        this.productSpec = productSpec;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public long getCreated() {
        return created;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDouble(productPrice);
        dest.writeString(productSpec);
        dest.writeString(content);
        dest.writeString(productId);
        dest.writeInt(score);
        dest.writeString(productName);
        dest.writeString(userName);
        dest.writeString(level);
        dest.writeLong(created);
    }
}
