package com.loonxi.ju53.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;

/**
 * 选择图片Activity
 * Created by Administrator on 2016/1/21.
 */
public class ChosePicActivity extends BaseActivity {

    public final static int CONSULT_DOC_PICTURE = 1000;
    public final static int CONSULT_DOC_CAMERA = 1001;
    private int SELECT_PICTURE = 0;
    private int SELECT_CAMERA = 1;


    private Bitmap bmp;
    private Uri outputFileUri;

    @ViewInject(R.id.button)
    private Button button;

    @ViewInject(R.id.imageView)
    private ImageView iv;

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_pic);
        x.view().inject(this);
        mContext = this;
        button.setOnClickListener(cameraClickListener);
    }


    private View.OnClickListener cameraClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            CharSequence[] items = {"相册", "相机"};
            new AlertDialog.Builder(mContext).setTitle("选择图片来源").setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == SELECT_PICTURE) {
                        Intent intent = new Intent( Intent.ACTION_PICK);
                        intent.setDataAndType(MediaStore.Images.Media.INTERNAL_CONTENT_URI, "image/*");

                        startActivityForResult(Intent.createChooser(intent, "选择图片"), CONSULT_DOC_PICTURE);
                    } else {

                        File file = new File(Environment.getExternalStorageDirectory(), "textphoto.jpg");
                        outputFileUri = Uri.fromFile(file);
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
                        startActivityForResult(intent, CONSULT_DOC_CAMERA);
                    }
                }
            }).create().show();

        }
    };

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ChosePicActivity.CONSULT_DOC_PICTURE) {

            if (data == null) {
                return;
            }

            Uri uri = data.getData();
            String[] proj = {MediaStore.Images.Media.DATA};
            Cursor cursor = ((Activity) mContext).managedQuery(uri, proj, null, null, null);

            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            String filePath = cursor.getString(column_index);

            Glide.with(this).load(filePath).into(iv);

        } else if (requestCode == ChosePicActivity.CONSULT_DOC_CAMERA) {

            Glide.with(this).load(outputFileUri.getPath()).into(iv);

        } else {
            Toast.makeText(mContext, "请重新选择图片", Toast.LENGTH_SHORT).show();
        }

    }

}
