package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.entity.IndexJsonInfo;
import com.loonxi.ju53.entity.MainTabEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2015/12/18.
 */
public interface IndexService {

    /**
     * 获取首页的广告和活动
     * @param map
     */
    @FormUrlEncoded
    @POST("index/indexContent")
    Call<IndexJsonInfo> getIndexContent(@FieldMap Map<String, Object> map);

    /**
     * 获取首页的推荐宝贝
     * @param map
     */
    @FormUrlEncoded
    @POST("index/push")
    Call<JsonArrayInfo<IndexEntity>> getRecommends(@FieldMap Map<String, Object> map);

    /**
     * 获取软件更新信息
     * @param map
     */
    @FormUrlEncoded
    @POST("index/getVersion")
    Call<GetVersionEntity> getVersion(@FieldMap Map<String, Object> map);


    /**
     * 获取首页的广告和活动
     * @param map
     */
    @FormUrlEncoded
    @POST("customNav/NavInfo")
    Call<JsonArrayInfo<MainTabEntity>> getMainTab(@FieldMap Map<String, Object> map);



}
