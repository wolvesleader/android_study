package com.loonxi.ju53.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewStub;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.fragment.HomeTabFragment;
import com.loonxi.ju53.fragment.MineFragment;
import com.loonxi.ju53.fragment.PromotionFragment;
import com.loonxi.ju53.fragment.ShoppingFragment;
import com.loonxi.ju53.fragment.SortFragment;
import com.loonxi.ju53.fragment.StoreFragment;
import com.loonxi.ju53.manager.HomeManager;
import com.loonxi.ju53.receiver.ConnectionChangeReceiver;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.TimeUtil;
import com.loonxi.ju53.widgets.CycleViewPagerHandler;
import com.umeng.socialize.UMShareAPI;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends BaseActivity implements View.OnClickListener {

    public static final String FROM_FLAG = "FROM_FLAG";
    public static final String FIRST_SHOW_SORT = "FIRST_SHOW_SORT";
    public static final String RESET_ACCOUNT_LOGIN_PASSWORD = "RESET_ACCOUNT_LOGIN_PASSWORD";
    public static final String RESET_CART = "RESET_CART";
    public static final String RESET_POPWINDOW = "RESET_POPWINDOW";
    public static final String RESET_SORT = "RESET_SORT";
    public static final String RESET_STORE = "RESET_STORE";
    public static final String RESET_MINE = "RESET_MINE";
    public String mFrom;


    private LinearLayout mLayoutContainer;
    private RadioGroup mRgp;
    private RadioButton mRbtnHome;
    private RadioButton mRbtnSort;
    private RadioButton mRbtnPromotion;
    private RadioButton mRbtnShopping;
    private RadioButton mRbtnMine;
    private RadioButton mRbtnStore;

    @ViewInject(R.id.main_preload_root_layout)
    private FrameLayout mRootLayout;
    @ViewInject(R.id.stu_main_layout)
    private ViewStub mStuMainLayout;
    @ViewInject(R.id.stu_introduce_layout)
    private ViewStub mStuIntroduce;

    private FragmentTransaction mTransaction;
    private HomeTabFragment mHomeFragment;
    private SortFragment mSortFragment;
    private PromotionFragment mPromotionFragment;
    private ShoppingFragment mShoppingFragment;
    private StoreFragment mStoreFragment;
    private MineFragment mMineFragment;

    private View mLastCheckView;
    private Handler mMainHandle;
    private Context mContext;
    private long mExitTime = 0;
    private static int INTERAL = 2000;
    private static int SPLASH_VIEW_INDEX = 2;
    public static final int REQUEST_CODE_LOGIN_MINE = 1001;
    public static final int REQUEST_CODE_LOGIN_CART = 1002;
    public static final int REQUEST_CODE_CART_INVOICE = 1003;//购物车结算
    public static final int REQUEST_CODE_LOGIN_STORE = 1004;
    private boolean mIsFirst = true;
    private ConnectionChangeReceiver mConnectChangeReceiver;//监听网络变化
    private List<BaseFragment> mListFragment = new ArrayList<>();
    private String mFirstShowSort;//首次显示的分类类目
    private boolean mNeedGetSort;//是否需要请求分类数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_preload);
        x.view().inject(this);
        mContext = this;
        showSplashView();
        initView();
        initContent();
        setListener();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        dealNewIntentData(intent);
    }

    private void setListener() {
        mRbtnHome.setOnClickListener(this);
        mRbtnSort.setOnClickListener(this);
        mRbtnPromotion.setOnClickListener(this);
        mRbtnStore.setOnClickListener(this);
        mRbtnShopping.setOnClickListener(this);
        mRbtnMine.setOnClickListener(this);
    }

    public void initView() {
        initBottomBtn();
    }

    public void initContent() {

        mTransaction = getSupportFragmentManager().beginTransaction();
        if (mHomeFragment != null) {
            mTransaction.remove(mHomeFragment);
        }
        if (mSortFragment != null) {
            mTransaction.remove(mSortFragment);
        }
        if (mPromotionFragment != null) {
            mTransaction.remove(mPromotionFragment);
        }
        if (mShoppingFragment != null) {
            mTransaction.remove(mShoppingFragment);
        }
        if (mStoreFragment != null) {
            mTransaction.remove(mStoreFragment);
        }
        if (mMineFragment != null) {
            mTransaction.remove(mMineFragment);
        }
        mTransaction.commitAllowingStateLoss();
        mHomeFragment = new HomeTabFragment();
        mSortFragment = new SortFragment();
        mPromotionFragment = new PromotionFragment();
        mShoppingFragment = new ShoppingFragment();
        mStoreFragment = new StoreFragment();
        mMineFragment = new MineFragment();

        onClick(mRbtnHome);
        initNetWorkReceiver();
    }

    /**
     * 初始化网络链接监听器
     */
    private void initNetWorkReceiver() {
        mListFragment.add(mHomeFragment);
        mListFragment.add(mMineFragment);
//        mListFragment.add(mShoppingFragment);
//        mListFragment.add(mPromotionFragment);
        mListFragment.add(mSortFragment);
        mListFragment.add(mStoreFragment);
        mConnectChangeReceiver = new ConnectionChangeReceiver(mListFragment);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(mConnectChangeReceiver, intentFilter);
    }

    /**
     * 展示 开屏幕页
     */
    private void showSplashView() {
        showIntroduceView();
        showMainView();
        getVersionTask();
    }

    /**
     * 展示介绍页
     */
    private void showIntroduceView() {
        mIsFirst = SpUtil.getBoolean(mContext, SpUtil.FIRST_IN_APP, true);
        if (mIsFirst) {
            //第一次
            mStuIntroduce.inflate();
        }
    }

    /**
     * 展示主页
     */
    private void showMainView() {
        View mainLayout = mStuMainLayout.inflate();
        initMainLayoutView(mainLayout);
    }

    /**
     * 检测软件更新task
     */
    private void getVersionTask() {
        mMainHandle = new CycleViewPagerHandler<>(this);
        Runnable runnable = new DelayRunnable(this, mRootLayout, mIsFirst);
        mMainHandle.postDelayed(runnable, INTERAL);
    }

    /**
     * 初始化mainLayout
     *
     * @param mainLayout
     */
    private void initMainLayoutView(View mainLayout) {
        mLayoutContainer = (LinearLayout) mainLayout.findViewById(R.id.main_layout_container);
        mRgp = (RadioGroup) mainLayout.findViewById(R.id.main_rgp);
        mRbtnHome = (RadioButton) mainLayout.findViewById(R.id.main_rbtn_home);
        mRbtnSort = (RadioButton) mainLayout.findViewById(R.id.main_rbtn_sort);
        mRbtnPromotion = (RadioButton) mainLayout.findViewById(R.id.main_rbtn_promotion);
        mRbtnShopping = (RadioButton) mainLayout.findViewById(R.id.main_rbtn_shopping);
        mRbtnStore = (RadioButton) mainLayout.findViewById(R.id.main_rbtn_store);
        mRbtnMine = (RadioButton) mainLayout.findViewById(R.id.main_rbtn_mine);
    }

    static class DelayRunnable implements Runnable {
        private WeakReference<Context> contextRef;
        private WeakReference<FrameLayout> mRootLayoutRef;
        private boolean isFirst;

        public DelayRunnable(Context context, FrameLayout frameLayout, boolean isFirst) {
            this.contextRef = new WeakReference<Context>(context);
            this.mRootLayoutRef = new WeakReference<FrameLayout>(frameLayout);
            this.isFirst = isFirst;
        }

        @Override
        public void run() {
            Activity context = (Activity) contextRef.get();
            if (mRootLayoutRef.get() == null || contextRef.get() == null) {
                return;
            }
            if (mRootLayoutRef.get() == null) {
                return;
            }
            FrameLayout frameLayout = mRootLayoutRef.get();
            frameLayout.removeViewAt(SPLASH_VIEW_INDEX);
            if (!isFirst) {
                //如果已显示过介绍页，则直接发请求
                ((MainActivity) context).getNewVersion(context);
            }
        }
    }

    /**
     * 获得新版本(每天检查一次)
     */
    public void getNewVersion(Context context) {
        String updateTime = SpUtil.getString(context, SpUtil.LATEST_UPDATE_TIME, "");
        String currentTime = TimeUtil.getFormatTimeFromTimestamp(System.currentTimeMillis(), "yyyy-MM-dd");
        boolean needCheckVersion = currentTime.equals(updateTime) ? false : true;
        if (needCheckVersion) {
            SpUtil.putString(context, SpUtil.LATEST_UPDATE_TIME, currentTime);
            mHomeFragment.getVersion();
        }
    }

    private void dealNewIntentData(Intent intent) {
        if (intent == null) {
            return;
        }
        mFrom = intent.getStringExtra(FROM_FLAG);
        mFirstShowSort = intent.getStringExtra(FIRST_SHOW_SORT);
        if (TextUtils.isEmpty(mFrom)) {
            return;
        }
        if (mFrom.equals(RESET_ACCOUNT_LOGIN_PASSWORD) || mFrom.equals(RESET_POPWINDOW)) {
            onClick(mRbtnHome);
            mFrom = null;
        } else if (mFrom.equals(RESET_CART)) {
            onClick(mRbtnShopping);
            mFrom = null;
        } else if (mFrom.equals(RESET_SORT)) {
            if(!StringUtil.isEmpty(mFirstShowSort)){
                Bundle data = new Bundle();
                data.putString("firstSort", mFirstShowSort);
                Bundle arguments = mSortFragment.getArguments();
                if(arguments != null){
                    arguments.clear();
                    arguments.putAll(data);
                }else{
                    mSortFragment.setArguments(data);
                }
//                if(mSortFragment.getArguments() == null) {
//                    mSortFragment.setArguments(data);
//                }else{
//                    mSortFragment.getArguments().clear();
//                    mSortFragment.getArguments().putAll(data);
//                }
            }
            onClick(mRbtnSort);
            if(mLastCheckView == mRbtnSort){
                mSortFragment.fragmentResume(mFirstShowSort);
            }
            mFrom = null;
        } else if (mFrom.equals(RESET_STORE)) {
            onClick(mRbtnStore);
            mFrom = null;
        } else if (mFrom.equals(RESET_MINE)) {
            onClick(mRbtnMine);
            mFrom = null;
        }

    }

    /**
     * 初始化底部菜单
     */
    private void initBottomBtn() {
        mRbtnHome.setCompoundDrawables(null, HomeManager.generateButton(mContext, 1), null, null);
        mRbtnSort.setCompoundDrawables(null, HomeManager.generateButton(mContext, 2), null, null);
        mRbtnPromotion.setCompoundDrawables(null, HomeManager.generateButton(mContext, 3), null, null);
        mRbtnShopping.setCompoundDrawables(null, HomeManager.generateButton(mContext, 4), null, null);
        mRbtnMine.setCompoundDrawables(null, HomeManager.generateButton(mContext, 5), null, null);
        mRbtnStore.setCompoundDrawables(null, HomeManager.generateButton(mContext, 6), null, null);
    }

    /**
     * “我的”
     *
     * @param needCommit
     */
    private void showMineFragment(boolean needCommit) {
        if (needCommit) {
            mTransaction = getSupportFragmentManager().beginTransaction();
        }
        if (mMineFragment.isAdded()) {
            mTransaction.show(mMineFragment);
        } else {
            mTransaction.add(R.id.main_layout_container, mMineFragment, mMineFragment.getClass().getSimpleName());
        }
        if (needCommit) {
            mTransaction.commitAllowingStateLoss();
        }
        mRgp.check(R.id.main_rbtn_mine);
    }

    /**
     * “购物车”
     *
     * @param needCommit
     */
    private void showShoppingFragment(boolean needCommit) {
        if (needCommit) {
            mTransaction = getSupportFragmentManager().beginTransaction();
        }
        if (mShoppingFragment.isAdded()) {
            mTransaction.show(mShoppingFragment);
        } else {
            mTransaction.add(R.id.main_layout_container, mShoppingFragment, mShoppingFragment.getClass().getSimpleName());
        }
        if (needCommit) {
            mTransaction.commitAllowingStateLoss();
        }
        mRgp.check(R.id.main_rbtn_shopping);
    }

    /**
     * “店铺”
     *
     * @param needCommit
     */
    private void showStoreFragment(boolean needCommit) {
        if (needCommit) {
            mTransaction = getSupportFragmentManager().beginTransaction();
        }
        if (mStoreFragment.isAdded()) {
            mTransaction.show(mStoreFragment);
        } else {
            mTransaction.add(R.id.main_layout_container, mStoreFragment, mStoreFragment.getClass().getSimpleName());
        }
        if (needCommit) {
            mTransaction.commitAllowingStateLoss();
        }
        mRgp.check(R.id.main_rbtn_store);
    }

    @Override
    public void onClick(View v) {
        mTransaction = getSupportFragmentManager().beginTransaction();
        switch (v.getId()) {
            case R.id.main_rbtn_home://首页
                mLastCheckView = mRbtnHome;
                mRgp.check(R.id.main_rbtn_home);
                hidenFragment(1);
                if (mHomeFragment.isAdded()) {
                    mTransaction.show(mHomeFragment);
                } else {
                    mTransaction.add(R.id.main_layout_container, mHomeFragment, mHomeFragment.getClass().getSimpleName());
                }
                break;
            case R.id.main_rbtn_sort://分类
                mLastCheckView = mRbtnSort;
                mRgp.check(R.id.main_rbtn_sort);
                hidenFragment(2);
                if (mSortFragment.isAdded()) {
                    mTransaction.show(mSortFragment);
                } else {
                    mTransaction.add(R.id.main_layout_container, mSortFragment, mSortFragment.getClass().getSimpleName());
                }
                break;
            case R.id.main_rbtn_promotion://活动
                mLastCheckView = mRbtnPromotion;
                mRgp.check(R.id.main_rbtn_promotion);
                hidenFragment(3);
                if (mPromotionFragment.isAdded()) {
                    mTransaction.show(mPromotionFragment);
                } else {
                    mTransaction.add(R.id.main_layout_container, mPromotionFragment, mPromotionFragment.getClass().getSimpleName());
                }
                break;
            case R.id.main_rbtn_shopping://购物车
                hidenFragment(4);
                if (LoginUtil.isLoginNew()) {
                    if (mLastCheckView == mRbtnShopping) {
                        return;
                    }
                    showShoppingFragment(false);
                    mLastCheckView = mRbtnShopping;
                } else {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), REQUEST_CODE_LOGIN_CART);
                }
                break;
            case R.id.main_rbtn_store://店铺
                hidenFragment(6);
                if (LoginUtil.isLoginNew()) {
                    if (mLastCheckView == mRbtnStore) {
                        return;
                    }
                    showStoreFragment(false);
                    mLastCheckView = mRbtnStore;
                } else {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), REQUEST_CODE_LOGIN_STORE);
                }
                break;
            case R.id.main_rbtn_mine://我的
                hidenFragment(5);
                if (LoginUtil.isLoginNew()) {
                    if (mLastCheckView == mRbtnMine) {
                        return;
                    }
                    showMineFragment(false);
                    mLastCheckView = mRbtnMine;
                } else {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), REQUEST_CODE_LOGIN_MINE);
                }
                break;
        }
        mTransaction.commitAllowingStateLoss();
        pauseHomeFragment();
        fragmentDisplayAction();
    }

    /**
     * HomeFragment中暂停有关操作（主要是停掉图片轮播）
     */
    private void pauseHomeFragment() {
        if (mHomeFragment != null && mLastCheckView != mRbtnHome) {
            // mHomeFragment.fragmentPause();
        }
    }

    /**
     * 隐藏Fragment
     *
     * @param position
     */
    private void hidenFragment(int position) {
        if (position != 1 && mHomeFragment.isAdded()) {
            mTransaction.hide(mHomeFragment);
        }
        if (position != 2 && mSortFragment.isAdded()) {
            mTransaction.hide(mSortFragment);
        }
        if (position != 3 && mPromotionFragment.isAdded()) {
            mTransaction.hide(mPromotionFragment);
        }
        if (position != 4 && mShoppingFragment.isAdded()) {
            mTransaction.hide(mShoppingFragment);
        }
        if (position != 5 && mMineFragment.isAdded()) {
            mTransaction.hide(mMineFragment);
        }
        if (position != 6 && mStoreFragment.isAdded()) {
            mTransaction.hide(mStoreFragment);
        }
    }

    /**
     * 执行fragment显示时候的操作
     */
    private void fragmentDisplayAction() {
        if (mHomeFragment != null && mLastCheckView == mRbtnHome) {
            //  mHomeFragment.fragmentResume(0);
        }
        if (mMineFragment != null && mLastCheckView == mRbtnMine) {
            mMineFragment.fragmentResume(0);
        }
        if (mShoppingFragment != null && mLastCheckView == mRbtnShopping) {
            mShoppingFragment.fragmentResume(0);
        }
        if (mStoreFragment != null && mLastCheckView == mRbtnStore) {
            mStoreFragment.fragmentResume(0);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        UMShareAPI.get(mContext).onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_LOGIN_CART:
                if (resultCode == RESULT_OK) {
                    mLastCheckView = mRbtnShopping;
                    mRgp.check(R.id.main_rbtn_shopping);
                    showShoppingFragment(true);
                    mShoppingFragment.fragmentResume(0);
                } else {
                    mLastCheckView = mRbtnHome;
                    onClick(mLastCheckView);
                }
                break;
            case REQUEST_CODE_LOGIN_MINE:
                if (resultCode == RESULT_OK) {
                    mLastCheckView = mRbtnMine;
                    mRgp.check(R.id.main_rbtn_mine);
                    showMineFragment(true);
                    mMineFragment.fragmentResume(0);
                } else {
                    mLastCheckView = mRbtnHome;
                    onClick(mLastCheckView);
                }
                break;
            case REQUEST_CODE_CART_INVOICE:
                if (resultCode == RESULT_OK) {
                    if (mShoppingFragment != null) {
                        mShoppingFragment.onRefresh();
                    }
                }
                break;
            case REQUEST_CODE_LOGIN_STORE:
                if (resultCode == RESULT_OK) {
                    mLastCheckView = mRbtnStore;
                    mRgp.check(R.id.main_rbtn_store);
                    showStoreFragment(true);
                    mStoreFragment.fragmentResume(0);
                } else {
                    mLastCheckView = mRbtnHome;
                    onClick(mLastCheckView);
                }
                break;
            case IntentUtil.REQUEST_CODE_CAMERA:
            case IntentUtil.REQUEST_CODE_ALBUM:
            case IntentUtil.REQUEST_CODE_CROP:
                if (mMineFragment != null && !mMineFragment.isHidden()) {
                    mMineFragment.onActivityResult(requestCode, resultCode, data);
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mConnectChangeReceiver);
    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() - mExitTime > INTERAL) {
            showToast(getResources().getString(R.string.exit));
            mExitTime = System.currentTimeMillis();
        } else {
            finish();
        }
    }

}
