package com.loonxi.ju53.entity;

import java.io.Serializable;

/**
 * 运费模板
 * Created by Xuzue on 2016/1/22.
 */
public class FreightRule implements Serializable {
    private int pid;
    private int freightId;
    private String regions;
    private double start;
    private double freight;
    private double plus;
    private int freightType;
    private double freightPlus;
    private int isDefault;
    private int state;
    private long createTime;
    private long updateTime;
    private String unit;//0：按个数计费 1：按重量计费

    public FreightRule(){

    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getFreightId() {
        return freightId;
    }

    public void setFreightId(int freightId) {
        this.freightId = freightId;
    }

    public String getRegions() {
        return regions;
    }

    public void setRegions(String regions) {
        this.regions = regions;
    }

    public double getStart() {
        return start;
    }

    public void setStart(double start) {
        this.start = start;
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }

    public double getPlus() {
        return plus;
    }

    public void setPlus(double plus) {
        this.plus = plus;
    }

    public int getFreightType() {
        return freightType;
    }

    public void setFreightType(int freightType) {
        this.freightType = freightType;
    }

    public double getFreightPlus() {
        return freightPlus;
    }

    public void setFreightPlus(double freightPlus) {
        this.freightPlus = freightPlus;
    }

    public int getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(int isDefault) {
        this.isDefault = isDefault;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
}
