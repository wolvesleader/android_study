package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.models.IPromotionModel;
import com.loonxi.ju53.models.impl.PromotionModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IPromotionDetailView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2015/12/23.
 */
public class PromotionDetailPresenter {
    private IPromotionModel mModel;
    private IPromotionDetailView mDetailView;


    public PromotionDetailPresenter(IPromotionDetailView mDetailView) {
        this.mDetailView = mDetailView;
        mModel = new PromotionModel();
    }

    /**
     * 获取活动详情
     *
     * @param promotionId
     */
    public void getPromotionDetail(String promotionId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("acId", promotionId);
        mModel.getPromotionDetail(map, new Callback<JsonInfo<PromotionEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<PromotionEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<PromotionEntity> data, Retrofit retrofit) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.onGetPromotionDetailSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mDetailView == null) {
                    return;
                }
                mDetailView.onGetPromotiondetailFailed(apiErrorCode, message);
            }
        });
    }

}
