package com.loonxi.ju53.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.PromotionAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.presenters.PromotionPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.views.IPromotionView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2015/12/17.
 */

@ContentView(R.layout.fragment_promotion)
public class PromotionFragment extends BaseSafeFragment<IPromotionView, PromotionPresenter> implements IPromotionView, OnNetWorkListener {

    @ViewInject(R.id.fragment_promotion_actionbar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_promotion_plv)
    private PullToRefreshListView mPlv;
    @ViewInject(R.id.fragment_promotion_stub)
    private ViewStub mStub;

    private PromotionAdapter mAdapter;
    private PromotionPresenter mPresenter;
    private ListView mListView;

    private int mCurrentPage = 1;
    private List<PromotionEntity> mPromotions = new ArrayList<>();

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void initView() {
        mActionBar.setLeftVisibility(View.INVISIBLE);
        mActionBar.setBackgroundColor(Color.WHITE);
        mActionBar.setTitle(R.string.promotion_title);
        mActionBar.setTitleColor(getResources().getColor(R.color.app_black));
        mPlv.scrollTo(0, 0);
        mPlv.setVisibility(View.GONE);
        mListView = mPlv.getRefreshableView();
        mListView.setFocusable(false);
        mListView.setEmptyView(getEmptyView(R.string.empty_promotion, AppConst.Empty.COMMENT, false));
    }

    @Override
    public void initContent() {
        mPresenter = new PromotionPresenter(this);
        mCurrentPage = 1;
        mAdapter = new PromotionAdapter(mContext, mPromotions);
        mListView.setAdapter(mAdapter);
        mPresenter.getPromotions();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void setData(List<PromotionEntity> promotions) {
        mPromotions.clear();
        if (!ListUtil.isEmpty(promotions)) {
            mPromotions.addAll(promotions);
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void setListener() {
        setOnNetWorkListener(this);
        mPlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getPromotions();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                mPresenter.getPromotions();
            }
        });
    }

    @Override
    public void onGetPromotionSuccess(List<PromotionEntity> promotions) {
        mPlv.setVisibility(View.VISIBLE);
        setNetErrorView(mPlv, mStub, false);
        if (mPlv.isRefreshing()) {
            mPlv.onRefreshComplete();
        }
        setData(promotions);
    }

    @Override
    public void onGetPromotionFailed(int apiErrorCode, String message) {
        LogUtil.mLog().i(apiErrorCode);
        if (mPlv.isRefreshing()) {
            mPlv.onRefreshComplete();
        }
        checkError(apiErrorCode, message, mPlv, mStub);
    }

    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {
        mCurrentPage = 1;
        mPresenter.getPromotions();
    }

    @Override
    protected PromotionPresenter createPresenter(IPromotionView view) {
        return new PromotionPresenter(this);
    }

    @Override
    public void onNetWorkConnected() {
        if(mPresenter==null){
            return;
        }
        if(mPromotions.size()==0) {
            mPresenter.getPromotions();
        }
    }
}
