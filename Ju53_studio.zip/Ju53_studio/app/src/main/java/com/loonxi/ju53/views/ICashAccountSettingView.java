package com.loonxi.ju53.views;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public interface ICashAccountSettingView extends IBaseView {
    void bandAccountSuccess();
    void bandAccountFailed(int apiErrorCode, String message);
}
