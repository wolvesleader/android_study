package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 首页实体
 * Created by Xuzue on 2015/12/18.
 */
public class IndexEntity implements Parcelable {
    private String productId;
    private String title;
    private String imgUrl;
    private String imgLink;
    private int activityType;
    private int sort;
    private double price;
    private String quantity;
    private String productName;

    public IndexEntity() {

    }

    protected IndexEntity(Parcel in) {
        productId = in.readString();
        title = in.readString();
        imgUrl = in.readString();
        imgLink = in.readString();
        activityType = in.readInt();
        sort = in.readInt();
        price = in.readDouble();
        quantity = in.readString();
        productName = in.readString();
    }

    public static final Creator<IndexEntity> CREATOR = new Creator<IndexEntity>() {
        @Override
        public IndexEntity createFromParcel(Parcel in) {
            return new IndexEntity(in);
        }

        @Override
        public IndexEntity[] newArray(int size) {
            return new IndexEntity[size];
        }
    };

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgLink() {
        return imgLink;
    }

    public void setImgLink(String imgLink) {
        this.imgLink = imgLink;
    }

    public int getActivityType() {
        return activityType;
    }

    public void setActivityType(int activityType) {
        this.activityType = activityType;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(productId);
        dest.writeString(title);
        dest.writeString(imgUrl);
        dest.writeString(imgLink);
        dest.writeInt(activityType);
        dest.writeInt(sort);
        dest.writeDouble(price);
        dest.writeString(quantity);
        dest.writeString(productName);
    }
}
