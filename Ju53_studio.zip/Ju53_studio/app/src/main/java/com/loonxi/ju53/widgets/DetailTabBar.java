package com.loonxi.ju53.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class DetailTabBar extends LinearLayout implements View.OnClickListener {

    @ViewInject(R.id.tab_detail_layout_pic)
    private RelativeLayout mLayoutPic;
    @ViewInject(R.id.tab_detail_layout_pic_line)
    private TextView mLayoutPicLine;
    @ViewInject(R.id.tab_detail_tv_pic)
    private TextView mTvPic;
    @ViewInject(R.id.tab_detail_layout_attribute)
    private RelativeLayout mLayoutAttribute;
    @ViewInject(R.id.tab_detail_layout_attribute_line)
    private TextView mLayoutAttributeLine;
    @ViewInject(R.id.tab_detail_tv_attribute)
    private TextView mTvAttribute;

    private int mCurrentPosition = 0;
    private OnDetailTabClickListener mListener;

    public DetailTabBar(Context context) {
        this(context, null);
    }

    public DetailTabBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        View bar = LayoutInflater.from(context).inflate(R.layout.include_tab_detail, null);
        addView(bar, LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        x.view().inject(this, bar);
        mLayoutPic.setOnClickListener(this);
        mLayoutAttribute.setOnClickListener(this);
        changeTab(1);
    }


    @Override
    public void onClick(View v) {
        if (mListener == null) {
            return;
        }
        switch (v.getId()) {
            case R.id.tab_detail_layout_pic:
                changeTab(1);
                mListener.onTabClick(1);
                break;
            case R.id.tab_detail_layout_attribute:
                changeTab(2);
                mListener.onTabClick(2);
                break;
        }
    }

    public void changeTab(int position) {
        mCurrentPosition = position;
        switch (position) {
            case 1:
                mTvPic.setTextColor(getResources().getColor(R.color.app_red));
                mTvAttribute.setTextColor(getResources().getColor(R.color.app_black));
                mLayoutPicLine.setVisibility(VISIBLE);
                mLayoutAttributeLine.setVisibility(GONE);
                break;
            case 2:
                mTvPic.setTextColor(getResources().getColor(R.color.app_black));
                mTvAttribute.setTextColor(getResources().getColor(R.color.app_red));
                mLayoutPicLine.setVisibility(GONE);
                mLayoutAttributeLine.setVisibility(VISIBLE);
                break;
        }
    }

    public void setPicTabVisibility(int visibility){
        if(visibility == VISIBLE || visibility == GONE || visibility == INVISIBLE){
            mLayoutPic.setVisibility(visibility);
        }
    }

    public void setAttributeTabVisibility(int visibility){
        if(visibility == VISIBLE || visibility == GONE || visibility == INVISIBLE){
            mLayoutAttribute.setVisibility(visibility);
        }
    }

    public void setAttributeTabEnable(boolean enable){
        mLayoutAttribute.setClickable(enable);
        mTvAttribute.setVisibility(enable ? VISIBLE : INVISIBLE);
    }

    public void setOnDetailTabClickListener(OnDetailTabClickListener listener) {
        mListener = listener;
    }

    public interface OnDetailTabClickListener {
        void onTabClick(int position);
    }
}
