package com.loonxi.ju53.models.impl;

import android.content.Context;
import android.util.Log;

import com.loonxi.ju53.entity.UserEntity;
import com.loonxi.ju53.models.ILoginModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.service.AccountService;
import com.loonxi.ju53.utils.SpUtil;

import java.util.Map;

import retrofit.Call;

/**
 * "登入model"
 * Created by Xuzue on 2016/1/5.
 */
public class LoginModel implements ILoginModel {

    public Call<UserEntity> login(Map<String, Object> map, Callback<UserEntity> callback) {
        Call<UserEntity> call = Request.creatApi(AccountService.class).login(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * @param context
     */
    public void saveLoginInfo(Context context, UserEntity user) {
        if (context == null || user == null) {
            return;
        }
        String userName = user.getUserName();
        String userId = user.getUserId();
        String mobile = user.getMobile();
        String logo = user.getLogo();
        SpUtil.putString(context, SpUtil.ACCOUNT_USER_NAME, userName);
        SpUtil.putString(context, SpUtil.ACCOUNT_USER_ID, userId);
        Log.e("登录状态","userId"+userId+"已经保存 获取测试"+SpUtil.getString(context,SpUtil.ACCOUNT_USER_ID));
        SpUtil.putString(context, SpUtil.ACCOUNT_USER_MOBILE, mobile);
        SpUtil.putString(context, SpUtil.ACCOUNT_USER_HEAD, logo);
    }

}
