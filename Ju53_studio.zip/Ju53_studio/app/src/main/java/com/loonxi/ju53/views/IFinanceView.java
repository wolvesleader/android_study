package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.views.IBaseView;

import java.util.Map;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public interface IFinanceView extends IBaseView {
    void getFinanceInfoSuccess(FinanceEntity info);
    void getFinanceInfoFailed(int apiErrorCode, String message);
}
