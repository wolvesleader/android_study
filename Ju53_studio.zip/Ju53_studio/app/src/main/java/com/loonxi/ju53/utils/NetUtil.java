package com.loonxi.ju53.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

/**
 * Created by Xuzue on 2015/9/2.
 */
public class NetUtil {

    private static NetworkInfo.State mWifiState = null;
    private static NetworkInfo.State mMobileState = null;

    public static final int TYPE_DISCONNECTED = 1001;
    public static final int TYPE_WIFI = 1002;
    public static final int TYPE_2G = 1002;
    public static final int TYPE_3G = 1003;
    public static final int TYPE_4G = 1004;
    public static final int TYPE_UNKNOWN = 1005;

    public enum NetworkState{
        WIFI, MOBILE, NONE;
    }


    /**
     * 判断是否有网络连接
     *
     * @param context
     * @return
     */
    public static boolean isConnected(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) {
            return false;
        }
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isAvailable()) {
            return false;
        } else {
            return false;
        }
    }

    /**
     * 获取网络连接类型 wifi/gprs
     * @param context
     * @return
     */
    public static NetworkState getConnectState(Context context){
        ConnectivityManager manager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if(manager == null){
            return NetworkState.NONE;
        }
        mWifiState = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
        mMobileState = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState();
        if(mWifiState != null && mMobileState != null
                && mMobileState == NetworkInfo.State.CONNECTED
                && mWifiState != NetworkInfo.State.CONNECTED){
            return NetworkState.MOBILE;
        }
        if(mWifiState != null && mMobileState != null
                && mMobileState != NetworkInfo.State.CONNECTED
                && mWifiState == NetworkInfo.State.CONNECTED){
            return NetworkState.WIFI;
        }
        return NetworkState.NONE;
    }

    /**
     * 获取网络连接类型
     * @param context
     * @return
     */
    public static int getActiveNetType(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) {
            return TYPE_DISCONNECTED;
        }
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isAvailable()) {
            return TYPE_DISCONNECTED;
        }
        if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
            return TYPE_WIFI;
        }
        if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
            int subType = networkInfo.getSubtype();
            switch (subType) {
                case TelephonyManager.NETWORK_TYPE_GPRS:
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_CDMA:
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                case TelephonyManager.NETWORK_TYPE_IDEN:
                    return TYPE_2G;
                case TelephonyManager.NETWORK_TYPE_UMTS:
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                case TelephonyManager.NETWORK_TYPE_EVDO_B:
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_HSPAP:
                case TelephonyManager.NETWORK_TYPE_EHRPD:
                    return TYPE_3G;
                case TelephonyManager.NETWORK_TYPE_LTE:
                    return TYPE_4G;
                default:
                    return TYPE_UNKNOWN;

            }
        }
        return TYPE_UNKNOWN;
    }








}
