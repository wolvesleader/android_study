package com.loonxi.ju53.modules.glide;

import android.content.Context;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory;
import com.bumptech.glide.module.GlideModule;

/**
 * 自定义Glide配置
 * Created by Xuzue on 2015/12/16.
 */
public class GlideConfiguration implements GlideModule {
    @Override
    public void applyOptions(Context context, GlideBuilder builder) {
        //如果RGB_565格式的图片质量不能满足需求，可设置为ARGB_8888
        //        builder.setDecodeFormat(DecodeFormat.PREFER_ARGB_8888);
        //设置图片本地缓存
        builder.setDiskCache(new InternalCacheDiskCacheFactory(context, 50 * 1024 * 1024));
    }

    @Override
    public void registerComponents(Context context, Glide glide) {

    }
}
