package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.MainBannderEntity;
import com.loonxi.ju53.entity.MainListEntity;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by laojiaqi on 2016/6/1.
 */
public interface IHomeTabViewServer
{


    /**
     * 获得主界面第一页数据
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("customNav/Main")
    Call<MainBannderEntity> getTopListData(@FieldMap Map<String, Object> map);

    @FormUrlEncoded
    @POST("customNav/Crossband")
    Call<MainListEntity>  getMainListData(@FieldMap  Map<String,Object>  map);
}
