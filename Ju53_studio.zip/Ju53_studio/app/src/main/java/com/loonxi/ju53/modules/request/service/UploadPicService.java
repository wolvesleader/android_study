package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.squareup.okhttp.RequestBody;

import retrofit.Call;
import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;

/**
 * "上传图片"service
 * Created by laojiaqi on 2016/2/15.
 */
public interface UploadPicService {
    @Multipart
    @POST("person/certifyName")
    Call<BaseJsonInfo> checkIn(@Part("image\"; filename=\"a.jpg") RequestBody file,@Part("idCard")String idCard,@Part("customName")String customName,@Part("requestType")int requestType,@Part("version")String version);
}
