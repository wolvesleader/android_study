package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.List;

/**
 * 店铺商品数据
 * Created by XuZue on 2016/5/6 0006.
 */
public class StoreDataEntity implements Parcelable {
    private String count_on;
    private String count_off;
    private List<StoreProductEntity> list;

    public StoreDataEntity() {

    }


    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(count_on);
        dest.writeString(count_off);
        dest.writeList(list);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<StoreDataEntity> CREATOR = new Creator<StoreDataEntity>() {
        @Override
        public StoreDataEntity createFromParcel(Parcel in) {
            StoreDataEntity data = new StoreDataEntity();
            data.setCountOn(in.readString());
            data.setCountOff(in.readString());
            data.setList(in.readArrayList(Thread.currentThread().getContextClassLoader()));
            return data;
        }

        @Override
        public StoreDataEntity[] newArray(int size) {
            return new StoreDataEntity[size];
        }
    };

    public String getCountOn() {
        return count_on;
    }

    public void setCountOn(String count_on) {
        this.count_on = count_on;
    }

    public String getCountOff() {
        return count_off;
    }

    public void setCountOff(String count_off) {
        this.count_off = count_off;
    }

    public List<StoreProductEntity> getList() {
        return list;
    }

    public void setList(List<StoreProductEntity> list) {
        this.list = list;
    }
}
