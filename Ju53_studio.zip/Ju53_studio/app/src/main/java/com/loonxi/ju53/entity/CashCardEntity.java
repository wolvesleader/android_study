package com.loonxi.ju53.entity;

/**
 * 提现绑卡信息
 * Created by XuZue on 2016/5/10 0010.
 */
public class CashCardEntity {
    private String pid;
    private String cardlen;//账号（加密后的）
    private String bankname;
    private String account;//账号（未加密）

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getCardlen() {
        return cardlen;
    }

    public void setCardlen(String cardlen) {
        this.cardlen = cardlen;
    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
}
