package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.widgets.FixedGridView;

import java.util.List;

/**
 * 分类页面右侧列表适配器
 * Created by Xuzue on 2015/12/24.
 */
public class SortContentAdapter extends BaseObjectListAdapter<SortEntity>{
    public SortContentAdapter(Context context, List<SortEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if(convertView == null){
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_sort_content, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_sort_content_layout_root);
            holder.mTvTitle = (TextView) convertView.findViewById(R.id.listitem_sort_content_title);
            holder.mFgr = (FixedGridView) convertView.findViewById(R.id.listitem_sort_content_fgv);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        final SortEntity sort = get(position);
        holder.mTvTitle.setText(sort.getName());
        if(!ListUtil.isEmpty(sort.getList())){
            holder.mFgr.setVisibility(View.VISIBLE);
            SortGridviewAdapter gridviewAdapter = new SortGridviewAdapter(mContext, sort.getList());
            holder.mFgr.setAdapter(gridviewAdapter);
        }else{
            holder.mFgr.setVisibility(View.GONE);
        }

        return convertView;
    }

    static class ViewHolder{
        LinearLayout mLayoutRoot;
        TextView mTvTitle;
        FixedGridView mFgr;
    }
}
