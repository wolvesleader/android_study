package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2016/1/25.
 */
public class OrderTime implements Parcelable {
    private long createTime;
    private int state;

    protected OrderTime(Parcel in) {
        createTime = in.readLong();
        state = in.readInt();
    }

    public static final Creator<OrderTime> CREATOR = new Creator<OrderTime>() {
        @Override
        public OrderTime createFromParcel(Parcel in) {
            return new OrderTime(in);
        }

        @Override
        public OrderTime[] newArray(int size) {
            return new OrderTime[size];
        }
    };

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(createTime);
        dest.writeInt(state);
    }
}
