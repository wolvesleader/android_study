package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.utils.FileUtil;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
public class SettingActivity extends ActionBarActivity implements View.OnClickListener {


    @ViewInject(R.id.setting_layout_feedback)
    private LinearLayout mLayoutFeedback;
    @ViewInject(R.id.setting_layout_about)
    private LinearLayout mLayoutAbout;
    @ViewInject(R.id.setting_layout_clearcache)
    private LinearLayout mLayoutClearCache;
    @ViewInject(R.id.setting_tv_cache)
    private TextView mTvCache;
    @ViewInject(R.id.setting_layout_tel)
    private LinearLayout mLayoutTel;

    private boolean clearFinish = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
    }

    @Override
    public void initView() {
        setTitle(R.string.setting_title);
    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mLayoutFeedback.setOnClickListener(this);
        mLayoutClearCache.setOnClickListener(this);
        mLayoutAbout.setOnClickListener(this);
        mLayoutTel.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setCacheSize();
    }


    private void setCacheSize() {
        mTvCache.setText(FileUtil.FormatFileSize(getCacheSize()));
    }

    private long getCacheSize() {
        long glideSize = FileUtil.getFolderSize(Glide.getPhotoCacheDir(mContext));
        long webviewSize = FileUtil.getWebviewCacheSize(mContext);
        return glideSize + webviewSize;
    }

    /**
     * 清理缓存
     */
    private void clearCache() {
        if (getCacheSize() <= 0) {
            return;
        }
        clearFinish = false;
        showLoadingDialog();
        clearWebViewCache();
        clearGlideCache();
    }


    /**
     * 清理webview缓存
     */
    private void clearWebViewCache() {
        FileUtil.clearWebviewCacheFolder(mContext.getCacheDir(), System.currentTimeMillis());//删除此时之前的缓存
    }

    /**
     * 清理Glide缓存
     */
    private void clearGlideCache() {
        Glide.get(mContext).clearMemory();
        new AsyncTask<String, Integer, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected String doInBackground(String... params) {
                Glide.get(mContext).clearDiskCache();
                return null;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                if (!clearFinish) {
                    finishClear();
                }
            }
        }.execute();
    }

    private void finishClear() {
        clearFinish = true;
        dismissLoadingDialog();
        showToast(R.string.cache_success);
        setCacheSize();
    }

    /**
     * 跳转到“关于我们”webView
     */
    private void gotoWebViewActivity() {
        Intent webViewIntent = new Intent(mContext, AboutUsActivity.class);
        startActivity(webViewIntent);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.setting_layout_feedback:
                startActivity(new Intent(mContext, QuestionActivity.class));
                break;
            case R.id.setting_layout_clearcache:
                clearCache();
                break;
            case R.id.setting_layout_about:
                gotoWebViewActivity();
                break;
            case R.id.setting_layout_tel:
                IntentUtil.intentToDial(mContext, AppConst.HOT_LINE);
                break;
        }
    }
}
