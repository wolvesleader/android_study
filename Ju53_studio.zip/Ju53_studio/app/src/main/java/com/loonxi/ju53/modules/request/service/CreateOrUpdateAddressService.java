package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 新建、修改 收货地址（国内、国外）service
 * Created by Administrator on 2016/1/26.
 */
public interface CreateOrUpdateAddressService {

    /**
     * 新建国内地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/insertAddress")
    Call<BaseJsonInfo> createAddress(@FieldMap Map<String, Object> map);

    /**
     * 修改国内地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateAddress")
    Call<BaseJsonInfo> updateAddress(@FieldMap Map<String, Object> map);


    /**
     * 新建国外地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/insertOverseaAddress")
    Call<BaseJsonInfo> createOverSeasAddress(@FieldMap Map<String, Object> map);


    /**
     * 修改国外地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateOverseaAddress")
    Call<BaseJsonInfo> updateOverseasAddress(@FieldMap Map<String, Object> map);

}
