package com.loonxi.ju53.listener;


/**
 * 购物车UI更新监听器
 * Created by Xuzue on 2015/12/29.
 */
public interface OnUpdateCartViewListener {

    void updateBottomView();

}
