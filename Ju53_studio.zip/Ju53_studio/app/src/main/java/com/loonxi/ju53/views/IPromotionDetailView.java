package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.PromotionEntity;

/**
 * Created by Xuzue on 2016/2/25.
 */
public interface IPromotionDetailView {
    void onGetPromotionDetailSuccess(PromotionEntity promotion);
    void onGetPromotiondetailFailed(int apiErrorCode, String message);
}
