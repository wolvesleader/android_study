package com.loonxi.ju53.entity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * 购物车实体（店名 + 产品列表）
 * Created by Xuzue on 2015/12/26.
 */
public class CartEntity implements Serializable{

    /**
     * 店铺id
     */
    private String supperId;
    private String uid;
    /**
     * 店铺名
     */
    private String userName;
    /**
     * 创建时间（宝贝加入购物车的时间）
     */
    private long createdTime;
    /**
     * 宝贝列表
     */
    private ArrayList<BaseProductEntity> list;
    /**
     * 买家备注
     */
    private String notes;
    /**
     * 卖家备注
     */
    private String remark;
    /**
     * 店铺下所有产品总运费(根据运费模板算)
     */
    private double totalFreight;
    /**
     * 总费用（包含运费）
     */
    private double totalFee;
    /**
     * 店铺下所有产品数
     */
    private int totalCount;

    public CartEntity(){

    }

    public String getSupperId() {
        return supperId;
    }

    public void setSupperId(String supperId) {
        this.supperId = supperId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }

    public ArrayList<BaseProductEntity> getList() {
        return list;
    }

    public void setList(ArrayList<BaseProductEntity> list) {
        this.list = list;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public double getTotalFreight() {
        return totalFreight;
    }

    public void setTotalFreight(double totalFreight) {
        this.totalFreight = totalFreight;
    }

    public double getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(double totalFee) {
        this.totalFee = totalFee;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

}
