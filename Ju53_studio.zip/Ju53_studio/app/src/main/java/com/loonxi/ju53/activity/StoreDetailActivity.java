package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.StoreDetailAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreDetailEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.manager.StoreManager;
import com.loonxi.ju53.presenters.StoreDetailPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IStoreDetailView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedGridView;
import com.loonxi.ju53.widgets.dialog.ShareDialog;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;
import com.umeng.socialize.UMShareAPI;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreDetailActivity extends ActionBarActivity implements View.OnClickListener, IStoreDetailView {

    @ViewInject(R.id.store_detail_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.store_detail_layout_empty)
    private RelativeLayout mLayoutEmpty;
    @ViewInject(R.id.store_detail_fgv)
    private FixedGridView mFlv;
    @ViewInject(R.id.store_detail_iv_head)
    private ImageView mIvHead;
    @ViewInject(R.id.store_detail_tv_name)
    private TextView mTvName;

    private int mCurrentPage = 1;
    private StoreDetailAdapter mAdapter;
    private List<StoreProductEntity> mProducts = new ArrayList<>();
    private StoreDetailPresenter mPresenter;
    private ShareDialog mShareDialog;
    private StoreBaseInfoEntity mStoreBaseInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);
    }

    @Override
    public void initView() {
        setTitle("店铺预览");
        setRightVisibility(View.VISIBLE);
        setRightTextVisibility(View.VISIBLE);
        setRightText("分享");
    }

    @Override
    public void initContent() {
        mCurrentPage = 1;
        mPresenter = new StoreDetailPresenter(this);
        mAdapter = new StoreDetailAdapter(mContext, mProducts);
        mFlv.setAdapter(mAdapter);
        mFlv.setFocusable(false);
        mPresenter.getStoreBaseInfo();
        mPresenter.getStoreDetail(mCurrentPage);
        setBaseInfo(null);
    }


    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getStoreBaseInfo();
                mPresenter.getStoreDetail(mCurrentPage);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getStoreDetail(mCurrentPage);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                share();
                break;
        }
    }

    private void setEmptyViewVisibility() {
        if (ListUtil.isEmpty(mProducts)) {
            mLayoutEmpty.setVisibility(View.VISIBLE);
            mFlv.setVisibility(View.GONE);
        } else {
            mLayoutEmpty.setVisibility(View.GONE);
            mFlv.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 设置店铺基本信息
     *
     * @param baseInfo
     */
    private void setBaseInfo(StoreBaseInfoEntity baseInfo) {
        mStoreBaseInfo = baseInfo;
        if (baseInfo == null) {
            StoreManager.setStoreBaseInfo(mIvHead, mTvName);
            return;
        }
        StoreManager.saveStoreBaseInfo(mStoreBaseInfo.getStore_logo(), mStoreBaseInfo.getStore_name());
        StoreManager.setStoreBaseInfo(mIvHead, mTvName);
    }

    @Override
    public void onGetStoreDetailSuccess(StoreDataEntity store) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        if (store != null) {
            if (mCurrentPage == 1) {
                mProducts.clear();
            }
            if (!ListUtil.isEmpty(store.getList())) {
                mProducts.addAll(store.getList());
                mCurrentPage++;
            } else {
                if (mCurrentPage != 1) {
                    showToast(R.string.empty_list);
                }
            }
            mAdapter.notifyDataSetChanged();
        }
        setEmptyViewVisibility();
    }

    @Override
    public void onGetStoreDetailFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void getBaseInfoSuccess(StoreBaseInfoEntity base) {
        setBaseInfo(base);
    }

    @Override
    public void getBaseInfoFailed(int apiErrorCode, String message) {

    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    private void share() {
        String userName = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_NAME);
        String storeName = (mStoreBaseInfo == null || StringUtil.isEmpty(mStoreBaseInfo.getStore_name())) ?
                (userName + "的聚小店") : mStoreBaseInfo.getStore_name();
        String title = storeName;
        String content = (mStoreBaseInfo != null && !StringUtil.isEmpty(mStoreBaseInfo.getShare_content())) ?
                mStoreBaseInfo.getShare_content() :
                ("这是我的聚小店，好货多多，来逛逛哦" + ("\n" + storeName));
        String imgUrl = AppConst.PIC_HEAD + SpUtil.getString(mContext, SpUtil.STORE_LOGO, "");
        String targetUrl = mStoreBaseInfo == null ? "" : mStoreBaseInfo.getShow_url();
        mShareDialog = new ShareDialog(mContext, title, content, imgUrl, targetUrl);
        mShareDialog.setDialogAttribute(this, Gravity.BOTTOM);
        mShareDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(mContext).onActivityResult(requestCode, resultCode, data);
    }
}
