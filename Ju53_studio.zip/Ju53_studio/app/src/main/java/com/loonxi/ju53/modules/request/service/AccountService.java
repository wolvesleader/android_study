package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.RegistAuthEntity;
import com.loonxi.ju53.entity.UserEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 账户有关的接口
 * Created by Xuzue on 2016/1/5.
 */
public interface AccountService {

    /**
     * 登录
     * @param map
     */
    @FormUrlEncoded
    @POST("user/loginPost")
    Call<UserEntity> login(@FieldMap Map<String, Object> map);


    /**
     * 注册，获取验证码
     * @param map
     */
    @FormUrlEncoded
    @POST("register/sendMobile")
     Call<BaseJsonInfo> getCheckCode(@FieldMap Map<String, Object> map );

    /**
     * 注册，校验验证码
     * @param map
     */
    @FormUrlEncoded
    @POST("register/checkMobileCode")
    Call<BaseJsonInfo> verifyCode(@FieldMap Map<String, Object> map);

    /**
     * 注册，上传信息
     * @param map
     */
    @FormUrlEncoded
    @POST("register/userRegister")
    Call<RegistAuthEntity> auth(@FieldMap Map<String, Object> map);
}
