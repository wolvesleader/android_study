package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.fragment.accountSafe.AccountSafeMainFragment;
import com.loonxi.ju53.fragment.accountSafe.AccountSafeMobileFragment;

/**
 * "账户安全"
 * Created by laojiaqi on 2016/2/17.
 */
public class AccountSafeActivity extends BaseActivity {

    public static final String FROM_TYPE = "FROM_TYPE";
    public static final int FROM_MINE_FRAGMENT = 0;
    public static final int FROM_LOGIN_ACTIVITY = 1;
    private int mCurrentType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_safe);
        getData();
        initFragment();
    }

    private void getData() {
        mCurrentType = getIntent().getIntExtra(FROM_TYPE, FROM_MINE_FRAGMENT);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initFragment() {
        if (mCurrentType == FROM_MINE_FRAGMENT) {
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            AccountSafeMainFragment accountSafeMainFragment = new AccountSafeMainFragment();
            ft.add(R.id.fragment_account_safe_container, accountSafeMainFragment);
            ft.commitAllowingStateLoss();
            return;
        }
        if (mCurrentType == FROM_LOGIN_ACTIVITY) {
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            AccountSafeMobileFragment accountSafeMobileFragment = new AccountSafeMobileFragment();
            ft.add(R.id.fragment_account_safe_container, accountSafeMobileFragment);
            ft.commitAllowingStateLoss();
            return;

        }
    }
}
