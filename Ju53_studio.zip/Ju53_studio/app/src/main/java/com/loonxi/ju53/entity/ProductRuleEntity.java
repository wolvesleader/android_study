package com.loonxi.ju53.entity;

/**
 * 产品规格实体entity
 * Created by Administrator on 2016/1/15.
 */
public class ProductRuleEntity {

    private String attrbuteOne;//颜色
    private String attrbuteTwo;//尺码
    private long stock;//库存
    private double  price;//价格
    private long stockId;//stockId

    public String getAttrbuteOne() {
        return attrbuteOne;
    }

    public void setAttrbuteOne(String attrbuteOne) {
        this.attrbuteOne = attrbuteOne;
    }

    public String getAttrbuteTwo() {
        return attrbuteTwo;
    }

    public void setAttrbuteTwo(String attrbuteTwo) {
        this.attrbuteTwo = attrbuteTwo;
    }

    public long getStock() {
        return stock;
    }

    public void setStock(long stock) {
        this.stock = stock;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public long getStockId() {
        return stockId;
    }

    public void setStockId(long stockId) {
        this.stockId = stockId;
    }

    @Override
    public String toString() {
        return "ProductRuleEntity{" +
                "attrbuteOne='" + attrbuteOne + '\'' +
                ", attrbuteTwo='" + attrbuteTwo + '\'' +
                ", stock=" + stock +
                ", price=" + price +
                ", stockId=" + stockId +
                '}';
    }
}
