package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 单个活动信息实体
 * Created by Xuzue on 2015/12/23.
 */
public class PromotionEntity implements Parcelable {

    /**
     *
     */
    private int id;

    /**
     *  活动标题
     */
    private String title;

    /**
     *  活动缩略图
     */
    private String thumb;

    /**
     *   主图
     */
    private String banner;

    /**
     *  排序
     */
    private int sort;


    /**
     * 活动商品列表
     */
    private List<PromotionProductEntity> list;

    protected PromotionEntity(Parcel in) {
        id = in.readInt();
        title = in.readString();
        thumb = in.readString();
        banner = in.readString();
        sort = in.readInt();
        list = in.createTypedArrayList(PromotionProductEntity.CREATOR);
    }

    public static final Creator<PromotionEntity> CREATOR = new Creator<PromotionEntity>() {
        @Override
        public PromotionEntity createFromParcel(Parcel in) {
            return new PromotionEntity(in);
        }

        @Override
        public PromotionEntity[] newArray(int size) {
            return new PromotionEntity[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public List<PromotionProductEntity> getList() {
        return list;
    }

    public void setList(List<PromotionProductEntity> list) {
        this.list = list;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(thumb);
        dest.writeString(banner);
        dest.writeInt(sort);
        dest.writeTypedList(list);
    }
}
