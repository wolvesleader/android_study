package com.loonxi.ju53.entity;

import java.io.Serializable;

/**
 * 物流信息 entity
 * Created by laojiaqi on 2016/2/4.
 */
public class LogisticsEntity implements Serializable{
    /**
     *
     */
    private Long pid;

    /**
     *
     */
    private Long userId;

    /**
     *  物流编号(暂时未使用 待定)
     */
    private String transId;

    /**
     *
     */
    private String orderId;

    /**
     *  物流类型(0-订单发货,1-退换货,2-其他)
     */
    private Byte transType;

    /**
     *  物流公司代码
     */
    private String tplid;

    /**
     *  物流公司
     */
    private String tplcom;

    /**
     *  运单号(物流公司)
     */
    private String postid;

    /**
     *  配送方式(0-物流/快递,1-自送,2-自取)
     */
    private Byte transMode;

    /**
     *  发货信息
     */
    private String sendInfo;

    /**
     *  收货信息
     */
    private String receiveInfo;

    /**
     *  发货日期
     */
    private long sendDate;

    /**
     *  发货说明
     */
    private String notes;

    /**
     *  创建时间
     */
    private long createTime;

    /**
     *  修改时间
     */
    private long updateTime;

    private static final long serialVersionUID = 1L;

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId == null ? null : transId.trim();
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public Byte getTransType() {
        return transType;
    }

    public void setTransType(Byte transType) {
        this.transType = transType;
    }

    public String getTplid() {
        return tplid;
    }

    public void setTplid(String tplid) {
        this.tplid = tplid == null ? null : tplid.trim();
    }

    public String getTplcom() {
        return tplcom;
    }

    public void setTplcom(String tplcom) {
        this.tplcom = tplcom == null ? null : tplcom.trim();
    }

    public String getPostid() {
        return postid;
    }

    public void setPostid(String postid) {
        this.postid = postid == null ? null : postid.trim();
    }

    public Byte getTransMode() {
        return transMode;
    }

    public void setTransMode(Byte transMode) {
        this.transMode = transMode;
    }

    public String getSendInfo() {
        return sendInfo;
    }

    public void setSendInfo(String sendInfo) {
        this.sendInfo = sendInfo == null ? null : sendInfo.trim();
    }

    public String getReceiveInfo() {
        return receiveInfo;
    }

    public void setReceiveInfo(String receiveInfo) {
        this.receiveInfo = receiveInfo == null ? null : receiveInfo.trim();
    }

    public long getSendDate() {
        return sendDate;
    }

    public void setSendDate(long sendDate) {
        this.sendDate = sendDate;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes == null ? null : notes.trim();
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }
}
