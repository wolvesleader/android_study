package com.loonxi.ju53.widgets;

import android.content.Context;
import android.os.Handler;

import java.lang.ref.WeakReference;

/**
 * 为了防止内存泄漏，定义外部类，防止内部类对外部类的引用
 */
public  class CycleViewPagerHandler<T extends Context> extends Handler {
	public  WeakReference<T> mRefContext=null;

	public CycleViewPagerHandler(T context) {
		this.mRefContext = new WeakReference<T>(context);
	}

};