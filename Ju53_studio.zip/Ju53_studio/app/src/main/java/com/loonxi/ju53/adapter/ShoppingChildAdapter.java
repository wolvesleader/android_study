package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.listener.OnUpdateCartViewListener;
import com.loonxi.ju53.presenters.ShoppingPresenter;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.MapUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.widgets.dialog.BtnDialog;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Xuzue on 2015/12/26.
 */
public class ShoppingChildAdapter extends BaseObjectListAdapter<BaseProductEntity> {

    private ShoppingPresenter mPresenter;

    private int mParentIndex;
    private CartEntity mCart;
    private onRightItemClickListener mListener;
    private OnUpdateCartViewListener mUpdateListener;
    private boolean mIsEditItem;
    private boolean mIsEditAll;
    private boolean mIsCheckAll;
    private Map<String, Boolean> mEditMap = new HashMap<>();
    private Map<String, Boolean> mCheckCompanyMap = new HashMap<>();
    private Map<String, Boolean> mCheckProductMap = new HashMap<>();
    private BtnDialog mDeleteDialog;
    private ShoppingAdapter.ViewHolder mParentHolder;

    public ShoppingChildAdapter(Context context, int parentIndex, CartEntity cart, List<BaseProductEntity> datas,
                                OnUpdateCartViewListener listener, ShoppingPresenter presenter, ShoppingAdapter.ViewHolder holder) {
        super(context, datas);
        mCart = cart;
        mParentIndex = parentIndex;
        mPresenter = presenter;
        mEditMap = mPresenter.getEditCompanyMap();
        mCheckCompanyMap = mPresenter.getCheckCompanyMap();
        mCheckProductMap = mPresenter.getCheckProductMap();
        mUpdateListener = listener;
        mParentHolder = holder;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_shopping_child, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_root);
            holder.mLayoutLeft = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_left);
            holder.mLayoutCheck = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_check);
            holder.mCbx = (CheckBox) convertView.findViewById(R.id.listitem_shopping_child_cbx);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_shopping_child_iv_head);
            holder.mLayoutName = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_name);
            holder.mTvName = (TextView) convertView.findViewById(R.id.listitem_shopping_child_tv_name);
            holder.mLayoutNumsManage = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_nums_manage);
            holder.mLayoutNumMinus = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_nums_minus);
            holder.mTvNumEdit = (TextView) convertView.findViewById(R.id.listitem_shopping_child_tv_nums_edit);
            holder.mLayoutNumPlus = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_nums_plus);
            holder.mLayoutOpen = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_open);
            holder.mLayoutAttribute = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_attribute);
            holder.mTvAttribute = (TextView) convertView.findViewById(R.id.listitem_shopping_child_tv_attribute);
            holder.mIvOpenAttribute = (ImageView) convertView.findViewById(R.id.listitem_shopping_child_iv_open_attribute);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_shopping_child_tv_price);
            holder.mLayoutNums = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_nums);
            holder.mTvNums = (TextView) convertView.findViewById(R.id.listitem_shopping_child_tv_nums);
            holder.mLayoutDelete = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_delete);
            holder.mDivider = convertView.findViewById(R.id.listitem_shopping_child_divider);
            holder.mLayoutRight = (LinearLayout) convertView.findViewById(R.id.listitem_shopping_child_layout_right);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        BaseProductEntity product = get(position);
        String companyId = mCart.getSupperId();
        boolean isCheckCompany = MapUtil.isEmpty(mCheckCompanyMap) ? false : mCheckCompanyMap.get(companyId);
        mIsEditItem = MapUtil.isEmpty(mEditMap) ? false : mEditMap.get(companyId);

        if (mIsEditItem) {
            holder.mLayoutName.setVisibility(View.GONE);
            holder.mLayoutNumsManage.setVisibility(View.VISIBLE);
            holder.mLayoutNums.setVisibility(View.GONE);
            if (mIsEditAll) {
                holder.mLayoutDelete.setVisibility(View.GONE);
            } else {
                holder.mLayoutDelete.setVisibility(View.VISIBLE);
            }
            holder.mIvOpenAttribute.setVisibility(View.VISIBLE);
            holder.mTvPrice.setVisibility(View.INVISIBLE);
            holder.mLayoutOpen.requestFocus();
        } else {
            holder.mLayoutName.setVisibility(View.VISIBLE);
            holder.mLayoutNumsManage.setVisibility(View.GONE);
            holder.mLayoutNums.setVisibility(View.VISIBLE);
            holder.mLayoutDelete.setVisibility(View.GONE);
            holder.mIvOpenAttribute.setVisibility(View.GONE);
            holder.mTvPrice.setVisibility(View.VISIBLE);
            holder.mLayoutOpen.clearFocus();
        }

        if (isCheckCompany) {
            holder.mCbx.setChecked(true);
        } else {
            holder.mCbx.setChecked(MapUtil.isEmpty(mCheckProductMap) ? false : mCheckProductMap.get(product.getStockid() + ""));
        }

        Glide.with(mContext).load(AppConst.PIC_HEAD + product.getPicture() + AppConst.PIC_SIZE_80).into(holder.mIvHead);
        holder.mTvNumEdit.setText(product.getCount() + "");
        holder.mTvName.setText(product.getProductName());
        String colorStr = StringUtil.isEmpty(product.getAttributeColor()) ? "" : product.getAttributeColor();
        String sizeStr = StringUtil.isEmpty(product.getAttributeMula()) ? "" : product.getAttributeMula();
        holder.mTvAttribute.setText("颜色:" + colorStr + " 尺码:" + sizeStr);
        holder.mTvPrice.setText("¥" + product.getPrice());
        holder.mTvNums.setText("x" + product.getCount());

        if (position == getCount() - 1) {
            holder.mDivider.setVisibility(View.GONE);
        } else {
            holder.mDivider.setVisibility(View.VISIBLE);
        }
        holder.mCbx.clearFocus();
        holder.mCbx.setClickable(false);

        setListener(holder, product, position);

        return convertView;
    }

    private void setListener(final ViewHolder holder, final BaseProductEntity product, final int position) {
        final CheckBox cbx = holder.mCbx;
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogUtil.mLog().i("click");
                Intent intent = new Intent(mContext, ProductDetailActivity.class);
                intent.putExtra("productId", product.getProductId());
                mContext.startActivity(intent);
            }
        });
        holder.mLayoutRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onRightItemClick(v, position);
                }
            }
        });
        holder.mLayoutCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbx.setChecked(cbx.isChecked() ? false : true);
                mPresenter.updateDataAfterCheckProduct(mCart, product, cbx.isChecked());
                if (mUpdateListener != null) {
                    mUpdateListener.updateBottomView();
                }
                updateParentView(cbx.isChecked());
            }
        });
        holder.mLayoutOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.mIvOpenAttribute.isShown()) {
                    mPresenter.getSku(holder.mTvAttribute, mCart, product);
                }
            }
        });
        holder.mLayoutNumMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int nums = StringUtil.isEmpty(holder.mTvNumEdit.getText().toString()) ? 0 : Integer.parseInt(holder.mTvNumEdit.getText().toString());
                if (nums > 1) {
                    nums--;
                    holder.mTvNumEdit.setText(nums + "");
                    mPresenter.updateDataAfterAltCartNums(mParentIndex, position, nums);
                    mPresenter.altCartAttribute(product.getPid() + "", product.getAttributeColor(), product.getAttributeMula(), product.getStockid(), nums);
                    if (mUpdateListener != null) {
                        mUpdateListener.updateBottomView();
                    }
                }
            }
        });
        holder.mLayoutNumPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int nums = StringUtil.isEmpty(holder.mTvNumEdit.getText().toString()) ? 0 : Integer.parseInt(holder.mTvNumEdit.getText().toString());
                nums++;
                holder.mTvNumEdit.setText(nums + "");
                mPresenter.updateDataAfterAltCartNums(mParentIndex, position, nums);
                mPresenter.altCartAttribute(product.getPid() + "", product.getAttributeColor(), product.getAttributeMula(), product.getStockid(), nums);
                if (mUpdateListener != null) {
                    mUpdateListener.updateBottomView();
                }
            }
        });
        holder.mLayoutDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog(product);
            }
        });
    }

    private void updateParentView(boolean isChecked) {
        boolean isCheckCompany = mPresenter.isCheckAllProduct4Company(mCart, isChecked);
        mParentHolder.mCbx.setChecked(isCheckCompany);
    }

    /**
     * 删除某个宝贝
     *
     * @param product
     */
    private void showDeleteDialog(final BaseProductEntity product) {
        mDeleteDialog = new BtnDialog(mContext,
                mContext.getResources().getString(R.string.tip),
                mContext.getResources().getString(R.string.shopping_delete),
                mContext.getResources().getString(R.string.confirm),
                mContext.getResources().getString(R.string.cancel),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDeleteDialog.dismiss();
                        mPresenter.deleteOneProduct(mCart, product);//网络删除（正式）
                    }
                },
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDeleteDialog.dismiss();
                    }
                });
        mDeleteDialog.show();
    }

    static class ViewHolder {
        LinearLayout mLayoutRoot;
        LinearLayout mLayoutLeft;
        LinearLayout mLayoutCheck;
        CheckBox mCbx;
        ImageView mIvHead;
        LinearLayout mLayoutName;
        TextView mTvName;
        LinearLayout mLayoutNumsManage;
        LinearLayout mLayoutNumMinus;
        TextView mTvNumEdit;
        LinearLayout mLayoutNumPlus;
        LinearLayout mLayoutOpen;
        LinearLayout mLayoutAttribute;
        TextView mTvAttribute;
        ImageView mIvOpenAttribute;
        TextView mTvPrice;
        LinearLayout mLayoutNums;
        TextView mTvNums;
        LinearLayout mLayoutDelete;
        LinearLayout mLayoutRight;
        View mDivider;
    }

    public boolean getIsEditItem() {
        return mIsEditItem;
    }

    public void setIsEditItem(boolean isEditItem) {
        mIsEditItem = isEditItem;
    }

    public boolean getIsEditAll() {
        return mIsEditAll;
    }

    public void setIsEditAll(boolean isEditAll) {
        mIsEditAll = isEditAll;
    }

    public boolean ismIsCheckAll() {
        return mIsCheckAll;
    }

    public void setmIsCheckAll(boolean mIsCheckAll) {
        this.mIsCheckAll = mIsCheckAll;
    }

    public void setOnRightItemClickListener(onRightItemClickListener listener) {
        mListener = listener;
    }

    public interface onRightItemClickListener {
        void onRightItemClick(View v, int position);
    }
}
