package com.loonxi.ju53.presenters;

import android.content.Context;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.MainTabEntity;
import com.loonxi.ju53.models.IHomeModel;
import com.loonxi.ju53.models.impl.HomeModel;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.views.ITabHomeView;

import retrofit.Retrofit;

/**
 * "首页"presenter
 * Created by Xuzue on 2015/12/18.
 */
public class HomeTabPresenter extends BasePresenter<ITabHomeView> {
    private IHomeModel mModel;
    private ITabHomeView mView;

    private float ALPHA_SCROLL_LENGTH_TITLE;
    private float ALPHA_SCROLL_LENGTH_SCROLLVIEW;

    public HomeTabPresenter(ITabHomeView view) {
        super(view);
        mView = getView();
        mModel = new HomeModel();
    }



    /**
     * 获取首页tab 数据
     */
    public  void    getMainTabData()
    {
        mModel.getMainTab(new Callback<JsonArrayInfo<MainTabEntity>>() {


            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<MainTabEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<MainTabEntity> data, Retrofit retrofit) {
                mView.endAsyncTask();
                mView.onGetTabListDataSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                mView.endAsyncTask();
                     mView.onGetTabListDataFailed(apiErrorCode,message);
            }
        });

    }

    /**
     * 初始化Title
     *
     * @param context
     */
    public void initTitleDisappearLength(Context context) {
        if (context == null) {
            return;
        }
        ALPHA_SCROLL_LENGTH_TITLE = context.getResources().getDimension(R.dimen.product_detail_title_disappear_length_two);
        ALPHA_SCROLL_LENGTH_SCROLLVIEW = context.getResources().getDimension(R.dimen.main_disappear_length_to_top);
    }


    /**
     * 获得透明度
     *
     * @param value
     * @return
     */
    public float getAlpha(float value, boolean isTitle) {
        float alpha = value / (isTitle ? ALPHA_SCROLL_LENGTH_TITLE : ALPHA_SCROLL_LENGTH_SCROLLVIEW);
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 1) {
            alpha = 1;
        }
        if (!isTitle) {
            if (alpha > 0.5) {
                alpha = 1;
            } else if (alpha > 0.3 && alpha < 0.5) {
                alpha = 0.5f;
            }
        }
        return alpha;
    }


    /**
     * 获取首页内容
     */
    public void getIndexContent() {

    }

    /**
     * 获取热销宝贝
     *
     * @param page
     */
    public void getRecommends(int page) {

    }

    /**
     * 获取版本信息
     */
    public void getVersion() {
        mModel.getVersion(new Callback<GetVersionEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, GetVersionEntity data) {

            }

            @Override
            public void onSuccess(GetVersionEntity data, Retrofit retrofit) {
                if (mView != null) {
                    GetVersionEntity getVersionEntity = data;
                    int flag = getVersionEntity.getFlag();
                    if (flag == ApiError.REQUEST_SUCCESS) {
                        mView.onGetVersionSuccess(getVersionEntity);
                    }
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
            }
        });
    }
}
