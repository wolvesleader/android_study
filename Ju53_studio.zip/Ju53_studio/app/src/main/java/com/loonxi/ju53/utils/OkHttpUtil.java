package com.loonxi.ju53.utils;

import android.os.Handler;
import android.os.Looper;
import android.util.Patterns;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.internal.$Gson$Types;
import com.loonxi.ju53.modules.request.ApiError;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.Headers;
import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ForwardingSink;
import okio.ForwardingSource;
import okio.Okio;
import okio.Sink;
import okio.Source;


/**
 * OkHttp网络请求及文件下载工具类
 * Created by Xuzue on 2015/12/15.
 */
public class OkHttpUtil {
    private static OkHttpUtil mInstance;
    private OkHttpClient mOkHttpClient;
    private static Handler mHandler;
    private Gson mGson;

    private static final int TIMEOUT_CONN = 10;//连接超时时间，单位秒
    private static final int TIMEOUT_READ = 10;//读取超时时间，单位秒
    private static final int TIMEOUT_WRITE = 10;//写入超时时间，单位秒

    private OkHttpUtil() {
        mOkHttpClient = new OkHttpClient();
        mOkHttpClient.setCookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER));
        mOkHttpClient.setConnectTimeout(TIMEOUT_CONN, TimeUnit.SECONDS);
        mOkHttpClient.setConnectTimeout(TIMEOUT_READ, TimeUnit.SECONDS);
        mOkHttpClient.setConnectTimeout(TIMEOUT_WRITE, TimeUnit.SECONDS);
        mHandler = new Handler(Looper.getMainLooper());
        mGson = new Gson();
    }

    private static OkHttpUtil getInstance() {
        if (mInstance == null) {
            synchronized (OkHttpUtil.class) {
                if (mInstance == null) {
                    mInstance = new OkHttpUtil();
                }
            }
        }
        return mInstance;
    }

    private OkHttpClient _getClient() {
        return mOkHttpClient;
    }

    private Response _getSync(String url) throws IOException {
        Request req = new Request.Builder().url(url).build();
        Call call = mOkHttpClient.newCall(req);
        int i = ApiError.CONNECT_DB_ERROR;
        return call.execute();
    }

    private String _getAsStringSync(String url) throws IOException {
        Response resp = _getSync(url);
        return resp.body().toString();
    }

    private void _get(String url, ResultCallback callback) {
        Logger.d(url);
        Request req = new Request.Builder().url(url).build();
        handleResult(req, callback);
    }

    private Response _postSync(String url, Param... params) throws IOException {
        Request req = setupPostRequest(url, params);
        return mOkHttpClient.newCall(req).execute();
    }

    private String _postAsStringSync(String url, Param... params) throws IOException {
        Response resp = _postSync(url, params);
        return resp.body().toString();
    }

    private void _post(String url, ResultCallback callback, Param... params) {
        if (StringUtil.isEmpty(url)) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(url).append("?");
        for (Param param : params) {
            sb.append("&").append(param.key).append("=").append(param.value);
        }
        Logger.d(sb.toString().replaceFirst("&", ""));
        Request req = setupPostRequest(url, params);
        handleResult(req, callback);
    }

    private Response _uploadSync(String url, File[] files, String[] fileKeys, Param... params) throws IOException {
        Request req = setupMultipartFormRequest(url, files, fileKeys, params, null);
        return mOkHttpClient.newCall(req).execute();
    }

    private void _upload(String url, ResultCallback callback, File[] files, String[] fileKeys, Param... params) {
        Request req = setupMultipartFormRequest(url, files, fileKeys, params, callback);
        handleResult(req, callback);
    }

    private void _download(final String url, final String destFileDir, final String fileName, final ResultCallback callback) {
        if (!Patterns.WEB_URL.matcher(url).matches()) {
            sendFailureStringCallback(null, new IllegalStateException("invalid url"), callback);
            return;
        }
        final Request req = new Request.Builder().url(url).build();
        //克隆
        OkHttpClient client = mOkHttpClient.clone();
        //增加拦截器
        client.networkInterceptors().add(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                //拦截
                Response originalResponse = chain.proceed(chain.request());
                //包装响应体并返回
                return originalResponse.newBuilder().body(new ProgressResponseBody(originalResponse.body(), callback)).build();
            }
        });
        final Call call = client.newCall(req);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                sendFailureStringCallback(req, e, callback);
            }

            @Override
            public void onResponse(Response response) throws IOException {
                InputStream is = null;
                byte[] buf = new byte[2048];
                int len;
                FileOutputStream fos = null;
                try {
                    is = response.body().byteStream();
                    File file = new File(destFileDir, fileName.equals("") ? getFileName(url) : fileName);
                    fos = new FileOutputStream(file);
                    while ((len = is.read(buf)) != -1) {
                        fos.write(buf, 0, len);
                    }
                    fos.flush();
                    sendSuccessStringCallback(file.getAbsolutePath(), callback);
                } catch (IOException e) {
                    sendFailureStringCallback(req, e, callback);
                } finally {
                    try {
                        if (is != null) {
                            is.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        if (fos != null) {
                            fos.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }


    private void handleResult(final Request req, final ResultCallback callback) {
        mOkHttpClient.newCall(req).enqueue(new Callback() {

            @Override
            public void onFailure(Request request, IOException e) {
                sendFailureStringCallback(request, e, callback);
            }

            @Override
            public void onResponse(Response response) throws IOException {
                try {
                    String result = response.body().toString();
                    if (callback.mType == String.class) {
                        sendSuccessStringCallback(result, callback);
                    } else {
                        Object object = mGson.fromJson(result, callback.mType);
                        sendSuccessStringCallback(object, callback);
                    }
                } catch (JsonParseException jsonParseException) {
                    sendFailureStringCallback(req, jsonParseException, callback);
                }

            }
        });
    }

    private void sendFailureStringCallback(final Request req, final Exception e, final ResultCallback callback) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onError(req, e);
                }
            }
        });
    }

    private void sendSuccessStringCallback(final Object obj, final ResultCallback callback) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onResponse(obj);
                }
            }
        });
    }

    private void sendProgressCallback(final long bytesLoaded, final long contentLength, final boolean done, final ResultCallback callback) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onProgress(bytesLoaded, contentLength, done);
                }
            }
        });
    }

    private Request setupPostRequest(String url, Param[] params) {
        if (params == null) {
            params = new Param[0];
        }
        FormEncodingBuilder builder = new FormEncodingBuilder();
        for (Param param : params) {
            builder.add(param.key, param.value);
        }
        RequestBody body = builder.build();
        return new Request.Builder().url(url).post(body).build();
    }


    private Request setupMultipartFormRequest(String url, File[] files, String[] fileKeys, Param[] params, ResultCallback callback) {
        params = validateParams(params);
        MultipartBuilder builder = new MultipartBuilder().type(MultipartBuilder.FORM);
        for (Param param : params) {
            builder.addPart(Headers.of("Content-Disposition", "form-data; name=\"" + param.key + "\""),
                    RequestBody.create(null, param.value));
        }
        if (files != null) {
            RequestBody fileBody;
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                String name = file.getName();
                fileBody = RequestBody.create(MediaType.parse(getMimeType(name)), file);
                builder.addPart(Headers.of("Content-Disposition",
                                "form-data; name=\"" + fileKeys[i] + "\"; filename=\"" + name + "\""),
                        fileBody);
            }
        }
        RequestBody requestBody = builder.build();
        if (callback != null) {
            return new Request.Builder().url(url).post(new ProgressRequestBody(requestBody, callback)).build();
        }
        return new Request.Builder().url(url).post(requestBody).build();
    }

    private static Param[] convertMap2Param(Map<String, String> map) {
        if (MapUtil.isEmpty(map)) {
            return new Param[0];
        }
        Param[] params = new Param[map.size()];
        int index = 0;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            params[index++] = new Param(entry.getKey(), entry.getValue());
        }
        return params;
    }

    private Param[] validateParams(Param[] params) {
        if (params == null) {
            return new Param[0];
        } else {
            return params;
        }
    }

    private String getMimeType(String name) {
        FileNameMap fileNameMap = URLConnection.getFileNameMap();
        String contentTypeFor = fileNameMap.getContentTypeFor(name);
        if (contentTypeFor == null) {
            contentTypeFor = "application/octet-stream";
        }
        return contentTypeFor;
    }

    private String getFileName(String url) {
        if (StringUtil.isEmpty(url)) {
            return url;
        }
        int index = url.indexOf("/");
        return (index < 0 ? url : url.substring(index + 1, url.length()));
    }

    public static abstract class ResultCallback<T> {
        Type mType;

        public ResultCallback() {
            mType = getSuperClassTypeParameter(getClass());
        }

        static Type getSuperClassTypeParameter(Class<?> subclass) {
            Type superClass = subclass.getGenericSuperclass();
            if (subclass instanceof Class) {
                throw new RuntimeException("missing type parameter");
            }
            ParameterizedType parameterizedType = (ParameterizedType) superClass;
            return $Gson$Types.canonicalize(parameterizedType.getActualTypeArguments()[0]);
        }

        public abstract void onResponse(T response);

        public abstract void onError(Request req, Exception e);

        public abstract void onProgress(long bytesLoaded, long contentLength, boolean done);
    }

    public static class Param {
        String key;
        String value;

        public Param() {

        }

        public Param(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    /**
     * 下载请求的封装
     */
    private class ProgressResponseBody extends ResponseBody {

        private final ResponseBody mResponseBody;//待封装的响应体
        private final ResultCallback mCallback;//进度回调接口
        private BufferedSource mBufferedSource;//分装完成的BufferedSource

        private ProgressResponseBody(ResponseBody responseBody, ResultCallback callback) {
            mResponseBody = responseBody;
            mCallback = callback;
        }

        @Override
        public MediaType contentType() {
            return mResponseBody.contentType();
        }

        @Override
        public long contentLength() throws IOException {
            return mResponseBody.contentLength();
        }

        @Override
        public BufferedSource source() throws IOException {
            if (mBufferedSource == null) {
                mBufferedSource = Okio.buffer(source(mResponseBody.source()));
            }
            return null;
        }

        private Source source(Source source) {
            return new ForwardingSource(source) {
                long totalBytesRead = 0;//当前读取字节数

                @Override
                public long read(Buffer sink, long byteCount) throws IOException {
                    long bytesRead = super.read(sink, byteCount);
                    //增加当前读取的字节数，如果读取完成了bytesRead会返回-1
                    totalBytesRead += bytesRead != -1 ? bytesRead : 0;
                    //回调，如果contentLength()不知道长度，会返回-1
                    sendProgressCallback(totalBytesRead, mResponseBody.contentLength(), bytesRead != -1, mCallback);
                    return bytesRead;
                }
            };
        }
    }

    /**
     * 上传请求的包装
     */
    private class ProgressRequestBody extends RequestBody {
        private final RequestBody mRequestBody;
        private final ResultCallback mCallback;
        private BufferedSink mBufferedSink;

        private ProgressRequestBody(RequestBody requestBody, ResultCallback callback) {
            mRequestBody = requestBody;
            mCallback = callback;
        }

        @Override
        public MediaType contentType() {
            return mRequestBody.contentType();
        }

        @Override
        public long contentLength() throws IOException {
            return mRequestBody.contentLength();
        }

        @Override
        public void writeTo(BufferedSink sink) throws IOException {
            if (mBufferedSink == null) {
                mBufferedSink = Okio.buffer(sink(sink));
            }
            //写入
            mRequestBody.writeTo(mBufferedSink);
            //必须调用flush，否则最后一部分数据可能不会被写入
            mBufferedSink.flush();
        }

        private Sink sink(Sink sink) {
            return new ForwardingSink(sink) {
                //当前写入字节数
                long bytesWritten = 0L;
                //总字节长度，避免多次调用contentLength()方法
                long contentLength = 0L;

                @Override
                public void write(Buffer source, long byteCount) throws IOException {
                    super.write(source, byteCount);
                    if (contentLength() == 0) {
                        //获得contentLength的值，后续不再调用
                        contentLength = contentLength();
                    }
                    //增加当前写入的字节数
                    bytesWritten += byteCount;
                    sendProgressCallback(bytesWritten, contentLength(), bytesWritten == contentLength, mCallback);
                }
            };
        }
    }


    ////////////////////////////////////////Public方法(Okhttp网络请求)////////////////////////////////////////////////////

    /**
     * 同步请求
     *
     * @param url
     * @return Response
     * @throws IOException
     */
    public static Response getSync(String url) throws IOException {
        return getInstance()._getSync(url);
    }

    /**
     * 同步请求
     *
     * @param url
     * @return String
     * @throws IOException
     */
    public static String getAsStringSync(String url) throws IOException {
        return getInstance()._getAsStringSync(url);
    }

    /**
     * 带回调的同步请求（GET方式）
     *
     * @param url
     * @param callback
     */
    public static void get(String url, ResultCallback callback) {
        getInstance()._get(url, callback);
    }

    /**
     * 同步请求（POST方式）
     *
     * @param url
     * @param params
     * @return Response
     * @throws IOException
     */
    public static Response postSync(String url, Param... params) throws IOException {
        return getInstance()._postSync(url, params);
    }

    /**
     * 同步请求（POST方式）
     *
     * @param url
     * @param params
     * @return String
     * @throws IOException
     */
    public static String postAsStringSync(String url, Param... params) throws IOException {
        return getInstance()._postAsStringSync(url, params);
    }

    /**
     * 带回调的同步请求（POST方式）
     *
     * @param url
     * @param callback
     * @param params
     */
    public static void post(String url, ResultCallback callback, Param... params) {
        getInstance()._post(url, callback, params);
    }

    /**
     * 带回调的同步请求（POST方式）
     *
     * @param url
     * @param map
     * @param callback
     */
    public static void post(String url, Map<String, String> map, ResultCallback callback) {
        Param[] params = convertMap2Param(map);
        post(url, callback, params);
    }

    /**
     * 多文件上传，带参数
     *
     * @param url
     * @param files
     * @param fileKeys
     * @param params
     * @return
     * @throws IOException
     */
    public static Response uploadSync(String url, File[] files, String[] fileKeys, Param... params) throws IOException {
        return getInstance()._uploadSync(url, files, fileKeys, params);
    }

    /**
     * 单个文件上传，带参数
     *
     * @param url
     * @param file
     * @param fileKey
     * @param params
     * @return
     * @throws IOException
     */
    public static Response uploadSync(String url, File file, String fileKey, Param... params) throws IOException {
        return uploadSync(url, new File[]{file}, new String[]{fileKey}, params);
    }

    /**
     * 单个文件上传
     *
     * @param url
     * @param file
     * @param fileKey
     * @return
     * @throws IOException
     */
    public static Response uploadSync(String url, File file, String fileKey) throws IOException {
        return uploadSync(url, new File[]{file}, new String[]{fileKey});
    }

    /**
     * 多个文件上传，带参数
     *
     * @param url
     * @param map
     * @param files
     * @param fileKeys
     * @return
     * @throws IOException
     */
    public static Response uploadSync(String url, Map<String, String> map, File[] files, String[] fileKeys) throws IOException {
        Param[] params = convertMap2Param(map);
        return uploadSync(url, files, fileKeys, params);
    }

    /**
     * 单个文件上传，带参数
     *
     * @param url
     * @param map
     * @param file
     * @param fileKey
     * @return
     * @throws IOException
     */
    public static Response uploadSync(String url, Map<String, String> map, File file, String fileKey) throws IOException {
        return uploadSync(url, map, new File[]{file}, new String[]{fileKey});
    }

    /**
     * 多个文件上传，带参数，带回调
     *
     * @param url
     * @param files
     * @param fileKeys
     * @param callback
     * @param params
     */
    public static void upload(String url, File[] files, String[] fileKeys, ResultCallback callback, Param... params) {
        getInstance()._upload(url, callback, files, fileKeys, params);
    }

    /**
     * 单个文件上传，带参数，带回调
     *
     * @param url
     * @param file
     * @param fileKey
     * @param callback
     * @param params
     */
    public static void upload(String url, File file, String fileKey, ResultCallback callback, Param... params) {
        upload(url, new File[]{file}, new String[]{fileKey}, callback, params);
    }

    /**
     * 单个文件上传，带回调
     *
     * @param url
     * @param file
     * @param fileKey
     * @param callback
     */
    public static void upload(String url, File file, String fileKey, ResultCallback callback) {
        upload(url, file, fileKey, callback, new Param[]{});
    }

    /**
     * 多个文件上传，带参数，带回调
     *
     * @param url
     * @param map
     * @param files
     * @param fileKeys
     * @param callback
     */
    public static void upload(String url, Map<String, String> map, File[] files, String[] fileKeys, ResultCallback callback) {
        Param[] params = convertMap2Param(map);
        getInstance()._upload(url, callback, files, fileKeys, params);
    }

    /**
     * 单个文件上传，带参数，带回调
     *
     * @param url
     * @param map
     * @param file
     * @param fileKey
     * @param callback
     */
    public static void upload(String url, Map<String, String> map, File file, String fileKey, ResultCallback callback) {
        upload(url, map, new File[]{file}, new String[]{fileKey}, callback);
    }

    /**
     * 文件下载，带回调
     *
     * @param url
     * @param destFileDir 文件存放目录（不带文件名）
     * @param fileName    文件名
     * @param callback
     */
    public static void download(String url, String destFileDir, String fileName, ResultCallback callback) {
        getInstance()._download(url, destFileDir, fileName, callback);
    }

    /**
     * 文件下载，带回调
     *
     * @param url
     * @param destFileDir 文件存放目录（不带文件名）
     * @param callback
     */
    public static void download(String url, String destFileDir, ResultCallback callback) {
        download(url, destFileDir, "", callback);//文件名取url中的文件名
    }

    public static OkHttpClient getClient() {
        return getInstance()._getClient();
    }

    public static OkHttpClient getClient(int timeout){
        OkHttpClient client = getInstance()._getClient().clone();
        client.setConnectTimeout(timeout, TimeUnit.SECONDS);
        return client;
    }

}
