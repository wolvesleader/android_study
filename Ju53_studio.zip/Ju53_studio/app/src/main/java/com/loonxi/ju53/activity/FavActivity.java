package com.loonxi.ju53.activity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.FavCompanyAdapter;
import com.loonxi.ju53.adapter.FavProductAdapter;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.FavEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.presenters.FavPresenter;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.IFavView;
import com.loonxi.ju53.widgets.FavTabBar;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/2/17.
 */
public class FavActivity extends BaseActivity implements View.OnClickListener, FavTabBar.OnFavTabClickListener, IFavView {

    @ViewInject(R.id.fav_layout_left)
    private LinearLayout mLayoutLeft;
    @ViewInject(R.id.fav_tab)
    private FavTabBar mTabBar;
    @ViewInject(R.id.fav_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.actionbar_iv_right)
    private ImageView mIvRight;
    @ViewInject(R.id.fav_plv)
    private PullToRefreshListView mPlv;

    private SwipeMenuListView mSwipeListView;

    private boolean mIsProduct = true;

    private FavPresenter mPresenter;
    private FavProductAdapter mProductAdapter;
    private FavCompanyAdapter mCompanyAdapter;
    private List<BaseProductEntity> mFavProducts = new ArrayList<>();
    private List<SupplierEntity> mFavCompanies = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav);
        x.view().inject(this);
        initViews();
        initContent();
        setListener();
    }

    private void initViews() {
        mTabBar.changeTab(1);
    }

    private void initContent() {
        mPlv.setEmptyView(getEmptyView(R.string.empty_fav, AppConst.Empty.FAV));
        mPlv.setVisibility(View.GONE);
        mPresenter = new FavPresenter(this);
//        initSwipeListView();
        mPresenter.getFavList();
    }

    private void setListener() {
        mLayoutLeft.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
        mTabBar.setOnFavTabClickListener(this);
        mPlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                mPresenter.getFavList();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                mPresenter.getFavList();
            }
        });
    }

    private void initSwipeListView() {
        SwipeMenuCreator creator = new SwipeMenuCreator() {
            @Override
            public void create(SwipeMenu menu) {
                SwipeMenuItem openItem = new SwipeMenuItem(mContext);
                openItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));
                openItem.setWidth(DisplayUtil.dip2px(mContext, 90));
                openItem.setTitle(R.string.delete);
                openItem.setTitleSize(18);
                openItem.setTitleColor(Color.WHITE);
                menu.addMenuItem(openItem);
            }
        };
        mSwipeListView.setMenuCreator(creator);
        mSwipeListView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                if (mFavProducts != null && mProductAdapter != null) {
                    mFavProducts.remove(position);
                    mProductAdapter.notifyDataSetChanged();
                }
                //delete

                return false;
            }
        });
        mSwipeListView.setSwipeDirection(SwipeMenuListView.DIRECTION_LEFT);
        mSwipeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showToast("click");
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fav_layout_left:
                finish();
                break;
            case R.id.fav_layout_right:
                ActionBarRightPopupWindow.show(mContext, mIvRight);
                break;
            case R.id.fav_tab:

                break;
        }
    }

    @Override
    public void onTabClick(int position) {
        if (position == 1) {
            mIsProduct = true;
            mPresenter.getFavList();
        } else if (position == 2) {
            mIsProduct = false;
            mPresenter.getFavList();
        }
    }

    @Override
    public void onGetFavListSuccess(FavEntity favs) {
        if(mPlv.isRefreshing()){
            mPlv.onRefreshComplete();
        }
        mPlv.setVisibility(View.VISIBLE);
        if (favs != null) {
            if (mIsProduct) {
                mFavProducts.clear();
                if(!ListUtil.isEmpty(favs.getProList())){
                    mFavProducts.addAll(favs.getProList());
                }
                if (mProductAdapter == null) {
                    mProductAdapter = new FavProductAdapter(mContext, mFavProducts);
                }
                mPlv.setAdapter(mProductAdapter);
                mProductAdapter.notifyDataSetChanged();
            } else {
                mFavCompanies.clear();
                if(!ListUtil.isEmpty(favs.getSupList())) {
                    mFavCompanies.addAll(favs.getSupList());
                }
                if (mCompanyAdapter == null) {
                    mCompanyAdapter = new FavCompanyAdapter(mContext, mFavCompanies);
                }
                mPlv.setAdapter(mCompanyAdapter);
                mCompanyAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onGetFavListFailed(int apiErrorCode, String message) {
        if(mPlv.isRefreshing()){
            mPlv.onRefreshComplete();
        }
        mPlv.setVisibility(View.VISIBLE);
        checkError(apiErrorCode, message);
    }
}
