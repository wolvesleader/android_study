package com.loonxi.ju53.manager;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 可调度的线程池，采用命令模式，Runnable对象放到此线程池中执行
 * 
 * @author laojiaqi
 * 
 */
public class ThreadPoolManager {

	public static int corePoolSize = Runtime.getRuntime().availableProcessors()+1;
	public static ScheduledExecutorService executorService;
	public static AtomicInteger atomicInteger = new AtomicInteger(0);
	private static final int TIME_GAP=2500;

	/**
	 * 获得线程池
	 * 
	 * @return
	 */
	private static ScheduledExecutorService getThreadPool() {
		if (executorService == null) {
			executorService = ExecutorHolder.getExecutorService();
		}
		return executorService;
	}

	/**
	 * 创建线程工厂
	 * 
	 * @return
	 */
	private static ThreadFactory geThreadFactory() {
		ThreadFactory threadFactory = new ThreadFactory() {

			@Override
			public Thread newThread(Runnable r) {
				Thread thread = new Thread(r);
				thread.setName("num = " + atomicInteger);
				thread.setDaemon(true);
				return thread;
			}
		};
		return threadFactory;
	}

	/**
	 * 关闭线程池
	 */
	public static void shutdownThreadPool() {
		getThreadPool().shutdown();
	}

	/**
	 * @param runnable
	 */
	public static Future<?> executeTask(Runnable runnable) {
		if (runnable != null) {
			return 	getThreadPool().submit(runnable);
		}else {
			return null;
		}
	}

	/**
	 * @param runnable
	 */
	public static Future<?> executeTask(Runnable runnable,int timeGap) {
		if (runnable != null) {
			return 	getThreadPool().scheduleAtFixedRate(runnable, 0, timeGap, TimeUnit.MILLISECONDS);
		}else {
			return null;
		}
	}
	
	/**
	 * 延迟占位类，防止DCL问题
	 * 
	 * @author Sam
	 * 
	 */
	static class ExecutorHolder {
		private static ScheduledExecutorService holderExecutorService = Executors.newScheduledThreadPool(corePoolSize, geThreadFactory());

		public static ScheduledExecutorService getExecutorService() {
			return holderExecutorService;
		}

	}

}
