package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.presenters.OrderDetailPresenter;
import com.loonxi.ju53.widgets.FixedListView;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class OrderDetailAdapter extends BaseObjectListAdapter<CartEntity> {

    private OrderDetailPresenter mPresenter;
    private OrderEntity mOrderEntity;

    public OrderDetailAdapter(Context context, OrderEntity detail, List<CartEntity> datas, OrderDetailPresenter presenter) {
        super(context, datas);
        mPresenter = presenter;
        mOrderEntity = detail;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_order_detail_parent, null);
            holder.mLayoutCompany = (LinearLayout) convertView.findViewById(R.id.listitem_order_detail_parent_layout_company);
            holder.mTvCompanyName = (TextView) convertView.findViewById(R.id.listitem_order_detail_parent_tv_company);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_order_detail_parent_tv_status);
            holder.mFlv = (FixedListView) convertView.findViewById(R.id.listitem_order_detail_parent_flv);
            holder.mLayoutFreight = (LinearLayout) convertView.findViewById(R.id.listitem_order_detail_parent_layout_freight);
            holder.mTvFreight = (TextView) convertView.findViewById(R.id.listitem_order_detail_parent_tv_freight);
            holder.mTvNotes = (EditText) convertView.findViewById(R.id.listitem_order_detail_parent_edt_notes);
            holder.mTvTotal = (TextView) convertView.findViewById(R.id.listitem_order_detail_parent_tv_total);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        CartEntity cart = get(position);
        holder.mTvCompanyName.setText(cart.getUserName());
        Spanned total = Html.fromHtml("共" + cart.getTotalCount() + "件商品合计: <font color=\"#ee0c00\">¥" + cart.getTotalFee() + "</font> (含运费" + cart.getTotalFreight() + "元)");
        holder.mTvTotal.setText(total);
        holder.mTvStatus.setText("");
        holder.mTvNotes.setText(mOrderEntity == null ? "" : mOrderEntity.getNotes());
        OrderDetailChildAdapter childAdapter = new OrderDetailChildAdapter(mContext, mOrderEntity, cart.getList());
        holder.mFlv.setAdapter(childAdapter);
        setListener(holder, cart);
        return convertView;
    }

    private void setListener(ViewHolder holder, final CartEntity cart) {
        if(holder == null){
            return;
        }
        holder.mLayoutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", mOrderEntity.getSupplierId() + "");
                intent.putExtra("userName", cart.getUserName());
                mContext.startActivity(intent);
            }
        });
    }

    class ViewHolder {
        LinearLayout mLayoutCompany;
        TextView mTvCompanyName;
        TextView mTvStatus;
        FixedListView mFlv;
        LinearLayout mLayoutFreight;
        TextView mTvFreight;
        EditText mTvNotes;
        TextView mTvTotal;
    }
}
