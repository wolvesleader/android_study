package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.CashRecordAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.entity.CashRecordInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.presenters.CashRecordPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.ICashRecordView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 提现记录
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashRecordActivity extends ActionBarActivity implements View.OnClickListener, ICashRecordView {

    @ViewInject(R.id.cash_record_ptr)
    private PullToRefreshListView mPtr;

    private ListView mListView;

    private CashRecordAdapter mAdapter;
    private int mCurrentPage = 1;
    private CashRecordPresenter mPresenter;
    private CashRecordInfo mCashRecordInfo;
    private List<CashRecordEntity> mRecords = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cash_record);
    }

    @Override
    public void initView() {
        setTitle("提现记录");
        mListView = mPtr.getRefreshableView();
        mListView.setEmptyView(getEmptyView(R.string.empty_cash_record, AppConst.Empty.CASH_RECORD, false));
    }

    @Override
    public void initContent() {
        mPresenter = new CashRecordPresenter(this);
        mCurrentPage = 1;
        mAdapter = new CashRecordAdapter(mContext, mRecords);
        mListView.setAdapter(mAdapter);
        mPresenter.getCashRecord(mCurrentPage, true);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getCashRecord(mCurrentPage, false);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                mPresenter.getCashRecord(mCurrentPage, false);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
        }
    }

    @Override
    public void getCashRecordSuccess(JsonInfo<CashRecordInfo> records) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mPtr.setVisibility(View.VISIBLE);
        if (records != null) {
            mCashRecordInfo = records.getData();
        }
        if (mCashRecordInfo != null) {
            if (mCurrentPage == 1) {
                mRecords.clear();
            }
            if (!ListUtil.isEmpty(mCashRecordInfo.getList())) {
                mRecords.addAll(mCashRecordInfo.getList());
                mCurrentPage++;
            } else {
                if (mCurrentPage != 1) {
                    showToast(R.string.empty_list);
                }
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void getCashRecordFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
