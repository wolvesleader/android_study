package com.loonxi.ju53.listener;

/**
 * Created by Xuzue on 2016/1/8.
 */
public interface OnNetWorkListener {
    void OnDisconnected();
    void OnConnected();
    void OnRetry();
}
