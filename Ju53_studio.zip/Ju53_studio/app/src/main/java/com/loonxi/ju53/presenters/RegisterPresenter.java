package com.loonxi.ju53.presenters;

import com.loonxi.ju53.R;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.entity.RegistAuthEntity;
import com.loonxi.ju53.models.IRegistModel;
import com.loonxi.ju53.models.impl.RegisterModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.MD5;
import com.loonxi.ju53.utils.MapUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IRegistAuthView;
import com.loonxi.ju53.views.IRegistCodeView;
import com.loonxi.ju53.views.IRegistPhoneView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/1/5.
 */
public class RegisterPresenter {
    IRegistModel mModel;
    IRegistPhoneView mPhoneView;
    IRegistCodeView mCodeView;
    IRegistAuthView mAuthView;

    public RegisterPresenter(IRegistPhoneView mPhoneView) {
        this.mPhoneView = mPhoneView;
        mModel = new RegisterModel();
    }

    public RegisterPresenter(IRegistCodeView mCodeView, IRegistPhoneView mPhoneView) {
        this.mCodeView = mCodeView;
        this.mPhoneView = mPhoneView;
        mModel = new RegisterModel();
    }

    public RegisterPresenter(IRegistAuthView mAuthView) {
        this.mAuthView = mAuthView;
        mModel = new RegisterModel();
    }

    /**
     * 获取验证码
     *
     * @param phone
     */
    public void getCheckCode(String phone) {
        if (StringUtil.isEmpty(phone) || phone.length() != 11) {
            mPhoneView.showToast(R.string.register_phone_illegal);
            return;
        }
        if(mPhoneView != null){
            mPhoneView.startAsyncTask();
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("service", ApiConst.Code.REGIST_GET_CODE);
        map.put("mobile", phone);

        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));
        mModel.getCheckCode(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mPhoneView == null) {
                    return;
                }
                mPhoneView.endAsyncTask();
                mPhoneView.onGetCodeSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mPhoneView == null) {
                    return;
                }
                mPhoneView.endAsyncTask();
                mPhoneView.onGetCodeFailed(apiErrorCode, message);

            }
        });
    }

    /**
     * 校验验证码
     *
     * @param phone
     * @param code
     */
    public void verifyCode(String phone, String code) {
        if (StringUtil.isEmpty(phone) || StringUtil.isEmpty(code)) {
            mCodeView.showToast(R.string.register_code_null);
            return;
        }
        if(mCodeView != null){
            mCodeView.startAsyncTask();
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("service", ApiConst.Code.REGIST_VERIFY_CODE);
        map.put("mobile", phone);
        map.put("verifyCode", code);

        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));
        mModel.checkCodeIsCorrect(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mCodeView == null) {
                    return;
                }
                mCodeView.endAsyncTask();
                mCodeView.onVerifyCodeSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mCodeView == null) {
                    return;
                }
                mCodeView.endAsyncTask();
                mCodeView.onVerifyCodeFailed(apiErrorCode, message);

            }
        });
    }

    /**
     * 注册
     *
     * @param phone
     * @param name
     * @param password
     */
    public void auth(String phone, String name, String password) {
        if (StringUtil.isEmpty(phone)) {
            mAuthView.showToast(R.string.register_phone_null);
            return;
        }
        if (StringUtil.isEmpty(name) || name.trim().length() < 4 || name.trim().length() > 16) {
            mAuthView.showToast(R.string.register_username_illegal);
            return;
        }
        if (StringUtil.isEmpty(password) || password.trim().length() < 6 || password.trim().length() > 16) {
            mAuthView.showToast(R.string.register_password_illegal);
            return;
        }
        if (mAuthView != null) {
            mAuthView.startAsyncTask();
        }
        final Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("service", ApiConst.Code.REGIST_AUTH);
        map.put("mobile", phone);
        map.put("userName", name);
        map.put("password", StringUtil.toBase64String(password));
        map.put("isBeginner", "0");

        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign + ApiConst.KEY_REGISTER).getBytes()));

        mModel.auth(map, new Callback<RegistAuthEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, RegistAuthEntity data) {

            }

            @Override
            public void onSuccess(RegistAuthEntity data, Retrofit retrofit) {
                if (mAuthView == null) {
                    return;
                }
                mAuthView.endAsyncTask();
                mAuthView.onAuthSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mAuthView == null) {
                    return;
                }
                mAuthView.endAsyncTask();
                mAuthView.onAuthFailed(apiErrorCode, message);
            }
        });
    }
}
