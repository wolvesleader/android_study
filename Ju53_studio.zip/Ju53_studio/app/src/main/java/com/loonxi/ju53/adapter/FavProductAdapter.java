package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.constants.ProductState;
import com.loonxi.ju53.entity.BaseProductEntity;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/5.
 */
public class FavProductAdapter extends BaseObjectListAdapter<BaseProductEntity> {

    public FavProductAdapter(Context context, List<BaseProductEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_fav_product, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_fav_product_layout_root);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_fav_product_iv_head);
            holder.mTvName = (TextView) convertView.findViewById(R.id.listitem_fav_product_tv_name);
            holder.mTvState = (TextView) convertView.findViewById(R.id.listitem_fav_product_tv_status);
            holder.mTvSales = (TextView) convertView.findViewById(R.id.listitem_fav_product_tv_sales_nums);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_fav_product_tv_price);
            holder.mTvPriceAdvise = (TextView) convertView.findViewById(R.id.listitem_fav_product_tv_advise);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }

        final BaseProductEntity product = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + product.getPicture() + AppConst.PIC_SIZE_80).into(holder.mIvHead);
        holder.mTvName.setText(product.getProductName());
        holder.mTvSales.setText(mContext.getResources().getString(R.string.sales) +
                product.getSold() + mContext.getResources().getString(R.string.search_bi));
        holder.mTvPrice.setText("¥" + product.getPrice());
        holder.mTvPriceAdvise.setText(mContext.getResources().getString(R.string.search_advise) + ":¥" + product.getMarkPrice());
        ProductState.setProductState(holder.mTvState, product.getState());

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int state = product.getState();
//                if(state == ProductState.ON || state == ProductState.OFF) {
                    Intent intent = new Intent(mContext, ProductDetailActivity.class);
                    intent.putExtra("productId", product.getProductId());
                    mContext.startActivity(intent);
//                }
            }
        });

        return convertView;
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvHead;
        TextView mTvName;
        TextView mTvState;
        TextView mTvSales;
        TextView mTvPrice;
        TextView mTvPriceAdvise;
    }
}
