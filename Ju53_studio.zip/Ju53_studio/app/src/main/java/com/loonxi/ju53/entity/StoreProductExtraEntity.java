package com.loonxi.ju53.entity;

/**
 * 店铺产品附加信息（发货地、上下架状态）--分销商商品详情页用到
 * Created by XuZue on 2016/5/12 0012.
 */
public class StoreProductExtraEntity {
    private String product_id;
    private String state;
    private String show_region_name;
    private String share_url;//分享链接
    private String share_title;//分享标题
    private String share_content;//分享内容
    private int activity_type;//产品类型 0：普通产品 1：团购产品 2:打折产品
    private String activity_description;//活动描述
    private String activity_price;//活动价
    private long activity_countdown;//剩余时间（毫秒）


    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getShow_region_name() {
        return show_region_name;
    }

    public void setShow_region_name(String show_region_name) {
        this.show_region_name = show_region_name;
    }

    public String getShare_url() {
        return share_url;
    }

    public void setShare_url(String share_url) {
        this.share_url = share_url;
    }

    public String getShare_title() {
        return share_title;
    }

    public void setShare_title(String share_title) {
        this.share_title = share_title;
    }

    public String getShare_content() {
        return share_content;
    }

    public void setShare_content(String share_content) {
        this.share_content = share_content;
    }

    public int getActivityType() {
        return activity_type;
    }

    public void setActivityType(int type) {
        this.activity_type = type;
    }

    public String getActivity_description() {
        return activity_description;
    }

    public void setActivity_description(String activity_description) {
        this.activity_description = activity_description;
    }

    public String getActivity_price() {
        return activity_price;
    }

    public void setActivity_price(String activity_price) {
        this.activity_price = activity_price;
    }

    public long getActivity_countdown() {
        return activity_countdown;
    }

    public void setActivity_countdown(long activity_countdown) {
        this.activity_countdown = activity_countdown;
    }
}
