package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * Created by Xuzue on 2016/1/6.
 */
public interface ISearchView {
    void showToast(int resId);
    void onSearchSuccess(JsonArrayInfo<BaseProductEntity> jsonArrayInfo);
    void onSearchFailed(int apiErrorCode, String message);
}
