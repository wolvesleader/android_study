package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.models.IFinanceModel;
import com.loonxi.ju53.models.impl.FinanceModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IFinanceView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class FinancePresenter {
    private IFinanceModel mModel;
    private IFinanceView mView;

    public FinancePresenter(IFinanceView mView) {
        this.mView = mView;
        mModel = new FinanceModel();
    }

    /**
     * 获取资金信息
     */
    public void getFinanceInfo(boolean showDialog) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        if (showDialog && mView != null) {
            mView.startAsyncTask();
        }
        mModel.getFinanceInfo(map, new Callback<JsonInfo<FinanceEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<FinanceEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<FinanceEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.getFinanceInfoSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.getFinanceInfoFailed(apiErrorCode, message);
                }
            }
        });
    }
}
