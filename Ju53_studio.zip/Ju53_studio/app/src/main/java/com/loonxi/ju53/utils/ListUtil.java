package com.loonxi.ju53.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuze on 2015/9/1.
 */
public class ListUtil {

    public static final String DEFAULT_JOIN_SEPARATOR = ",";

    /**
     * 判断List是否为空
     *
     * @param sourceList
     * @param <V>
     * @return
     */
    public static <V> boolean isEmpty(List<V> sourceList) {
        return (sourceList == null || sourceList.size() == 0);
    }

    /**
     * 判断两个List是否相等
     *
     * @param actual
     * @param expected
     * @param <V>
     * @return
     */
    public static <V> boolean isEquals(ArrayList<V> actual, ArrayList<V> expected) {
        if (isEmpty(actual)) {
            return isEmpty(expected);
        }
        for (int i = 0; i < actual.size(); i++) {
            if (!ObjectUtil.isEquals(actual.get(i), expected.get(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 用默认的拼接符号将List拼接
     *
     * @param list
     * @return
     */
    public static String join(List<String> list) {
        return join(list, DEFAULT_JOIN_SEPARATOR);
    }

    /**
     * 自定义char拼接符号将List拼接
     *
     * @param list
     * @param separator
     * @return
     */
    public static String join(List<String> list, char separator) {
        return join(list, new String(new char[]{separator}));
    }

    /**
     * 自定义String拼接符号将List拼接
     *
     * @param list
     * @param separator
     * @return
     */
    public static String join(List<String> list, String separator) {
        if (isEmpty(list)) {
            return "";
        }
        if (separator == null) {
            separator = DEFAULT_JOIN_SEPARATOR;
        }
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i));
            if (i != list.size() - 1) {
                sb.append(separator);
            }
        }
        return sb.toString();
    }

    /**
     * 往List添加不同的实体
     *
     * @param list
     * @param entity
     * @param <V>
     * @return
     */
    public static <V> boolean addDistinctEntity(List<V> list, V entity) {
        return (list != null && !list.contains(entity) ? list.add(entity) : false);
    }

    /**
     * 往List添加不同的实体
     *
     * @param sourceList
     * @param entryList
     * @param <V>
     * @return 添加的对象数
     */
    public static <V> int addDistinctList(List<V> sourceList, List<V> entryList) {
        if (isEmpty(sourceList) || isEmpty(entryList)) {
            return 0;
        }
        int sourceCount = sourceList.size();
        for (V entry : entryList) {
            if (!sourceList.contains(entry)) {
                sourceList.add(entry);
            }
        }
        return sourceList.size() - sourceCount;
    }

    /**
     * 删除List中相同的实体
     *
     * @param sourceList
     * @param <V>
     * @return 删除个数
     */
    public static <V> int distinctList(List<V> sourceList) {
        if (isEmpty(sourceList)) {
            return 0;
        }
        int sourceCount = sourceList.size();
        int sourceListSize = sourceList.size();
        for (int i = 0; i < sourceListSize; i++) {
            for (int j = (i + 1); j < sourceListSize; j++) {
                if (ObjectUtil.isEquals(sourceList.get(j), sourceList.get(i))) {
                    sourceList.remove(j);
                    j--;
                }

            }
        }
        return sourceCount - sourceList.size();
    }

    /**
     * 往List中添加一个非空实体
     *
     * @param list
     * @param entity
     * @param <V>
     * @return
     */
    public static <V> boolean addListNotNullValue(List<V> list, V entity) {
        return (list != null && entity != null ? list.add(entity) : false);
    }

    /**
     * 获取List中某个实体的上一个实体
     *
     * @param list
     * @param value
     * @param <V>
     * @return
     */
    public static <V> V getLast(List<V> list, V value) {
        return (list == null ? null : (V) ArrayUtil.getLast(list.toArray(), value, true));
    }

    /**
     * 获取List中某个实体的下一个实体
     *
     * @param list
     * @param value
     * @param <V>
     * @return
     */
    public static <V> V getNext(List<V> list, V value) {
        return (list == null ? null : (V) ArrayUtil.getNext(list.toArray(), value, true));
    }

    /**
     * 将List倒置
     *
     * @param list
     * @param <V>
     * @return
     */
    public static <V> List<V> invertList(List<V> list) {
        if (isEmpty(list)) {
            return list;
        }
        List<V> invertList = new ArrayList<V>();
        for (int i = list.size(); i >= 0; i--) {
            invertList.add(list.get(i));
        }
        return invertList;
    }

}
