package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.PromotionEntity;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/23.
 */
public interface IPromotionView {
    void onGetPromotionSuccess(List<PromotionEntity> promotions);
    void onGetPromotionFailed(int apiErrorCode, String message);
}
