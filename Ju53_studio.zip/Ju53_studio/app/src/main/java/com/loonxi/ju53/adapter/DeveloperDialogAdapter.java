package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;

import java.util.List;

/**
 * Created by Xuzue on 2016/3/1.
 */
public class DeveloperDialogAdapter extends BaseObjectListAdapter<String> {

    public DeveloperDialogAdapter(Context context, List<String> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if(convertView == null){
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_developer_dialog, null);
            holder.mTvContent = (TextView) convertView.findViewById(R.id.listitem_developer_tv);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        holder.mTvContent.setText(get(position));
        return convertView;
    }

    class ViewHolder{
        TextView mTvContent;
    }
}
