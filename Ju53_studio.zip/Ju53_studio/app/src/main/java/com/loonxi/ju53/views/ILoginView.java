package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.UserEntity;

/**
 * Created by Xuzue on 2016/1/5.
 */
public interface ILoginView extends IBaseView{
    void showToast(int resId);
    void onLoginSuccess(UserEntity object);
    void onLoginFailed(int apiErrorCode, String message);
}
