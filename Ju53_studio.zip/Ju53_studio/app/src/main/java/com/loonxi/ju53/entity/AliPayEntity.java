package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 付款后的返回结果
 * Created by Xuzue on 2016/1/29.
 */
public class AliPayEntity implements Parcelable {
    private int flag;
    private String signData;

    public AliPayEntity(){

    }

    protected AliPayEntity(Parcel in) {
        flag = in.readInt();
        signData = in.readString();
    }

    public static final Creator<AliPayEntity> CREATOR = new Creator<AliPayEntity>() {
        @Override
        public AliPayEntity createFromParcel(Parcel in) {
            return new AliPayEntity(in);
        }

        @Override
        public AliPayEntity[] newArray(int size) {
            return new AliPayEntity[size];
        }
    };

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getSignData() {
        return signData;
    }

    public void setSignData(String signData) {
        this.signData = signData;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(flag);
        dest.writeString(signData);
    }
}
