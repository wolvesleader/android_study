package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.AgentAdapter;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.presenters.AgentPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.SoftInputUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IAgentView;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/2/19.
 */
public class AgentSearchActivity extends BaseActivity implements View.OnClickListener, IAgentView {

    @ViewInject(R.id.agent_search_layout_left)
    private LinearLayout mLayoutLeft;
    @ViewInject(R.id.agent_search_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.agent_search_layout_title)
    private LinearLayout mLayoutTitle;
    @ViewInject(R.id.agent_search_edt_title)
    private EditText mEdtKey;
    @ViewInject(R.id.agent_search_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.agent_search_flv)
    private FixedListView mFlv;

    private List<AgentProductEntity> mAgents = new ArrayList<>();
    private AgentPresenter mPresenter;
    private AgentAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_search);
        x.view().inject(this);
        initViews();
        initContent();
        setListener();
    }

    private void initViews() {


    }

    private void initContent() {
        mPresenter = new AgentPresenter(this);
        mAdapter = new AgentAdapter(mContext, mAgents);
        mFlv.setAdapter(mAdapter);
    }

    private void setListener() {
        mLayoutLeft.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                search();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                search();
            }
        });
        mEdtKey.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH){
                    search();
                    return true;
                }
                return false;
            }
        });
    }

    private void search() {
        String key = mEdtKey.getText().toString();
        if (StringUtil.isEmpty(key)) {
            showToast("请输入关键字");
            return;
        }
        SoftInputUtil.closeKeybord(mEdtKey, mContext);
        mPresenter.searchAgentProduct(key);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.agent_search_layout_left:
                SoftInputUtil.closeKeybord(mEdtKey, mContext);
                finish();
                break;
            case R.id.agent_search_layout_right:
                search();
                break;
        }
    }

    @Override
    public void onGetAgentProductSuccess(List<AgentProductEntity> jsonArrayInfo) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mAgents.clear();
        if (!ListUtil.isEmpty(jsonArrayInfo)) {
            mAgents.addAll(jsonArrayInfo);
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onGetAgentProductFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mAgents.clear();
        mAdapter.notifyDataSetChanged();
        checkError(apiErrorCode, message);
    }
}
