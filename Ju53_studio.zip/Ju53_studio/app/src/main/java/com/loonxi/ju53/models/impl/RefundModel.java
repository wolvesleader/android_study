package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.RefundEntity;
import com.loonxi.ju53.models.IRefundModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.OrderService;
import com.loonxi.ju53.modules.request.service.RefundService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/16.
 */
public class RefundModel implements IRefundModel {
    @Override
    public Call<JsonInfo<RefundEntity>> getRefundDetail(Map<String, Object> map, Callback<JsonInfo<RefundEntity>> callback) {
        Call<JsonInfo<RefundEntity>> call = Request.creatApi(RefundService.class).getRefundDetail(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> updateRefund(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(OrderService.class).updateRefunds(map);
        call.enqueue(callback);
        return call;
    }


}
