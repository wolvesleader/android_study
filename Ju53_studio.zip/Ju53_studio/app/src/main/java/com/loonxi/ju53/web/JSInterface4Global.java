package com.loonxi.ju53.web;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.JavascriptInterface;

import com.loonxi.ju53.activity.AccountSafeActivity;
import com.loonxi.ju53.activity.AddressActivity;
import com.loonxi.ju53.activity.AgentActivity;
import com.loonxi.ju53.activity.CartActivity;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.activity.FavActivity;
import com.loonxi.ju53.activity.FinanceActivity;
import com.loonxi.ju53.activity.LoginActivity;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.activity.MessageActivity;
import com.loonxi.ju53.activity.MyOrderActivity;
import com.loonxi.ju53.activity.OrderDetailActivity;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.activity.SaleOrderDetailActivity;
import com.loonxi.ju53.activity.SearchActivity;
import com.loonxi.ju53.activity.SearchHistoryActivity;
import com.loonxi.ju53.activity.StoreDetailActivity;
import com.loonxi.ju53.activity.StoreProductDetailActivity;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.service.StoreService;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.ArrayUtil;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;

import java.util.Map;

import retrofit.Call;
import retrofit.Retrofit;

/**
 * js与Android互调接口（全局）
 */
public class JSInterface4Global {
    private Context mContext;
    private BaseWebView mBaseWebview;

    public JSInterface4Global(Context context, BaseWebView baseWebView) {
        this.mContext = context;
        this.mBaseWebview = baseWebView;
    }


    ///////////////////////////////////交互接口//////////////////////////////////

    /**
     * 打开webview
     *
     * @param url
     */
    @JavascriptInterface
    public void openWebView(String url) {
        openWebView(url, null);
    }

    /**
     * 打开webview
     *
     * @param url
     * @param title
     */
    @JavascriptInterface
    public void openWebView(String url, String title) {
        if (TextUtils.isEmpty(url)) {
            ToastUtil.showToast(mContext, "请输入URL地址！");
            return;
        }
        Intent webIntent = new Intent(mContext, CommonWebviewActivity.class);
        webIntent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, url);
        webIntent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, StringUtil.isEmpty(title) ? "" : title);
        mContext.startActivity(webIntent);
    }

    /**
     * 设置WebView能否刷新
     *
     * @param enable
     */
    public void setWebViewRefresh(int enable) {
        if (mBaseWebview == null) {
            return;
        }
        if (enable == 1) {
            mBaseWebview.setRefreshEnable(true);
        } else if (enable == 0) {
            mBaseWebview.setRefreshEnable(false);
        }
    }

    /**
     * 打开“市场”
     */
    @JavascriptInterface
    public void openMainMarket() {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_POPWINDOW);
        mContext.startActivity(intent);
    }

    /**
     * 打开“小店”
     */
    @JavascriptInterface
    public void openMainStore() {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_STORE);
        mContext.startActivity(intent);
    }

    /**
     * 打开“分类”
     */
    @JavascriptInterface
    public void openMainSort() {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_SORT);
        mContext.startActivity(intent);
    }

    /**
     * 打开“分类”
     *
     * @param sortId 类目id
     */
    @JavascriptInterface
    public void openMainSort(String sortId) {
        if (StringUtil.isEmpty(sortId)) {
            return;
        }
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_SORT);
        intent.putExtra(MainActivity.FIRST_SHOW_SORT, sortId);
        mContext.startActivity(intent);
    }

    /**
     * 打开“我的”
     */
    @JavascriptInterface
    public void openMainMine() {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_MINE);
        mContext.startActivity(intent);
    }

    /**
     * 打开“消息”页面
     */
    public void openMessageActivity() {
        IntentUtil.intentCommonActivity(mContext, MessageActivity.class);
    }

    /**
     * 打开“搜索”页面
     */
    @JavascriptInterface
    public void openSearchHistoryActivity() {
        IntentUtil.intentCommonActivity(mContext, SearchHistoryActivity.class);
    }

    /**
     * 打开“搜索列表”页面（关键字搜索）
     *
     * @param key 关键字
     */
    @JavascriptInterface
    public void openSearchList(String key) {
        if (StringUtil.isEmpty(key)) {
            return;
        }
        Intent intent = new Intent(mContext, SearchActivity.class);
        intent.putExtra("key", key);
        mContext.startActivity(intent);
    }

    /**
     * 打开“搜索列表”页面（分类搜索）
     *
     * @param categoryId 类目id
     */
    @JavascriptInterface
    public void openSortSearchList(String categoryId) {
        if (StringUtil.isEmpty(categoryId)) {
            return;
        }
        Intent intent = new Intent(mContext, SearchActivity.class);
        intent.putExtra("categoryId", categoryId);
        intent.putExtra("isSort", true);
        mContext.startActivity(intent);
    }

    /**
     * 打开“资金管理”页面
     */
    @JavascriptInterface
    public void openFinance() {
        IntentUtil.intentCommonActivity(mContext, FinanceActivity.class);
    }

    /**
     * 打开“代理商品”页面
     */
    @JavascriptInterface
    public void openAgent() {
        IntentUtil.intentCommonActivity(mContext, AgentActivity.class);
    }

    /**
     * 打开“收藏夹”页面
     */
    @JavascriptInterface
    public void openFav() {
        IntentUtil.intentCommonActivity(mContext, FavActivity.class);
    }

    /**
     * 打开“购物车”页面
     */
    @JavascriptInterface
    public void openCart() {
        IntentUtil.intentCommonActivity(mContext, CartActivity.class);
    }

    /**
     * 打开“账户与安全”页面
     */
    @JavascriptInterface
    public void openAccountAndSafe() {
        Intent intent = new Intent(mContext, AccountSafeActivity.class);
        intent.putExtra(AccountSafeActivity.FROM_TYPE, AccountSafeActivity.FROM_MINE_FRAGMENT);
        mContext.startActivity(intent);
    }

    /**
     * 打开“收货地址管理”页面
     */
    @JavascriptInterface
    public void openAddressManage() {
        IntentUtil.intentCommonActivity(mContext, AddressActivity.class);
    }

    /**
     * 打开“供应商展厅”页面
     */
    @JavascriptInterface
    public void openSupplier(String supplierId) {
        if (StringUtil.isEmpty(supplierId)) {
            return;
        }
        Intent intent = new Intent(mContext, SupplierActivity.class);
        intent.putExtra("userId", supplierId);
        mContext.startActivity(intent);
    }

    /**
     * 打开“店铺详情”页面
     */
    @JavascriptInterface
    public void openStoreDetail() {
        IntentUtil.intentCommonActivity(mContext, StoreDetailActivity.class);
    }

    /**
     * 打开“分销订单列表”页面
     *
     * @param index 0-全部 1-待付款 2-待发货 3-待收货 4-退款中
     */
    @JavascriptInterface
    public void openSaleOrderList(int index) {
        if (index < 0) {
            return;
        }
        Intent intent = new Intent(mContext, MyOrderActivity.class);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_FRAGMENT_FLAG, index);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_ORDER_BUY, false);
        mContext.startActivity(intent);
    }

    /**
     * 获取用户ID
     *
     * @return
     */
    @JavascriptInterface
    public String getUserId() {
        return SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID);
    }

    /**
     * 打开“进货订单列表”页面
     *
     * @param index 0-全部 1-待付款 2-待发货 3-待收货 4-待评价 5-退款
     */
    @JavascriptInterface
    public void openBuyOrderList(int index) {
        if (index < 0) {
            return;
        }
        Intent intent = new Intent(mContext, MyOrderActivity.class);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_FRAGMENT_FLAG, index);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_ORDER_BUY, true);
        mContext.startActivity(intent);
    }

    /**
     * 打开“进货订单详情”页面
     *
     * @param orderId 订单id
     */
    @JavascriptInterface
    public void openBuyOrderDetail(String orderId) {
        if (StringUtil.isEmpty(orderId)) {
            return;
        }
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setOrderId(orderId);
        Intent intent = new Intent(mContext, OrderDetailActivity.class);
        intent.putExtra("order", orderEntity);
        mContext.startActivity(intent);
    }

    /**
     * 打开“分销订单详情”页面
     *
     * @param orderId 订单id
     */
    @JavascriptInterface
    public void openSaleOrderDetail(String orderId) {
        if (StringUtil.isEmpty(orderId)) {
            return;
        }
        Intent intent = new Intent(mContext, SaleOrderDetailActivity.class);
        intent.putExtra("orderId", orderId);
        mContext.startActivity(intent);
    }


    /**
     * 打开“供应商产品详情”页面
     *
     * @param productId 产品id
     */
    @JavascriptInterface
    public void openProductDetail(String productId) {
        if (StringUtil.isEmpty(productId)) {
            return;
        }
        Intent intent = new Intent(mContext, ProductDetailActivity.class);
        intent.putExtra("productId", productId);
        mContext.startActivity(intent);
    }

    /**
     * 打开“分销商产品详情”页面
     *
     * @param productId 产品id
     */
    @JavascriptInterface
    public void openStoreProductDetail(String productId) {
        if (StringUtil.isEmpty(productId)) {
            return;
        }
        Intent intent = new Intent(mContext, StoreProductDetailActivity.class);
        intent.putExtra("productId", productId);
        mContext.startActivity(intent);
    }

    /**
     * H5去分销
     *
     * @param data
     */
    @JavascriptInterface
    public void toCommitStoreProduct(String data) {
        LogUtil.mLog.i("data:" + data);
        if (StringUtil.isEmpty(data)) {
            return;
        }
        uploadH5StoreProduct(data);
    }


    ///////////////////////////////////非交互接口//////////////////////////////////

    /**
     * 上架H5产品
     *
     * @param data
     */
    private void uploadH5StoreProduct(String data) {
        if (StringUtil.isEmpty(data)) {
            return;
        }
        String[] infos = data.split(",");
        if (ArrayUtil.isEmpty(infos) || infos.length < 5) {
            return;
        }
        final String productId = infos[0];
        String gys_id = infos[1];
        String gys_name = infos[2];
        String shop_name = infos[3];
        String product_pic = infos[4];
        String userId = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, "");
        Log.e("登录状态", "userId" + userId + "已经保存 获取测试" + SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, ""));
        if (StringUtil.isEmpty(userId)) {
            Intent intent = new Intent(mContext, LoginActivity.class);
            mContext.startActivity(intent);
            return;
        }

        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productId);
        map.put("supplier_id", gys_id);
        map.put("supplier_name", gys_name);
        map.put("product_name", shop_name);
        map.put("product_pic", product_pic);
        map.put("userId", userId);

        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).onSaleH5StoreProduct(map);
        call.enqueue(new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                Intent intent = new Intent(mContext, StoreProductDetailActivity.class);
                intent.putExtra("productId", productId);

                mContext.startActivity(intent);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                ToastUtil.showToast(mContext, "上架失败，请重试");
            }
        });

    }

}
