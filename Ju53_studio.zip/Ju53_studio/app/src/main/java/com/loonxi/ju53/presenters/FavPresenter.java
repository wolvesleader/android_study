package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.FavEntity;
import com.loonxi.ju53.models.impl.FavModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IFavView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/18.
 */
public class FavPresenter {
    private IFavView mView;
    private FavModel mModel;

    public FavPresenter(IFavView mView) {
        this.mView = mView;
        mModel = new FavModel();
    }

    /**
     * 获取收藏列表
     */
    public void getFavList(){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getFavList(map, new Callback<JsonInfo<FavEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<FavEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<FavEntity> data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onGetFavListSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.onGetFavListFailed(apiErrorCode, message);
            }
        });
    }
}
