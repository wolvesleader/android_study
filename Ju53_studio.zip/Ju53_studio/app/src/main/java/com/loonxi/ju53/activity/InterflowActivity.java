package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.presenters.InterflowPresenter;
import com.loonxi.ju53.views.IInterflowView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by Xuzue on 2016/1/15.
 */
public class InterflowActivity extends ActionBarActivity implements View.OnClickListener, IInterflowView {

    @ViewInject(R.id.interflow_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.interflow_iv_head)
    private ImageView mIvHead;
    @ViewInject(R.id.interflow_tv_status)
    private TextView mTvStatus;
    @ViewInject(R.id.interflow_tv_company)
    private TextView mTvCompany;
    @ViewInject(R.id.interflow_tv_orderno)
    private TextView mTvOrderNo;
    @ViewInject(R.id.interflow_lv)
    private ListView mLv;

    private InterflowPresenter mPresenter;
    private String mComCode = "yuantong";
    private String mInterflowOrderno = "880998177603639930";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interflow);
    }

    @Override
    public void initView() {
        setTitle(R.string.interflow_title);
    }

    @Override
    public void initContent() {
        mPresenter = new InterflowPresenter(this);
//        mComCode = getIntent().getStringExtra("com");
//        mInterflowOrderno = getIntent().getStringExtra("nu");
        mPresenter.getInterflowDetail(mComCode, mInterflowOrderno);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:

                break;
        }
    }

    @Override
    public void onGetInterflowDetailSuccess(Object object) {
        showToast("success");
    }

    @Override
    public void onGetInterflowDetailFailed(int apiErrorCode, String message) {

    }
}
