package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreDetailEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
public interface IStoreModel {

    Call<JsonInfo<StoreDataEntity>> getStoreProducts(Map<String, Object> map, Callback<JsonInfo<StoreDataEntity>> callback);

    Call<BaseJsonInfo> offSaleProduct(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> onSaleProduct(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> deleteProduct(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> moveToTop(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<JsonInfo<StoreDataEntity>> getStoreDetail(Map<String, Object> map, Callback<JsonInfo<StoreDataEntity>> callback);

    Call<JsonInfo<StoreBaseInfoEntity>> getStoreBaseInfo(Map<String, Object> map, Callback<JsonInfo<StoreBaseInfoEntity>> callback);

    Call<BaseJsonInfo> altStoreName(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> altStoreLOGO(Map<String, Object> map, Callback<BaseJsonInfo> callback);

}
