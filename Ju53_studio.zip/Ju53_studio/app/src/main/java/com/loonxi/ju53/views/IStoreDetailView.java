package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreDetailEntity;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public interface IStoreDetailView extends IBaseView{
    void onGetStoreDetailSuccess(StoreDataEntity store);
    void onGetStoreDetailFailed(int apiErrorCode, String message);
    void getBaseInfoSuccess(StoreBaseInfoEntity base);
    void getBaseInfoFailed(int apiErrorCode, String message);
}
