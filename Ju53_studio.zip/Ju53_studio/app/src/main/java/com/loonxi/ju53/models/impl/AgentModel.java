package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.service.AgentService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/19.
 */
public class AgentModel {

    /**
     * 获取已代理商品
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonArrayInfo<AgentProductEntity>> getAgentProduct(Map<String, Object> map, Callback<JsonArrayInfo<AgentProductEntity>> callback){
        Call<JsonArrayInfo<AgentProductEntity>> call = Request.creatApi(AgentService.class).getAgentProduct(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 搜索已代理商品
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonArrayInfo<AgentProductEntity>> searchAgentProduct(Map<String, Object> map, Callback<JsonArrayInfo<AgentProductEntity>> callback){
        Call<JsonArrayInfo<AgentProductEntity>> call = Request.creatApi(AgentService.class).searchAgentProduct(map);
        call.enqueue(callback);
        return call;
    }
}
