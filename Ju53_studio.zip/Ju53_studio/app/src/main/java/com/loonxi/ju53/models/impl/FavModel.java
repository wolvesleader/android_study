package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.FavEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.FavouriteService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/17.
 */
public class FavModel {

    /**
     * 收藏/取消收藏
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> fav(Map<String, Object> map, Callback<BaseJsonInfo> callback){
        Call<BaseJsonInfo> call = Request.creatApi(FavouriteService.class).fav(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 收藏列表
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonInfo<FavEntity>> getFavList(Map<String, Object> map, Callback<JsonInfo<FavEntity>> callback){
        Call<JsonInfo<FavEntity>> call = Request.creatApi(FavouriteService.class).getFavList(map);
        call.enqueue(callback);
        return call;
    }
}
