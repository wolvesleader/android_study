package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.models.impl.AddressModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IAddressView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Administrator on 2016/1/25.
 */
public class DisplayAddressPresenter extends BasePresenter<IAddressView> {

    private AddressModel mModel;
    private IAddressView mView;

    public DisplayAddressPresenter(IAddressView view) {
        super(view);
        mView = getView();
        mModel = new AddressModel();
    }

    /**
     * 获得地址
     */
    public void getAddressData() {

        mModel.getAddress(PrefsRepos.getDefaultMap(), new Callback<JsonArrayInfo<AddressEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<AddressEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<AddressEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.getAddressSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {

            }
        });
    }

    /**
     * 删除地址
     *
     * @param addressEntity
     */
    public void deleteAddressData(AddressEntity addressEntity) {
        if (addressEntity == null) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", addressEntity.getPid());
        mModel.deleteAddress(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(data != null){
                    ToastUtil.showToast(data.getMessage(), false);
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                ToastUtil.showToast(message, false);
            }
        });
    }


}
