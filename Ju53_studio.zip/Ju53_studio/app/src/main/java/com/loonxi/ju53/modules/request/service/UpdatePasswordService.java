package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.VerifyCodeEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 更新密码 service
 * Created by laojiaqi on 2016/2/17.
 */
public interface UpdatePasswordService {

    /**
     * 记得登录密码，更新登录密码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateNewPassword")
    Call<BaseJsonInfo> updateLoginPassword(@FieldMap Map<String, Object> map);

    /**
     * 记得支付密码，更新支付密码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateNewCashPassword")
    Call<BaseJsonInfo> updatePayPassword(@FieldMap Map<String, Object> map);


    /**
     * 忘记登录密码，获得验证码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/getForgetPassword")
    Call<VerifyCodeEntity> getLoginPasswordVerifyCode(@FieldMap Map<String, Object> map);

    /**
     * 校验_忘记登录密码_验证码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/checkVerifyCode")
    Call<BaseJsonInfo> checkLoginPasswordVerifyCode(@FieldMap Map<String, Object> map);

    /**
     * 重置_忘记登录密码_密码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/updatePassword")
    Call<BaseJsonInfo> resetLoginPassword(@FieldMap Map<String, Object> map);


    /**
     * 重置_忘记支付密码_密码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateCashPassword")
    Call<BaseJsonInfo> resetPayPassword(@FieldMap Map<String, Object> map);

    /**
     * 验证登录密码
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/checkLoginPassword")
    Call<BaseJsonInfo> checkLoginPassword(@FieldMap Map<String, Object> map);

    /**
     * 退出登录状态
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/loginOut")
    Call<BaseJsonInfo> logout(@FieldMap Map<String, Object> map);


}
