package com.loonxi.ju53.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.loonxi.ju53.base.BaseFragment;

import java.util.List;

/**
 * "监听网络变化"receiver
 * Created by laojiaqi on 2016/3/7.
 */
public class ConnectionChangeReceiver extends BroadcastReceiver {
    private static boolean isFirstIntoApp = true;
    List<BaseFragment> mList;

    public ConnectionChangeReceiver(List<BaseFragment> list) {
        this.mList = list;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (isFirstIntoApp) {
            isFirstIntoApp = false;
            return;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            notifyChange();
        }
    }

    /**
     * 网络发生变化
     */
    private void notifyChange() {
        if (mList != null) {
            for (BaseFragment baseFragment : mList) {
                baseFragment.onNetWorkConnected();
            }
        }
    }
}
