package com.loonxi.ju53.constants;

import android.content.Context;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;

/**
 * 订单状态
 * Created by Xuzue on 2016/1/25.
 */
public class OrderState {
    public static final int ERROR = -8;//出错(供程序使用，数据库中不会有这个值)
    public static final int CANCEL = -1;//交易关闭
    public static final int WAIT_PAY = 0;//待付款
    public static final int PAYED = 1;//已付款/待发货
    public static final int WAIT_RECEIVE = 6;//待收货/卖家已发货
    public static final int CONFIRM_RECEIVED = 7;//已确认收货
    public static final int RECOMMENDS_BUYER = 10;//买方已评
    public static final int RECOMMENDS_SALER = 11;//卖方已评
    public static final int RECOMMENDS_BOTH = 12;//双方已评

    public static void setOrderState(TextView tv, int state){
        Context context = BaseApplication.instance;
        if(tv == null){
            return;
        }
        switch (state){
            case CANCEL:
                tv.setText(context.getResources().getString(R.string.order_state_cancel));
                break;
            case WAIT_PAY:
                tv.setText(context.getResources().getString(R.string.order_state_wait_pay));
                break;
            case PAYED:
                tv.setText(context.getResources().getString(R.string.order_state_payed));
                break;
            case WAIT_RECEIVE:
                tv.setText(context.getResources().getString(R.string.order_state_wait_receive));
                break;
            case CONFIRM_RECEIVED:
                tv.setText(context.getResources().getString(R.string.order_state_confirm_received));
                break;
            case RECOMMENDS_BUYER:
                tv.setText(context.getResources().getString(R.string.order_state_recommend_buyer));
                break;
            case RECOMMENDS_SALER:
                tv.setText(context.getResources().getString(R.string.order_state_recommend_saler));
                break;
            case RECOMMENDS_BOTH:
                tv.setText(context.getResources().getString(R.string.order_state_recommend_both));
                break;
        }
    }
}
