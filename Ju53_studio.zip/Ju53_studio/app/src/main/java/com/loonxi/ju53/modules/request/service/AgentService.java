package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/2/19.
 */
public interface AgentService {
    /**
     * 获得已代理商品
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/distributor")
    Call<JsonArrayInfo<AgentProductEntity>> getAgentProduct(@FieldMap Map<String, Object> map);

    /**
     * 搜索已代理商品
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/distributorSearch")
    Call<JsonArrayInfo<AgentProductEntity>> searchAgentProduct(@FieldMap Map<String, Object> map);
}
