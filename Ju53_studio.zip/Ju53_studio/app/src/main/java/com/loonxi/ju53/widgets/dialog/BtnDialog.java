package com.loonxi.ju53.widgets.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.utils.StringUtil;


/**
 * Created by butterfly on 2015/8/28.
 */
public class BtnDialog extends BaseDialog {

    public static String DEFALUT_TITLE= BaseApplication.getInstance().getResources().getString(R.string.dialog_defalut_title);
    public static String DEFALUT_OK= BaseApplication.getInstance().getResources().getString(R.string.dialog_defalut_ok);
    public static String DEFALUT_CANCEL= BaseApplication.getInstance().getResources().getString(R.string.dialog_defalut_cancle);

    private TextView mTvContent;
    private Button mBtnOk;
    private Button mBtnCancle;


    public BtnDialog(Context context, String title, String content, String ok, String cancle, View.OnClickListener okListener, View.OnClickListener cancleListner) {
        super(context);
        View v = LayoutInflater.from(context).inflate(R.layout.dialog_btn, null);
        addView(v);
        setTitle(StringUtil.isEmpty(title) ? context.getResources().getString(R.string.tip) : title);
        mTvContent = (TextView) findViewById(R.id.dialog_tv_content);
        mBtnOk = (Button) findViewById(R.id.dialog_btn_ok);
        mBtnCancle = (Button) findViewById(R.id.dialog_btn_cancle);
        mTvContent.setText(StringUtil.isEmpty(content) ? "" : content);
        mBtnOk.setText(StringUtil.isEmpty(ok) ? context.getResources().getString(R.string.confirm) : ok);
        mBtnCancle.setText(StringUtil.isEmpty(ok) ? context.getResources().getString(R.string.cancel) : cancle);
        mBtnOk.setOnClickListener(okListener);
        mBtnCancle.setOnClickListener(cancleListner);
    }

    public void setCancelBtnVisiable(){
        mBtnCancle.setVisibility(View.GONE);
    }

}
