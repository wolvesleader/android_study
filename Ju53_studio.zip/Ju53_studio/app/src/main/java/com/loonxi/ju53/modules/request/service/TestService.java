package com.loonxi.ju53.modules.request.service;

import com.squareup.okhttp.Response;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by XuZue on 2016/5/4 0004.
 */
public interface TestService {

    @FormUrlEncoded
    @POST("test/testMemc")
    Call<Object> testPhp(@FieldMap Map<String, Object> map);

    @FormUrlEncoded
    @POST("user/userInfo")
    Call<Object> testUser(@FieldMap Map<String, Object> map);
}
