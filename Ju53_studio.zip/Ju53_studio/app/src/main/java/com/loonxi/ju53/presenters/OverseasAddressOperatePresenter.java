package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.models.impl.OperateAddressModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IOverseasAddressInfoView;
import com.loonxi.ju53.views.IUpdateAddressView;

import java.util.HashMap;
import java.util.Map;

import retrofit.Retrofit;

/**
 * 修改，新建 （国外）收货地址 presenter
 * Created by laojiaqi on 2016/1/27.
 */
public class OverseasAddressOperatePresenter extends BasePresenter<IOverseasAddressInfoView> {

    private OperateAddressModel mModel;
    private IOverseasAddressInfoView mView;

    public OverseasAddressOperatePresenter(IOverseasAddressInfoView view) {
        super(view);
        mView = getView();
        mModel = new OperateAddressModel();
    }

    /**
     * 获得国外 国家信息
     */
    public void getOverseasAddressInfo() {
        mModel.getOverseasAddressInfoEntity(new Callback<JsonInfo<Object>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<Object> data) {

            }

            @Override
            public void onSuccess(JsonInfo<Object> data, Retrofit retrofit) {
                if (mView != null) {
                    Map<String, String> map = new HashMap<String, String>();
                    if (data != null) {
                        map = (Map<String, String>) data.getData();
                    }
                    mView.getAddressInfoSuccess(map);
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                ToastUtil.showToast(message, false);
            }
        });
    }


    /**
     * 保存收货地址
     */
    public void saveAddress(AddressEntity addressEntity) {
        //TODO
        Map<String, Object> map = PrefsRepos.getObjectMap();
        map.put("contact", addressEntity.getContact());
        map.put("phone", addressEntity.getPhones());
        map.put("regionId", addressEntity.getRegionId());
        map.put("isDefault", addressEntity.getIsDefault());
        map.put("streetAddress", addressEntity.getStreetAddress());
        map.put("city", addressEntity.getCity());
        map.put("unit", addressEntity.getUnit());
        map.put("zip", addressEntity.getZip());
        map.put("provinceArea", addressEntity.getProvinceArea());
        map.put("address", addressEntity.getAddress());

        mModel.saveOverseaAddress(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressFailure(message);
            }
        });
    }

    /**
     * 修改
     *
     * @param addressEntity
     */
    public void updateAddress(AddressEntity addressEntity) {
        Map<String, Object> map = PrefsRepos.getObjectMap();
        map.put("contact", addressEntity.getContact());
        map.put("phone", addressEntity.getPhones());
        map.put("regionId", addressEntity.getRegionId());
        map.put("isDefault", addressEntity.getIsDefault());
        map.put("streetAddress", addressEntity.getStreetAddress());
        map.put("city", addressEntity.getCity());
        map.put("unit", addressEntity.getUnit());
        map.put("zip", addressEntity.getZip());
        map.put("provinceArea", addressEntity.getProvinceArea());
        map.put("pid", addressEntity.getPid());
        map.put("address", addressEntity.getAddress());

        mModel.updateOverseasAddress(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressFailure(message);
            }
        });

    }

}
