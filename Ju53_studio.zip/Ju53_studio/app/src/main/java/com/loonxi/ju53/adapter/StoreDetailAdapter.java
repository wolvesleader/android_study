package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.StoreProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.utils.SpUtil;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/19.
 */
public class StoreDetailAdapter extends BaseObjectListAdapter<StoreProductEntity> {


    public StoreDetailAdapter(Context context, List<StoreProductEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.griditem_store_product, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.griditem_store_product_layout_root);
            holder.mIvPic = (ImageView) convertView.findViewById(R.id.griditem_store_product_img);
            holder.mTvName = (TextView) convertView.findViewById(R.id.griditem_store_product_tv_name);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.griditem_store_product_tv_price);
            holder.mTvSales = (TextView) convertView.findViewById(R.id.griditem_store_product_tv_sales);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.mIvPic.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int width = holder.mLayoutRoot.getWidth();
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, width);
                holder.mIvPic.setLayoutParams(params);
                holder.mIvPic.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });

        final StoreProductEntity entity = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + entity.getPicture() + AppConst.PIC_SIZE_80).into(holder.mIvPic);
        holder.mTvName.setText(entity.getProductName());
        holder.mTvPrice.setText("¥" + entity.getPrice());
        holder.mTvSales.setText("库存" + entity.getStock() + "件");

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, StoreProductDetailActivity.class);
                intent.putExtra("productId", entity.getProductId());
                intent.putExtra("isOnSale", "1".equals(entity.getState()) ? true : false);
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    static class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvPic;
        TextView mTvName;
        TextView mTvPrice;
        TextView mTvSales;
    }
}
