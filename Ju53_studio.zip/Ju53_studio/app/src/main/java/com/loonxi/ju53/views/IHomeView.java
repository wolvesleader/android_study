package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.entity.IndexJsonInfo;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/18.
 */
public interface IHomeView {
    void onGetIndextContentSuccess(IndexJsonInfo jsonInfo);
    void onGetIndexContentFailed(int apiErrorCode, String message);
    void onGetRecommendsSuccess(List<IndexEntity> products);
    void onGetRecommendsFailed(int apiErrorCode, String message);
    void onGetVersionSuccess(GetVersionEntity getVersionEntity);
    void onGetVersionFailed(String message);
}
