package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartCheckEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.List;
import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/30.
 */
public interface IShoppingModel {

    void _initData(List<CartEntity> carts);

    void _initData(List<CartEntity> carts, boolean changeEdit);

    void _putEditMap(String companyId, boolean isEdit);

    void _putCheckCompanyMap(String companyId, boolean isChecked);

    void _putCheckProductMap(String productId, boolean isChecked);

    void _putCheckProductNumsMap(String companyId, String stockId, boolean isChecked);

    void _putCheckProductList(CartEntity cart, BaseProductEntity product, boolean isAdd);

    Map<String, Boolean> _getEditCompanyMap();

    Map<String, Boolean> _getCheckCompanyMap();

    Map<String, Boolean> _getCheckProductMap();

    Map<String, Integer> _getCheckProductNumsMap();

    List<CartCheckEntity> _getCheckProductList();

    int _getProductTotalNums();

    boolean _isCheckAllProduct4Company(CartEntity cart, boolean isCheckProduct);

    void _setCarts(List<CartEntity> carts);

    List<CartEntity> _getCarts();

    double _getCheckPrice();

    String _getCheckStockId();

    boolean _productIsExist(CartEntity cart, String stockId);

    String _getCheckFreightIds();



    void _updateDataAfterCheckAll(boolean isCheckAll);

    void _updateDataAfterEditAll(boolean isEditAll);

    void _updateDataAfterEditCompany(CartEntity cart, boolean isEdit);

    void _updateDataAfterCheckProduct(CartEntity cart, BaseProductEntity product, boolean isChecked);

    void _updateDataAfterCheckCompany(CartEntity cart, boolean isChecked);

    void _updateDataAfterDeleteOneProduct(CartEntity cart, BaseProductEntity product);

    void _updateDataAfterDeleteMultiProduct(List<CartCheckEntity> carts);

    void _updateDataAfterAltCartNums(int parentIndex, int productIndex, int nums);

    void _updateDataAfterAltCartAttribute(String companyId, BaseProductEntity product, String color, String size, boolean checkProduct);


    Call<JsonArrayInfo<CartEntity>> getCarts(Map<String, Object> map, Callback<JsonArrayInfo<CartEntity>> callback);

    Call<JsonArrayInfo<CartEntity>> deleteProduct(Map<String, Object> map, Callback<JsonArrayInfo<CartEntity>> callback);

    Call<ProductAttributeEntity> getSku(Map<String, Object> map, Callback<ProductAttributeEntity> callback);

    Call<BaseJsonInfo> updateCart(Map<String, Object> map, Callback<BaseJsonInfo> callback);

    Call<BaseJsonInfo> moveToFav(Map<String, Object> map, Callback<BaseJsonInfo> callback);
}
