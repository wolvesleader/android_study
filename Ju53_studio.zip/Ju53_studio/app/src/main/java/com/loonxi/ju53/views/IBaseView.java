package com.loonxi.ju53.views;

/**
 * Created by Xuzue on 2016/1/12.
 */
public interface IBaseView {
    void startAsyncTask();
    void endAsyncTask();
}
