package com.loonxi.ju53.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.MessageEntity;
import com.loonxi.ju53.utils.TimeUtil;

import java.util.List;

/**
 * "消息列表"adapter
 * Created by laojiaqi on 2016/2/3.
 */
public class MessageListAdapter extends BaseAdapter {

    public static final int SYSTEM = 1;
    public static final int TRADE = 2;
    public static final int LOGISTICS = 3;//物流

    public static final int UNREAD = 0;//未读
    public static final int READ = 1;//已读

    Context mContext;
    List<MessageEntity> mMessageList;


    public MessageListAdapter(Context context, List<MessageEntity> messageEntityList) {
        this.mContext = context;
        this.mMessageList = messageEntityList;

    }

    @Override
    public int getCount() {
        return mMessageList == null ? 0 : mMessageList.size();
    }

    @Override
    public MessageEntity getItem(int position) {
        return mMessageList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.listitem_message_list, null);
            viewHolder = new ViewHolder();
            viewHolder.imageView = (ImageView) convertView.findViewById(R.id.message_list_item_image_view);
            viewHolder.content = (TextView) convertView.findViewById(R.id.message_list_item_content);
            viewHolder.title = (TextView) convertView.findViewById(R.id.message_list_item_title);
            viewHolder.time = (TextView) convertView.findViewById(R.id.message_list_item_time);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        MessageEntity messageEntity = getItem(position);
        if (messageEntity != null) {
            viewHolder.time.setText(messageEntity.getCreated() + "");
            viewHolder.time.setText(TimeUtil.getFormatTimeFromTimestamp(messageEntity.getCreated(),"yyyy/MM/dd HH:mm"));
            viewHolder.title.setText(messageEntity.getTitle());
            viewHolder.content.setText(messageEntity.getContent());
            setTitleAndPicByType(messageEntity,viewHolder.title,viewHolder.imageView);
        }
        return convertView;
    }

    /**
     * 根据类型设置标题
     */
    private void setTitleAndPicByType(MessageEntity messageEntity, TextView title, ImageView imageView) {
        if (mContext == null) {
            return;
        }
        switch (messageEntity.getType()) {
            case SYSTEM:
                title.setText(R.string.message_item_system_title);
                if (!TextUtils.isEmpty(messageEntity.getPicPath())) {
                    Glide.with(mContext).load((AppConst.PIC_HEAD + messageEntity.getPicPath())).into(imageView);
                } else {
                    Glide.with(mContext).load(R.drawable.ic_launcher).into(imageView);
                }
                break;
            case TRADE:
                title.setText(R.string.message_item_trade_title);
                if (messageEntity.getStatus() == UNREAD) {
                    Glide.with(mContext).load(R.drawable.message_item_trade_new).into(imageView);
                }
                if (messageEntity.getStatus() == READ) {
                    Glide.with(mContext).load(R.drawable.message_item_trade).into(imageView);
                }
                break;
            case LOGISTICS:
                title.setText(R.string.message_item_logistics_title);
                if (messageEntity.getStatus() == UNREAD) {
                    Glide.with(mContext).load(R.drawable.message_item_logistics_new).into(imageView);
                }
                if (messageEntity.getStatus() == READ) {
                    Glide.with(mContext).load(R.drawable.message_item_logistics).into(imageView);
                }
                break;
            default:
                title.setText(R.string.message_action_bar_title);
                Glide.with(mContext).load(R.drawable.ic_launcher).into(imageView);
                break;
        }
    }

    class ViewHolder {
        ImageView imageView;
        TextView title;
        TextView time;
        TextView content;
    }
}
