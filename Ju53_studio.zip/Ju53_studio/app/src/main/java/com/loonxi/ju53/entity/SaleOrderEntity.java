package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 分销订单实体
 * Created by XuZue on 2016/5/7 0007.
 */
public class SaleOrderEntity implements Parcelable {

    private String orderId;
    private String storeName;//分销商店铺名
    private String price;
    private int num;
    private String state;
    private String time;
    private String freight;
    private String customId;//供应商id
    private String customName;//供应商名
    private List<SaleOrderUnitEntity> attrs;

    protected SaleOrderEntity(Parcel in) {
        orderId = in.readString();
        storeName = in.readString();
        price = in.readString();
        num = in.readInt();
        state = in.readString();
        time = in.readString();
        freight = in.readString();
        customId = in.readString();
        customName = in.readString();
        attrs = in.readArrayList(Thread.currentThread().getContextClassLoader());
    }

    public static final Creator<SaleOrderEntity> CREATOR = new Creator<SaleOrderEntity>() {
        @Override
        public SaleOrderEntity createFromParcel(Parcel in) {
            return new SaleOrderEntity(in);
        }

        @Override
        public SaleOrderEntity[] newArray(int size) {
            return new SaleOrderEntity[size];
        }
    };

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String name) {
        this.storeName = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getFreight() {
        return freight;
    }

    public void setFreight(String freight) {
        this.freight = freight;
    }

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public List<SaleOrderUnitEntity> getAttr() {
        return attrs;
    }

    public void setAttr(List<SaleOrderUnitEntity> product) {
        this.attrs = product;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(orderId);
        dest.writeString(storeName);
        dest.writeString(price);
        dest.writeInt(num);
        dest.writeString(state);
        dest.writeString(time);
        dest.writeString(freight);
        dest.writeString(customId);
        dest.writeString(customName);
        dest.writeList(attrs);
    }
}
