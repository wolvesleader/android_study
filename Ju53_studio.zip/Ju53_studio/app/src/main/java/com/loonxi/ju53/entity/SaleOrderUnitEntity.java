package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by XuZue on 2016/5/12 0012.
 */
public class SaleOrderUnitEntity implements Parcelable {

    private String orderId;
    private String productName;
    private String attribute;
    private String price;
    private String picture;
    private String num;
    private String time;
    private String state;
    private String is_backed;
    private String productId;

    protected SaleOrderUnitEntity(Parcel in) {
        orderId = in.readString();
        productName = in.readString();
        attribute = in.readString();
        price = in.readString();
        picture = in.readString();
        num = in.readString();
        time = in.readString();
        state = in.readString();
        is_backed = in.readString();
        productId = in.readString();
    }

    public static final Creator<SaleOrderUnitEntity> CREATOR = new Creator<SaleOrderUnitEntity>() {
        @Override
        public SaleOrderUnitEntity createFromParcel(Parcel in) {
            return new SaleOrderUnitEntity(in);
        }

        @Override
        public SaleOrderUnitEntity[] newArray(int size) {
            return new SaleOrderUnitEntity[size];
        }
    };

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String name) {
        this.productName = name;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attr) {
        this.attribute = attr;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getIs_backed() {
        return is_backed;
    }

    public void setIs_backed(String is_backed) {
        this.is_backed = is_backed;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(orderId);
        dest.writeString(productName);
        dest.writeString(attribute);
        dest.writeString(price);
        dest.writeString(picture);
        dest.writeString(num);
        dest.writeString(time);
        dest.writeString(state);
        dest.writeString(is_backed);
        dest.writeString(productId);
    }
}
