package com.loonxi.ju53.fragment;

import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CashAccountActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.CashCardEntity;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.presenters.CashAccountPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.ICashAccountView;
import com.loonxi.ju53.widgets.dialog.BtnDialog;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
@ContentView(R.layout.fragment_cash_account)
public class CashAccountFragment extends BaseSafeFragment<ICashAccountView, CashAccountPresenter> implements ICashAccountView, View.OnClickListener {

    @ViewInject(R.id.cash_account_layout_open)
    private LinearLayout mLayoutOpen;
    @ViewInject(R.id.cash_account_tv_count)
    private TextView mTvCount;
    @ViewInject(R.id.cash_account_iv_open)
    private ImageView mIvOpen;
    @ViewInject(R.id.cash_account_tv_unband)
    private TextView mTvUnband;

    private List<CashCardEntity> mCashCards = new ArrayList<>();
    private CashCardEntity mCurrentCashCard;
    private BtnDialog mDialog;
    private boolean mHasCashing = false;//是否有提现中的金额


    @Override
    public void initView() {
        if (getActivity() != null) {
            ((CashAccountActivity) getActivity()).setTitle(false);
        }
    }

    @Override
    public void initContent() {
        if(getArguments() != null){
            mHasCashing = getArguments().getBoolean("hasCashing", false);
        }
        if (mPresenter == null) {
            mPresenter = new CashAccountPresenter(this);
        }
    }

    @Override
    public void setListener() {
        mLayoutOpen.setOnClickListener(this);
        mTvUnband.setOnClickListener(this);
    }

    @Override
    protected CashAccountPresenter createPresenter(ICashAccountView iCashAccountView) {
        return new CashAccountPresenter(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mPresenter != null) {
            mPresenter.getCashCount();
        }
    }

    /**
     * 设置账户信息
     */
    private void setCountInfo() {
        if (mCashCards != null && mCashCards.size() > 0 && mCashCards.get(0) != null) {
            mCurrentCashCard = mCashCards.get(0);
            mLayoutOpen.setClickable(false);
            mIvOpen.setVisibility(View.GONE);
            mTvCount.setText(mCashCards.get(0).getAccount());
            mTvUnband.setVisibility(View.VISIBLE);
        } else {
            mCurrentCashCard = null;
            mLayoutOpen.setClickable(true);
            mIvOpen.setVisibility(View.VISIBLE);
            mTvCount.setText("未设置");
            mTvUnband.setVisibility(View.GONE);
        }
    }

    @Override
    public void getCashAccountSuccess(List<CashCardEntity> accounts) {
        mCashCards = accounts;
        setCountInfo();
    }

    @Override
    public void getCashAccountFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void unbandAccountSuccess() {
        mCashCards.clear();
        setCountInfo();
        showToast("解绑成功");
    }

    @Override
    public void unbandAccountFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cash_account_layout_open:
                toBandAccount();
                break;
            case R.id.cash_account_tv_unband:
                unband();
                break;
        }
    }

    /**
     * 解绑
     */
    private void unband() {
        if(mCurrentCashCard == null){
            return;
        }
        if(mHasCashing){
            showToast("该账号还有提现中的金额，不能解绑");
            return;
        }
        mDialog = new BtnDialog(mContext, "", "确定解绑？解绑后需重新绑卡才能提现哟", "", "",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDialog.dismiss();
                        if (mPresenter != null) {
                            mPresenter.unbandCashCount(mCurrentCashCard.getPid());
                        }
                    }
                },
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDialog.dismiss();
                    }
                });
        mDialog.show();
    }

    /**
     * 绑卡
     */
    private void toBandAccount() {
        CashAccountSetFragment setFragment = new CashAccountSetFragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.cash_account_container, setFragment);
        ft.addToBackStack("cashAccountFragment");
        ft.commitAllowingStateLoss();
    }
}
