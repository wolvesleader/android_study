package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2015/12/25.
 */
public interface SortService {

    /**
     * 获取分类
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("nav/navIndex")
    Call<JsonArrayInfo<SortEntity>> getSorts(@FieldMap Map<String, Object> map);

    /**
     * 获取二级分类
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("nav/getNav")
    Call<JsonArrayInfo<SortEntity>> getSortById(@FieldMap Map<String, Object> map);

}
