package com.loonxi.ju53.utils;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.loonxi.ju53.base.BaseApplication;

/**
 * Created by Xuze on 2015/9/4.
 */
public class DisplayUtil {

    private  static final int GEOMETRIC_WIDTH=720;
    private  static final int GEOMETRIC_HEIGHT=1280;

    /**
     * 获得屏幕密度
     * @param context
     * @return
     */
    public static float getScreenDensity(Context context){
        if(context==null){
            return 0;
        }
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(dm);
        return dm.density;
    }

    /**
     * dp转px
     * @param dipValue
     * @return
     */
    public static int dip2px(float dipValue){
        float density=getDensityDpi(BaseApplication.getInstance());
       return dip2px(dipValue,density);
    }

    /**
     * 获得缩放密度
     * @param context
     * @return
     */
    public static float getScaleDensity(Context context){
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(dm);
        return dm.scaledDensity;
    }

    /**
     * 获得屏幕宽度dp
     * @param context
     * @return 屏幕宽度dp
     */
    public static float getScreenWidthDip(Context context){
          int pix=getScreenWidth(context);
          float density=getScaleDensity(context);
        return  px2dip(pix,density);
    }


    /**
     * 获得屏幕高度dp
     * @param context
     * @return
     */
    public static float getScreenHeightDip(Context context){
        int pix=getScreenHeight(context);
        float density=getScaleDensity(context);
        return px2dip(pix,density);
    }



    /**
     * 获得屏幕宽度（单位：像素）
     * @param context
     * @return
     */
    public static int getScreenWidth(Context context){
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(dm);
        return dm.widthPixels;
    }

    /**
     * 获得屏幕高度（单位：像素）
     * @param context
     * @return
     */
    public static int getScreenHeight(Context context){
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(dm);
        return dm.heightPixels;
    }

    /**
     * 获得密度dpi
     * @param context
     * @return
     */
    public static int getDensityDpi(Context context){
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(dm);
        return dm.densityDpi;
    }

    /**
     * 将px值转换为dip或dp值，保证尺寸大小不变
     *
     * @param pxValue
     * @param density （DisplayMetrics类中属性density）
     * @return
     */

    public static int px2dip(float pxValue, float density) {
        return (int) (pxValue / density + 0.5f);
    }

    /**
     * 将dip或dp值转换为px值，保证尺寸大小不变
     *
     * @param dipValue
     * @param density  （DisplayMetrics类中属性density）
     * @return
     */

    public static int dip2px(float dipValue, float density) {
        return (int) (dipValue * density + 0.5f);
    }

    /**
     * 将dip或dp值转换为px值
     * @param context
     * @param dipValue
     * @return
     */
    public static int dip2px(Context context,float dipValue){
        return dip2px(dipValue, getScaleDensity(context));
    }


    /**
     * 将px值转换为sp值，保证文字大小不变
     *
     * @param pxValue
     * @param fontScale （DisplayMetrics类中属性scaledDensity）
     * @return
     */

    public static int px2sp(float pxValue, float fontScale) {
        return (int) (pxValue / fontScale + 0.5f);
    }

    /**
     * 将sp值转换为px值，保证文字大小不变
     *
     * @param spValue
     * @param fontScale （DisplayMetrics类中属性scaledDensity）
     * @return
     */

    public static int sp2px(float spValue, float fontScale) {
        return (int) (spValue * fontScale + 0.5f);
    }


    /**
     * 获取到等比的宽
     * @return
     */
    public static  int  getGeometricWidth(Context context,int width)
    {
    return  (getScreenWidth(context)*width)/GEOMETRIC_WIDTH;
    }
    /**
     * 获取到等比的高
     * @return
     */
    public static int getGeometricHeight(Context context,int height)
    {
        return  (getScreenHeight(context)*height)/GEOMETRIC_HEIGHT;
    }

}
