package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.service.FeedbackService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/19.
 */
public class FeedbackModel {

    /**
     * 提交反馈
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> feedback(Map<String, Object> map, Callback<BaseJsonInfo> callback){
        Call<BaseJsonInfo> call = Request.creatApi(FeedbackService.class).feedback(map);
        call.enqueue(callback);
        return call;
    }

}
