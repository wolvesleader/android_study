package com.loonxi.ju53.fragment.address;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.bigkoo.pickerview.OptionsPickerView;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.AddressActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.AddressInfoEntity;
import com.loonxi.ju53.presenters.DomesticAddressOperatePresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IAddressInfoView;
import com.loonxi.ju53.views.IUpdateAddressView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 增加、修改国内地址Fragment
 * Created by laojiaqi on 2016/1/25.
 */
@ContentView(R.layout.fragment_add_address)
public class OperateDomesticAddressFragment extends BaseSafeFragment<IAddressInfoView, DomesticAddressOperatePresenter> implements View.OnClickListener, IAddressInfoView, IUpdateAddressView {

    @ViewInject(R.id.address_add_name)
    EditText mNameView;
    @ViewInject(R.id.address_add_phone)
    EditText mPhoneView;
    @ViewInject(R.id.address_add_address)
    TextView mAddressView;
    @ViewInject(R.id.address_add_detail_address)
    EditText mDetailAddressView;
    @ViewInject(R.id.address_add_default_address)
    TextView mDefaultView;
    @ViewInject(R.id.address_add_action_bar)
    ActionBar mActionBar;
    @ViewInject(R.id.address_add_confirm)
    TextView mConfirmView;
    @ViewInject(R.id.address_default_address_check_box)
    CheckBox mCheckBox;

    public static final String ADDRESS_FRAGMENT_TYPE = "address_fragment_type";
    public static final int ADDRESS_ADD_FLAGE = 1;//新建
    public static final int ADDRESS_MODIFY_FLAGE = 2;//修改
    public static final String ADDRESS_MODIFY_ENTITY = "address_modify_entity";

    private OptionsPickerView mSelectView;
    private ArrayList<AddressInfoEntity> mOptions1Items = new ArrayList<AddressInfoEntity>();
    private ArrayList<List<AddressInfoEntity>> mOptions2Items = new ArrayList<List<AddressInfoEntity>>();
    private ArrayList<List<List<AddressInfoEntity>>> mOptions3Items = new ArrayList<List<List<AddressInfoEntity>>>();
    private String mRegionId;//区域id
    private String mPid;//修改时的Id值
    private int mFragmentType;//表示当前类别
    private AddressEntity mModifyEntity;
    @Nullable
    Button button;

    @Override
    public void initView() {
        mSelectView = new OptionsPickerView(mContext);
    }

    @Override
    public void initContent() {
        mFragmentType = getArguments().getInt(ADDRESS_FRAGMENT_TYPE);
        setContentByType();

    }

    @Override
    public void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mConfirmView.setOnClickListener(this);
        mAddressView.setOnClickListener(this);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_address, null);
        return view;
    }


    /**
     * 设置View的内容
     */
    private void setContentByType() {
        if (mFragmentType == ADDRESS_ADD_FLAGE) {
            mActionBar.setTitle(getString(R.string.address_add_title));
            return;
        }
        if (mFragmentType == ADDRESS_MODIFY_FLAGE) {
            mActionBar.setTitle(getString(R.string.address_modify_title));
            mModifyEntity = (getArguments().getParcelable(ADDRESS_MODIFY_ENTITY));
            if (mModifyEntity != null) {
                mNameView.setText(mModifyEntity.getContact());
                mPhoneView.setText(mModifyEntity.getPhones());
                mAddressView.setText(mModifyEntity.getAddress());
                mDetailAddressView.setText(mModifyEntity.getDetailAddress());
                mCheckBox.setChecked(mModifyEntity.getIsDefault() == 1 ? true : false);
                //收货地址id
                mPid = mModifyEntity.getPid();
                //区域id
                mRegionId = mModifyEntity.getRegionId();
            }
            return;
        }
    }

    @Override
    protected DomesticAddressOperatePresenter createPresenter(IAddressInfoView iAddressInfoView) {
        return new DomesticAddressOperatePresenter(this);
    }

    @Override
    public void getAddressInfoSuccess(List<AddressInfoEntity> dataList) {
        if (isAdded()) {
            initSeletAddressData(dataList);
            initSelectAddressView();
        }
    }

    @Override
    public void getAddressInfoFailure(String message) {
        ToastUtil.showToast(message, false);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.address_add_address:
                getAddressInfo();//获得地址的触发事件
                hiddenKeyboard();
                break;
            case R.id.address_add_confirm:
                createOrUpdate();
                break;
        }

    }


    /**
     * 获得地址信息
     */
    private void getAddressInfo() {
        if (mOptions1Items.size() > 0 && mOptions2Items.size() > 0 && mOptions3Items.size() > 0 && mSelectView != null) {
            mSelectView.show();
        } else {
            mPresenter.getAddressInfo();
        }
    }

    /**
     * 隐藏键盘
     */
    private void hiddenKeyboard() {
        if (getActivity() == null) {
            return;
        }
        ((AddressActivity) getActivity()).hiddenKeyboard();
    }


    /**
     * 进行修改或新建
     */
    private void createOrUpdate() {
        if (checkDataHasEmpty()) {
            showToast(R.string.address_has_empty);
            return;
        }
        if (mFragmentType == ADDRESS_ADD_FLAGE) {
            mPresenter.saveAddress(getInputData());
            return;
        }
        if (mFragmentType == ADDRESS_MODIFY_FLAGE) {
            mPresenter.updateAddress(getInputData());
        }
    }


    /**
     * 检查是否有未填项
     *
     * @return
     */
    private boolean checkDataHasEmpty() {
        String contact = mNameView.getText().toString();
        String phone = mPhoneView.getText().toString();
        String regionId = mRegionId;
        int isDefault = mCheckBox.isChecked() ? 1 : 0;
        String address = mAddressView.getText().toString();
        String detailAddress = mDetailAddressView.getText().toString();
        if (StringUtil.isEmpty(contact) || StringUtil.isEmpty(phone) || StringUtil.isEmpty(regionId)
                || StringUtil.isEmpty(address) || StringUtil.isEmpty(detailAddress)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 获得输入数据
     *
     * @return
     */
    private AddressEntity getInputData() {
        String contact = mNameView.getText().toString();
        String phone = mPhoneView.getText().toString();
        String regionId = mRegionId;
        int isDefault = mCheckBox.isChecked() ? 1 : 0;
        String address = mAddressView.getText().toString();
        String detailAddress = mDetailAddressView.getText().toString();

        //TODO 判断值

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setContact(contact);
        addressEntity.setPhones(mPhoneView.getText().toString());
        addressEntity.setRegionId(mRegionId);
        addressEntity.setIsDefault(isDefault);
        addressEntity.setAddress(address);
        addressEntity.setDetailAddress(detailAddress);
        if (!TextUtils.isEmpty(mPid)) {
            addressEntity.setPid(mPid);
        }
        return addressEntity;
    }


    /**
     * 设置选择器数据
     *
     * @param dataList
     */
    private void initSeletAddressData(List<AddressInfoEntity> dataList) {
        if (dataList == null || dataList.size() == 0) {
            return;
        }
        mOptions1Items.clear();
        mOptions2Items.clear();
        mOptions3Items.clear();
        for (AddressInfoEntity levelOneEntity : dataList) {
            if (levelOneEntity != null) {
                mOptions1Items.add(levelOneEntity);
                List<AddressInfoEntity> levelTwoList = levelOneEntity.getList();
                if (levelTwoList != null) {
                    mOptions2Items.add(levelTwoList);
                    List<List<AddressInfoEntity>> allLevelThreeItem = new ArrayList<List<AddressInfoEntity>>();
                    for (AddressInfoEntity levelTwoEntity : levelTwoList) {
                        if (levelTwoEntity != null) {
                            allLevelThreeItem.add(levelTwoEntity.getList());
                        }
                    }
                    mOptions3Items.add(allLevelThreeItem);
                }
            }

        }
    }

    /**
     * 设置选择器视图
     */
    private void initSelectAddressView() {
        if (mOptions1Items == null || mOptions2Items == null || mOptions3Items == null) {
            return;
        }
        mSelectView.setPicker(mOptions1Items, mOptions2Items, mOptions3Items, true);
        //设置选择的三级单位
        //        pwOptions.setLabels("省", "市", "区");
        mSelectView.setTitle(getResources().getString(R.string.address_add_select_title));
        mSelectView.setCyclic(false, false, false);
        //设置默认选中的三级项目
        //监听确定选择按钮
        mSelectView.setSelectOptions(0, 0, 0);
        mSelectView.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {

            @Override
            public void onOptionsSelect(int options1, int option2, int options3) {
                //返回的分别是三个级别的选中位置
                String tx = mOptions1Items.get(options1).getPickerViewText()
                        + mOptions2Items.get(options1).get(option2).getPickerViewText()
                        + mOptions3Items.get(options1).get(option2).get(options3).getPickerViewText();
                mRegionId = mOptions3Items.get(options1).get(option2).get(options3).getRegionId();
                mAddressView.setText(tx);
            }
        });
        mSelectView.show();
    }


    /**
     * 回退栈
     */
    private void goBack() {
        if(getFragmentManager() != null) {
            getFragmentManager().popBackStack();
        }
    }

    @Override
    public void updateAddressSuccess() {
        goBack();
    }

    @Override
    public void updateAddressFailure(String message) {
        ToastUtil.showToast(message, false);
    }
}
