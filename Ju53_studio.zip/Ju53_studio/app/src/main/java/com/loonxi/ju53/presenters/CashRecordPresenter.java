package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.entity.CashRecordInfo;
import com.loonxi.ju53.models.IFinanceModel;
import com.loonxi.ju53.models.impl.FinanceModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ICashRecordView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashRecordPresenter {
    private ICashRecordView mView;
    private IFinanceModel mModel;

    public CashRecordPresenter(ICashRecordView mView) {
        this.mView = mView;
        mModel = new FinanceModel();
    }

    /**
     * 获取提现记录
     */
    public void getCashRecord(int page, boolean showDialog) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("page", page + "");
        map.put("pageSize", "10");
        if (showDialog && mView != null) {
            mView.startAsyncTask();
        }
        mModel.getCashRecord(map, new Callback<JsonInfo<CashRecordInfo>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<CashRecordInfo> data) {

            }

            @Override
            public void onSuccess(JsonInfo<CashRecordInfo> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.getCashRecordSuccess(data);
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.getCashRecordFailed(apiErrorCode, message);
                }
            }
        });
    }
}
