package com.loonxi.ju53.widgets.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.utils.PrefsUtil;
import com.loonxi.ju53.utils.ToastUtil;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

@SuppressLint("InflateParams")
@ContentView(R.layout.dialog_browser)
public class BrowserDialog extends Dialog implements android.view.View.OnClickListener {
    @ViewInject(R.id.gv_browser)
    private GridView mGvBrowser;
    @ViewInject(R.id.bn_always)
    private Button mBnAlways;
    @ViewInject(R.id.bn_once)
    private Button mBnOnce;

    private Context context;
    private List<ResolveInfo> resolveInfos;
    private PackageManager pm;
    private String url;
    private String defaultBrowser = "";

    public BrowserDialog(Context context, String url) {
        super(context, R.style.dialog_style);
        this.context = context;
        try {
            this.url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            this.url = url;
        }
        initView();
        getData();
    }

    private void initView() {
        View view = LayoutInflater.from(context).inflate(
                R.layout.dialog_browser, null);
        setContentView(view);
        x.view().inject(this, view);

        mGvBrowser.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                mBnOnce.setEnabled(true);
                mBnOnce.setOnClickListener(BrowserDialog.this);
                mBnAlways.setEnabled(true);
                mBnAlways.setOnClickListener(BrowserDialog.this);
                if (defaultBrowser.equals(resolveInfos.get(position).activityInfo.packageName)) {
                    startActivity(defaultBrowser);
                }
                view.setSelected(true);
                defaultBrowser = resolveInfos.get(position).activityInfo.packageName;
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bn_always) {
            PrefsUtil.setSharedStringData(context, AppConst.DEFAULT_BROWSER, defaultBrowser);
        }
        startActivity(defaultBrowser);
    }

    @Override
    public void show() {
        String defaultBrowser = PrefsUtil.getSharedStringData(context, AppConst.DEFAULT_BROWSER);
        if (resolveInfos.size() == 0) {
            //			Toast.makeText(context, "手机中暂无浏览器", Toast.LENGTH_SHORT).show();
            ToastUtil.showToast(context, "手机中暂无浏览器");
        } else if (resolveInfos.size() == 1) {
            startActivity(resolveInfos.get(0).activityInfo.packageName);
        } else {
            if (TextUtils.isEmpty(defaultBrowser)) {
                super.show();
            } else {
                startActivity(defaultBrowser);
            }
        }
    }

    private void startActivity(String packageName) {
        Intent intent = pm.getLaunchIntentForPackage(packageName);
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        context.startActivity(intent);
        dismiss();
    }

    private void getData() {
        Uri uri = Uri.parse(url);
        Intent it = new Intent(Intent.ACTION_VIEW, uri);
        // 通过查询，获得所有ResolveInfo对象.
        pm = context.getPackageManager();
        resolveInfos = pm.queryIntentActivities(it,
                PackageManager.MATCH_DEFAULT_ONLY);
        for (int i = 0, len = resolveInfos.size(); i < len; i++) {
            String name = resolveInfos.get(i).loadLabel(pm).toString().trim();
            if (name.contains("淘宝") || name.contains("天猫")) {
                resolveInfos.remove(i);
                len--;
                i--;
            }
        }
        mGvBrowser.setAdapter(new BrowsersAdapter());
    }

    private class BrowsersAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return resolveInfos.size();
        }

        @Override
        public Object getItem(int position) {
            return resolveInfos.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder vh;
            if (convertView == null) {
                vh = new ViewHolder();
                convertView = LayoutInflater.from(context).inflate(
                        R.layout.item_browser, null);
                vh.mTvBrowser = (TextView) convertView
                        .findViewById(R.id.tv_browser);
                convertView.setTag(vh);
            } else {
                vh = (ViewHolder) convertView.getTag();
            }
            try {
                Drawable drawable = pm.getApplicationIcon(resolveInfos.get(position).activityInfo.packageName);
                drawable.setBounds(0, 0, drawable.getMinimumWidth(),
                        drawable.getMinimumHeight());
                vh.mTvBrowser.setCompoundDrawables(null, drawable, null, null);
                vh.mTvBrowser.setText(resolveInfos.get(position).loadLabel(pm));
            } catch (NameNotFoundException e1) {
                e1.printStackTrace();
            }
            return convertView;
        }

        private class ViewHolder {
            TextView mTvBrowser;
        }
    }
}
