package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.AddressEntity;

import java.util.List;

/**
 * 收货地址 回调接口
 * Created by Administrator on 2016/1/25.
 */
public interface IAddressView {

    public void getAddressSuccess(List<AddressEntity> dataList);

    public void getAddressFailure(String message);
}
