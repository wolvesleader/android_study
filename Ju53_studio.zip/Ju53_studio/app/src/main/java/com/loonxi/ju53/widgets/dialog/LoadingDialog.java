package com.loonxi.ju53.widgets.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.StringUtil;


/**
 * Created by butterfly on 2015/8/29.
 */
public class LoadingDialog extends Dialog {

    private Context mContext;
    private LinearLayout mLayoutContainer;
    private TextView mTvContent;

    public LoadingDialog(Context context){
        this(context, false);
    }

    public LoadingDialog(Context context, boolean dimed) {
        super(context, dimed ? R.style.loadingdialog_style_dimed : R.style.loadingdialog_style);
        mContext = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_loading);
        setCanceledOnTouchOutside(false);
        setCancelable(true);
        setAttribute();
        mLayoutContainer = (LinearLayout) findViewById(R.id.loading_layout_container);
        mTvContent = (TextView) findViewById(R.id.loading_tv_content);
    }

    public void setAttribute(){
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = DisplayUtil.dip2px(mContext, 120);
        lp.height = DisplayUtil.dip2px(mContext, 100);
        getWindow().setAttributes(lp);
    }

    @Override
    public void show() {
        if(!isShowing()){
            super.show();
        }
    }

    public void setContent(String content){
        if(!StringUtil.isEmpty(content) && mTvContent != null){
            mTvContent.setText(content);
        }
    }

    public View findViewById(int id) {
        if (super.findViewById(id) == null) {
            return mLayoutContainer.findViewById(id);
        }
        return super.findViewById(id);
    }
}
