package com.loonxi.ju53.activity;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.utils.JPushUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;

import cn.jpush.android.api.JPushInterface;


public class JPushMainActivity extends ActionBarActivity implements OnClickListener {

    @ViewInject(R.id.jpush_main_tv_imei)
    private TextView mImei;
    @ViewInject(R.id.jpush_main_tv_appkey)
    private TextView mAppKey;
    @ViewInject(R.id.jpush_main_tv_package)
    private TextView mPackage;
    @ViewInject(R.id.jpush_main_tv_device_id)
    private TextView mDeviceId;
    @ViewInject(R.id.jpush_main_tv_version)
    private TextView mVersion;
    @ViewInject(R.id.jpush_main_btn_init)
    private Button mInit;
    @ViewInject(R.id.jpush_main_btn_setting)
    private Button mSetting;
    @ViewInject(R.id.jpush_main_btn_stopPush)
    private Button mStopPush;
    @ViewInject(R.id.jpush_main_btn_resumePush)
    private Button mResumePush;
    @ViewInject(R.id.jpush_main_tv_msg_rec)
    private TextView msgText;

    //for receive customer msg from jpush server
    private MessageReceiver mMessageReceiver;
    public static boolean isForeground = false;
    public static final String MESSAGE_RECEIVED_ACTION = "com.loonxi.ju53.MESSAGE_RECEIVED_ACTION";
    public static final String KEY_TITLE = "title";
    public static final String KEY_MESSAGE = "message";
    public static final String KEY_EXTRAS = "extras";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jpush_main);
        initView();
        registerMessageReceiver();
    }

    @Override
    public void initView() {
        setTitle("极光推送测试");
    }

    @Override
    public void initContent() {
        String udid = SpUtil.getString(getApplicationContext(), SpUtil.IMEI, "");
        String appKey = JPushUtil.getAppKey(getApplicationContext());
        String packageName = getPackageName();
        String deviceId = JPushUtil.getDeviceId(getApplicationContext());
        String versionName = JPushUtil.GetVersion(getApplicationContext());
        mImei.setText("IMEI: " + udid);
        mAppKey.setText("AppKey: " + (StringUtil.isEmpty(appKey) ? "AppKey异常" : appKey));
        mPackage.setText("PackageName: " + packageName);
        mDeviceId.setText("deviceId:" + deviceId);
        mVersion.setText("Version: " + versionName);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mInit.setOnClickListener(this);
        mStopPush.setOnClickListener(this);
        mResumePush.setOnClickListener(this);
        mSetting.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case R.id.jpush_main_btn_init:
                init();
                break;
            case R.id.jpush_main_btn_setting:

                break;
            case R.id.jpush_main_btn_stopPush:
                JPushInterface.stopPush(getApplicationContext());
                break;
            case R.id.jpush_main_btn_resumePush:
                JPushInterface.resumePush(getApplicationContext());
                break;
        }
    }

    /**
     * 初始化 JPush。如果已经初始化，但没有登录成功，则执行重新登录。
     */
    private void init() {
        JPushInterface.init(getApplicationContext());
    }


    @Override
    protected void onResume() {
        isForeground = true;
        super.onResume();
    }


    @Override
    protected void onPause() {
        isForeground = false;
        super.onPause();
    }


    @Override
    protected void onDestroy() {
        unregisterReceiver(mMessageReceiver);
        super.onDestroy();
    }


    public void registerMessageReceiver() {
        mMessageReceiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        filter.addAction(MESSAGE_RECEIVED_ACTION);
        registerReceiver(mMessageReceiver, filter);
    }

    public class MessageReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (MESSAGE_RECEIVED_ACTION.equals(intent.getAction())) {
                String messge = intent.getStringExtra(KEY_MESSAGE);
                String extras = intent.getStringExtra(KEY_EXTRAS);
                StringBuilder showMsg = new StringBuilder();
                showMsg.append(KEY_MESSAGE + " : " + messge + "\n");
                if (!StringUtil.isEmpty(extras)) {
                    showMsg.append(KEY_EXTRAS + " : " + extras + "\n");
                }
                setCustomMsg(showMsg.toString());
            }
        }
    }

    private void setCustomMsg(String msg) {
        if (null != msgText) {
            msgText.setText(msg);
            msgText.setVisibility(View.VISIBLE);
        }
    }

}