package com.loonxi.ju53.base;

import android.app.Application;
import android.content.Context;

import com.loonxi.ju53.R;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.constants.OpenConst;
import com.loonxi.ju53.database.DBUpdateHelper;
import com.loonxi.ju53.manager.JPushManager;
import com.loonxi.ju53.modules.open.OpenApiConst;
import com.loonxi.ju53.utils.ChannelUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.Logger;
import com.loonxi.ju53.utils.SpUtil;
import com.squareup.leakcanary.LeakCanary;
import com.squareup.leakcanary.RefWatcher;
import com.umeng.analytics.MobclickAgent;
import com.umeng.socialize.Config;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.utils.Log;

import org.xutils.DbManager;
import org.xutils.x;

import cn.jpush.android.api.JPushInterface;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by Xuzue on 2015/12/16.
 */
public class BaseApplication extends Application {


    public static BaseApplication instance;
    private static volatile DbManager mDbManager;
    public static Context context;
    private boolean isDebug = false;//////////////////////////////////软件发布时，切记置为false
    public static boolean isDeveloper = false;

    public static RefWatcher refWatcher;

    @Override
    public void onCreate() {
        super.onCreate();
//        setFonts();
        instance = this;
        CrashHandler.getInstance().init(getApplicationContext());
        x.Ext.init(instance);
        x.Ext.setDebug(false);
        initDB();
        refWatcher = initRefWatcher();
        setReleaseVersionParams();
        setJPushParams();
        setShareParams();
    }

    /**
     * 设置全局字体
     */
    private void setFonts() {
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/OpenSans-ExtraBoldItalic.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
    }


    /**
     * 设置发布版本参数
     */
    private void setReleaseVersionParams() {
        isDeveloper = isDebug;
        LogUtil.enableLogger(isDebug);
        Logger.setForceShow(isDebug);
        MobclickAgent.startWithConfigure(new MobclickAgent.UMAnalyticsConfig(
                instance, OpenConst.UMENG_APPKEY,
                ChannelUtil.getChannel(this)));
        MobclickAgent.enableEncrypt(true);//对友盟统计日志加密
        MobclickAgent.setCatchUncaughtExceptions(!isDebug);//是否开启错误统计
        JPushInterface.setDebugMode(isDebug);
        JPushInterface.init(this);
    }

    /**
     * 初始化initRefWatcher
     *
     * @return
     */
    private RefWatcher initRefWatcher() {
        if (AppConst.OPEN_REF_WATCH) {
            return LeakCanary.install(this);
        } else {
            return RefWatcher.DISABLED;
        }
    }


    /**
     * 设置JPush的Tag、Alias等
     */
    private void setJPushParams() {
        new JPushManager(this).setTag(SpUtil.getString(this, SpUtil.ACCOUNT_USER_ID, ""));
        new JPushManager(this).setAlias(SpUtil.getString(this, SpUtil.ACCOUNT_USER_ID, ""));
//        new JPushManager(this).setStyleCustom();
        SpUtil.putString(this, SpUtil.JPUSH_TAG, SpUtil.getString(this, SpUtil.ACCOUNT_USER_ID, ""));
        SpUtil.putString(this, SpUtil.JPUSH_ALIAS, SpUtil.getString(this, SpUtil.ACCOUNT_USER_ID, ""));
        SpUtil.putString(this, SpUtil.JPUSH_REGISTRATIONID, JPushInterface.getRegistrationID(this));

        LogUtil.mLog().d("\ntag:" + SpUtil.getString(this, SpUtil.JPUSH_TAG, "") +
                "\nalias:" + SpUtil.getString(this, SpUtil.JPUSH_ALIAS, "") +
                "\nregistrationId:" + SpUtil.getString(this, SpUtil.JPUSH_REGISTRATIONID, ""));
    }

    /**
     * 设置友盟社会化分享参数
     */
    private void setShareParams() {
        Config.isloadUrl = true;
        Config.OpenEditor = true;
        Log.LOG = true;
        PlatformConfig.setWeixin(OpenApiConst.Wechat.APP_ID, OpenApiConst.Wechat.APP_SECRET);
        PlatformConfig.setSinaWeibo(OpenApiConst.Sina.APP_KEY, OpenApiConst.Sina.APP_SECRET);
        PlatformConfig.setQQZone(OpenApiConst.Tencent.APP_ID, OpenApiConst.Tencent.APP_KEY);
    }

    /**
     * 初始化数据库
     */
    private static void initDB() {
        Logger.i("initDB");
        DbManager.DaoConfig daoConfig = new DbManager.DaoConfig()
                .setDbName(AppConst.DB_NAME)
                .setDbVersion(AppConst.DB_VERSION)
                .setDbUpgradeListener(new DbManager.DbUpgradeListener() {
                    @Override
                    public void onUpgrade(DbManager db, int oldVersion, int newVersion) {
                        DBUpdateHelper.onUpgrade(db, oldVersion, newVersion);
                    }
                });
        mDbManager = x.getDb(daoConfig);
    }

    public static BaseApplication getInstance() {
        return instance;
    }

    /**
     * 获取数据库管理器
     *
     * @return
     */
    public static DbManager getDbManager() {
        if (mDbManager == null) {
            synchronized (BaseApplication.class) {
                if (mDbManager == null) {
                    initDB();
                }
            }
        }
        return mDbManager;
    }

    /**
     * 退出程序
     */
    public static void exit() {
        android.os.Process.killProcess(android.os.Process.myPid());
        android.os.Process.killProcess(android.os.Process.myTid());
        android.os.Process.killProcess(android.os.Process.myUid());
    }
}
