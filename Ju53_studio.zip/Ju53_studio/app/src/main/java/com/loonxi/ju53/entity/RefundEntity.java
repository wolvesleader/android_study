package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2016/2/16.
 */
public class RefundEntity implements Parcelable{
    /**
     *
     */
    private int pid;

    /**
     *
     */
    private long userId;

    /**
     *  申请退款时对应的PAYMENTID
     */
    private String paymentId;

    /**
     *  订单id
     */
    private String orderId;

    /**
     *  产品id
     */
    private String productId;

    /**
     *  申请退款金额
     */
    private double backapply;

    /**
     * 原因
     */
    private int reason;

    /**
     *  退款说明
     */
    private String notes;

    /**
     *  申请退款时的订单状态
     */
    private int orderState;

    /**
     *  状态(0-申请退款,1-不同意退款,2-同意退款（且已退款）,3-退款结束(比如确认收货则退款结束),4.退款修改-1取消申请退款，5.买家同意退款但未退款 7退货退款时的卖家同意退货 8.退货退款时买家退回货物)
     */
    private int state;

    /**
     *  是否申请客服介入0：未申请客服介入1。已申请客服介入2.客服已处理
     */
    private int isServer;

    /**
     *  申请客服介入对应的退款记录ID
     */
    private int serverRecord;

    /**
     *  efunds_records的PID走向
     */
    private String recordPidRule;

    /**
     *  申请退款的处理状态 0-2-3-4
     */
    private String stateRole;

    /**
     *  实际退款金额
     */
    private double backed;

    /**
     *  退款时间
     */
    private long backTime;

    /**
     *  客服id
     */
    private int servicerId;

    /**
     *  产品订单中的产品规格id
     */
    private int attrId;

    /**
     *  申请退款类型1仅退款 2退货退款
     */
    private int applyType;

    /**
     *  退货退款对应的收货地址
     */
    private String addressChosse;

    /**
     *  创建时间
     */
    private long createTime;

    /**
     *  修改时间
     */
    private long updateTime;
    /**
     * 供应商姓名
     */
    private String customName;

    /**
     * 卖家拒绝原因
     */
    private int replyReason;

    /**
     * 卖家拒绝说明
     */
    private String reply;
    /**
     * 剩余时间
     */
    private String remainTime;

    protected RefundEntity(Parcel in) {
        pid = in.readInt();
        userId = in.readLong();
        paymentId = in.readString();
        orderId = in.readString();
        productId = in.readString();
        backapply = in.readDouble();
        reason = in.readInt();
        notes = in.readString();
        orderState = in.readInt();
        state = in.readInt();
        isServer = in.readInt();
        serverRecord = in.readInt();
        recordPidRule = in.readString();
        stateRole = in.readString();
        backed = in.readDouble();
        backTime = in.readLong();
        servicerId = in.readInt();
        attrId = in.readInt();
        applyType = in.readInt();
        addressChosse = in.readString();
        createTime = in.readLong();
        updateTime = in.readLong();
        customName = in.readString();
        replyReason = in.readInt();
        reply = in.readString();
        remainTime = in.readString();
    }

    public static final Creator<RefundEntity> CREATOR = new Creator<RefundEntity>() {
        @Override
        public RefundEntity createFromParcel(Parcel in) {
            return new RefundEntity(in);
        }

        @Override
        public RefundEntity[] newArray(int size) {
            return new RefundEntity[size];
        }
    };

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getReason() {
        return reason;
    }

    public void setReason(int reason) {
        this.reason = reason;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getOrderState() {
        return orderState;
    }

    public void setOrderState(int orderState) {
        this.orderState = orderState;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getIsServer() {
        return isServer;
    }

    public void setIsServer(int isServer) {
        this.isServer = isServer;
    }

    public int getServerRecord() {
        return serverRecord;
    }

    public void setServerRecord(int serverRecord) {
        this.serverRecord = serverRecord;
    }

    public String getRecordPidRule() {
        return recordPidRule;
    }

    public void setRecordPidRule(String recordPidRule) {
        this.recordPidRule = recordPidRule;
    }

    public String getStateRole() {
        return stateRole;
    }

    public void setStateRole(String stateRole) {
        this.stateRole = stateRole;
    }


    public double getBackapply() {
        return backapply;
    }

    public void setBackapply(double backapply) {
        this.backapply = backapply;
    }

    public double getBacked() {
        return backed;
    }

    public void setBacked(double backed) {
        this.backed = backed;
    }

    public long getBackTime() {
        return backTime;
    }

    public void setBackTime(long backTime) {
        this.backTime = backTime;
    }

    public int getServicerId() {
        return servicerId;
    }

    public void setServicerId(int servicerId) {
        this.servicerId = servicerId;
    }

    public int getAttrId() {
        return attrId;
    }

    public void setAttrId(int attrId) {
        this.attrId = attrId;
    }

    public int getApplyType() {
        return applyType;
    }

    public void setApplyType(int applyType) {
        this.applyType = applyType;
    }

    public String getAddressChosse() {
        return addressChosse;
    }

    public void setAddressChosse(String addressChosse) {
        this.addressChosse = addressChosse;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public int getReplyReason() {
        return replyReason;
    }

    public void setReplyReason(int replyReason) {
        this.replyReason = replyReason;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getRemainTime() {
        return remainTime;
    }

    public void setRemainTime(String remainTime) {
        this.remainTime = remainTime;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(pid);
        dest.writeLong(userId);
        dest.writeString(paymentId);
        dest.writeString(orderId);
        dest.writeString(productId);
        dest.writeDouble(backapply);
        dest.writeInt(reason);
        dest.writeString(notes);
        dest.writeInt(orderState);
        dest.writeInt(state);
        dest.writeInt(isServer);
        dest.writeInt(serverRecord);
        dest.writeString(recordPidRule);
        dest.writeString(stateRole);
        dest.writeDouble(backed);
        dest.writeLong(backTime);
        dest.writeInt(servicerId);
        dest.writeInt(attrId);
        dest.writeInt(applyType);
        dest.writeString(addressChosse);
        dest.writeLong(createTime);
        dest.writeLong(updateTime);
        dest.writeString(customName);
        dest.writeInt(replyReason);
        dest.writeString(reply);
        dest.writeString(remainTime);
    }
}
