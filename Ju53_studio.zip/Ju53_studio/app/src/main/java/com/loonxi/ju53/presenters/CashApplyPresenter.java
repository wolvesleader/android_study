package com.loonxi.ju53.presenters;

import com.loonxi.ju53.models.IFinanceModel;
import com.loonxi.ju53.models.impl.FinanceModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ICashApplyView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class CashApplyPresenter {
    private ICashApplyView mView;
    private IFinanceModel mModel;

    public CashApplyPresenter(ICashApplyView mView) {
        this.mView = mView;
        mModel = new FinanceModel();
    }

    /**
     * 申请提现
     *
     * @param money
     */
    public void cashApply(String money, String pid) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("money", money);
        map.put("pid", pid);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.cashApply(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.cashApplySuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.cashApplyFailed(apiErrorCode, message);
                }
            }
        });
    }
}
