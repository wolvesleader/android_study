package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 分销订单详情-时间信息
 * Created by XuZue on 2016/5/12 0012.
 */
public class SaleOrderDetailTime implements Parcelable{
    private String createTime;
    private String payTime;
    private String shippingTime;
    private String receiveTime;

    protected SaleOrderDetailTime(Parcel in) {
        createTime = in.readString();
        payTime = in.readString();
        shippingTime = in.readString();
        receiveTime = in.readString();
    }

    public static final Creator<SaleOrderDetailTime> CREATOR = new Creator<SaleOrderDetailTime>() {
        @Override
        public SaleOrderDetailTime createFromParcel(Parcel in) {
            return new SaleOrderDetailTime(in);
        }

        @Override
        public SaleOrderDetailTime[] newArray(int size) {
            return new SaleOrderDetailTime[size];
        }
    };

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getShippingTime() {
        return shippingTime;
    }

    public void setShippingTime(String shippingTime) {
        this.shippingTime = shippingTime;
    }

    public String getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(String receiveTime) {
        this.receiveTime = receiveTime;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(createTime);
        dest.writeString(payTime);
        dest.writeString(shippingTime);
        dest.writeString(receiveTime);
    }
}
