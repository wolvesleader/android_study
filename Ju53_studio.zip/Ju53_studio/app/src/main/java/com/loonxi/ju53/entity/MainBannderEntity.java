package com.loonxi.ju53.entity;

import java.util.List;

/**
 * Created by laojiaqi on 2016/6/1.
 */
public class MainBannderEntity
{


    /**
     * message : success
     * flag : 1
     * data : {"category":[{"img_url":"/ju53/146475130125086.jpg","id":"239","title":"水扁啊胡二胡VU","img_link":"dsdvcdv"},{"img_url":"/ju53/146475127731161.jpg","id":"238","title":"ios 大幅度DVD","img_link":"ddvdvdvb"},{"img_url":"/ju53/146475123532640.jpg","id":"237","title":"分类数据ios 2","img_link":"sfsdsdgv"},{"img_url":"/ju53/146475121129699.jpg","id":"236","title":"加数据好累啊1","img_link":"wdeqdfqw"},{"img_url":"/ju53/146474743213373.jpg","id":"229","title":"IOS --新版分类图","img_link":"www.baidu.com"}],"feature":[{"child":[{"sort":"0","update_time":null,"module_id":"8","state":"0","create_time":"2016-06-24 16:03:16","img":"asda.jpg","cate_gory":"1","module_name":"模二图2","url":"www.dsdasd.com","parent_id":"6"},{"sort":"0","update_time":null,"module_id":"7","state":"0","create_time":"2016-06-14 16:01:05","img":"f.jpg","cate_gory":"1","module_name":"模二下的图1","url":"www.44.com","parent_id":"6"}],"sort":"0","update_time":null,"module_id":"6","state":"0","create_time":"2016-06-02 15:59:24","img":"e.jpg","cate_gory":"1","module_name":"特色模块二","url":"www.mo2.com","parent_id":"0"},{"child":[{"sort":"0","update_time":null,"module_id":"5","state":"0","create_time":"2016-06-02 15:56:44","img":"d.jpg","cate_gory":"1","module_name":"模块下图片4","url":"www.4.com","parent_id":"1"},{"sort":"0","update_time":null,"module_id":"4","state":"0","create_time":"2016-06-02 15:56:41","img":"c.jpg","cate_gory":"1","module_name":"模块下图片3","url":"www.3.com","parent_id":"1"},{"sort":"0","update_time":null,"module_id":"3","state":"0","create_time":"2016-06-02 15:56:35","img":"b.jpg","cate_gory":"1","module_name":"模块下图片2","url":"www.1.com","parent_id":"1"},{"sort":"0","update_time":null,"module_id":"2","state":"0","create_time":"2016-06-02 15:56:32","img":"/aa/a/a.jpg","cate_gory":"1","module_name":"模块下图片1","url":"www.1.com","parent_id":"1"}],"sort":"0","update_time":null,"module_id":"1","state":"0","create_time":"2016-06-02 15:56:38","img":null,"cate_gory":"1","module_name":"特色模块一","url":null,"parent_id":"0"}],"banner":[{"img_url":"/ju53/146474505412417.jpg","id":"226","title":"IOS --banner测试","img_link":"www"}]}
     */
    private String message;
    private String flag;
    private DataEntity data;

    public void setMessage(String message) {
        this.message = message;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public String getFlag() {
        return flag;
    }

    public DataEntity getData() {
        return data;
    }

    public class DataEntity {
        /**
         * category : [{"img_url":"/ju53/146475130125086.jpg","id":"239","title":"水扁啊胡二胡VU","img_link":"dsdvcdv"},{"img_url":"/ju53/146475127731161.jpg","id":"238","title":"ios 大幅度DVD","img_link":"ddvdvdvb"},{"img_url":"/ju53/146475123532640.jpg","id":"237","title":"分类数据ios 2","img_link":"sfsdsdgv"},{"img_url":"/ju53/146475121129699.jpg","id":"236","title":"加数据好累啊1","img_link":"wdeqdfqw"},{"img_url":"/ju53/146474743213373.jpg","id":"229","title":"IOS --新版分类图","img_link":"www.baidu.com"}]
         * feature : [{"child":[{"sort":"0","update_time":null,"module_id":"8","state":"0","create_time":"2016-06-24 16:03:16","img":"asda.jpg","cate_gory":"1","module_name":"模二图2","url":"www.dsdasd.com","parent_id":"6"},{"sort":"0","update_time":null,"module_id":"7","state":"0","create_time":"2016-06-14 16:01:05","img":"f.jpg","cate_gory":"1","module_name":"模二下的图1","url":"www.44.com","parent_id":"6"}],"sort":"0","update_time":null,"module_id":"6","state":"0","create_time":"2016-06-02 15:59:24","img":"e.jpg","cate_gory":"1","module_name":"特色模块二","url":"www.mo2.com","parent_id":"0"},{"child":[{"sort":"0","update_time":null,"module_id":"5","state":"0","create_time":"2016-06-02 15:56:44","img":"d.jpg","cate_gory":"1","module_name":"模块下图片4","url":"www.4.com","parent_id":"1"},{"sort":"0","update_time":null,"module_id":"4","state":"0","create_time":"2016-06-02 15:56:41","img":"c.jpg","cate_gory":"1","module_name":"模块下图片3","url":"www.3.com","parent_id":"1"},{"sort":"0","update_time":null,"module_id":"3","state":"0","create_time":"2016-06-02 15:56:35","img":"b.jpg","cate_gory":"1","module_name":"模块下图片2","url":"www.1.com","parent_id":"1"},{"sort":"0","update_time":null,"module_id":"2","state":"0","create_time":"2016-06-02 15:56:32","img":"/aa/a/a.jpg","cate_gory":"1","module_name":"模块下图片1","url":"www.1.com","parent_id":"1"}],"sort":"0","update_time":null,"module_id":"1","state":"0","create_time":"2016-06-02 15:56:38","img":null,"cate_gory":"1","module_name":"特色模块一","url":null,"parent_id":"0"}]
         * banner : [{"img_url":"/ju53/146474505412417.jpg","id":"226","title":"IOS --banner测试","img_link":"www"}]
         */
        private List<CategoryEntity> category;
        private List<FeatureEntity> feature;
        private List<BannerEntity> banner;

        public void setCategory(List<CategoryEntity> category) {
            this.category = category;
        }

        public void setFeature(List<FeatureEntity> feature) {
            this.feature = feature;
        }

        public void setBanner(List<BannerEntity> banner) {
            this.banner = banner;
        }

        public List<CategoryEntity> getCategory() {
            return category;
        }

        public List<FeatureEntity> getFeature() {
            return feature;
        }

        public List<BannerEntity> getBanner() {
            return banner;
        }

        public class CategoryEntity {
            /**
             * img_url : /ju53/146475130125086.jpg
             * id : 239
             * title : 水扁啊胡二胡VU
             * img_link : dsdvcdv
             */
            private String img_url;
            private String id;
            private String title;
            private String img_link;

            public void setImg_url(String img_url) {
                this.img_url = img_url;
            }

            public void setId(String id) {
                this.id = id;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public void setImg_link(String img_link) {
                this.img_link = img_link;
            }

            public String getImg_url() {
                return img_url;
            }

            public String getId() {
                return id;
            }

            public String getTitle() {
                return title;
            }

            public String getImg_link() {
                return img_link;
            }
        }

        public class FeatureEntity {
            /**
             * child : [{"sort":"0","update_time":null,"module_id":"8","state":"0","create_time":"2016-06-24 16:03:16","img":"asda.jpg","cate_gory":"1","module_name":"模二图2","url":"www.dsdasd.com","parent_id":"6"},{"sort":"0","update_time":null,"module_id":"7","state":"0","create_time":"2016-06-14 16:01:05","img":"f.jpg","cate_gory":"1","module_name":"模二下的图1","url":"www.44.com","parent_id":"6"}]
             * sort : 0
             * update_time : null
             * module_id : 6
             * state : 0
             * create_time : 2016-06-02 15:59:24
             * img : e.jpg
             * cate_gory : 1
             * module_name : 特色模块二
             * url : www.mo2.com
             * parent_id : 0
             */
            private List<ChildEntity> child;
            private String sort;
            private String update_time;
            private String module_id;
            private String state;
            private String create_time;
            private String img;
            private String cate_gory;
            private String module_name;
            private String url;
            private String parent_id;

            public void setChild(List<ChildEntity> child) {
                this.child = child;
            }

            public void setSort(String sort) {
                this.sort = sort;
            }

            public void setUpdate_time(String update_time) {
                this.update_time = update_time;
            }

            public void setModule_id(String module_id) {
                this.module_id = module_id;
            }

            public void setState(String state) {
                this.state = state;
            }

            public void setCreate_time(String create_time) {
                this.create_time = create_time;
            }

            public void setImg(String img) {
                this.img = img;
            }

            public void setCate_gory(String cate_gory) {
                this.cate_gory = cate_gory;
            }

            public void setModule_name(String module_name) {
                this.module_name = module_name;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public void setParent_id(String parent_id) {
                this.parent_id = parent_id;
            }

            public List<ChildEntity> getChild() {
                return child;
            }

            public String getSort() {
                return sort;
            }

            public String getUpdate_time() {
                return update_time;
            }

            public String getModule_id() {
                return module_id;
            }

            public String getState() {
                return state;
            }

            public String getCreate_time() {
                return create_time;
            }

            public String getImg() {
                return img;
            }

            public String getCate_gory() {
                return cate_gory;
            }

            public String getModule_name() {
                return module_name;
            }

            public String getUrl() {
                return url;
            }

            public String getParent_id() {
                return parent_id;
            }

            public class ChildEntity {
                /**
                 * sort : 0
                 * update_time : null
                 * module_id : 8
                 * state : 0
                 * create_time : 2016-06-24 16:03:16
                 * img : asda.jpg
                 * cate_gory : 1
                 * module_name : 模二图2
                 * url : www.dsdasd.com
                 * parent_id : 6
                 */
                private String sort;
                private String update_time;
                private String module_id;
                private String state;
                private String create_time;
                private String img;
                private String cate_gory;
                private String module_name;
                private String url;
                private String parent_id;

                public void setSort(String sort) {
                    this.sort = sort;
                }

                public void setUpdate_time(String update_time) {
                    this.update_time = update_time;
                }

                public void setModule_id(String module_id) {
                    this.module_id = module_id;
                }

                public void setState(String state) {
                    this.state = state;
                }

                public void setCreate_time(String create_time) {
                    this.create_time = create_time;
                }

                public void setImg(String img) {
                    this.img = img;
                }

                public void setCate_gory(String cate_gory) {
                    this.cate_gory = cate_gory;
                }

                public void setModule_name(String module_name) {
                    this.module_name = module_name;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public void setParent_id(String parent_id) {
                    this.parent_id = parent_id;
                }

                public String getSort() {
                    return sort;
                }

                public String getUpdate_time() {
                    return update_time;
                }

                public String getModule_id() {
                    return module_id;
                }

                public String getState() {
                    return state;
                }

                public String getCreate_time() {
                    return create_time;
                }

                public String getImg() {
                    return img;
                }

                public String getCate_gory() {
                    return cate_gory;
                }

                public String getModule_name() {
                    return module_name;
                }

                public String getUrl() {
                    return url;
                }

                public String getParent_id() {
                    return parent_id;
                }
            }
        }

        public class BannerEntity {
            /**
             * img_url : /ju53/146474505412417.jpg
             * id : 226
             * title : IOS --banner测试
             * img_link : www
             */
            private String img_url;
            private String id;
            private String title;
            private String img_link;

            public void setImg_url(String img_url) {
                this.img_url = img_url;
            }

            public void setId(String id) {
                this.id = id;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public void setImg_link(String img_link) {
                this.img_link = img_link;
            }

            public String getImg_url() {
                return img_url;
            }

            public String getId() {
                return id;
            }

            public String getTitle() {
                return title;
            }

            public String getImg_link() {
                return img_link;
            }
        }
    }
}
