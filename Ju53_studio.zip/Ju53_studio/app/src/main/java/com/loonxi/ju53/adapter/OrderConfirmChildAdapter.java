package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class OrderConfirmChildAdapter extends BaseObjectListAdapter<BaseProductEntity> {


    public OrderConfirmChildAdapter(Context context, List<BaseProductEntity> datas) {
        super(context, datas);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_order_confirm_child, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_order_confirm_child_layout_root);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_order_confirm_child_iv_head);
            holder.mTvProductName = (TextView) convertView.findViewById(R.id.listitem_order_confirm_child_tv_name);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_order_confirm_child_tv_price);
            holder.mTvAttribute = (TextView) convertView.findViewById(R.id.listitem_order_confirm_child_tv_attribute);
            holder.mTvNum = (TextView) convertView.findViewById(R.id.listitem_order_confirm_child_tv_num);
            holder.mDivider = convertView.findViewById(R.id.listitem_order_confirm_child_divider);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if (position == getCount() - 1) {
            holder.mDivider.setVisibility(View.GONE);
        }
        BaseProductEntity product = get(position);
        String color = StringUtil.isEmpty(product.getAttributeColor()) ? "" : product.getAttributeColor();
        String mula = StringUtil.isEmpty(product.getAttributeMula()) ? "" : product.getAttributeMula();

        Glide.with(mContext).load(AppConst.PIC_HEAD + product.getPicture() + AppConst.PIC_SIZE_80).into(holder.mIvHead);
        holder.mTvProductName.setText(product.getProductName());
        holder.mTvPrice.setText("¥ " + product.getPrice());
        holder.mTvAttribute.setText("颜色:" + color + ",尺码:" + mula);
        holder.mTvNum.setText("x " + product.getCount());

        setListener(holder, product, position);

        return convertView;
    }

    private void setListener(ViewHolder holder, final BaseProductEntity product, final int position) {
        if (holder == null) {
            return;
        }
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ProductDetailActivity.class);
                intent.putExtra("productId", product.getProductId());
                mContext.startActivity(intent);
            }
        });

    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvHead;
        TextView mTvProductName;
        TextView mTvPrice;
        TextView mTvAttribute;
        TextView mTvNum;
        View mDivider;
    }

}
