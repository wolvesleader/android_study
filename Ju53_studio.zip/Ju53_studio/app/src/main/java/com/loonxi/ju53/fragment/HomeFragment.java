package com.loonxi.ju53.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.AboutUsActivity;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.activity.LoginActivity;
import com.loonxi.ju53.activity.MessageActivity;
import com.loonxi.ju53.activity.SearchActivity;
import com.loonxi.ju53.activity.SearchHistoryActivity;
import com.loonxi.ju53.adapter.HomeRecommendReCycleAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.entity.IndexJsonInfo;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.presenters.HomePresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.PackageUtil;
import com.loonxi.ju53.views.IHomeView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.CycleViewPager;
import com.loonxi.ju53.widgets.ViewFactory;
import com.loonxi.ju53.widgets.dialog.BtnDialog;
import com.marshalchen.ultimaterecyclerview.ObservableScrollState;
import com.marshalchen.ultimaterecyclerview.ObservableScrollViewCallbacks;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 首页 fragment
 * Created by Xuzue on 2015/12/18.
 */
@ContentView(R.layout.fragment_home)
public class HomeFragment extends BaseSafeFragment<IHomeView, HomePresenter> implements IHomeView, View.OnClickListener, OnNetWorkListener, FragmentLifeCircle {

    @ViewInject(R.id.fragment_home_actionbar)
    private ActionBar mActionBar;

    private CycleViewPager mViewPager;
    private ImageView mIvTopic1;
    private ImageView mIvTopic2;
    private ImageView mIvTopic3;
    private ImageView mIvTopic4;
    private ImageView mIvTopic5;
    private ImageView mIvTopic6;
    private ImageView mIvTopic7;
    private ImageView mIvTopic8;
    private LinearLayout mLayoutRecommend;

    @ViewInject(R.id.fragment_home_recyclerView)
    private UltimateRecyclerView mUltimateRecyclerView;
    private LinearLayout mLayoutAbout;
    @ViewInject(R.id.fragment_home_iv_top)
    private ImageView mIvTotop;


    private boolean viewVisible = false;
    private List<ImageView> mBannersImgs = new ArrayList<>();
    private HomeRecommendReCycleAdapter mRecycleAdapter;
    private static final int PUSH_START_PAGE = 102;
    private int mCurrentPage = PUSH_START_PAGE;

    private List<IndexEntity> mTopics = new ArrayList<>();//活动+单品
    private List<IndexEntity> mRecommends = new ArrayList<>();//推荐宝贝
    private List<IndexEntity> mProducts = new ArrayList<>();//单品
    private IndexEntity mTopicIndex1;
    private IndexEntity mTopicIndex2;
    private IndexEntity mTopicIndex8;
    private BtnDialog mBtnDialog;
    private boolean backFlag = false;//是否回退标志位


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewVisible = true;
    }


    @Override
    protected HomePresenter createPresenter(IHomeView iHomeView) {
        return new HomePresenter(this);
    }

    @Override
    public void initView() {
        mActionBar.setBackgroundColorResource(R.color.app_red);
        mActionBar.setLineVisibility(View.GONE);
        mActionBar.setTitleVisibility(View.INVISIBLE);
        mActionBar.setTitleImgVisibility(View.VISIBLE);
        mActionBar.setTitleImgResource(R.drawable.ju53);
        mActionBar.setLeftTextVisibility(View.VISIBLE);
        mActionBar.setLeftText("消息");
        mActionBar.setLeftImageResource(R.drawable.icon_message_white);
        mActionBar.setRightVisibility(View.VISIBLE);
        mActionBar.setRightTextVisibility(View.VISIBLE);
        mActionBar.setRightImageResource(R.drawable.icon_search);
        mActionBar.setRightText("搜索");
        mActionBar.setRightTextSize(11);
        mActionBar.setRightTextColor(Color.WHITE);
        initRecyclerView();
    }

    /**
     * 设置瀑布流
     */
    private void initRecyclerView() {
        configRecyclerView();
        setHeaderView();
    }

    /**
     * 设置瀑布流的headView
     */
    private void setHeaderView() {
        if (mInflater == null) {
            return;
        }
        View headView = mInflater.inflate(R.layout.fragment_home_head_view, null, false);
        mViewPager = (CycleViewPager)getFragmentManager().findFragmentById(R.id.fragment_home_head_cycleviewpager);
        mIvTopic1 = (ImageView) headView.findViewById(R.id.main_iv_topic_1);
        mIvTopic2 = (ImageView) headView.findViewById(R.id.main_iv_topic_2);
        mIvTopic3 = (ImageView) headView.findViewById(R.id.main_iv_topic_3);
        mIvTopic4 = (ImageView) headView.findViewById(R.id.main_iv_topic_4);
        mIvTopic5 = (ImageView) headView.findViewById(R.id.main_iv_topic_5);
        mIvTopic6 = (ImageView) headView.findViewById(R.id.main_iv_topic_6);
        mIvTopic7 = (ImageView) headView.findViewById(R.id.main_iv_topic_7);
        mIvTopic8 = (ImageView) headView.findViewById(R.id.main_iv_topic_8);
        mLayoutRecommend = (LinearLayout) headView.findViewById(R.id.main_layout_recommend);
        mLayoutAbout = (LinearLayout) headView.findViewById(R.id.fragment_home_layout_about);
        mUltimateRecyclerView.setNormalHeader(headView);
    }


    /**
     * 设置瀑布流
     */
    private void configRecyclerView() {
        StaggeredGridLayoutManager mgr = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mUltimateRecyclerView.setLayoutManager(mgr);
        //TODO 加载更多操作
        mUltimateRecyclerView.setOnLoadMoreListener(new UltimateRecyclerView.OnLoadMoreListener() {
            @Override
            public void loadMore(int itemsCount, int maxLastVisiblePosition) {
                mPresenter.getRecommends(mCurrentPage);
            }
        });
        mRecycleAdapter = new HomeRecommendReCycleAdapter(mContext, mRecommends);
        mUltimateRecyclerView.enableLoadmore();
        mUltimateRecyclerView.setAdapter(mRecycleAdapter);
        mUltimateRecyclerView.setScrollViewCallbacks(new ObservableScrollViewCallbacks() {
            @Override
            public void onScrollChanged(int scrollY, boolean firstScroll, boolean dragging) {
                if (backFlag) {
                    backFlag = false;
                    return;
                }
                float alphaTitle = mPresenter.getAlpha(scrollY, true);
                float alphaScrollview = mPresenter.getAlpha(scrollY, false);
                mActionBar.getRootLayout().getBackground().setAlpha((int) (alphaTitle * 255));
                if (alphaScrollview <= 0.3) {
                    mIvTotop.setVisibility(View.GONE);
                } else {
                    mIvTotop.setVisibility(View.VISIBLE);
                    mIvTotop.setAlpha((int) (alphaScrollview * 255));
                }
            }

            @Override
            public void onDownMotionEvent() {
            }

            @Override
            public void onUpOrCancelMotionEvent(ObservableScrollState observableScrollState) {
            }
        });
        //TODO 下拉刷新
        mUltimateRecyclerView.setDefaultOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (mPresenter != null) {
                    mCurrentPage = PUSH_START_PAGE;
                    mPresenter.getIndexContent();
                }
            }
        });
    }


    @Override
    public void initContent() {
        mPresenter = new HomePresenter(this);
        mPresenter.initTitleDisappearLength(mContext);
        mCurrentPage = PUSH_START_PAGE;
        mPresenter.getIndexContent();
    }

    /**
     * 获得版本信息
     */
    public void getVersion() {
        if (mPresenter != null) {
            mPresenter.getVersion();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void setListener() {
        setOnNetWorkListener(this);
        mActionBar.setOnLeftClickListener(this);
        mActionBar.setOnRightClickListener(this);
        mIvTopic1.setOnClickListener(this);
        mIvTopic2.setOnClickListener(this);
        mIvTopic3.setOnClickListener(this);
        mIvTopic4.setOnClickListener(this);
        mIvTopic5.setOnClickListener(this);
        mIvTopic6.setOnClickListener(this);
        mIvTopic7.setOnClickListener(this);
        mIvTopic8.setOnClickListener(this);
        mIvTotop.setOnClickListener(this);
        mLayoutAbout.setOnClickListener(this);
    }


    /**
     * 设置banner
     *
     * @param banners
     */
    private void setCycleViewPager(List<IndexEntity> banners) {
        if (ListUtil.isEmpty(banners)) {
            return;
        }
        mBannersImgs.clear();
        mBannersImgs.add(ViewFactory.getImageView(mContext, banners.get(banners.size() - 1) == null ? "" : banners.get(banners.size() - 1).getImgUrl()));
        for (int i = 0; i < banners.size(); i++) {
            mBannersImgs.add(ViewFactory.getImageView(mContext, banners.get(i) == null ? "" : banners.get(i).getImgUrl()));
        }
        mBannersImgs.add(ViewFactory.getImageView(mContext, banners.get(0) == null ? "" : banners.get(0).getImgUrl()));
        mViewPager.setCycle(true);
        mViewPager.setData(mBannersImgs, banners, new MyImageCycleViewListener());
        mViewPager.setWheel(true);
        mViewPager.setTime(3000);
    }

    /**
     * 设置活动/单品
     *
     * @param topics
     */
    private void setTopics(List<IndexEntity> topics) {
        if (ListUtil.isEmpty(topics) || topics.size() < 8) {
            return;
        }
        mTopics.clear();
        mTopics.addAll(topics);

        for (IndexEntity entity : topics) {
            if (entity.getActivityType() == 4) {
                mProducts.add(entity);
            }
        }
        for (IndexEntity entity : topics) {
            int activityType = entity.getActivityType();
            switch (activityType) {
                case 2://活动小图
                    mTopicIndex1 = entity;
                    mPresenter.loadImg(mContext, entity.getImgUrl(), mIvTopic1);
                    break;
                case 3://活动小图
                    mTopicIndex2 = entity;
                    mPresenter.loadImg(mContext, entity.getImgUrl(), mIvTopic2);
                    break;
                case 5://活动大图
                    mTopicIndex8 = entity;
                    mPresenter.loadImg(mContext, entity.getImgUrl(), mIvTopic8);
                    break;
            }
        }
        if (mProducts.size() >= 5) {
            mPresenter.loadImg(mContext, mProducts.get(0).getImgUrl(), mIvTopic3);
            mPresenter.loadImg(mContext, mProducts.get(1).getImgUrl(), mIvTopic4);
            mPresenter.loadImg(mContext, mProducts.get(2).getImgUrl(), mIvTopic5);
            mPresenter.loadImg(mContext, mProducts.get(3).getImgUrl(), mIvTopic6);
            mPresenter.loadImg(mContext, mProducts.get(4).getImgUrl(), mIvTopic7);
        }
    }

    /**
     * 设置推荐宝贝列表
     *
     * @param products
     */
    private void setRecommends(List<IndexEntity> products) {
        if (ListUtil.isEmpty(products)) {
            if (ListUtil.isEmpty(mRecommends)) {
                mLayoutRecommend.setVisibility(View.GONE);
            } else {
                showToast(R.string.home_recommend_finish);
            }
            return;
        }
        mLayoutRecommend.setVisibility(View.VISIBLE);
        if (mCurrentPage == PUSH_START_PAGE) {
            mRecommends.clear();
        }
        mRecommends.addAll(products);
        if (mRecycleAdapter == null) {
            mRecycleAdapter = new HomeRecommendReCycleAdapter(mContext, mRecommends);
            mUltimateRecyclerView.setAdapter(mRecycleAdapter);
        } else {
            mRecycleAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                gotoMessageActivity();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                startActivity(new Intent(mContext, SearchHistoryActivity.class));
                break;
            case R.id.main_iv_topic_1:
                gotoSortFragment(0);
                break;
            case R.id.main_iv_topic_2:
                gotoSortFragment(1);
                break;
            case R.id.main_iv_topic_3:
                gotoSortFragment(2);
                break;
            case R.id.main_iv_topic_4:
                gotoSortFragment(3);
                break;
            case R.id.main_iv_topic_5:
                gotoSortFragment(4);
                break;
            case R.id.main_iv_topic_6:
                gotoSortFragment(5);
                break;
            case R.id.main_iv_topic_7:
                gotoSortFragment(6);
                break;
            case R.id.main_iv_topic_8:
                goBannerActivity(mTopicIndex8);
                break;
            case R.id.fragment_home_layout_about:
                startActivity(new Intent(mContext, AboutUsActivity.class));
                break;
            case R.id.fragment_home_iv_top:
                backToTop();
                break;

        }
    }

    /**
     * 向上返回
     */
    private void backToTop() {
        backFlag = true;
        mUltimateRecyclerView.scrollVerticallyToPosition(0);
        mActionBar.getRootLayout().getBackground().setAlpha(0);
        mIvTotop.setVisibility(View.GONE);
    }


    /**
     * 跳转到“消息activity”
     */
    private void gotoMessageActivity() {
        if (mContext == null) {
            return;
        }

        if (LoginUtil.isLoginNew()) {
            Intent intent = new Intent(mContext, MessageActivity.class);
            startActivity(intent);
        } else {
            LoginUtil.gotoLogin(mContext, LoginActivity.MESSAGE_ACTIVITY_LOGIN_FLAG);
        }
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    /**
     * 跳转到"分类"搜索页面
     */
    private void gotoSortFragment(int index) {
        if (mContext == null || mTopics == null || index >= mTopics.size()) {
            return;
        }
        Intent intent = new Intent(mContext, SearchActivity.class);
        intent.putExtra("key", mTopics.get(index).getTitle());
        intent.putExtra("categoryId", mTopics.get(index).getImgLink());
        mContext.startActivity(intent);

    }


    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {

    }

    @Override
    public void fragmentPause() {
        if (mViewPager != null) {
            mViewPager.setWheel(false);
        }
    }

    @Override
    public void fragmentResume(int position) {
        if (mViewPager != null) {
            mViewPager.setWheel(true);
        }
    }

    private class MyImageCycleViewListener implements CycleViewPager.ImageCycleViewListener {

        @Override
        public void onImageClick(IndexEntity info, int position, View imageView) {
            goBannerActivity(info);
        }
    }

    private void goBannerActivity(IndexEntity info) {
        if(info == null){
            return;
        }
        Intent intent = new Intent(mContext, CommonWebviewActivity.class);
        intent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, info.getTitle());
        intent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, info.getImgLink());
        getActivity().startActivity(intent);
    }

    @Override
    public void onGetIndextContentSuccess(IndexJsonInfo jsonInfo) {
        if (viewVisible) {
            if (jsonInfo != null) {
                setCycleViewPager(jsonInfo.getBanners());
                setTopics(jsonInfo.getTopics());
                setRecommends(jsonInfo.getPushs());
            }
        }
    }

    //首页-第一屏推荐列表
    @Override
    public void onGetIndexContentFailed(int apiErrorCode, String message) {
        mUltimateRecyclerView.setRefreshing(false);
        if (ListUtil.isEmpty(mRecommends)) {
            checkError(apiErrorCode, message);
        }
    }

    //加载更多-推荐列表
    @Override
    public void onGetRecommendsSuccess(List<IndexEntity> products) {
        if (viewVisible) {
            if (!ListUtil.isEmpty(products)) {
                mCurrentPage++;
            }
            setRecommends(products);
        }
    }

    @Override
    public void onGetRecommendsFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onGetVersionSuccess(GetVersionEntity getVersionEntity) {
        double currentCode = PackageUtil.getVersionCode(mContext);
        if (currentCode < getVersionEntity.getCurrent_version()) {
            showUpdateDialog(getVersionEntity);
        }
    }

    private void showUpdateDialog(final GetVersionEntity getVersionEntity) {
        if(mContext == null || getActivity() == null){
            return;
        }
        mBtnDialog = new BtnDialog(mContext, "版本升级", getVersionEntity.getUpdate_desc(), "马上升级", "以后再说",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        gotoWebView(getVersionEntity.getUpdate_url(), "版本升级");
                        mBtnDialog.dismiss();
                    }
                }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBtnDialog.dismiss();
            }
        });
        mBtnDialog.show();
    }

    private void gotoWebView(String url, String title) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        Intent intent = new Intent(mContext, CommonWebviewActivity.class);
        intent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, title);
        intent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, url);
        getActivity().startActivity(intent);
    }


    @Override
    public void onGetVersionFailed(String message) {

    }

    @Override
    public void onNetWorkConnected() {
        if (mPresenter == null) {
            return;
        }
        if (mTopics.size() == 0 || mProducts.size() == 0 || mRecommends.size() == 0) {
            mPresenter.getIndexContent();
        }
    }
}
