package com.loonxi.ju53.views;

/**
 * 更新密码View
 * Created by laojiaqi on 2016/2/17.
 */
public interface IUpdatePasswordView {
    public void onUpdatePasswordSuccess(String message);
    public void onUpdatePasswordFailure(String message);
}
