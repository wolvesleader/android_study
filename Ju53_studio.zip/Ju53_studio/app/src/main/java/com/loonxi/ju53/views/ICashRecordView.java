package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.entity.CashRecordInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public interface ICashRecordView extends IBaseView {
    void getCashRecordSuccess(JsonInfo<CashRecordInfo> records);
    void getCashRecordFailed(int apiErrorCode, String message);
}
