package com.loonxi.ju53.views;

import android.view.View;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartCheckEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/30.
 */
public interface IShoppingView extends IBaseView {
    void showToast(int resId);

    void onGetCartsSuccess(JsonArrayInfo<CartEntity> carts);

    void onGetCartsFailed(int apiErrorCode, String message);

    void onDeleteOneProductSuccess(CartEntity cart, BaseProductEntity product);

    void onDeleteOneProductFailed(int apiErrorCode, String message);

    void onDeleteMultiProductsSuccess(List<CartCheckEntity> carts);

    void onDeleteMultiProductsFailed(int apiErrorCode, String message);

    void onUpdateCartSuccess();

    void onUpdateCartFailed(int apiErrorCode, String message);

    void onGetSkuSuccess(View view, CartEntity cart, BaseProductEntity product, ProductAttributeEntity attribute);

    void onGetSkuFailed(int apiErorCode, String message);

    void onMoveToFavSuccess(List<CartCheckEntity> carts);

    void onMoveToFavFailed(int apiErrorCode, String message);
}
