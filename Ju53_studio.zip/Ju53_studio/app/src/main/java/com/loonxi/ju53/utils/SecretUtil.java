package com.loonxi.ju53.utils;

import java.util.List;

public class SecretUtil {

    /**
     * 将byte数组转换为表示16进制值的字符串， 如：byte[]{8,18}转换为：0813， 和public static byte[]
     * hexStr2ByteArr(String strIn) 互为可逆的转换过程
     *
     * @param arrB 需要转换的byte数组
     * @return 转换后的字符串
     * @throws Exception
     */
    public static String byteArr2HexStr(byte[] arrB) throws Exception {
        int iLen = arrB.length;
        // 每个byte用两个字符才能表示，所以字符串的长度是数组长度的两倍
        StringBuffer sb = new StringBuffer(iLen * 2);
        for (int i = 0; i < iLen; i++) {
            int intTmp = arrB[i];
            // 把负数转换为正数
            while (intTmp < 0) {
                intTmp = intTmp + 256;
            }
            // 小于0F的数需要在前面补0
            if (intTmp < 16) {
                sb.append("0");
            }
            sb.append(Integer.toString(intTmp, 16));
        }
        return sb.toString();
    }

    /**
     * 将表示16进制值的字符串转换为byte数组， 和public static String byteArr2HexStr(byte[] arrB)
     * 互为可逆的转换过程
     *
     * @param strIn 需要转换的字符串
     * @return 转换后的byte数组
     * @throws Exception
     */
    public static byte[] hexStr2ByteArr(String strIn) throws Exception {
        byte[] arrB = strIn.getBytes();
        int iLen = arrB.length;

        // 两个字符表示一个字节，所以字节数组长度是字符串长度除以2
        byte[] arrOut = new byte[iLen / 2];
        for (int i = 0; i < iLen; i = i + 2) {
            String strTmp = new String(arrB, i, 2);
            arrOut[i / 2] = (byte) Integer.parseInt(strTmp, 16);
        }
        return arrOut;
    }

    /**
     * 加密字节数组
     *
     * @param arrB 需加密的字节数组
     * @return 加密后的字节数组
     * @throws Exception
     */
    public static byte[] encrypt(byte[] arrB) throws Exception {
        return AesSecretUtil.aesEncrypt(arrB);
    }

    /**
     * 加密字符串
     *
     * @param strIn 需加密的字符串
     * @return 加密后的字符串
     * @throws Exception
     */
    public static String encryptMode(String strIn) throws Exception {
        return byteArr2HexStr(encrypt(strIn.getBytes()));
    }

    /**
     * 解密字节数组
     *
     * @param arrB 需解密的字节数组
     * @return 解密后的字节数组
     * @throws Exception
     */
    public static byte[] decrypt(byte[] arrB) throws Exception {
        return AesSecretUtil.aesDecrypt(arrB);
    }

    /**
     * 解密字符串
     *
     * @param strIn 需解密的字符串
     * @return 解密后的字符串
     * @throws Exception
     */
    public static String decryptMode(String strIn) throws Exception {
        try {
            return new String(decrypt(hexStr2ByteArr(strIn)));
        } catch (Exception e) {
            return "";
        }
    }

    public static String joinBusKey(String appKey, long userId, String attName) {
        return appKey + "|" + userId + "|" + attName;
    }

    public static String[] cutBusKey(String joinBusKey) {
        return joinBusKey.split("\\|");
    }

    public static String getBusCipherText(String appKey, long userId, String attName) throws Exception {
        String joinBuskey = joinBusKey(appKey, userId, attName);
        return SecretUtil.encryptMode(joinBuskey);
    }

    public static long getBusUserId(String ciphertext) throws Exception {
        String joinBusKey = SecretUtil.decryptMode(ciphertext);
        String[] keys = cutBusKey(joinBusKey);
        return Long.parseLong(keys[2]);
    }

    public static long getSuperUserId(String ciphertext) throws Exception {
        String joinBusKey = SecretUtil.decryptMode(ciphertext);
        String[] keys = joinBusKey.split("_");
        return Long.parseLong(keys[4]);

    }

    public static String getSuperCipherText(String appKey, long userId) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append(appKey).append("_").append(System.currentTimeMillis()).append("_").append((int) Math.ceil(Math.random() * 1000)).append("_").append((int) Math.ceil(Math.random() * 1000)).append("_").append(userId);
        return SecretUtil.encryptMode(sb.toString());
    }

    public static String getSuperCipherTextIp(String appKey, long userId, String attName, String ip) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append(appKey).append("_").append(System.currentTimeMillis()).append("_").append((int) Math.ceil(Math.random() * 1000)).append("_").append((int) Math.ceil(Math.random() * 1000)).append("_").append(userId).append("_").append(ip);
        return SecretUtil.encryptMode(sb.toString());
    }

    public static int banarySearch(List<Long> list, long num) {
        int begin = 0;
        int end = list.size() - 1;
        do {
            if (begin == end) {
                if (list.get(begin) >= num) {
                    return begin;
                } else {
                    return -1;
                }
            }
            int searchIndex = (end + begin) / 2;
            if (list.get(searchIndex) >= num && list.get(searchIndex - 1) < num) {
                return searchIndex;
            }
            if (list.get(searchIndex) < num) {
                begin = searchIndex + 1;
            } else {
                end = searchIndex - 1;
            }
        } while (true);
    }

    public static Long ip2Long(String ip) {
        if (ip == null) return null;
        if (ip == null || "".equals(ip)) return null;
        String[] temp = ip.split("\\.");
        try {
            long _1 = Integer.parseInt((temp[0]));
            long _2 = Integer.parseInt((temp[1]));
            long _3 = Integer.parseInt((temp[2]));
            long _4 = Integer.parseInt((temp[3]));
            return new Long((_1 << 24) + (_2 << 16) + (_3 << 8) + _4);
        } catch (Exception e) {
        }
        return -1L;
    }
    
    public static void main(String[] args) throws Exception {
    	System.out.println(encryptMode("13958880130"));
	}
    

}
