package com.loonxi.ju53.entity;

import java.io.Serializable;
import java.util.List;

/**
 * Created by laojiaqi on 2016/6/2.
 */
public class MainListEntity   implements Serializable
{

    /**
     * message : success
     * flag : 1
     * data : {"crossband":[{"child":[{"module_id":"12","img":"/ju53/146475121129699.jpg","module_name":"活动下随便","url":"www.jaa.com"},{"module_id":"11","img":"/ju53/146485804711746.jpg","module_name":"活动下打折","url":"sss.sds.com"},{"module_id":"10","img":null,"module_name":"活动下拼团","url":"www.sdasd/2124231/54234.html"}],"module_id":"9","module_name":"活动模块一"},{"child":[],"module_id":"13","module_name":"活动模块二"}]}
     */
    private String message;
    private String flag;
    private DataEntity data;

    public void setMessage(String message) {
        this.message = message;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public String getFlag() {
        return flag;
    }

    public DataEntity getData() {
        return data;
    }

    public class DataEntity {
        /**
         * crossband : [{"child":[{"module_id":"12","img":"/ju53/146475121129699.jpg","module_name":"活动下随便","url":"www.jaa.com"},{"module_id":"11","img":"/ju53/146485804711746.jpg","module_name":"活动下打折","url":"sss.sds.com"},{"module_id":"10","img":null,"module_name":"活动下拼团","url":"www.sdasd/2124231/54234.html"}],"module_id":"9","module_name":"活动模块一"},{"child":[],"module_id":"13","module_name":"活动模块二"}]
         */
        private List<CrossbandEntity> crossband;

        public void setCrossband(List<CrossbandEntity> crossband) {
            this.crossband = crossband;
        }

        public List<CrossbandEntity> getCrossband() {
            return crossband;
        }

        public class CrossbandEntity {
            /**
             * child : [{"module_id":"12","img":"/ju53/146475121129699.jpg","module_name":"活动下随便","url":"www.jaa.com"},{"module_id":"11","img":"/ju53/146485804711746.jpg","module_name":"活动下打折","url":"sss.sds.com"},{"module_id":"10","img":null,"module_name":"活动下拼团","url":"www.sdasd/2124231/54234.html"}]
             * module_id : 9
             * module_name : 活动模块一
             */
            private List<ChildEntity> child;
            private String module_id;
            private String module_name;

            public void setChild(List<ChildEntity> child) {
                this.child = child;
            }

            public void setModule_id(String module_id) {
                this.module_id = module_id;
            }

            public void setModule_name(String module_name) {
                this.module_name = module_name;
            }

            public List<ChildEntity> getChild() {
                return child;
            }

            public String getModule_id() {
                return module_id;
            }

            public String getModule_name() {
                return module_name;
            }

            public class ChildEntity {
                /**
                 * module_id : 12
                 * img : /ju53/146475121129699.jpg
                 * module_name : 活动下随便
                 * url : www.jaa.com
                 */
                private String module_id;
                private String img;
                private String module_name;
                private String url;

                public void setModule_id(String module_id) {
                    this.module_id = module_id;
                }

                public void setImg(String img) {
                    this.img = img;
                }

                public void setModule_name(String module_name) {
                    this.module_name = module_name;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getModule_id() {
                    return module_id;
                }

                public String getImg() {
                    return img;
                }

                public String getModule_name() {
                    return module_name;
                }

                public String getUrl() {
                    return url;
                }
            }
        }
    }
}
