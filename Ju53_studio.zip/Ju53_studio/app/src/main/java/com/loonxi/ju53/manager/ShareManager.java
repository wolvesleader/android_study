package com.loonxi.ju53.manager;

import android.app.Activity;
import android.content.Context;

import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.view.UMFriendListener;

/**
 * 友盟分享管理类
 * Created by Xuzue on 2016/4/7.
 */
public class ShareManager {

    /**
     * 授权
     *
     * @param context
     * @param platform
     * @param authListener
     */
    public static void auth(Context context, SHARE_MEDIA platform, UMAuthListener authListener) {
        if (context == null) {
            return;
        }
        UMShareAPI mShareAPI = UMShareAPI.get(context);
        mShareAPI.doOauthVerify((Activity) context, platform, authListener);
    }

    /**
     * 取消授权
     *
     * @param context
     * @param platform
     * @param delAuthListener
     */
    public static void delAuth(Context context, SHARE_MEDIA platform, UMAuthListener delAuthListener) {
        if (context == null) {
            return;
        }
        UMShareAPI mShareAPI = UMShareAPI.get(context);
        mShareAPI.deleteOauth((Activity) context, platform, delAuthListener);
    }

    /**
     * 获取用户信息
     *
     * @param context
     * @param platform
     * @param authListener
     */
    public static void getUserInfo(Context context, SHARE_MEDIA platform, UMAuthListener authListener) {
        if (context == null) {
            return;
        }
        UMShareAPI mShareAPI = UMShareAPI.get(context);
        mShareAPI.getPlatformInfo((Activity) context, platform, authListener);
    }

    /**
     * 获取好友信息
     *
     * @param context
     * @param platform
     * @param friendListener
     */
    public static void getFriend(Context context, SHARE_MEDIA platform, UMFriendListener friendListener) {
        if (context == null) {
            return;
        }
        UMShareAPI mShareAPI = UMShareAPI.get(context);
        mShareAPI.getFriend((Activity) context, platform, friendListener);
    }


}
