package com.loonxi.ju53.views;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public interface IStoreManageView extends IBaseView{
    void getBaseInfoSuccess();
    void getBaseInfoFailed(int apiErrorCode, String message);
    void altHeadSuccess();
    void altHeadFailed(int apiErrorCode, String message);
}
