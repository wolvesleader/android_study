package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.AddressInfoEntity;
import com.loonxi.ju53.models.impl.OperateAddressModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IAddressInfoView;
import com.loonxi.ju53.views.IUpdateAddressView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * 修改，新建 （国内）收货地址 presenter
 * Created by Administrator on 2016/1/26.
 */
public class DomesticAddressOperatePresenter extends BasePresenter<IAddressInfoView>{

    private OperateAddressModel mModel;
    private IAddressInfoView mView;
    public DomesticAddressOperatePresenter(IAddressInfoView view) {
        super(view);
        mView=getView();
        mModel=new OperateAddressModel();

    }

    /**
     * 获取各个地区的数据
     */
    public void getAddressInfo(){
        mModel.getAddressInfoEntity(new Callback<JsonArrayInfo<AddressInfoEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<AddressInfoEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<AddressInfoEntity> data, Retrofit retrofit) {
                mView.getAddressInfoSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                ToastUtil.showToast(message,false);
            }
        });
    }

    /**
     * 保存收货地址
     */
    public void saveAddress(AddressEntity addressEntity){
        //TODO
        Map<String,Object> map= PrefsRepos.getObjectMap();
        map.put("contact",addressEntity.getContact());
        map.put("phone",addressEntity.getPhones());
        map.put("regionId",addressEntity.getRegionId());
        map.put("isDefault",addressEntity.getIsDefault());
        map.put("address",addressEntity.getAddress());
        map.put("detailAddress",addressEntity.getDetailAddress());

        mModel.saveAddress(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressFailure(message);
            }
        });
    }

    /**
     * 修改收货地址
     */
    public void updateAddress(AddressEntity addressEntity){
        //TODO
        Map<String,Object> map= PrefsRepos.getObjectMap();
        map.put("contact",addressEntity.getContact());
        map.put("phone",addressEntity.getPhones());
        map.put("regionId",addressEntity.getRegionId());
        map.put("isDefault",addressEntity.getIsDefault());
        map.put("address",addressEntity.getAddress());
        map.put("pid",addressEntity.getPid());
        map.put("detailAddress",addressEntity.getDetailAddress());

        mModel.updateAddress(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                ((IUpdateAddressView) mView).updateAddressFailure(message);
            }
        });
    }
}
