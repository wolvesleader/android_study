package com.loonxi.ju53.fragment.accountSafe;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.presenters.UpdatePasswordPresenter;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IUpdatePasswordView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * "知道密码：重置密码"
 * Created by laojiaqi on 2016/2/17.
 */
public class AccountSafeResetPasswordFragment extends BaseSafeFragment<IUpdatePasswordView, UpdatePasswordPresenter> implements View.OnClickListener, IUpdatePasswordView {

    public static final String TAG = "AccountSafeResetPasswordFragment";
    private int mCurrentType;
    private String mMobile;
    @ViewInject(R.id.fragment_account_safe_reset_old_password)
    private TextView mOldPasswordText;
    @ViewInject(R.id.fragment_account_safe_reset_new_password)
    private TextView mNewPasswordText;
    @ViewInject(R.id.fragment_account_safe_reset_confirm)
    private TextView mConfirm;
    @ViewInject(R.id.fragment_account_safe_reset_action_bar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_account_safe_reset_new_password_edit)
    private EditText mNewPasswordEdit;
    @ViewInject(R.id.fragment_account_safe_reset_old_password_edit)
    private EditText mOldPasswordEdit;
    @ViewInject(R.id.fragment_account_safe_reset_old_password_layout)
    private LinearLayout mOldPasswordLayout;
    @ViewInject(R.id.fragment_account_safe_reset_old_password_line)
    private View mInnerLineView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getData();

    }

    @Override
    protected UpdatePasswordPresenter createPresenter(IUpdatePasswordView iUpdatePasswordView) {
        return new UpdatePasswordPresenter(this);
    }


    private void getData() {
        Bundle bundle = getArguments();
        mCurrentType = bundle.getInt(AccountSafeTypeFragment.UPDATE_TYPE);
        mMobile = bundle.getString(AccountSafeLoginPasswordFragment.LOGIN_MOBILE_FLAG, "");
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account_safe_reset_password, null);
        x.view().inject(view);
        return view;
    }

    @Override
    public void initView() {
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD) {
            mActionBar.setTitle(R.string.account_safe_login_title);
            mNewPasswordText.setText(getString(R.string.account_safe_login_new_password));
            mOldPasswordText.setText(getString(R.string.account_safe_login_old_password));
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_PAY_PASSWORD) {
            mActionBar.setTitle(R.string.account_safe_pay_title);
            mNewPasswordText.setText(getString(R.string.account_safe_pay_new_password));
            mOldPasswordText.setText(getString(R.string.account_safe_pay_old_password));
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_FORGET_LOGIN_PASSWORD) {
            mActionBar.setTitle(R.string.account_safe_login_title);
            mOldPasswordLayout.setVisibility(View.GONE);
            mInnerLineView.setVisibility(View.GONE);
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_FORGET_PAY_PASSWORD) {
            mActionBar.setTitle(R.string.account_safe_pay_title);
            mOldPasswordLayout.setVisibility(View.GONE);
            mInnerLineView.setVisibility(View.GONE);
            return;
        }
    }

    @Override
    public void initContent() {
    }

    @Override
    public void setListener() {
        mConfirm.setOnClickListener(this);
        mActionBar.setOnLeftClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.fragment_account_safe_reset_confirm:
                confirm();
                break;
        }
    }

    private void confirm() {
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD) {
            String oldPassword = mOldPasswordEdit.getText().toString();
            String newPassword = mNewPasswordEdit.getText().toString();
            mPresenter.updateLoginPassword(newPassword, oldPassword);
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_PAY_PASSWORD) {
            String oldPassword = mOldPasswordEdit.getText().toString();
            String newPassword = mNewPasswordEdit.getText().toString();
            mPresenter.updatePayPassword(newPassword, oldPassword);
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_FORGET_LOGIN_PASSWORD) {
            String newPassword = mNewPasswordEdit.getText().toString();
            String phone = getPhone();
            mPresenter.resetLoginPassword(newPassword, phone);
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_FORGET_PAY_PASSWORD) {
            //TODO 重置支付密码
            String newCashPassword = mNewPasswordEdit.getText().toString();
            String phone = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_MOBILE);
            mPresenter.resetPayPassword(newCashPassword, phone);
            return;
        }

    }

    /**
     * 获得手机号
     * 1.从“忘记密码入口来”，则直接获取mMobile
     * 2.从“我的”来,则读取sp中mobile
     *
     * @return
     */
    private String getPhone() {
        if (!TextUtils.isEmpty(mMobile)) {
            return mMobile;
        }
        return SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_MOBILE);
    }


    private void goBack() {
        getFragmentManager().popBackStack();
    }

    @Override
    public void onUpdatePasswordSuccess(String message) {
        ToastUtil.showShortToast(message);
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_FORGET_PAY_PASSWORD ||
                mCurrentType == AccountSafeTypeFragment.UPDATE_PAY_PASSWORD) {
            if (getActivity() != null) {
                getActivity().finish();
                return;
            }
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_FORGET_LOGIN_PASSWORD ||
                mCurrentType == AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD) {
            logout();
        }
    }

    /**
     * 1.调用退出登录接口 2.清除本地cookie 3.清除登录状态 4.结束该activity 5.跳转到主页
     */
    private void logout() {
        if (getActivity() == null) {
            return;
        }

        mPresenter.logout();
        gotoMainActivity();
        LoginUtil.logout(getActivity());
    }


    /**
     * 跳转到 “首页”
     */
    private void gotoMainActivity() {
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, MainActivity.RESET_ACCOUNT_LOGIN_PASSWORD);
        getActivity().startActivity(intent);
    }


    @Override
    public void onUpdatePasswordFailure(String message) {
        ToastUtil.showShortToast(message);
    }
}
