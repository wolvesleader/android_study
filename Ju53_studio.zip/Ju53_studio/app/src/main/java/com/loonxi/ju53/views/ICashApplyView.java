package com.loonxi.ju53.views;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public interface ICashApplyView extends IBaseView {
    void cashApplySuccess();
    void cashApplyFailed(int apiErrorCode, String message);
}
