package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.MainTabEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * Created by Xuzue on 2015/12/18.
 */
public interface ITabHomeView   extends  IBaseView{
    void onGetTabListDataSuccess(JsonArrayInfo<MainTabEntity> data);
    void onGetTabListDataFailed(int apiErrorCode, String message);
    void onGetVersionSuccess(GetVersionEntity getVersionEntity);
    void onGetVersionFailed(String message);
}
