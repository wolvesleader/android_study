package com.loonxi.ju53.utils;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;


/**
 * Toast提示工具类
 * Created by Xuze on 2015/9/5.
 */
public class ToastUtil {

    public static void showToast(Context context, String text) {
        showToast(context, text, Toast.LENGTH_SHORT);
    }

    public static void showToast(Context context, int resId){
        if(context == null){
            return;
        }
        showToast(context, context.getResources().getString(resId), Toast.LENGTH_SHORT);
    }

    public static void showToast(Context context, String text, boolean isLong){
        if(isLong){
            showToast(context, text, Toast.LENGTH_LONG);
        }else{
            showToast(context, text, Toast.LENGTH_SHORT);
        }
    }

    public static void showToast(Context context, int resId, String text) {
        showToast(context, resId, text, Toast.LENGTH_SHORT, Gravity.BOTTOM);
    }

    public static void showToast(Context context, String text, int duration) {
        showToast(context, -1, text, duration, Gravity.BOTTOM);
    }

    public static void showToast(Context context, int resId, String text, int duration, int gravity) {
        if (context == null) {
            return;
        }
        TextView tv;
        ImageView iv;
        Toast toast = null;
        context= BaseApplication.getInstance();//防止内存泄漏
        LinearLayout view = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.include_toast, null);
        tv = (TextView) view.findViewById(R.id.toast_tv_content);
        iv = (ImageView) view.findViewById(R.id.toast_iv);
        toast = new Toast(context.getApplicationContext());
        toast.setView(view);
        toast.setDuration(duration);
        toast.setGravity(gravity, 0, 0);
        tv.setText(text);
        if (resId > 0) {
            iv.setVisibility(View.VISIBLE);
            iv.setBackgroundResource(resId);
        } else {
            iv.setVisibility(View.GONE);
        }
        toast.show();
    }


    public static void showToast( String text, boolean isLong){
       Context context= BaseApplication.getInstance();//防止内存泄漏
        if(isLong){
            showToast(context, text, Toast.LENGTH_LONG);
        }else{
            showToast(context, text, Toast.LENGTH_SHORT);
        }
    }

    public static void showShortToast( String text){
        Context context= BaseApplication.getInstance();//防止内存泄漏
        showToast(context, text, Toast.LENGTH_SHORT);

    }

}
