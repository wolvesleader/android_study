package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.MessageArrayEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 *
 * Created by laojiaqi on 2016/2/2.
 */
public interface MessageService {


    /**
     * 获得消息
     * @param map
     */
    @FormUrlEncoded
    @POST("user/core/message")
    Call<MessageArrayEntity> getMessage(@FieldMap Map<String, Object> map);

    /**
     * 设置已读消息
     * @param map
     */
    @FormUrlEncoded
    @POST("user/core/updateMessage")
    Call<BaseJsonInfo> setReadFlag(@FieldMap Map<String, Object> map);

    /**
     * 获得物流信息
     * @param map
     */
    @FormUrlEncoded
    @POST("user/core/orderTrans")
    Call<JsonInfo<LogisticsEntity>> getLogistics(@FieldMap Map<String, Object> map);

}
