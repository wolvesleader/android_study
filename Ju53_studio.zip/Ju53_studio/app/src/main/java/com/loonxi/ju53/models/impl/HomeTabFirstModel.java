package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.MainBannderEntity;
import com.loonxi.ju53.entity.MainListEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.service.IHomeTabViewServer;

import java.util.Map;

import retrofit.Call;

/**
 * Created by laojiaqi on 2016/6/1.
 */
public class HomeTabFirstModel
{

    /**
     * 获取主界面上半页数据
     * @return
     */
    public Call<MainBannderEntity> getTopListData(Map<String, Object> map, Callback<MainBannderEntity> callback)
    {
        Call<MainBannderEntity> call = NewRequest.creatApi(IHomeTabViewServer.class).getTopListData(map);
        call.enqueue(callback);
        return call;
    }
    /**
     * 获取热门活动数据
     * @return
     */
    public Call<MainListEntity> getHotActivity(Map<String, Object> map, Callback<MainListEntity> callback)
    {
        Call<MainListEntity> call = NewRequest.creatApi(IHomeTabViewServer.class).getMainListData(map);
        call.enqueue(callback);
        return null;
    }


}
