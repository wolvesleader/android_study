package com.loonxi.ju53.manager;

import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.alipay.sdk.app.PayTask;
import com.loonxi.ju53.R;
import com.loonxi.ju53.listener.AlipayListener;
import com.loonxi.ju53.modules.open.alipay.PayResult;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;

import java.lang.ref.WeakReference;

/**
 * Created by Xuzue on 2016/1/26.
 */
public class AlipayManager {

    private static final int SDK_PAY_FLAG = 1;
    private static final int SDK_CHECK_FLAG = 2;

    private static WeakReference<AlipayListener> mListener;
    private static double mPayMoney;
    private static String mOrderId;

    public void pay(final Activity activity, final String mPayInfo, final AlipayListener listener){
        pay(activity, mPayInfo, listener, 0, "");
    }

    public void pay(final Activity activity, final String mPayInfo, final AlipayListener listener, double payMoney, String orderId) {
        if (StringUtil.isEmpty(mPayInfo)) {
            ToastUtil.showToast(activity, activity.getResources().getString(R.string.error_order_info));
            return;
        }
        mPayMoney = payMoney;
        mOrderId = orderId;
        final MyHandler myHandler = new MyHandler(listener);

        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(activity);
                // 调用支付接口，获取支付结果
                String result = alipay.pay(mPayInfo, true);
                Message msg = Message.obtain();
                msg.what = SDK_PAY_FLAG;
                msg.obj = result;
                myHandler.sendMessage(msg);
            }
        };
        ThreadPoolManager.executeTask(payRunnable);
    }

    private static class MyHandler extends Handler {

        public MyHandler(AlipayListener listener) {
            mListener = new WeakReference<AlipayListener>(listener);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SDK_PAY_FLAG: {
                    PayResult payResult = new PayResult((String) msg.obj);
                    // 支付宝返回此次支付结果及加签，建议对支付宝签名信息拿签约时支付宝提供的公钥做验签
                    String resultInfo = payResult.getResult();
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
                    if (TextUtils.equals(resultStatus, "9000")) {
                        if (mListener != null && mListener.get() != null) {
                            mListener.get().onAlipaySuccess(mPayMoney, mOrderId);
                        }
                    } else if (TextUtils.equals(resultStatus, "6001")) {
                        if (mListener != null && mListener.get() != null) {
                            mListener.get().onAlipayCancel();
                        }
                    } else if (TextUtils.equals(resultStatus, "8000")) {
                        // “8000”代表支付结果因为支付渠道原因或者系统原因还在等待支付结果确认，最终交易是否成功以服务端异步通知为准（小概率状态）
                        if (mListener != null && mListener.get() != null) {
                            mListener.get().onAlipayConfirming();
                        }
                    } else {
                        // 其他值就可以判断为支付失败，包括用户主动取消支付，或者系统返回的错误
                        if (mListener != null && mListener.get() != null) {
                            mListener.get().onAlipayFailed();
                        }
                    }
                    break;
                }
                case SDK_CHECK_FLAG: {

                    break;
                }
                default:
                    break;
            }
        }
    }


}
