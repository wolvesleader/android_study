package com.loonxi.ju53.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.List;

/**
 * Created by laojiaqi on 2016/6/1.
 */
public class HomeTabFirstRecycleAdapter extends UltimateViewAdapter<HomeTabFirstRecycleAdapter.HomeRecommendViewHolder> {

    private List<String> mDatas;
    private Context mContext;

    public HomeTabFirstRecycleAdapter(Context context, List<String> datas) {
        this.mContext = context;
        this.mDatas = datas;
    }


    @Override
    public HomeRecommendViewHolder getViewHolder(View view) {
        return new HomeRecommendViewHolder(view);
    }


    @Override
    public HomeRecommendViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.listitem_main_hot, parent, false);
        HomeRecommendViewHolder viewHolder = new HomeRecommendViewHolder(v);
        return viewHolder;
    }

    @Override
    public int getAdapterItemCount() {
        return mDatas == null ? 0 : mDatas.size();
    }

    @Override
    public long generateHeaderId(int position) {
        return 0;
    }

    @Override
    public void onBindViewHolder(HomeRecommendViewHolder holder, int position) {

        if (position > 0) {

            String item = mDatas.get(position - 1);
            //处理业务
            //设置title
            holder.tv_host_huodong.setText(item);
            //设置内容图片
            Glide.with(mContext).load("http://s7.mogucdn.com/p1/160314/2p_ifrtamjrgjstoyrug4zdambqhayde_428x174.jpg").into(holder.iv_pic_bander);

        }


    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    public class HomeRecommendViewHolder extends UltimateRecyclerviewViewHolder {
        ImageView iv_pic_bander;
        TextView tv_host_huodong;

        public HomeRecommendViewHolder(View itemView) {
            super(itemView);

            iv_pic_bander = (ImageView) itemView.findViewById(R.id.iv_pic_bander);
            tv_host_huodong = (TextView) itemView.findViewById(R.id.tv_host_huodong);
        }
    }
}
