package com.loonxi.ju53.utils;

import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;

import com.loonxi.ju53.utils.bean.AppInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Package/AndroidManifest工具类
 * Created by Xuze on 2015/9/4.
 */
public class PackageUtil {

    /**
     * 获取包名
     *
     * @param context
     * @return
     */
    public static String getPackageName(Context context) {
        if (context == null) {
            return null;
        }
        return context.getPackageName();
    }

    /**
     * 获取versionCode
     *
     * @param context
     * @return
     */
    public static int getVersionCode(Context context) {
        if (context == null) {
            return -1;
        }
        PackageManager manager = context.getPackageManager();
        if (manager == null) {
            return -1;
        }
        try {
            PackageInfo packageInfo = manager.getPackageInfo(context.getPackageName(), 0);
            if (packageInfo != null) {
                return packageInfo.versionCode;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * 获取versionName
     *
     * @param context
     * @return
     */
    public static String getVersionName(Context context) {
        PackageManager manager = context.getPackageManager();
        if (context == null || manager == null) {
            return null;
        }
        try {
            PackageInfo packageInfo = manager.getPackageInfo(context.getPackageName(), 0);
            if (packageInfo != null) {
                return packageInfo.versionName;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取Application元素中的meta-data值
     *
     * @param context
     * @param metaKey key
     * @return
     */
    public static String getMetaDataInApplication(Context context, String metaKey) {
        if (context == null || StringUtil.isEmpty(metaKey)) {
            return null;
        }
        try {
            PackageManager manager = context.getPackageManager();
            if (null == manager) {
                return null;
            }
            ApplicationInfo applicationInfo = manager.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            if (null != applicationInfo && null != applicationInfo.metaData) {
                return applicationInfo.metaData.getString(metaKey);
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取<activity></activity>里的meta-data元素值
     *
     * @param context
     * @param activity
     * @param metaKey
     * @return
     */
    public static String getMetaDataInActivity(Context context, Activity activity, String metaKey) {
        if (context == null || activity == null || StringUtil.isEmpty(metaKey)) {
            return null;
        }
        try {
            PackageManager manager = context.getPackageManager();
            if (null == manager) {
                return null;
            }
            ActivityInfo info = manager.getActivityInfo(activity.getComponentName(), PackageManager.GET_META_DATA);
            if (null == info || null == info.metaData) {
                return null;
            }
            return info.metaData.getString(metaKey);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取<service></service>里的meta-data元素值
     *
     * @param context
     * @param service
     * @param metaKey
     * @return
     */
    public static String getMetaDataInService(Context context, Service service, String metaKey) {
        if (context == null || service == null || StringUtil.isEmpty(metaKey)) {
            return null;
        }
        PackageManager manager = context.getPackageManager();
        if (null == manager) {
            return null;
        }
        ComponentName cn = new ComponentName(context, service.getClass());
        try {
            ServiceInfo info = manager.getServiceInfo(cn, PackageManager.GET_META_DATA);
            if (null == info || null == info.metaData) {
                return null;
            }
            return info.metaData.getString(metaKey);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取<receiver></receiver>里的meta-data元素值
     *
     * @param context
     * @param receiver
     * @param metaKey
     * @return
     */
    public static String getMetaDataInReceiver(Context context, BroadcastReceiver receiver, String metaKey) {
        if (context == null || receiver == null || StringUtil.isEmpty(metaKey)) {
            return null;
        }
        PackageManager manager = context.getPackageManager();
        if (null == manager) {
            return null;
        }
        ComponentName cn = new ComponentName(context, receiver.getClass());
        try {
            ActivityInfo info = manager.getActivityInfo(cn, PackageManager.GET_META_DATA);
            if (null == info || null == info.metaData) {
                return null;
            }
            return info.metaData.getString(metaKey);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取AndroidManifest.xml文件里所有的activity元素
     *
     * @param context
     * @return
     */
    public static ActivityInfo[] getActivities(Context context) {
        if (context == null) {
            return null;
        }
        try {
            PackageManager manager = context.getPackageManager();
            if (null == manager) {
                return null;
            }
            PackageInfo packageInfo = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_ACTIVITIES);
            if (null != packageInfo) {
                ActivityInfo[] activities = packageInfo.activities;
                if (!ArrayUtil.isEmpty(activities)) {
                    for (ActivityInfo activityInfo : activities) {
                        LogUtil.mLog().d("name:" + activityInfo.name);
                        LogUtil.mLog().d(" oriention:" + activityInfo.screenOrientation);
                        LogUtil.mLog().d(" lanchMode:" + activityInfo.launchMode + "\n");
                    }
                } else {
                    LogUtil.mLog().d("no activity");
                }
                return activities;
            }

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取AndroidManifest.xml文件里所有的service元素
     *
     * @param context
     * @return
     */
    public static ServiceInfo[] getServices(Context context) {
        if (context == null) {
            return null;
        }
        PackageManager manager = context.getPackageManager();
        if (null == manager) {
            return null;
        }
        try {
            PackageInfo packageInfo = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_SERVICES);
            if (null != packageInfo) {
                ServiceInfo[] services = packageInfo.services;
                if (!ArrayUtil.isEmpty(services)) {
                    for (ServiceInfo serviceInfo : services) {
                        LogUtil.mLog().d("name:" + serviceInfo.name);
                    }
                } else {
                    LogUtil.mLog().d("no service");
                }
                return services;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取AndroidManifest.xml文件里所有的receiver元素
     *
     * @param context
     * @return
     */
    public static ActivityInfo[] getReceivers(Context context) {
        if (context == null) {
            return null;
        }
        PackageManager manager = context.getPackageManager();
        if (null == manager) {
            return null;
        }
        try {
            PackageInfo packageInfo = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_RECEIVERS);
            if (null == packageInfo) {
                return null;
            }
            ActivityInfo[] receivers = packageInfo.receivers;
            if (!ArrayUtil.isEmpty(receivers)) {
                for (ActivityInfo receiver : receivers) {
                    LogUtil.mLog().d(receiver.name);
                }
            } else {
                LogUtil.mLog().d("no receiver");
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取所有权限信息
     *
     * @param context
     * @return
     */
    public static String[] getPermissions(Context context) {
        if (context == null) {
            return null;
        }
        PackageManager manager = context.getPackageManager();
        if (manager == null) {
            return null;
        }
        try {
            PackageInfo packageInfo = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_PERMISSIONS);
            if (packageInfo == null) {
                return null;
            }
            String[] infos = packageInfo.requestedPermissions;
            if (ArrayUtil.isEmpty(infos)) {
                LogUtil.mLog().d("no permission");
                return null;
            }
            for (String permission : infos) {
                LogUtil.mLog().d(permission);
            }
            return infos;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取所有已安装的应用（不包含系统应用）
     *
     * @param context
     * @return
     */
    public static List<AppInfo> getInstalledApp(Context context) {
        return getInstalledApp(context, false);
    }

    /**
     * 获取所有已安装的应用
     *
     * @param context
     * @param systemIncluded false:不包含系统应用 true:包含系统应用
     * @return
     */
    public static List<AppInfo> getInstalledApp(Context context, boolean systemIncluded) {
        if (context == null) {
            return null;
        }
        ArrayList<AppInfo> list = new ArrayList<AppInfo>();
        List<PackageInfo> packageInfos = null;
        PackageManager manager = context.getPackageManager();
        if (null == manager) {
            return null;
        }
        packageInfos = manager.getInstalledPackages(0);
        if (ListUtil.isEmpty(packageInfos)) {
            return null;
        }
        for (PackageInfo packageInfo : packageInfos) {
            AppInfo appInfo = new AppInfo();
            appInfo.setAppName(packageInfo.applicationInfo.loadLabel(manager).toString());
            appInfo.setPackageName(packageInfo.packageName);
            appInfo.setVersionCode(packageInfo.versionCode + "");
            appInfo.setVersionName(packageInfo.versionName);
            appInfo.setAppIcon(packageInfo.applicationInfo.loadIcon(manager));
            if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {//非系统应用
                list.add(appInfo);
//                LogUtil.mLog().d(appInfo.parseToString() + "\n");
            } else {//系统应用
                if (systemIncluded) {
                    list.add(appInfo);
//                    LogUtil.mLog().d("系统应用：" + appInfo.parseToString() + "\n");
                }
            }
        }
        return list;
    }

    /**
     * 比较版本号大小
     * @param version1
     * @param version2
     * @return  -1: 前者小 0：相等 1：前者大
     */
    public static int compareVersion(String version1, String version2) {
        int diff = 0;
        if (version1 == null || version2 == null) {
            diff = -1;
        }
        String[] versionArray1 = version1.split("\\.");//注意此处为正则匹配，不能用"."；
        String[] versionArray2 = version2.split("\\.");
        int idx = 0;
        int minLength = Math.min(versionArray1.length, versionArray2.length);//取最小长度值
        while (idx < minLength
                && (diff = versionArray1[idx].length() - versionArray2[idx].length()) == 0//先比较长度
                && (diff = versionArray1[idx].compareTo(versionArray2[idx])) == 0) {//再比较字符
            ++idx;
        }
        //如果已经分出大小，则直接返回，如果未分出大小，则再比较位数，有子版本的为大；
        diff = (diff != 0) ? diff : versionArray1.length - versionArray2.length;
        LogUtil.mLog().i(diff + "");
        return diff;
    }
}