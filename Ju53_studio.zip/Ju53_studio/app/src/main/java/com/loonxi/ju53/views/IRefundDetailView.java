package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.RefundEntity;

/**
 * Created by Xuzue on 2016/2/16.
 */
public interface IRefundDetailView extends IBaseView {
    void onGetRefundDetailSuccess(RefundEntity detailEntity);

    void onGetRefundDetailFailed(int apiErrorCode, String message);

    void onUpdateRefundSuccess();

    void onUpdateRefundFailed(int apiErrorCode, String message);
}
