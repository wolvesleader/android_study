package com.loonxi.ju53.utils;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Debug;

import com.loonxi.ju53.utils.bean.ProcessInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * ActivityManager工具类
 * Created by Xuzue on 2015/9/9.
 */
public class AppUtil {

    /**
     * 判断app是否在前台运行
     * @param context
     * @return
     */
    public static boolean isRunningForeground(Context context){
        if(context == null){
            return false;
        }
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager == null){
            return false;
        }
        ComponentName cn = manager.getRunningTasks(1).get(0).topActivity;
        String currentTop = cn.getPackageName();
        if(!StringUtil.isEmpty(currentTop) && currentTop.equals(context.getPackageName())){
            return true;
        }else{
            return false;
        }
    }

    /**
     * 判断某个Activity是否在前台
     * @param context
     * @param className 类名全称，例如:com.hrbanlv.com.activity.LoginActivity
     * @return
     */
    public static boolean isTopActivity(Context context, String className){
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> infos =  activityManager.getRunningTasks(1);
        if(infos != null && infos.size() > 0){
            ComponentName cname = infos.get(0).topActivity;
            if(cname != null){
                String topName = cname.getClassName();
                if(className.equals(topName)){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 判断应用是否是debug状态
     * @param context
     * @return
     */
    public static boolean isApkDebugable(Context context) {
        ApplicationInfo info = context.getApplicationInfo();
        return (info.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

    /**
     * 获取所有正在运行的进程信息
     * @param context
     * @return
     */
    public static List<ProcessInfo> getRunnningAppProcessInfo(Context context){
        if(context == null){
            return null;
        }
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager == null){
            return null;
        }
        List<ProcessInfo> list = new ArrayList<ProcessInfo>();
        List<ActivityManager.RunningAppProcessInfo> appProcessInfos = manager.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo info : appProcessInfos){
            ProcessInfo processInfo = new ProcessInfo();
            processInfo.setPid(info.pid + "");
            processInfo.setUid(info.uid + "");
            processInfo.setProcessName(info.processName);
            processInfo.setPkgList(info.pkgList);
            int[] memPid = new int[]{info.pid};
            Debug.MemoryInfo[] memoryInfo = manager.getProcessMemoryInfo(memPid);
            int memSize = memoryInfo[0].dalvikPrivateDirty;
            processInfo.setMemorySize(memSize + "");
            LogUtil.mLog().d(processInfo.parseToString() + "\n");
            list.add(processInfo);
        }
        return list;
    }

}
