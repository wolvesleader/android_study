package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SupplierActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.widgets.FixedListView;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class AgentAdapter extends BaseObjectListAdapter<AgentProductEntity> {


    public AgentAdapter(Context context, List<AgentProductEntity> datas) {
        super(context, datas);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_agent_parent, null);
            holder.mLayoutCompany = (LinearLayout) convertView.findViewById(R.id.listitem_agent_parent_layout_company);
            holder.mTvCompanyName = (TextView) convertView.findViewById(R.id.listitem_agent_parent_tv_company);
            holder.mFlv = (FixedListView) convertView.findViewById(R.id.listitem_agent_parent_flv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        AgentProductEntity agent = get(position);
        holder.mTvCompanyName.setText(agent.getSupplierUserName());

        AgentChildAdapter childAdapter = new AgentChildAdapter(mContext, agent.getList());
        holder.mFlv.setAdapter(childAdapter);
        setListener(holder, agent, position);
        return convertView;
    }


    private void setListener(ViewHolder holder, final AgentProductEntity agent, final int position) {
        if (holder == null) {
            return;
        }
        holder.mLayoutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", agent.getSupplierUserId() + "");
                intent.putExtra("userName", agent.getSupplierUserName());
                mContext.startActivity(intent);
            }
        });
    }

    class ViewHolder {
        LinearLayout mLayoutCompany;
        TextView mTvCompanyName;
        FixedListView mFlv;
    }
}
