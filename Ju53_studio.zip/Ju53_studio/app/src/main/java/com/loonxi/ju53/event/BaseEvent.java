package com.loonxi.ju53.event;

import android.os.Bundle;

import java.io.Serializable;

/**
 * Created by Xuzue on 2015/12/17.
 */
public class BaseEvent implements Serializable{
    private static int eventState;
    private Bundle extras;

    public static int getEventState() {
        return eventState;
    }

    public static void setEventState(int eventState) {
        BaseEvent.eventState = eventState;
    }

    public Bundle getExtras() {
        return extras;
    }

    public void setExtras(Bundle extras) {
        this.extras = extras;
    }


}
