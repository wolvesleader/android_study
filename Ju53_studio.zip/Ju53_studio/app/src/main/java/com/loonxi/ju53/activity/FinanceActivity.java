package com.loonxi.ju53.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.entity.FinanceEntity;
import com.loonxi.ju53.presenters.FinancePresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IFinanceView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * Created by XuZue on 2016/5/5 0005.
 */
public class FinanceActivity extends BaseActivity implements View.OnClickListener, IFinanceView {

    @ViewInject(R.id.finance_layout_left)
    private LinearLayout mLayoutLeft;
    @ViewInject(R.id.finance_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.finance_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.finance_tv_available)
    private TextView mTvAvailable;
    @ViewInject(R.id.finance_tv_all)
    private TextView mTvAll;
    @ViewInject(R.id.finance_tv_wait)
    private TextView mTvWait;
    @ViewInject(R.id.finance_tv_cashing)
    private TextView mTvCashing;
    @ViewInject(R.id.finance_tv_cashed)
    private TextView mTvCashed;
    @ViewInject(R.id.finance_tv_torecord)
    private TextView mTvTorecord;
    @ViewInject(R.id.finance_tv_tocash)
    private TextView mTvTocash;
    @ViewInject(R.id.finance_tv_wait_invoice)
    private TextView mTvWaitInvoice;
    @ViewInject(R.id.finance_layout_toband)
    private LinearLayout mLayoutToBand;
    @ViewInject(R.id.finance_tv_toband)
    private TextView mTvToBand;
    @ViewInject(R.id.finance_layout_torecord)
    private LinearLayout mLayoutToRecord;

    private FinancePresenter mPresenter;
    private FinanceEntity mFinance;
    private double mBalance = 0;//可提现金额
    private boolean mIsFirst = true;
    private int mMinMoney = 10;//提现最低金额

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finance);
        x.view().inject(this);
        initView();
        initContent();
        setListener();
    }

    public void initView() {
        setTitle("资金账户");
    }

    public void initContent() {

    }

    public void setListener() {
        mLayoutLeft.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
        mLayoutToBand.setOnClickListener(this);
        mLayoutToRecord.setOnClickListener(this);
        mTvTocash.setOnClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getFinanceInfo(false);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPresenter == null) {
            mPresenter = new FinancePresenter(this);
        }
        mPresenter.getFinanceInfo(mIsFirst ? true : false);
        mIsFirst = false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.finance_layout_left:
                finish();
                break;
            case R.id.finance_layout_right:
                if (mFinance == null) {
                    return;
                }
                gotoCommonWebView(mFinance.getHelpurl(), "提现说明");
                break;
            case R.id.finance_layout_toband:
                toCashAccount();
                break;
            case R.id.finance_layout_torecord:
                startActivity(new Intent(mContext, CashRecordActivity.class));
                break;
            case R.id.finance_tv_tocash:
                toCash();
                break;
        }
    }

    /**
     * 提现账户
     */
    private void toCashAccount() {
        Intent intent = new Intent(mContext, CashAccountActivity.class);
        String frozen = mFinance == null ? "" : mFinance.getFrozen();
        boolean hasCashing = false;
        if (!StringUtil.isEmpty(frozen) && Integer.parseInt(frozen) > 0) {
            hasCashing = true;
        }
        intent.putExtra("hasCashing", hasCashing);
        startActivity(intent);
    }

    /**
     * 提现
     */
    private void toCash() {
        if (mBalance < mMinMoney) {
            showToast("可提现金额小于" + mMinMoney + "，不能提现");
            return;
        }
        if (mFinance != null && "0".equals(mFinance.getState())) {
            showToast("请先绑定支付宝");
            return;
        }
        Intent intent = new Intent(mContext, CashApplyActivity.class);
        intent.putExtra("finance", mFinance);
        startActivity(intent);
    }

    /**
     * 设置资金信息
     *
     * @param finance
     */
    private void setFinanceInfo(FinanceEntity finance) {
        if (finance == null) {
            return;
        }
        mMinMoney = finance.getFloor() <= 0 ? 10 : (int)finance.getFloor();
        mBalance = StringUtil.isEmpty(finance.getBalance()) ? 0 : Double.parseDouble(finance.getBalance());
        mTvAvailable.setText(StringUtil.isEmpty(finance.getBalance()) ? "0.00" : finance.getBalance());
        mTvAll.setText(StringUtil.isEmpty(finance.getTotal()) ? "0.00" : finance.getTotal());
        mTvWaitInvoice.setText("0.00");
        mTvCashing.setText(StringUtil.isEmpty(finance.getFrozen()) ? "0.00" : finance.getFrozen());
        mTvToBand.setText("1".equals(finance.getState()) ? finance.getAccount() : "未设置");
        mTvCashed.setText(StringUtil.isEmpty(finance.getTotal_out()) ? "0.00" : finance.getTotal_out());
        mTvTocash.setEnabled(mBalance <= 0 ? false : true);
    }

    @Override
    public void getFinanceInfoSuccess(FinanceEntity info) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mFinance = info;
        if (info == null) {
            showToast("获取失败");
            return;
        }
        setFinanceInfo(info);
    }

    @Override
    public void getFinanceInfoFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
