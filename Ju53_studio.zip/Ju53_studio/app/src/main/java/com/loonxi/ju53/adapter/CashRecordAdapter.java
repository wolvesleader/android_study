package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.CashRecordEntity;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;

/**
 * Created by XuZue on 2016/5/6 0006.
 */
public class CashRecordAdapter extends BaseObjectListAdapter<CashRecordEntity> {


    public CashRecordAdapter(Context context, List<CashRecordEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_cash_record, null);
            holder.mTvAccount = (TextView) convertView.findViewById(R.id.listitem_cash_record_tv_account);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_cash_record_tv_status);
            holder.mTvTime = (TextView) convertView.findViewById(R.id.listitem_cash_record_tv_time);
            holder.mTvMoney = (TextView) convertView.findViewById(R.id.listitem_cash_record_tv_money);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        CashRecordEntity record = get(position);
        String state = record.getState();
        String stateDes = "处理中";
        String time = "";
        String applyTime = record.getApplytime();
        String dealTime = record.getDealTime();
        if ("1".equals(state)) {
            stateDes = "转账失败";
            time = dealTime;
        } else if ("2".equals(state)) {
            stateDes = "已到账";
            time = dealTime;
        } else if ("0".equals(state)) {
            time = applyTime;
        }
        holder.mTvAccount.setText("提现到: " + (StringUtil.isEmpty(record.getAccount()) ? "" : record.getAccount()));
        holder.mTvStatus.setText(stateDes);
        holder.mTvTime.setText(time);
        holder.mTvMoney.setText(StringUtil.isEmpty(record.getApplied()) ? "" : record.getApplied());

        return convertView;
    }

    class ViewHolder {
        TextView mTvAccount;
        TextView mTvStatus;
        TextView mTvTime;
        TextView mTvMoney;
    }
}
