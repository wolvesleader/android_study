package com.loonxi.ju53.entity;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * 验证码 entity
 * Created by laojiaqi on 2016/2/18.
 */
public class VerifyCodeEntity extends BaseJsonInfo {
    String validateCode;

    public String getValidateCode() {
        return validateCode;
    }

    public void setValidateCode(String validateCode) {
        this.validateCode = validateCode;
    }
}
