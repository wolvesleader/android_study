package com.loonxi.ju53.modules.request;

import android.net.Uri;

import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.modules.cookie.PersistentCookieStore;
import com.loonxi.ju53.modules.cookie.SerializableHttpCookie;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.logging.HttpLoggingInterceptor;

import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;

import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

/**
 * HTTP请求工具(JAVA)
 * Created by Xuzue on 2015/12/16.
 */
public class Request {

    private static volatile Request instance;
    private static Retrofit mRetrofit;
    private static int mTimeOut;
    private static OkHttpClient client;

    public static Request getInstance(String baseUrl, int... arg) {
        if (instance == null) {
            synchronized (Request.class) {
                if (instance == null) {
                    instance = new Request(baseUrl, arg);
                }
            }
        }
        return instance;
    }

    /**
     * JAVA接口请求
     *
     * @param clazz
     * @param timeOut
     * @param <T>
     * @return
     */
    public static <T> T creatApi(Class<T> clazz, int... timeOut) {
        return getInstance(null, timeOut).mRetrofit.create(clazz);
    }

    /**
     * JAVA接口请求
     *
     * @param clazz
     * @param baseUrl
     * @param timeOut
     * @param <T>
     * @return
     */
    public static <T> T creatApi(Class<T> clazz, String baseUrl, int... timeOut) {
        return getInstance(baseUrl, timeOut).mRetrofit.create(clazz);
    }

    private Request(String baseUrl, int... arg) {
        int time;
        if (arg.length == 1) {
            time = arg[0];
        } else {
            time = AppConst.TIME_OUT;
        }
        initClient(time);

        mRetrofit = new Retrofit.Builder()
                .baseUrl(StringUtil.isEmpty(baseUrl) ? ApiConst.URL_ROOT : baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

    }

    private static void initClient(int time){
        client = new OkHttpClient();
        PersistentCookieStore cookieStore = new PersistentCookieStore(BaseApplication.getInstance());
        CookieManager cookieManager = new CookieManager(cookieStore, CookiePolicy.ACCEPT_ALL);
        client.setCookieHandler(cookieManager);
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);//TODO 加入log控制
        client.interceptors().add(interceptor);
        client.setConnectTimeout(time, TimeUnit.SECONDS);
    }

    public static void changeBaseUrl(String baseUrl) {
        if(client == null){
            initClient(AppConst.TIME_OUT);
        }
        mRetrofit = new Retrofit.Builder()
                .baseUrl(StringUtil.isEmpty(baseUrl) ? ApiConst.URL_ROOT : baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        LogUtil.mLog().e("changeBaseUrl:" + mRetrofit.baseUrl().url().url().toString());
    }

    public static Retrofit getRetrofit() {
        return mRetrofit;
    }
}
