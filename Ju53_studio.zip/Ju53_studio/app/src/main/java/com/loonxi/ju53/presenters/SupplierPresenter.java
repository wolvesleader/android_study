package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.models.impl.FavModel;
import com.loonxi.ju53.models.impl.SupplierModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ISupplierView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/18.
 */
public class SupplierPresenter {
    private ISupplierView mView;
    private SupplierModel mModel;
    private FavModel mFavModel;

    public SupplierPresenter(ISupplierView mView) {
        this.mView = mView;
        mModel = new SupplierModel();
        mFavModel = new FavModel();
    }

    /**
     * 获取供应商信息
     *
     * @param userId
     * @param page
     */
    public void getSupplierInfo(String userId, int page) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("userId", userId);
        map.put("page", page + "");
        mModel.getSupplierInfo(map, new Callback<JsonInfo<SupplierEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<SupplierEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<SupplierEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetSupplierInfoSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetSupplierInfoFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 收藏/取消收藏
     * @param targetId
     * @param type
     * @param state
     */
    public void fav(String targetId, int type, final int state){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("targetId", targetId);
        map.put("type", type + "");
        map.put("state", state + "");
        mFavModel.fav(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onFavSuccess(state == 0 ? true : false);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onFavFailed(apiErrorCode, message);
            }
        });
    }
}
