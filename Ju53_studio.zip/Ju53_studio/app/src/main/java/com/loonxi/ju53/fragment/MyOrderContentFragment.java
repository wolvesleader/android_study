package com.loonxi.ju53.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MyOrderActivity;
import com.loonxi.ju53.activity.OrderPaySuccessActivity;
import com.loonxi.ju53.adapter.OrderAdapter;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.PaySuccessEntity;
import com.loonxi.ju53.listener.AlipayListener;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.listener.OrderContentListener;
import com.loonxi.ju53.manager.AlipayManager;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.presenters.OrderPresenter;
import com.loonxi.ju53.utils.InterflowUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.views.IOrderView;
import com.loonxi.ju53.widgets.dialog.PayPasswordDialog;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * 进货订单Fragment
 * Created by Administrator on 2016/1/19.
 */
@ContentView(R.layout.include_buy_order_viewpager)
public class MyOrderContentFragment extends BaseSafeFragment<IOrderView, OrderPresenter> implements IOrderView, FragmentLifeCircle, OrderContentListener, AlipayListener {

    @ViewInject(R.id.include_buy_order_viewpager_ptr)
    private PullToRefreshListView mPlv;
    private PayPasswordDialog mPasswordDialog;

    private ListView mListView;

    public static final String ARG_PAGE = "page_num";
    private Context mContext;
    private List<OrderEntity> mOrders = new ArrayList<OrderEntity>();
    private OrderAdapter mAdapter;

    private int mCurrentNum;
    private int mCurrentPage = 1;
    private boolean mIsFirstIn = true;//第一次进进货订单列表

    public static final int REQUEST_CODE_REFUND = 1001;//退款
    public static final int REQUEST_CODE_ORDER_DETAIL = 1002;//订单详情

    public static MyOrderContentFragment createContentFragment(int value) {
        MyOrderContentFragment myOrderContentFragment = new MyOrderContentFragment();
        WeakReference<MyOrderContentFragment> refContentFragment = new WeakReference<MyOrderContentFragment>(myOrderContentFragment);
        Bundle arg = new Bundle();
        arg.putInt(ARG_PAGE, value);
        myOrderContentFragment.setArguments(arg);
        return refContentFragment.get();
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentNum = getArguments().getInt(ARG_PAGE);
        mContext = this.getContext();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void initView() {
        mListView = mPlv.getRefreshableView();
        mListView.setEmptyView(getEmptyView(R.string.empty_order, AppConst.Empty.ORDER));
        mPlv.setVisibility(View.INVISIBLE);

    }


    @Override
    public void initContent() {
        mAdapter = new OrderAdapter(mContext, this, mCurrentNum, mOrders, mPresenter, this);
        mListView.setAdapter(mAdapter);
        if (mCurrentNum == MyOrderActivity.DEFAULT_DISPLAY_FRAGMENT && mIsFirstIn) {
            LogUtil.mLog().i("initContent");
            mIsFirstIn = false;
            getOrder(mCurrentNum);
        }
    }

    @Override
    public void setListener() {
        mPlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData(true);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                mPresenter.getOrders(mCurrentNum, false);
            }
        });
    }

    /**
     * 获取进货订单
     *
     * @param position
     */
    public void getOrder(int position) {
        clearList();
        if (mPresenter != null) {
            if (mPlv != null) {
                mPlv.setVisibility(View.INVISIBLE);
            }
            LogUtil.mLog.e("进货" + position);
        } else {
            mPresenter = createPresenter(MyOrderContentFragment.this);
            LogUtil.mLog.e("//进货" + position);
        }
        mPresenter.getOrders(position, true);
    }


    /**
     * 清除屏幕数据
     */
    private void clearList() {
        if (mOrders != null && mAdapter != null && mOrders.size() > 0) {
            mOrders.clear();
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected OrderPresenter createPresenter(IOrderView view) {
        return new OrderPresenter(this);
    }

    @Override
    public void onGetOrdersSuccess(JsonArrayInfo<OrderEntity> jsonArrayInfo) {
        if (mPlv != null) {
            mPlv.setVisibility(View.VISIBLE);
            if (mPlv.isRefreshing()) {
                mPlv.onRefreshComplete();
            }
        }
        if (mCurrentPage == 1) {
            mOrders.clear();
        }
        if (jsonArrayInfo != null && !ListUtil.isEmpty(jsonArrayInfo.getData())) {
            mOrders.addAll(jsonArrayInfo.getData());
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onGetOrdersFailed(int apiErrorCode, String message) {
        if (mPlv != null) {
            if (mPlv.isRefreshing()) {
                mPlv.onRefreshComplete();
            }
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void onConfirmOrderSuccess(BaseJsonInfo jsonInfo) {
        if (mPasswordDialog != null && mPasswordDialog.isShowing()) {
            mPasswordDialog.dismiss();
        }
        initData(true);
    }

    @Override
    public void onConfirmOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onPayOrderSuccess(AliPayEntity entity, double payMoney, String orderId) {
        String data = entity.getSignData();
        new AlipayManager().pay(getActivity(), data, this, payMoney, orderId);
    }

    @Override
    public void onPayOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void getTransOrderSuccess(LogisticsEntity logisticsEntity) {
        InterflowUtil.gotoInterflowActivity(mContext, logisticsEntity);
    }

    @Override
    public void getTransOrderFailure(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onCloseOrderSuccess() {
        showToast(R.string.my_order_colse_success);
        initData(true);
    }

    @Override
    public void onCloseOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
//         showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void fragmentPause() {
        //TODO 取消网络请求
    }

    @Override
    public void fragmentResume(int position) {
        LogUtil.mLog().i("fragmentResume");
        if(position == mCurrentNum) {
            getOrder(position);
        }
    }

    @Override
    public void showPayConfirmDialog(final OrderEntity order) {
        mPasswordDialog = new PayPasswordDialog(mContext, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPasswordDialog.hideSoftInput();
                if (order == null) {
                    return;
                }
                mPresenter.confirmOrder(order.getOrderId(), mPasswordDialog.getPassword());
            }
        });
        mPasswordDialog.setDialogAttribute(getActivity(), Gravity.BOTTOM);
        mPasswordDialog.show();
    }

    @Override
    public void onAlipaySuccess(double payMoney, String orderId) {
        showToast(R.string.pay_success);
        initData(true);
        toPaySuccess(payMoney, orderId);
    }

    @Override
    public void onAlipayCancel() {
        showToast(R.string.pay_cancel);

    }

    @Override
    public void onAlipayFailed() {
        showToast(R.string.pay_failed);

    }

    @Override
    public void onAlipayConfirming() {
        showToast(R.string.pay_confirming);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_REFUND:
            case REQUEST_CODE_ORDER_DETAIL:
                if (resultCode == Activity.RESULT_OK) {
                    initData(true);
                }
                break;
        }
    }

    /**
     * 去支付成功页
     */
    private void toPaySuccess(double payMoney, String orderId){
        PaySuccessEntity paySuccessEntity = new PaySuccessEntity();
        paySuccessEntity.setMoney(payMoney + "");
        paySuccessEntity.setOrderId(orderId);
        Intent intent = new Intent(mContext, OrderPaySuccessActivity.class);
        intent.putExtra("successEntity", paySuccessEntity);
        startActivity(intent);
    }

    /**
     * 重新获取订单数据
     *
     * @param showDialog
     */
    private void initData(boolean showDialog) {
        mCurrentPage = 1;
        mPresenter.getOrders(mCurrentNum, showDialog);
    }
}
