package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.SupplierEntity;

/**
 * Created by Xuzue on 2016/2/18.
 */
public interface ISupplierView {
    void onGetSupplierInfoSuccess(SupplierEntity supplierEntity);
    void onGetSupplierInfoFailed(int apiErrorCode, String message);
    void onFavSuccess(boolean isFav);
    void onFavFailed(int apiErrorCode, String message);
}
