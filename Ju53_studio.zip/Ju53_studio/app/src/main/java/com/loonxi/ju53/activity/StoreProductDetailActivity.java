package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.StoreProductExtraEntity;
import com.loonxi.ju53.fragment.ProductDetailAttributeFragment;
import com.loonxi.ju53.fragment.ProductDetailPicFragment;
import com.loonxi.ju53.listener.OnScrollDownListenter;
import com.loonxi.ju53.manager.BroadcastManager;
import com.loonxi.ju53.manager.StoreManager;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.presenters.StoreProductDetailPresenter;
import com.loonxi.ju53.utils.CountDownTimer;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.SpannableStringUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.TimeUtil;
import com.loonxi.ju53.views.IStoreProductDetailView;
import com.loonxi.ju53.widgets.DetailTabBar;
import com.loonxi.ju53.widgets.SlideDetailsLayout;
import com.loonxi.ju53.widgets.dialog.NetErrorDialog;
import com.loonxi.ju53.widgets.dialog.ShareDialog;
import com.loonxi.ju53.widgets.viewpagerindicator.ProductDetailBanner;
import com.umeng.socialize.UMShareAPI;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * "分销商商品详情"activity
 * Created by Xuzue on 2016/1/11.
 */
public class StoreProductDetailActivity extends BaseActivity implements IStoreProductDetailView, DetailTabBar.OnDetailTabClickListener,
        View.OnClickListener, OnScrollDownListenter {

    private final static double BACKGROUND_DISAPPEAR_RATE = 0.5;
    private int TITLE_HIDDEN_LENGTH_ONE;//图标消失距离
    private int TITLE_HIDDEN_LENGTH_TWO;//背景显示距离

    @ViewInject(R.id.store_product_detail_layout_title)
    private LinearLayout mLayoutTitle;
    @ViewInject(R.id.store_product_detail_iv_title_back)
    private ImageView mIvBack;
    @ViewInject(R.id.store_product_detail_tv_title)
    private TextView mTvTitle;
    @ViewInject(R.id.store_product_detail_tv_right)
    private TextView mTvRight;
    @ViewInject(R.id.store_product_detail_iv_right)
    private ImageView mIvRight;
    @ViewInject(R.id.store_product_detail_layout_bottom)
    private LinearLayout mLayoutBottom;


    @ViewInject(R.id.store_product_detail_layout_container)
    private SlideDetailsLayout mScroolViewContainer;
    @ViewInject(R.id.store_product_detail_scrollview_one)
    private ScrollView mScrollViewOne;


    @ViewInject(R.id.store_product_detail_dtabbar)
    private DetailTabBar mDetailTabBar;

    private ProductDetailBanner mCycleViewPager;
    @ViewInject(R.id.store_product_detail_tv_product_name)
    private TextView mTvName;
    @ViewInject(R.id.store_product_detail_tv_product_price)
    private TextView mTvPrice;
    @ViewInject(R.id.store_product_detail_tv_product_referprice)
    private TextView mTvReferPrice;
    @ViewInject(R.id.store_product_detail_tv_product_postage)
    private TextView mTvPostage;
    @ViewInject(R.id.store_product_detail_tv_product_sales)
    private TextView mTvSales;
    @ViewInject(R.id.store_product_detail_tv_product_address)
    private TextView mTvAddress;
    @ViewInject(R.id.store_product_detail_iv_logo)
    private ImageView mIvLogo;
    @ViewInject(R.id.store_product_detail_layout_provider)
    private LinearLayout mLayoutProvider;
    @ViewInject(R.id.store_product_detail_tv_provider)
    private TextView mTvProvider;
    @ViewInject(R.id.store_product_detail_tv_to_recommend)
    private TextView mTvTomore;//继续拖动……
    @ViewInject(R.id.store_product_detail_layout_share)
    private LinearLayout mLayoutShare;
    @ViewInject(R.id.store_product_detail_layout_offsale)
    private LinearLayout mLayoutOffSale;
    @ViewInject(R.id.store_product_detail_tv_offsale)
    private TextView mTvOffSate;
    @ViewInject(R.id.store_product_detail_layout_price)
    private LinearLayout mLayoutPrice;
    @ViewInject(R.id.store_product_detail_layout_promotion_bar)
    private LinearLayout mLayoutPromotionBar;
    @ViewInject(R.id.store_product_detail_layout_promotion_bar_outtime)
    private LinearLayout mLayoutPromotionBarOuttime;
    @ViewInject(R.id.store_product_detail_layout_promotion_bar_ing)
    private LinearLayout mLayoutPromotionBarIng;
    @ViewInject(R.id.store_product_detail_layout_postage_info)
    private LinearLayout mLayoutPostage;
    @ViewInject(R.id.store_product_detail_tv_promotion_des)
    private TextView mTvPromotionDes;
    @ViewInject(R.id.store_product_detail_tv_promotion_money)
    private TextView mTvPromotionMoney;
    @ViewInject(R.id.store_product_detail_layout_promotion_info)
    private LinearLayout mLayoutPromotionInfo;
    @ViewInject(R.id.store_product_detail_tv_promotion_price)
    private TextView mTvPromotionPrice;
    @ViewInject(R.id.store_product_detail_tv_promotion_postage)
    private TextView mTvPromotionPostage;
    @ViewInject(R.id.store_product_detail_tv_promotion_stock)
    private TextView mTvPromotionStock;
    @ViewInject(R.id.store_product_detail_tv_hour)
    private TextView mTvPromotionHour;
    @ViewInject(R.id.store_product_detail_tv_minute)
    private TextView mTvPromotionMinute;
    @ViewInject(R.id.store_product_detail_tv_second)
    private TextView mTvPromotionSecond;

    private FragmentTransaction mTransaction;
    private ProductDetailPicFragment mPicFragment;
    private ProductDetailAttributeFragment mAttributeFragment;

    private StoreProductDetailPresenter mPresenter;
    private NetErrorDialog mNetErrorDialog;
    private String mProductId = "";
    private ShareDialog mShareDialog;

    private String mDataPicDes = "";//图片描述
    private List<ImageView> mHeadImgs = new ArrayList<>();
    private ProductDetailEntity mDetail;
    private boolean mDirection = false;//false:向下 true:向上
    private float mLastPosition = 0;//记录上一次滑动距离

    private boolean mJuIsOn = true;//聚小店里上架状态 true:上架 false:下架
    private StoreProductExtraEntity mExtraInfo;
    private CountDownTimer mTimer;
    private long TOTAL_TIME = 0;
    private static final long INTERVAL_TIME = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_product_detail);
        x.view().inject(this);
        initViews();
        initContent();
        setListener();
    }

    private void initViews() {
        mCycleViewPager = (ProductDetailBanner) getSupportFragmentManager().findFragmentById(R.id.store_product_detail_fragment_cycleviewpager);
        mCycleViewPager.setScrollable(false);
        mCycleViewPager.setCycle(false);
        mCycleViewPager.getView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int width = DisplayUtil.getScreenWidth(mContext);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, width);
                mCycleViewPager.getView().setLayoutParams(params);
                mCycleViewPager.getView().getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
        mDetailTabBar.setAttributeTabEnable(true);
        int top_default = getResources().getDimensionPixelSize(R.dimen.store_product_tab_detail_height);
        mScroolViewContainer.setSource(1);
        mScroolViewContainer.setChildLayoutTop(top_default);
    }

    private void initContent() {
        mJuIsOn = getIntent().getBooleanExtra("isOnSale", false);
        mProductId = getIntent().getStringExtra("productId");
        initTitleDisappearLength();
        initFragment();
        initOnState(mJuIsOn);
        mPresenter = new StoreProductDetailPresenter(this);
        mPresenter.getProductBaseInfo(mProductId);
        mPresenter.getExtraInfo(mProductId);
    }

    private void setListener() {
        mIvBack.setOnClickListener(this);
        mTvRight.setOnClickListener(this);
        mIvRight.setOnClickListener(this);
        mLayoutProvider.setOnClickListener(this);
        mDetailTabBar.setOnDetailTabClickListener(this);
        mLayoutShare.setOnClickListener(this);
        mLayoutOffSale.setOnClickListener(this);
        mScroolViewContainer.setOnSlideDetailsListener(new SlideDetailsLayout.OnSlideDetailsListener() {
            @Override
            public void onStatucChanged(SlideDetailsLayout.Status status) {
                switch (status) {
                    case OPEN:
                        onDetailTabShown();
                        break;
                    case CLOSE:
                        onDetailTabHiden();
                        break;
                }
            }
        });
        setScrollViewOneListener();
    }


    /**
     * 初始化商品上架状态
     */
    private void initOnState(boolean juIsOn) {
        mJuIsOn = juIsOn;
        mTvOffSate.setText(juIsOn ? "下架" : "上架");
    }

    /**
     * 初始化 title 消失距离
     */
    private void initTitleDisappearLength() {
        TITLE_HIDDEN_LENGTH_ONE = (int) getResources().getDimension(R.dimen.store_product_detail_title_disappear_length_one);
        TITLE_HIDDEN_LENGTH_TWO = (int) getResources().getDimension(R.dimen.store_product_detail_title_disappear_length_two);
    }

    private void setScrollViewOneListener() {
        if (mScrollViewOne != null) {
            mScrollViewOne.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                @Override
                public void onScrollChanged() {
                    float scrollY = mScrollViewOne.getScrollY(); //for verticalScrollView
                    float iconAlpha = getIconAlpha(scrollY);
                    float backgroundAlpha = getBackgroundAlpha(scrollY);
                    setDirection(scrollY);
                    setAlphaToIcon(iconAlpha, backgroundAlpha);
                    setAlphaToBackground(backgroundAlpha);
                    changeIconByAlpha(iconAlpha, backgroundAlpha);
                }
            });
        }

    }

    /**
     * 设置方向
     *
     * @param scrollY
     */
    private void setDirection(float scrollY) {
        if (scrollY > mLastPosition) {
            mDirection = false;
            mLastPosition = scrollY;
            return;
        }
        if (scrollY < mLastPosition) {
            mDirection = true;
            mLastPosition = scrollY;
            return;
        }
    }


    /**
     * 根据方向改变Title图标
     *
     * @param iconAlpha
     * @param backgroundAlpha
     */
    private void changeIconByAlpha(float iconAlpha, float backgroundAlpha) {
//        LogUtil.mLog().e(iconAlpha + " " + backgroundAlpha);
        //1.向下
        if (!mDirection) {
            if (iconAlpha <= 0.1 && backgroundAlpha > BACKGROUND_DISAPPEAR_RATE) {
                mIvBack.setImageDrawable(getResources().getDrawable(R.drawable.detail_change_back));
                mIvBack.setAlpha(backgroundAlpha);
//                mIvRight.setImageDrawable(getResources().getDrawable(R.drawable.detail_change_more));
                mIvRight.setAlpha(backgroundAlpha);
                mIvRight.setVisibility(View.GONE);
                mTvRight.setVisibility(View.VISIBLE);
                return;
            }
        }
        //2.向上
        if (mDirection) {
            if (iconAlpha > 0 && backgroundAlpha < BACKGROUND_DISAPPEAR_RATE) {
                mIvBack.setImageDrawable(getResources().getDrawable(R.drawable.detail_back));
                mIvBack.setAlpha(iconAlpha);
//                mIvRight.setImageDrawable(getResources().getDrawable(R.drawable.detail_more));
                mIvRight.setAlpha(iconAlpha);
                mIvRight.setVisibility(View.VISIBLE);
                mTvRight.setVisibility(View.GONE);
                return;
            }
        }
    }

    /**
     * 获得背景颜色alpha
     *
     * @param value
     * @return
     */
    private float getBackgroundAlpha(float value) {
        float alpha = value / TITLE_HIDDEN_LENGTH_TWO;
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 1) {
            alpha = 1;
        }
        return alpha;
    }


    /**
     * 获取图标显示alpha
     *
     * @param value
     * @return
     */
    private float getIconAlpha(float value) {
        float alpha = 1 - value / TITLE_HIDDEN_LENGTH_ONE;
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 1) {
            alpha = 1;
        }
        return alpha;
    }

    /**
     * 设置图标透明度
     *
     * @param alpha
     * @param backgroundAlpha
     */
    private void setAlphaToIcon(float alpha, float backgroundAlpha) {
        if (!mDirection) {
            mIvBack.setAlpha(alpha);
            mIvRight.setAlpha(alpha);
            return;
        }
        if (mDirection) {
            mIvBack.setAlpha(backgroundAlpha);
            mIvRight.setAlpha(backgroundAlpha);
            return;
        }
    }

    private void setAlphaToBackground(float alpha) {
        mLayoutTitle.getBackground().setAlpha((int) (alpha * 255));
    }


    private void initFragment() {
        mTransaction = getSupportFragmentManager().beginTransaction();
        if (mPicFragment != null) {
            mTransaction.remove(mPicFragment);
        }
        if (mAttributeFragment != null) {
            mTransaction.remove(mAttributeFragment);
        }
        mPicFragment = new ProductDetailPicFragment();
        mAttributeFragment = new ProductDetailAttributeFragment();
        mTransaction.commitAllowingStateLoss();
    }

    /**
     * 设置图片
     *
     * @param pictureUrl
     */
    private void setCycleViewPager(String pictureUrl) {
        mHeadImgs.clear();
        if (StringUtil.isEmpty(pictureUrl)) {
            return;
        }
        mCycleViewPager.setCycle(false);
        mCycleViewPager.setData(pictureUrl);
    }

    /**
     * 设置产品基本信息
     */
    private void setBaseInfo() {
        if (mDetail == null) {
            return;
        }
        mTvName.setText(mDetail.getProductName());
        StoreManager.setStoreBaseInfo(mIvLogo, mTvProvider);

        int top_default = getResources().getDimensionPixelSize(R.dimen.store_product_tab_detail_height);
        mScroolViewContainer.setChildLayoutTop(2 * top_default);

        setPromotionInfo();

    }

    /**
     * 设置产品附加信息（从php接口获取的）
     */
    private void setExtraInfo() {
        if (mExtraInfo != null) {
            mJuIsOn = "1".equals(mExtraInfo.getState()) ? true : false;
            initOnState(mJuIsOn);
            mTvAddress.setText(mExtraInfo.getShow_region_name());
            setPromotionInfo();
        }
    }

    /**
     * 设置活动信息
     */
    private void setPromotionInfo() {
        if (mExtraInfo == null) {
            return;
        }
        int type = mExtraInfo.getActivityType();
        if (type == 0) {
            mLayoutPrice.setVisibility(View.VISIBLE);
            mLayoutPostage.setVisibility(View.VISIBLE);
            mLayoutPromotionBar.setVisibility(View.GONE);
            mLayoutPromotionInfo.setVisibility(View.GONE);
            String price = "¥" + (mDetail == null ? "0.00" : mDetail.getPrice());
            SpannableString sb = new SpannableString(price);
            sb.setSpan(new AbsoluteSizeSpan(15, true), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new AbsoluteSizeSpan(25, true), 1, price.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            mTvPrice.setText(sb);
            mTvReferPrice.setText(getResources().getString(R.string.search_advise) + ": ¥"
                    + (mDetail == null ? "0.00" : mDetail.getMarkPrice()));
            mTvPostage.setText(mDetail == null ? "0.00" : mDetail.getFreight());
            mTvSales.setText(getResources().getString(R.string.sold)
                    + (mDetail == null ? 0 : mDetail.getSold()) + getResources().getString(R.string.piece));
        } else if (type == 1 || type == 2) {
            mLayoutPrice.setVisibility(View.GONE);
            mLayoutPostage.setVisibility(View.GONE);
            mLayoutPromotionBar.setVisibility(View.VISIBLE);
            mLayoutPromotionInfo.setVisibility(View.VISIBLE);
            mTvPromotionDes.setText(mExtraInfo.getActivity_description());
            mTvPromotionMoney.setText(mExtraInfo.getActivity_price());
            String price = "分销价: " + (mDetail == null ? "0.00" : mDetail.getPrice());
//            SpannableString sp = SpannableStringUtil.setStrikethrough(price, 0, price.length());
            mTvPromotionPrice.setText(price);
            mTvPromotionPostage.setText(mDetail == null ? "0.00" : mDetail.getFreight());
            mTvPromotionStock.setText("剩余: " + (mDetail == null ? 0 : mDetail.getStock()));
            TOTAL_TIME = mExtraInfo.getActivity_countdown() * 1000;
            initTimer();
        }
    }

    /**
     * 活动时间倒计时
     *
     * @param millisUntilFinished
     */
    private void setPromotionTime(long millisUntilFinished) {
        int hour = TimeUtil.getHour(millisUntilFinished);
        int minute = TimeUtil.getMinute(millisUntilFinished);
        int second = TimeUtil.getSecond(millisUntilFinished);
        mTvPromotionHour.setText(hour + "");
        mTvPromotionMinute.setText(minute < 10 ? ("0" + minute) : (minute + ""));
        mTvPromotionSecond.setText(second < 10 ? ("0" + second) : (second + ""));
    }

    /**
     * 活动时间清零
     */
    private void clearPromotionTime() {
        mTvPromotionHour.setText("0");
        mTvPromotionMinute.setText("00");
        mTvPromotionSecond.setText("00");
    }

    private void initTimer() {
        if (TOTAL_TIME <= 0) {
            mLayoutPromotionBarOuttime.setVisibility(View.VISIBLE);
            return;
        }
        mLayoutPromotionBarIng.setVisibility(View.VISIBLE);
        if (mTimer != null) {
            mTimer.onFinish();
            mTimer = null;
            LogUtil.mLog().i("clear");
        }
        mTimer = new CountDownTimer(TOTAL_TIME, INTERVAL_TIME) {
            @Override
            public void onTick(long millisUntilFinished) {
                LogUtil.mLog().i(millisUntilFinished);
                if (isFinishing()) {
                    if (mTimer != null) {
                        mTimer.cancel();
                        mTimer = null;
                    }
                    return;
                }
                setPromotionTime(millisUntilFinished);
            }

            @Override
            public void onFinish() {
                LogUtil.mLog().i("finish");
                clearPromotionTime();
            }
        };
        mTimer.start();
    }

    @Override
    public void onGetBaseInfoSuccess(JsonInfo<ProductDetailEntity> jsonInfo) {
        if (jsonInfo.getData() == null) {
            return;
        }
        mDetail = jsonInfo.getData();
        setCycleViewPager(mDetail.getPicture());
        setBaseInfo();
    }

    @Override
    public void onGetBaseInfoFailed(int apiErrorCode, String message) {
        showNetErrorDialog();
    }

    @Override
    public void onGetDetailSuccess(JsonInfo<ProductDetailEntity> jsonInfo) {
        LogUtil.mLog().i(jsonInfo.getData());
        mDataPicDes = jsonInfo.getData().getDesc();
        mPicFragment.setDetailPic(mDataPicDes);
        mAttributeFragment.setData(jsonInfo.getData().getProps());
        onTabClick(1);
    }

    @Override
    public void onGetDetailFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void offSaleSuccess() {
        showToast(R.string.store_product_off_success);
        initOnState(false);
        BroadcastManager.sendStoreProductChanged(mContext);
    }

    @Override
    public void offSaleFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onSaleSuccess() {
        showToast(R.string.store_product_on_success);
        initOnState(true);
        BroadcastManager.sendStoreProductChanged(mContext);
    }

    @Override
    public void onSaleFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void getExtraInfoSuccess(StoreProductExtraEntity extra) {
        mExtraInfo = extra;
        setExtraInfo();
    }

    @Override
    public void getExtraInfoFailed(int apiErrorCode, String message) {

    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onTabClick(int position) {
        mTransaction = getSupportFragmentManager().beginTransaction();
        if (position == 1) {//图片详情
            if (mAttributeFragment.isAdded()) {
                mTransaction.hide(mAttributeFragment);
            }
            if (mPicFragment.isAdded()) {
                mTransaction.show(mPicFragment);
            } else {
                mTransaction.add(R.id.store_product_detail_layout_more_container, mPicFragment, mPicFragment.getClass().getSimpleName());
            }
        } else if (position == 2) {//商品属性
            if (mPicFragment.isAdded()) {
                mTransaction.hide(mPicFragment);
            }
            if (mAttributeFragment.isAdded()) {
                mTransaction.show(mAttributeFragment);
            } else {
                mTransaction.add(R.id.store_product_detail_layout_more_container, mAttributeFragment, mAttributeFragment.getClass().getSimpleName());
            }
        }
        mTransaction.commitAllowingStateLoss();
    }

    @Override
    public void onDetailTabShown() {
        mTvTitle.setText("商品详情");
        mDetailTabBar.setVisibility(View.VISIBLE);
        if (StringUtil.isEmpty(mDataPicDes)) {
            mPresenter.getProductDetailInfo(mProductId);
        }
    }

    @Override
    public void onDetailTabHiden() {
        mDetailTabBar.setVisibility(View.GONE);
        mTvTitle.setText("");
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.store_product_detail_iv_title_back:
                finish();
                break;
            case R.id.store_product_detail_tv_right:
            case R.id.store_product_detail_iv_right:
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", mDetail.getUserId());
                intent.putExtra("userName", mDetail.getUserName());
                startActivity(intent);
                break;
            case R.id.store_product_detail_layout_provider:
                intent = new Intent(mContext, StoreDetailActivity.class);
//                intent.putExtra("store", mStoreBaseInfo);
                startActivity(intent);
                break;
            case R.id.store_product_detail_layout_share:
                share();
                break;
            case R.id.store_product_detail_layout_offsale:
                if (mJuIsOn) {
                    mPresenter.offSale(mProductId);
                } else {
                    mPresenter.onSale(mProductId);
                }
                break;
        }
    }

    /**
     * 网络出错
     */
    private void showNetErrorDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || mContext == null) {
                    return;
                }
                mNetErrorDialog = new NetErrorDialog(mContext, StoreProductDetailActivity.this,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mPresenter.getProductBaseInfo(mProductId);
                                mNetErrorDialog.dismiss();
                            }
                        },
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                finish();
                            }
                        });
                mNetErrorDialog.show();
            }
        });

    }

    /**
     * 分享
     */
    public void share() {
        if (mDetail == null) {
            return;
        }
        String title = (mExtraInfo != null && !StringUtil.isEmpty(mExtraInfo.getShare_title())) ?
                mExtraInfo.getShare_title() : SpUtil.getString(mContext, SpUtil.STORE_NAME);
        String picture = mDetail.getPicture();
        String imgUrl = "";
        if (!StringUtil.isEmpty(picture) && picture.split(",") != null && picture.split(",").length > 0) {
            imgUrl = picture.split(",")[0];
        }
        String content = (mExtraInfo != null && mExtraInfo.getActivityType() == 1) ?
                ("这么nice又便宜的好东西，我就不独享了，一起拼团吧！\n" + mDetail.getProductName()) :
                ("极品好货，推荐你看看这个\n" + mDetail.getProductName());
        String targetUrl = mExtraInfo == null ? "" : mExtraInfo.getShare_url();
        mShareDialog = new ShareDialog(mContext, title, content, AppConst.PIC_HEAD + imgUrl, targetUrl);
        mShareDialog.setDialogAttribute(this, Gravity.BOTTOM);
        mShareDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(mContext).onActivityResult(requestCode, resultCode, data);
    }
}
