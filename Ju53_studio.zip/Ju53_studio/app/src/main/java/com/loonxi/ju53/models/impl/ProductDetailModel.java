package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.models.IProductDetailModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.CommentService;
import com.loonxi.ju53.modules.request.service.ProductService;
import com.loonxi.ju53.modules.request.service.StoreService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/11.
 */
public class ProductDetailModel implements IProductDetailModel {

    @Override
    public Call<JsonInfo<ProductDetailEntity>> getBaseInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback) {
        Call<JsonInfo<ProductDetailEntity>> call = Request.creatApi(ProductService.class).getBaseInfo(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonInfo<ProductDetailEntity>> getDetailInfo(Map<String, Object> map, Callback<JsonInfo<ProductDetailEntity>> callback) {
        Call<JsonInfo<ProductDetailEntity>> call = Request.creatApi(ProductService.class).getDetailInfo(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<Object> addToCart(Map<String, Object> map, Callback<Object> callback) {
        Call<Object> call = Request.creatApi(ProductService.class).addToCart(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<ProductAttributeEntity> getSku(Map<String, Object> map, Callback<ProductAttributeEntity> callback) {
        Call<ProductAttributeEntity> call = Request.creatApi(ProductService.class).getSku(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<TotalCommentEntity> getComments(Map<String, Object> map, Callback<TotalCommentEntity> callback) {
        Call<TotalCommentEntity> call = Request.creatApi(CommentService.class).getComments(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<BaseProductEntity>> getRecommends(Map<String, Object> map, Callback<JsonArrayInfo<BaseProductEntity>> callback){
        Call<JsonArrayInfo<BaseProductEntity>> call = Request.creatApi(ProductService.class).getRecommends(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 上架到聚小店
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> onSaleToJu(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = NewRequest.creatApi(StoreService.class).onSaleProviderProduct(map);
        call.enqueue(callback);
        return call;
    }

}
