package com.loonxi.ju53.entity;

import java.io.Serializable;

/**
 * 产品基本信息
 * Created by Xuzue on 2015/12/26.
 */
public class BaseProductEntity implements Serializable {

    /**
     * pid
     */
    private long pid;
    /**
     * 宝贝id
     */
    private String productId;
    /**
     * 宝贝名称
     */
    private String productName;
    /**
     * 价格
     */
    private double price;
    /**
     * 建议价
     */
    private float markPrice;
    /**
     * 宝贝图片
     */
    private String picture;
    /**
     * 销量
     */
    private int sold;
    /**
     * 购物车里该宝贝的件数
     */
    private int count;
    /**
     * 颜色
     */
    private String attributeColor;
    /**
     * 尺寸
     */
    private String attributeMula;
    /**
     * 修改时间
     */
    private String modified;
    /**
     * 加入购物车时间
     */
    private long created;
    /**
     * 库存
     */
    private int stock;
    /**
     * 库存id
     */
    private String stockid;
    /**
     * 运费模板id
     */
    private int freightId;
    /**
     * 运费模板
     */
    private FreightRule freightRule;
    /**
     * 运费
     */
    private double freight;
    /**
     * 是否收藏 0:收藏 1：未收藏
     */
    private int follow;
    /**
     * 产品状态
     */
    private int state;

    /**
     * 重量
     */
    private double weight;

    /**
     * 产品类型 0：普通产品 1：团购产品
     */
    private int type;

    public BaseProductEntity(){

    }

    public long getPid() {
        return pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getAttributeColor() {
        return attributeColor;
    }

    public void setAttributeColor(String attributeColor) {
        this.attributeColor = attributeColor;
    }

    public String getAttributeMula() {
        return attributeMula;
    }

    public void setAttributeMula(String attributeMula) {
        this.attributeMula = attributeMula;
    }

    public String getModified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    public long getCreated() {
        return created;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getStockid() {
        return stockid;
    }

    public void setStockid(String stockid) {
        this.stockid = stockid;
    }

    public int getFreightId() {
        return freightId;
    }

    public void setFreightId(int freightId) {
        this.freightId = freightId;
    }

    public FreightRule getFreightRule() {
        return freightRule;
    }

    public void setFreightRule(FreightRule freightRule) {
        this.freightRule = freightRule;
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }

    public float getMarkPrice() {
        return markPrice;
    }

    public void setMarkPrice(float markPrice) {
        this.markPrice = markPrice;
    }

    public int getFollow() {
        return follow;
    }

    public void setFollow(int follow) {
        this.follow = follow;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
