package com.loonxi.ju53.fragment;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.web.BaseWebView;
import com.loonxi.ju53.widgets.ScrollSwipeRefreshLayout;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

/**
 * Created by laojiaqi on 2016/5/31.
 */

@ContentView(R.layout.activity_webview_layout)
public class WebViewFragment extends BaseFragment implements BaseWebView.onWebViewListener {
    @ViewInject(R.id.activity_base_web_view)
    BaseWebView mBaseWebview;
    @ViewInject(R.id.activity_sp_refresh)
    ScrollSwipeRefreshLayout mSsr;

    private String title;
    private String url;
    private boolean mIsTop;

    public static BaseFragment newInstance(String title, String url) {
        WebViewFragment fragment = new WebViewFragment();
        Bundle args = new Bundle();
        args.putString("title", title);
        args.putString("url", url);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void initView() {
        title = getArguments().getString("title");
        url = getArguments().getString("url");
       mBaseWebview.start(url);

      //  mBaseWebview.startAssetsFile("text.html");
    }

    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        mBaseWebview.setOnWebViewListener(this);
        mBaseWebview.setScrollViewGroup(mSsr);
        //下拉刷新监听
        mSsr.setEnabled(true);
        mSsr.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //刷新页面
                mBaseWebview.refResh();
            }
        });
    }

    @Override
    public void onHtmlFinsh() {
        Log.e("onHtmlFinsh", "onHtmlFinsh");
        if (mSsr != null && mSsr.isRefreshing()) {
            mSsr.setRefreshing(false);
        }
    }
}
