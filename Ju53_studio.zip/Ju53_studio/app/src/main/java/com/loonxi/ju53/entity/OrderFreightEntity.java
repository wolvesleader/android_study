package com.loonxi.ju53.entity;

/**
 * 订单运费
 * Created by XuZue on 2016/6/20 0020.
 */
public class OrderFreightEntity {
    private String supplierId;
    private double freight;

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }
}
