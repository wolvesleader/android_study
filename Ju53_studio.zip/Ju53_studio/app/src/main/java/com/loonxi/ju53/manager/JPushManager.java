package com.loonxi.ju53.manager;

import android.app.Notification;
import android.content.Context;
import android.os.Handler;
import android.util.Log;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.JPushUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;

import java.lang.ref.WeakReference;
import java.util.Set;

import cn.jpush.android.api.BasicPushNotificationBuilder;
import cn.jpush.android.api.CustomPushNotificationBuilder;
import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

/**
 * JPush管理类
 * Created by Xuzue on 2016/4/1.
 */
public class JPushManager {
    private static final String TAG = "JPush";


    private static final int MSG_SET_ALIAS = 1001;
    private static final int MSG_SET_TAGS = 1002;
    private static Context mContext;
    private static MyHandler mHandler = new MyHandler(mContext);

    public JPushManager(Context context) {
        mContext = context;
    }


    /**
     * 调用JPush API设置Tag
     *
     * @param tag
     */
    public void setTag(String tag) {
        if (StringUtil.isEmpty(tag) || mHandler == null) {
            return;
        }
        mHandler.sendMessage(mHandler.obtainMessage(MSG_SET_TAGS, tag));
    }

    /**
     * 调用JPush API设置Alias
     *
     * @param alias
     */
    public void setAlias(String alias) {
        if (StringUtil.isEmpty(alias) || mHandler == null) {
            return;
        }
        mHandler.sendMessage(mHandler.obtainMessage(MSG_SET_ALIAS, alias));
    }

    /**
     * 调用JPush api设置Push时间
     *
     * @param days     0:星期日 1：星期一 (接收消息的星期集合，0到6)
     * @param startime
     * @param endtime
     */
    public void setReceiveTime(Set<Integer> days, int startime, int endtime) {
        JPushInterface.setPushTime(mContext, days, startime, endtime);
    }


    /**
     * 设置通知提示方式 - 基础属性
     */
    public void setStyleBasic() {
        BasicPushNotificationBuilder builder = new BasicPushNotificationBuilder(mContext);
        if (android.os.Build.VERSION.SDK_INT < 21) {
            builder.statusBarDrawable = R.drawable.ic_launcher;
        } else {
            builder.statusBarDrawable = R.drawable.ic_launcher_21;
        }
        builder.notificationFlags = Notification.FLAG_AUTO_CANCEL;
        builder.notificationDefaults = Notification.DEFAULT_SOUND;
        JPushInterface.setPushNotificationBuilder(1, builder);
    }


    /**
     * 设置通知栏样式 - 定义通知栏Layout
     */
    public void setStyleCustom() {
        CustomPushNotificationBuilder builder = new CustomPushNotificationBuilder(mContext,
                R.layout.customer_notitfication_layout, R.id.icon, R.id.title, R.id.text);
        if (android.os.Build.VERSION.SDK_INT < 21) {
            builder.layoutIconDrawable = R.drawable.ic_launcher;
        } else {
            builder.layoutIconDrawable = R.drawable.ic_launcher_21;
        }
        builder.developerArg0 = "developerArg2";
        JPushInterface.setPushNotificationBuilder(2, builder);
    }

    /**
     * 设置别名的回调
     */
    private static TagAliasCallback mAliasCallback = new TagAliasCallback() {
        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            String logs;
            switch (code) {
                case 0:
                    logs = "Set alias success";
                    Log.i(TAG, logs);
                    break;

                case 6002:
                    logs = "Failed to set alias due to timeout. Try again after 60s.";
                    Log.i(TAG, logs);
                    if (JPushUtil.isConnected(mContext)) {
                        mHandler.sendMessageDelayed(mHandler.obtainMessage(MSG_SET_ALIAS, alias), 1000 * 60);
                    } else {
                        Log.i(TAG, "No network");
                    }
                    break;

                default:
                    logs = "Failed with errorCode = " + code;
                    Log.e(TAG, logs);
            }
            JPushUtil.showToast(logs, mContext);
        }
    };

    /**
     * 设置Tag的回调
     */
    private static TagAliasCallback mTagsCallback = new TagAliasCallback() {
        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            String logs;
            switch (code) {
                case 0:
                    logs = "Set tag success";
                    Log.i(TAG, logs);
                    break;

                case 6002:
                    logs = "Failed to set tags due to timeout. Try again after 60s.";
                    Log.i(TAG, logs);
                    if (JPushUtil.isConnected(mContext)) {
                        mHandler.sendMessageDelayed(mHandler.obtainMessage(MSG_SET_TAGS, tags), 1000 * 60);
                    } else {
                        Log.i(TAG, "No network");
                    }
                    break;

                default:
                    logs = "Failed with errorCode = " + code;
                    Log.e(TAG, logs);
            }
            JPushUtil.showToast(logs, mContext);
        }
    };


    private static class MyHandler extends Handler {

        private final WeakReference<Context> mActivity;

        public MyHandler(Context context) {
            mActivity = new WeakReference<Context>(context);
        }

        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            if (mActivity == null || mActivity.get() == null) {
                return;
            }
            LogUtil.mLog().d("receive:" + (String) msg.obj);
            switch (msg.what) {
                case MSG_SET_ALIAS:
                    Log.d(TAG, "Set alias in handler.");
                    JPushInterface.setAliasAndTags(mContext, (String) msg.obj, null, mAliasCallback);
                    break;

                case MSG_SET_TAGS:
                    Log.d(TAG, "Set tags in handler.");
                    JPushInterface.setAliasAndTags(mContext, null, (Set<String>) msg.obj, mTagsCallback);
                    break;

                default:
                    Log.i(TAG, "Unhandled msg - " + msg.what);
            }
        }
    }

    ;
}
