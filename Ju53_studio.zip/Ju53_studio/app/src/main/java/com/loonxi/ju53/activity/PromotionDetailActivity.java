package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.PromotionDetailAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.entity.PromotionProductEntity;
import com.loonxi.ju53.presenters.PromotionDetailPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IPromotionDetailView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedGridView;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 活动详情
 * Created by Xuzue on 2016/2/25.
 */
public class PromotionDetailActivity extends ActionBarActivity implements View.OnClickListener, IPromotionDetailView {

    @ViewInject(R.id.promotion_detail_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.promotion_detail_iv_logo)
    private ImageView mIvLogo;
    @ViewInject(R.id.promotion_detail_fixedgridview)
    private FixedGridView mFgv;

    private PromotionDetailPresenter mPresenter;
    private String promotionId;
    private PromotionDetailAdapter mAdapter;
    private List<PromotionProductEntity> mPromotionProducts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promotion_detail);
    }

    @Override
    public void initView() {
    }

    @Override
    public void initContent() {
        mPresenter = new PromotionDetailPresenter(this);
        promotionId = getIntent().getStringExtra("promotionId");
        mAdapter = new PromotionDetailAdapter(mContext, mPromotionProducts);
        mFgv.setAdapter(mAdapter);
        mPresenter.getPromotionDetail(promotionId);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getPromotionDetail(promotionId);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getPromotionDetail(promotionId);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
        }
    }

    @Override
    public void onGetPromotionDetailSuccess(PromotionEntity promotion) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mPromotionProducts.clear();
        if (promotion != null) {
            setTitle(promotion.getTitle());
            if (!isFinishing() && mContext != null && !StringUtil.isEmpty(promotion.getBanner())) {
                Glide.with(mContext).load(AppConst.PIC_HEAD + promotion.getBanner() + AppConst.PIC_SIZE_250).into(mIvLogo);
            }
            if (!ListUtil.isEmpty(promotion.getList())) {
                mPromotionProducts.addAll(promotion.getList());
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onGetPromotiondetailFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }
}
