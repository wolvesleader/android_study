package com.loonxi.ju53.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MessageActivity;
import com.loonxi.ju53.activity.SearchHistoryActivity;
import com.loonxi.ju53.adapter.SortContentAdapter;
import com.loonxi.ju53.adapter.SortMenuAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.listener.SortFragmentLifeCircle;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.presenters.SortPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ISortView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * "分类Fragment"
 * Created by Xuzue on 2015/12/17.
 */

@ContentView(R.layout.fragment_sort)
public class SortFragment extends BaseSafeFragment<ISortView, SortPresenter> implements ISortView, OnNetWorkListener, View.OnClickListener, SortFragmentLifeCircle {

    @ViewInject(R.id.fragment_sort_actionbar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_sort_layout_container)
    private LinearLayout mLayoutContainer;
    @ViewInject(R.id.fragment_sort_lv_menu)
    private ListView mLvMenu;
    @ViewInject(R.id.fragment_sort_ptr)
    private PullToRefreshScrollView mPullToRefershScrollView;
    @ViewInject(R.id.fragment_sort_flv)
    private FixedListView mFlv;
    @ViewInject(R.id.fragment_sort_stub)
    private ViewStub mStub;

    private SortMenuAdapter mMenuAdapter;
    private SortContentAdapter mContentAdapter;

    private LinearLayout mLastCheckLayoutMenu;
    private TextView mLastCheckTvName;

    private List<SortEntity> mMenu = new ArrayList<>();
    private List<SortEntity> mContent = new ArrayList<>();
    private SortPresenter mPresenter;
    private String mFirstCheckCategory;


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void initView() {
        mActionBar.setLeftImageResource(R.drawable.icon_message_gray);
        mActionBar.setRightVisibility(View.VISIBLE);
        mActionBar.setRightImageResource(R.drawable.icon_search_gray);
        mActionBar.setTitle(R.string.sort_title);
        mActionBar.setTitleColor(getResources().getColor(R.color.app_black));
    }

    @Override
    public void initContent() {
        mPresenter = new SortPresenter(this);
        Bundle b = getArguments();
        if (b != null) {
            mFirstCheckCategory = b.getString("firstSort");
        }
        mPresenter.getSorts();
        getSubSort();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void setListener() {
        setOnNetWorkListener(this);
        mActionBar.setOnRightClickListener(this);
        mActionBar.setOnLeftClickListener(this);
    }

    public void getSortById(String id) {
        mContent.clear();
        if (mContentAdapter != null) {
            mContentAdapter.notifyDataSetChanged();
        }
        if (mPresenter != null) {
            mPresenter.getSortById(id);
        }
    }

    private List<SortEntity> getFirstSort(JsonArrayInfo<SortEntity> json) {
        List<SortEntity> sorts = new ArrayList<>();
        if (ListUtil.isEmpty(json.getData()) || json.getData().get(0) == null) {
            return sorts;
        }
        sorts.addAll(json.getData().get(0).getList());
        return sorts;
    }

    private void getSubSort(){
        if (mMenuAdapter != null && mPresenter != null) {
            int index = mMenuAdapter.getFirstCheckPosition();
            if (index < 0) {//传进来的分类id不合法，则获取第一个分类
                mPresenter.getSorts();
            }else{
                mPresenter.getSortById(mFirstCheckCategory);

            }
        }
    }

    @Override
    public void onGetSortsSuccess(JsonArrayInfo<SortEntity> json) {
        setNetErrorView(mLayoutContainer, mStub, false);
        mMenu.clear();
        if (!ListUtil.isEmpty(json.getData())) {
            mMenu.addAll(json.getData());
            mContent.addAll(getFirstSort(json));
        }
        if (mMenuAdapter == null) {
            mMenuAdapter = new SortMenuAdapter(mContext, this, mMenu, mFirstCheckCategory);
            mLvMenu.setAdapter(mMenuAdapter);
        } else {
            mMenuAdapter.notifyDataSetChanged();
        }
        if (mContentAdapter == null) {
            mContentAdapter = new SortContentAdapter(mContext, mContent);
            mFlv.setAdapter(mContentAdapter);
        } else {
            mContentAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onGetSortsFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message, mLayoutContainer, mStub);
    }

    @Override
    public void onGetSortByIdSuccess(JsonArrayInfo<SortEntity> sorts) {
        mContent.clear();
        if (!ListUtil.isEmpty(sorts.getData())) {
            mContent.addAll(sorts.getData());
        }
        if (mContentAdapter == null) {
            mContentAdapter = new SortContentAdapter(mContext, mContent);
            mFlv.setAdapter(mContentAdapter);
        } else {
            mContentAdapter.notifyDataSetChanged();
        }
        if (ListUtil.isEmpty(mContent)) {
            showToast(R.string.sort_empty);
        }
    }

    @Override
    public void onGetSortByIdFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message, mLayoutContainer, mStub);
    }

    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {
        mPresenter.getSorts();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.RIGHT_CLICK_ID:
                startActivity(new Intent(mContext, SearchHistoryActivity.class));
                break;
            case ActionBar.LEFT_CLICK_ID:
                MessageActivity.gotoMessageActivity(mContext);
                break;
        }
    }

    @Override
    protected SortPresenter createPresenter(ISortView iSortView) {
        return new SortPresenter(this);
    }

    @Override
    public void onNetWorkConnected() {
        if (mPresenter == null) {
            return;
        }
        if (mMenu.size() == 0 || mContent.size() == 0) {
            mPresenter.getSorts();
        }
    }

    @Override
    public void fragmentResume(String firstShowSort) {
        mFirstCheckCategory = firstShowSort;
        if (mLvMenu != null) {
            mMenuAdapter = new SortMenuAdapter(mContext, this, mMenu, mFirstCheckCategory);
            mLvMenu.setAdapter(mMenuAdapter);
        }
        getSubSort();
    }
}
