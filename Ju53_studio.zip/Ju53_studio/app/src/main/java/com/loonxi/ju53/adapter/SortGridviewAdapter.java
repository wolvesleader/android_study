package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SearchActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.SortEntity;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/24.
 */
public class SortGridviewAdapter extends BaseObjectListAdapter<SortEntity> {
    public SortGridviewAdapter(Context context, List<SortEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.griditem_sort_content, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.griditem_sort_content_layout_root);
            holder.mIvLog = (ImageView) convertView.findViewById(R.id.griditem_sort_content_iv);
            holder.mTvName = (TextView) convertView.findViewById(R.id.griditem_sort_content_tv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final SortEntity entity = get(position);
        holder.mTvName.setText(entity.getName());
        Glide.with(mContext).load(AppConst.PIC_HEAD + entity.getImgUrl()).into(holder.mIvLog);

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, SearchActivity.class);
                intent.putExtra("key", entity.getName());
                intent.putExtra("categoryId", entity.getPid() + "");
                intent.putExtra("isSort", true);
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    static class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvLog;
        TextView mTvName;
    }
}
