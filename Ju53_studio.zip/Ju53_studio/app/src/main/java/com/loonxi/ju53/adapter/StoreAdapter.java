package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.StoreProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.fragment.StoreFragment;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.widgets.popupwindow.StorePopupWindow;
import com.loonxi.ju53.widgets.popupwindow.StorePopupWindowNew;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreAdapter extends BaseObjectListAdapter<StoreProductEntity> {

    private StoreFragment mFragment;
    private boolean mIsOffSale;
    private Map<Integer, Boolean> checkMap = new HashMap<>();

    public StoreAdapter(Context context, StoreFragment fragment, List<StoreProductEntity> datas, boolean isOffSale) {
        super(context, datas);
        mFragment = fragment;
        mIsOffSale = isOffSale;
        for (int i = 0; i < datas.size(); i++) {
            checkMap.put(i, false);
        }
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_store, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_store_layout_root);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_store_iv_head);
            holder.mTvName = (TextView) convertView.findViewById(R.id.listitem_store_tv_name);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_store_tv_price);
            holder.mTvCommission = (TextView) convertView.findViewById(R.id.listitem_store_tv_commission);
            holder.mTvStock = (TextView) convertView.findViewById(R.id.listitem_store_tv_stock);
            holder.mLayoutMore = (LinearLayout) convertView.findViewById(R.id.listitem_store_layout_more);
            holder.mIvMore = (ImageView) convertView.findViewById(R.id.listitem_store_iv_more);
            holder.mTvPromotion = (TextView) convertView.findViewById(R.id.listitem_store_tv_promotion);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final StoreProductEntity productEntity = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + productEntity.getPicture()).into(holder.mIvHead);
        holder.mTvName.setText(productEntity.getProductName());
        holder.mTvPrice.setText("¥" + productEntity.getPrice());
        holder.mTvCommission.setText("¥" + productEntity.getCommission());
        holder.mTvStock.setText(mContext.getString(R.string.store_main_instock) + ": " + productEntity.getStock());

        int productType = productEntity.getProduct_type();
        if (productType == 1 || productType == 2) {
            holder.mTvPromotion.setVisibility(View.VISIBLE);
            holder.mTvPromotion.setText(productEntity.getType_name());
        } else {
            holder.mTvPromotion.setVisibility(View.GONE);
        }

        boolean check = (checkMap == null || checkMap.size() < position + 1) ? false : checkMap.get(position);
        holder.mIvMore.setSelected(check);
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, StoreProductDetailActivity.class);
                intent.putExtra("productId", productEntity.getProductId());
                intent.putExtra("isOnSale", "1".equals(productEntity.getState()) ? true : false);
                mContext.startActivity(intent);
            }
        });
        holder.mLayoutMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initCheckMap(position);
                notifyDataSetChanged();
//                StorePopupWindow.show(mContext, position, mFragment, holder.mIvMore, productEntity, mIsOffSale, new PopupWindow.OnDismissListener() {
//                    @Override
//                    public void onDismiss() {
//                        initCheckMap(-1);
//                        notifyDataSetChanged();
//                    }
//                });

                float density = DisplayUtil.getScreenDensity(mContext);
                int width = 0;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                if (mIsOffSale) {
                    width = DisplayUtil.dip2px(150, density);
                } else {
                    width = DisplayUtil.dip2px(300, density);
                }

                StorePopupWindowNew popupWindowNew = new StorePopupWindowNew(mContext, holder.mIvMore, width, height,
                        mFragment, productEntity, mIsOffSale,
                        new PopupWindow.OnDismissListener() {
                            @Override
                            public void onDismiss() {
                                initCheckMap(-1);
                                notifyDataSetChanged();
                            }
                        });

            }
        });
        return convertView;
    }

    private void initCheckMap(int checkPosition) {
        for (int i = 0; i < getCount(); i++) {
            if (i == checkPosition) {
                checkMap.put(i, true);
            } else {
                checkMap.put(i, false);
            }
        }
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvHead;
        TextView mTvName;
        TextView mTvPrice;
        TextView mTvCommission;
        TextView mTvStock;
        LinearLayout mLayoutMore;
        ImageView mIvMore;
        TextView mTvPromotion;
    }
}
