package com.loonxi.ju53.presenters;

import android.content.Context;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.models.IStoreModel;
import com.loonxi.ju53.models.impl.StoreModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IStoreView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
public class StorePresenter extends BasePresenter<IStoreView> {

    private IStoreView mView;
    private IStoreModel mModel;

    public StorePresenter(IStoreView view) {
        super(view);
        mView = getView();
        mModel = new StoreModel();
    }


    /**
     * 获得透明度
     *
     * @param value
     * @return
     */
    public float getAlpha(Context context, float value) {
        float ALPHA_SCROLL_LENGTH = context.getResources().getDimension(R.dimen.store_fragment_disappear_length);
        float alpha = value / (ALPHA_SCROLL_LENGTH);
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 1) {
            alpha = 1;
        }
        if (alpha > 0.5) {
            alpha = 1;
        } else if (alpha > 0.3 && alpha < 0.5) {
            alpha = 0.5f;
        }
        return alpha;
    }

    /**
     * 获取店铺产品列表
     *
     * @param isOffSale
     */
    public void getStoreProduct(boolean isOffSale, int page, boolean showDialog) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("state", isOffSale ? "0" : "1");
        map.put("page", page + "");
        map.put("pageSize", "5");
        if (showDialog && mView != null) {
            mView.startAsyncTask();
        }
        mModel.getStoreProducts(map, new Callback<JsonInfo<StoreDataEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<StoreDataEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<StoreDataEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onGetStoreProductSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onGetStoreProductFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 下架店铺商品
     *
     * @param productEntity
     */
    public void offSaleProduct(StoreProductEntity productEntity) {
        if (productEntity == null) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productEntity.getProductId());
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.offSaleProduct(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.offSaleSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.offSaleFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 上架店铺商品
     *
     * @param productEntity
     */
    public void onSaleProduct(StoreProductEntity productEntity) {
        if (productEntity == null) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productEntity.getProductId());
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.onSaleProduct(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onSaleSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onSaleFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 删除店铺商品
     *
     * @param productEntity
     */
    public void deleteProduct(StoreProductEntity productEntity) {
        if (productEntity == null) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productEntity.getProductId());
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.deleteProduct(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.deleteProductSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.deleteProductFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 店铺商品移到顶部
     *
     * @param productEntity
     */
    public void moveToTop(StoreProductEntity productEntity) {
        if (productEntity == null) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", productEntity.getProductId());
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.moveToTop(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.moveToTopSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.moveToTopFailed(apiErrorCode, message);
                }
            }
        });
    }

    /**
     * 获取店铺基本信息
     */
    public void getStoreBaseInfo() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getStoreBaseInfo(map, new Callback<JsonInfo<StoreBaseInfoEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<StoreBaseInfoEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<StoreBaseInfoEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.getBaseInfoSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.getBaseInfoFailed(apiErrorCode, message);
                }
            }
        });
    }

}
