package com.loonxi.ju53.constants;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;

/**
 * 产品状态（0-下架,1-上架,9-违规,-1-删除）
 * Created by Xuzue on 2016/3/3.
 */
public class ProductState {
    public static final int ON = 1;
    public static final int OFF = 0;
    public static final int ILLEGAL = 9;
    public static final int DELETE = -1;

    public static void setProductState(TextView tv, int state){
        Context context = BaseApplication.instance;
        if(tv == null){
            return;
        }
        switch (state){
            case OFF:
                tv.setVisibility(View.VISIBLE);
                tv.setText(context.getResources().getString(R.string.product_state_invalidate));
                break;
            case ILLEGAL:
                tv.setVisibility(View.VISIBLE);
                tv.setText(context.getResources().getString(R.string.product_state_invalidate));
                break;
            case DELETE:
                tv.setVisibility(View.VISIBLE);
                tv.setText(context.getResources().getString(R.string.product_state_invalidate));
                break;
            default:
                tv.setVisibility(View.INVISIBLE);
                break;
        }
    }
}
