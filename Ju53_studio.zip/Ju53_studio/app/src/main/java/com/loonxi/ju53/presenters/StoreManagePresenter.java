package com.loonxi.ju53.presenters;

import com.loonxi.ju53.models.IStoreModel;
import com.loonxi.ju53.models.impl.StoreModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IStoreManageView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreManagePresenter {
    private IStoreManageView mView;
    private IStoreModel mModel;

    public StoreManagePresenter(IStoreManageView mView) {
        this.mView = mView;
        mModel = new StoreModel();
    }


    /**
     * 修改店铺头像
     */
    public void altStoreHead() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("", "");
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.altStoreName(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.altHeadSuccess();
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.altHeadFailed(apiErrorCode, message);
                }
            }
        });
    }
}
