package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.listener.OnPopwindowClickListener;

import java.util.ArrayList;
import java.util.List;

/**
 * 店铺里的“更多”
 * Created by Xuzue on 2016/5/3.
 */
public class StoreMorePopwindowAdapter extends BaseObjectListAdapter<String> {

    private List<String> mContentData = new ArrayList<>();
    private OnPopwindowClickListener mListener;

    public StoreMorePopwindowAdapter(Context context, List<String> datas, OnPopwindowClickListener listener) {
        super(context, datas);
        mContentData.clear();
        mContentData.addAll(datas);
        mListener = listener;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_popwindow_store, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_popwindow_store_layout_root);
            holder.mTvContent = (TextView) convertView.findViewById(R.id.listitem_popwindow_store_tv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.mTvContent.setText(mContentData.get(position));
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mListener != null){
                    mListener.click(get(position), position);
                }
            }
        });
        return convertView;
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        TextView mTvContent;
    }

}
