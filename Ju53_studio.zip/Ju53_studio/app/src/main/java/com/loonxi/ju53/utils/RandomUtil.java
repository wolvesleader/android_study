package com.loonxi.ju53.utils;

import java.util.Random;

/**
 * Created by Xuze on 2015/9/3.
 */
public class RandomUtil {
    /**
     * 数字
     */
    public static final String NUMBERS = "0123456789";
    /**
     * 字母
     */
    public static final String LETTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    /**
     * 大写字母
     */
    public static final String CAPITAL_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    /**
     * 小写字母
     */
    public static final String LOWER_CASE_LETTERS = "abcdefghijklmnopqrstuvwxyz";
    /**
     * 数字和字母
     */
    public static final String NUMBERS_AND_LETTERS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    /**
     * 随机获取固定个数的数字进行拼接
     *
     * @param length
     * @return
     */
    public static String getRandomNumbers(int length) {
        return getRandom(NUMBERS.toCharArray(), length);
    }

    /**
     * 随机获取固定个数的字母进行拼接
     *
     * @param length
     * @return
     */
    public static String getRandomLetters(int length) {
        return getRandom(LETTERS.toCharArray(), length);
    }

    /**
     * 随机获取固定个数的大写字母进行拼接
     *
     * @param length
     * @return
     */
    public static String getRandomCaptialLetters(int length) {
        return getRandom(CAPITAL_LETTERS.toCharArray(), length);
    }

    /**
     * 随机获取固定个数的小写字母进行拼接
     *
     * @param length
     * @return
     */
    public static String getRandomLowercaseLetters(int length) {
        return getRandom(LOWER_CASE_LETTERS.toCharArray(), length);
    }

    /**
     * 从字符数组中随机获取固定个数的字符进行拼接
     *
     * @param sourceChar
     * @param length
     * @return
     */
    public static String getRandom(char[] sourceChar, int length) {
        if (sourceChar == null || sourceChar.length == 0 || length <= 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder(length);
        Random random = new Random();
        for (int i = 0; i < sourceChar.length; i++) {
            sb.append(sourceChar[random.nextInt(length)]);
        }
        return sb.toString();
    }
}