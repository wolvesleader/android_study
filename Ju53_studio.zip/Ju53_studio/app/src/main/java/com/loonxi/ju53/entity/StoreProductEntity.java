package com.loonxi.ju53.entity;

/**
 * 店铺商品实体
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreProductEntity {

    private String product_id;
    private String product_name;
    private String product_pic;
    private String price;
    private String commission;
    private String stock;
    private String state;// 1:上架 0：下架
    private String share_url;//分享链接
    private String share_title;//分享标题
    private String share_content;//分享内容
    private String type_name;//活动名称
    private int product_type;// 0：普通类型 1：团购 2：打折


    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getProductId() {
        return product_id;
    }

    public void setProductId(String product_id) {
        this.product_id = product_id;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    private String sort;

    public String getProductName() {
        return product_name;
    }

    public void setProductName(String name) {
        this.product_name = name;
    }

    public String getPicture() {
        return product_pic;
    }

    public void setPicture(String picture) {
        this.product_pic = picture;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getShare_url() {
        return share_url;
    }

    public void setShare_url(String share_url) {
        this.share_url = share_url;
    }

    public String getShare_title() {
        return share_title;
    }

    public void setShare_title(String share_title) {
        this.share_title = share_title;
    }

    public String getShare_content() {
        return share_content;
    }

    public void setShare_content(String share_content) {
        this.share_content = share_content;
    }

    public String getType_name() {
        return type_name;
    }

    public void setType_name(String type_name) {
        this.type_name = type_name;
    }

    public int getProduct_type() {
        return product_type;
    }

    public void setProduct_type(int product_type) {
        this.product_type = product_type;
    }
}
