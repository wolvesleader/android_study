package com.loonxi.ju53.listener;

/**
 * Created by Administrator on 2016/1/14.
 */
public interface FragmentLifeCircle {

    public void fragmentPause();

    public void fragmentResume(int position);

}
