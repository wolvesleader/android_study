package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/25.
 */
public interface ISortModel {

    Call<JsonArrayInfo<SortEntity>> getSorts(Map<String, Object> map, Callback<JsonArrayInfo<SortEntity>> callback);

    Call<JsonArrayInfo<SortEntity>> getSortById(Map<String, Object> map, Callback<JsonArrayInfo<SortEntity>> callback);

}
