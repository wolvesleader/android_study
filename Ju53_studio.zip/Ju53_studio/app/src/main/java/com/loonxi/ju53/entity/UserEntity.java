package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * Created by Xuzue on 2016/3/7.
 */
public class UserEntity extends BaseJsonInfo implements Parcelable {
    private String userId;
    private String userName;
    private String mobile;
    private String logo;

    public UserEntity() {

    }

    protected UserEntity(Parcel in) {
        super(in);
        userId = in.readString();
        userName = in.readString();
        mobile = in.readString();
        logo = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(userId);
        dest.writeString(userName);
        dest.writeString(mobile);
        dest.writeString(logo);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<UserEntity> CREATOR = new Creator<UserEntity>() {
        @Override
        public UserEntity createFromParcel(Parcel in) {
            return new UserEntity(in);
        }

        @Override
        public UserEntity[] newArray(int size) {
            return new UserEntity[size];
        }
    };

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }
}
