package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.fragment.MyOrderContentFragment;
import com.loonxi.ju53.fragment.SaleOrderContentFragment;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;
import com.loonxi.ju53.widgets.viewpagerindicator.TabPageIndicator;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class MyOrderActivity extends BaseActivity implements View.OnClickListener, OnNetWorkListener {

    @ViewInject(R.id.order_layout_left)
    private LinearLayout mLayoutLeft;
    @ViewInject(R.id.order_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.order_iv_right)
    private ImageView mIvRight;
    @ViewInject(R.id.order_tv_title_onsale)
    private TextView mTvTitleOnsale;
    @ViewInject(R.id.order_tv_title_buy)
    private TextView mTvTitleBuy;

    @ViewInject(R.id.order_tabbar)
    private TabPageIndicator mTabBar;
    @ViewInject(R.id.order_viewpager)
    private ViewPager mBuyViewPager;
    @ViewInject(R.id.order_viewpager_sale)
    private ViewPager mSaleViewPager;


    public static String FIRST_DISPLAY_FRAGMENT_FLAG = "first_display_fragment_flag";
    public static String FIRST_DISPLAY_ORDER_BUY = "first_display_order_type";
    public static int DEFAULT_DISPLAY_FRAGMENT = 0;
    public int FIRST_DISPLAY_FRAGMENT = DEFAULT_DISPLAY_FRAGMENT;//初始显示的订单类别（按订单状态分）
    public static final int ORDER_DFK_INDEX = 1;
    public static final int ORDER_DFH_INDEX = 2;
    public static final int ORDER_DSH_INDEX = 3;
    public static final int ORDER_DPJ_INDEX = 4;
    public static final int ORDER_TK_INDEX = 5;

    private PullToRefreshListView mPlv;
    private BuyViewPagerAdapter mBuyViewPagerAdapter;
    private SaleViewPagerAdapter mSaleViewPagerAdapter;
    private static int FRAGMENT_NUM_BUY = 6;//进货单Tab数
    private static int FRAGMENT_NUM_SALE = 5;//分销单Tab数
    private String[] mBuyTitle;
    private String[] mSaleTitle;
    private List<MyOrderContentFragment> mBuyFragmentList = new ArrayList<>();
    private List<SaleOrderContentFragment> mSaleFragmentList = new ArrayList<>();
    private int mCurrentPosition = FIRST_DISPLAY_FRAGMENT;//默认显示全部订单
    private boolean mIsBuyOrder = false;//是否是进货订单
    private FragmentTransaction mTransaction;
    private FragmentManager mFragmentManager;
    private MyViewPageChangeListener mViewPageChangeListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        x.view().inject(this);
        initView();
        initContent();
        setListener();
    }


    public void initView() {
        mBuyTitle = getResources().getStringArray(R.array.my_buy_order_title);
        mSaleTitle = getResources().getStringArray(R.array.my_sale_order_title);
    }

    public void initContent() {
        initFirstDisplayIndex();
        mViewPageChangeListener = new MyViewPageChangeListener();
        changeOrder(mIsBuyOrder, FIRST_DISPLAY_FRAGMENT);
    }

    /**
     * 初始化第一次显示索引
     */
    private void initFirstDisplayIndex() {
        FIRST_DISPLAY_FRAGMENT = getIntent().getIntExtra(FIRST_DISPLAY_FRAGMENT_FLAG, DEFAULT_DISPLAY_FRAGMENT);
        mIsBuyOrder = getIntent().getBooleanExtra(FIRST_DISPLAY_ORDER_BUY, false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mTabBar.setCurrentItem(mCurrentPosition);
    }

    /**
     * 初始化进货单Fragment
     */
    private void initBuyFragment() {
        if (ListUtil.isEmpty(mBuyFragmentList)) {
            mBuyFragmentList = new ArrayList<>();
            for (int i = 0; i < FRAGMENT_NUM_BUY; i++) {
                MyOrderContentFragment temp = MyOrderContentFragment.createContentFragment(i);
                mBuyFragmentList.add(temp);
            }
        }
    }

    /**
     * 初始化分销单Fragment
     */
    private void initSaleFragment() {
        if (ListUtil.isEmpty(mSaleFragmentList)) {
            mSaleFragmentList = new ArrayList<>();
            for (int i = 0; i < FRAGMENT_NUM_SALE; i++) {
                SaleOrderContentFragment temp = SaleOrderContentFragment.createContentFragment(i);
                mSaleFragmentList.add(temp);
            }
        }
    }

    public void setListener() {
        setOnNetWorkListener(this);
        mLayoutLeft.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
        mTvTitleOnsale.setOnClickListener(this);
        mTvTitleBuy.setOnClickListener(this);
    }

    private void changeFragment(int position) {
        FragmentLifeCircle fragmentLifeCircle = null;
        if (mIsBuyOrder) {
            fragmentLifeCircle = (FragmentLifeCircle) mBuyViewPagerAdapter.getItem(position);
        } else {
            fragmentLifeCircle = (FragmentLifeCircle) mSaleViewPagerAdapter.getItem(position);
        }
        fragmentLifeCircle.fragmentResume(position);
    }

    private void removeFragment(View container, int position) {
        if (mTransaction == null) {
            mTransaction = getSupportFragmentManager().beginTransaction();
        }
        String name = getFragmentName(container.getId(), position);
        Fragment fragment = mFragmentManager.findFragmentByTag(name);
        mTransaction.remove(fragment);
        mTransaction.commitAllowingStateLoss();
        mTransaction = null;
        mFragmentManager.executePendingTransactions();
    }

    private String getFragmentName(int viewId, int index) {
        return "android:switcher:" + viewId + ":" + index;
    }

    /**
     * 自定义viewPager的Adapter
     */
    private class BuyViewPagerAdapter extends FragmentPagerAdapter {

        public BuyViewPagerAdapter(FragmentManager fm) {
            super(fm);
            mFragmentManager = fm;
        }

        @Override
        public Fragment getItem(int position) {
            return mBuyFragmentList.get(position);
        }

        @Override
        public Object instantiateItem(View container, int position) {
            removeFragment(container, position);
            MyOrderContentFragment fragment = (MyOrderContentFragment) super.instantiateItem(container, position);
            return fragment;
        }

        @Override
        public int getCount() {
            return mBuyTitle.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mBuyTitle[position % mBuyTitle.length];
        }
    }

    /**
     * 自定义viewPager的Adapter
     */
    private class SaleViewPagerAdapter extends FragmentPagerAdapter {

        public SaleViewPagerAdapter(FragmentManager fm) {
            super(fm);
            mFragmentManager = fm;
        }

        @Override
        public Fragment getItem(int position) {
            return mSaleFragmentList.get(position);
        }

        @Override
        public Object instantiateItem(View container, int position) {
            removeFragment(container, position);
            SaleOrderContentFragment fragment = (SaleOrderContentFragment) super.instantiateItem(container, position);
            return fragment;
        }

        @Override
        public int getCount() {
            return mSaleTitle.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mSaleTitle[position % mSaleTitle.length];
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.order_layout_left:
                finish();
                break;
            case R.id.order_layout_right:
                ActionBarRightPopupWindow.show(mContext, mIvRight);
                break;
            case R.id.order_tv_title_onsale:
                changeOrder(false, 0);
                break;
            case R.id.order_tv_title_buy:
                changeOrder(true, 0);
                break;
        }
    }

    private void changeOrder(boolean isBuyOrder, int firstItem) {
        mIsBuyOrder = isBuyOrder;
        changeTab(isBuyOrder);
        if (isBuyOrder) {
            initBuyFragment();
        } else {
            initSaleFragment();
        }
        mBuyViewPager.removeOnPageChangeListener(mViewPageChangeListener);
        mSaleViewPager.removeOnPageChangeListener(mViewPageChangeListener);
        if (mIsBuyOrder) {
            mBuyViewPager.setVisibility(View.VISIBLE);
            mSaleViewPager.setVisibility(View.GONE);
            if (mBuyViewPagerAdapter == null) {
                mBuyViewPagerAdapter = new BuyViewPagerAdapter(getSupportFragmentManager());
                mBuyViewPager.setAdapter(mBuyViewPagerAdapter);
            }

            mBuyViewPager.setCurrentItem(0);
            mBuyViewPager.setOffscreenPageLimit(1);
            mBuyViewPager.addOnPageChangeListener(mViewPageChangeListener);
            mBuyViewPagerAdapter.notifyDataSetChanged();
            mTabBar.setViewPager(mBuyViewPager);
        } else {
            mBuyViewPager.setVisibility(View.GONE);
            mSaleViewPager.setVisibility(View.VISIBLE);
            if (mSaleViewPagerAdapter == null) {
                mSaleViewPagerAdapter = new SaleViewPagerAdapter(getSupportFragmentManager());
                mSaleViewPager.setAdapter(mSaleViewPagerAdapter);
            }
            mSaleViewPager.setCurrentItem(0);
            mSaleViewPager.setOffscreenPageLimit(1);
            mSaleViewPager.addOnPageChangeListener(mViewPageChangeListener);
            mSaleViewPagerAdapter.notifyDataSetChanged();
            mTabBar.setViewPager(mSaleViewPager);
        }
        mTabBar.setCurrentItem(firstItem);
    }

    private class MyViewPageChangeListener implements ViewPager.OnPageChangeListener {

        public MyViewPageChangeListener() {

        }

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageSelected(int position) {
            if (position != mCurrentPosition) {
                if (!mIsBuyOrder && position == mSaleFragmentList.size() - 1 && mCurrentPosition == mBuyFragmentList.size() - 1) {
                    return;
                }
                mCurrentPosition = position;
                changeFragment(position);
            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {
        }
    }

    private void changeTab(boolean isBuyOrder) {
        if (isBuyOrder) {
            mTvTitleOnsale.setBackground(null);
            mTvTitleOnsale.setSelected(false);
            mTvTitleBuy.setBackgroundResource(R.drawable.order_bg_right);
            mTvTitleBuy.setSelected(true);
        } else {
            mTvTitleOnsale.setBackgroundResource(R.drawable.order_bg_left);
            mTvTitleOnsale.setSelected(true);
            mTvTitleBuy.setBackground(null);
            mTvTitleBuy.setSelected(false);
        }
    }

    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {

    }
}
