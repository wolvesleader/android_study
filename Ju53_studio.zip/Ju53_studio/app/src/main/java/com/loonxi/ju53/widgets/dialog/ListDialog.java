package com.loonxi.ju53.widgets.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.utils.StringUtil;

/**
 * 列表Dialog
 * @author Administrator
 *
 */
public class ListDialog extends BaseDialog {

	private ListView mLvDisplay;

	public ListDialog(Context context, String title, BaseObjectListAdapter adapter,
					  OnItemClickListener listener) {
		super(context);
		View v = LayoutInflater.from(context).inflate(R.layout.dialog_list,
				null);
		addView(v);

		setTitle(StringUtil.isEmpty(title) ? context.getResources().getString(R.string.tip) : title);
		mLvDisplay = (ListView) findViewById(R.id.dialog_lv_display);
		mLvDisplay.setAdapter(adapter);
		mLvDisplay.setOnItemClickListener(listener);
	}

}
