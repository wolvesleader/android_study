package com.loonxi.ju53.presenters;

import android.view.View;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.models.IProductDetailModel;
import com.loonxi.ju53.models.impl.FavModel;
import com.loonxi.ju53.models.impl.ProductDetailModel;
import com.loonxi.ju53.models.impl.SupplierModel;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IProductDetailView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/1/11.
 */
public class ProductDetailPresenter extends BasePresenter<IProductDetailView> {

    FavModel mFavModel;
    IProductDetailModel mModel;
    IProductDetailView mView;
    SupplierModel mRecommendModel;

    public ProductDetailPresenter(IProductDetailView view) {
        super(view);
        mView = getView();
        mFavModel = new FavModel();
        mModel = new ProductDetailModel();
        mRecommendModel = new SupplierModel();
    }


    /**
     * 获取产品基本信息
     *
     * @param productId
     */
    public void getProductBaseInfo(String productId) {
        if (mView != null) {
            mView.startAsyncTask();
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", productId);
        mModel.getBaseInfo(map, new Callback<JsonInfo<ProductDetailEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<ProductDetailEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<ProductDetailEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetBaseInfoSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetBaseInfoFailed(apiErrorCode, message);

            }
        });
    }

    /**
     * 获取图文详情
     *
     * @param productId
     */
    public void getProductDetailInfo(String productId) {
        mView.startAsyncTask();
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", productId);
        mModel.getDetailInfo(map, new Callback<JsonInfo<ProductDetailEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<ProductDetailEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<ProductDetailEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetDetailSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetDetailFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 加入购物车
     *
     * @param productId
     * @param supperId
     * @param attributeColor
     * @param attributeMula
     * @param stockId
     * @param count
     */
    public void addToCart(String productId, String supperId, String attributeColor, String attributeMula, String stockId, int count) {
        if (StringUtil.isEmpty(productId) || StringUtil.isEmpty(supperId)) {
            return;
        }
        mView.startAsyncTask();
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", productId);
        map.put("supperId", supperId);
        map.put("attrbuteColor", attributeColor);
        map.put("attrbuteMula", attributeMula);
        map.put("stockId", stockId);
        map.put("count", count + "");
        mModel.addToCart(map, new Callback<Object>() {

            @Override
            public void onOtherFlag(int flag, String message, Object data) {

            }

            @Override
            public void onSuccess(Object data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                try {
                    JSONObject object = new JSONObject(data.toString());
                    int flag = object.optInt("flag");
                    String message = object.optString("message");
                    if (flag == ApiError.REQUEST_SUCCESS) {
                        mView.onAddToCartSuccess(data);
                    } else if (flag == ApiError.REQUEST_FAILURE_INCORRECT_INFO) {
                        mView.onAddToCartFailed(ApiError.REQUEST_FAILURE_INCORRECT_INFO, message);
                    } else if (flag == ApiError.REQUEST_FAILURE_OFFLINE) {
                        mView.onAddToCartFailed(ApiError.REQUEST_FAILURE_OFFLINE, message);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    mView.onAddToCartFailed(ApiError.CONVERSION, BaseApplication.instance.getString(R.string.error_product_addtocart));
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onAddToCartFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 获取产品规格
     *
     * @param view
     * @param cart
     * @param product
     */
    public void getSku(final View view, final CartEntity cart, final BaseProductEntity product) {
        if (product == null) {
            mView.showToast(R.string.shopping_null);
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", product.getProductId());
        mView.startAsyncTask();
        mModel.getSku(map, new Callback<ProductAttributeEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, ProductAttributeEntity data) {

            }

            @Override
            public void onSuccess(ProductAttributeEntity data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetSkuSuccess(view, cart, product, data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetSkuFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 收藏/取消收藏
     *
     * @param targetId
     * @param type
     * @param state
     */
    public void fav(String targetId, int type, final int state) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("targetId", targetId);
        map.put("type", type + "");
        map.put("state", state + "");
        mFavModel.fav(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onFavSuccess(state == 0 ? true : false);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onFavFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 获取同店推荐
     *
     * @param userId
     * @param page
     */
    public void getSupplierRecommends(String userId, int page) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("userId", userId);
        map.put("page", page + "");
        if (mView != null && page == 1) {
            mView.startAsyncTask();
        }
        mRecommendModel.getSupplierInfo(map, new Callback<JsonInfo<SupplierEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<SupplierEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<SupplierEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetRecommendSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetRecommendFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 上架到聚小店
     *
     * @param detail
     */
    public void onSaleToJu(ProductDetailEntity detail) {
        if (detail == null) {
            return;
        }
        String detailPic = detail.getPicture();
        String firstPic = detailPic;
        if (!StringUtil.isEmpty(detailPic) && detailPic.split(",") != null && detailPic.split(",").length > 0) {
            firstPic = detailPic.split(",")[0];
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("product_id", detail.getProductId());
        map.put("product_name", detail.getProductName());
        map.put("supplier_id", detail.getUserId());
        map.put("supplier_name", detail.getUserName());
        map.put("product_pic", firstPic);
        map.put("product_type", firstPic);
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.onSaleToJu(map, new Callback<BaseJsonInfo>() {
            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onSaleToJuSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onSaleToJuFailed(apiErrorCode, message);
            }
        });
    }
}
