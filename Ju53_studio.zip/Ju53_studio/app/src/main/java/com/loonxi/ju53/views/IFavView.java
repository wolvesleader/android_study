package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.FavEntity;

/**
 * Created by Xuzue on 2016/2/18.
 */
public interface IFavView {
    void onGetFavListSuccess(FavEntity favs);
    void onGetFavListFailed(int apiErrorCode, String message);
}
