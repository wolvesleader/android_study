package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.models.ISortModel;
import com.loonxi.ju53.models.impl.SortModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ISortView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2015/12/25.
 */
public class SortPresenter extends BasePresenter<ISortView> {
    private ISortModel mModel;
    private ISortView mView;

    public SortPresenter(ISortView view) {
        super(view);
        mView = getView();
        mModel = new SortModel();
    }

    /**
     * 获取分类
     */
    public void getSorts() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getSorts(map, new Callback<JsonArrayInfo<SortEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<SortEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<SortEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetSortsSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetSortsFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 获取二级分类
     *
     * @param sortId
     */
    public void getSortById(String sortId) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("id", sortId);
        mModel.getSortById(map, new Callback<JsonArrayInfo<SortEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<SortEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<SortEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetSortByIdSuccess(data);
            }

            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetSortByIdFailed(apiErrorCode, message);
            }
        });
    }

}
