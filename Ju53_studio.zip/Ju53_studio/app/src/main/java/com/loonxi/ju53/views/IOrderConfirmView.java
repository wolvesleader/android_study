package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.FreightRule;
import com.loonxi.ju53.entity.OrderCreateEntity;
import com.loonxi.ju53.entity.OrderFreightEntity;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/18.
 */
public interface IOrderConfirmView extends IBaseView{
    void showToast(int resId);
    void onGetDefaultAddressSuccess(AddressEntity addressEntity);
    void onGetDefaultAddressFailed(int apiErrorCode, String message);
    void onCreateOrderSuccess(OrderCreateEntity entity);
    void onCreateOrderFailed(int apiErrorCode, String message);
    void onGetFreightRuleSuccess(List<FreightRule> freightRules);
    void onGetFreightRuleFailed(int apiErrorCode, String message);
    void onGetSupplierFreightSuccess(List<OrderFreightEntity> results);
    void onGetSupplierFrgightFailed(int apiErrorCode, String message);
}
