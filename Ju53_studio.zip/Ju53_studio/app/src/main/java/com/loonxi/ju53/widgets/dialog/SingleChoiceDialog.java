package com.loonxi.ju53.widgets.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.StringUtil;

/**
 * Created by Xuzue on 2015/10/30.
 */
public class SingleChoiceDialog extends BaseDialog {

    private ListView mListView;
    private Button mBtnOk;
    private Button mBtnCancel;

    public SingleChoiceDialog(Context context, String title, String ok, String cancel, BaseAdapter adapter,
                              AdapterView.OnItemClickListener itemClickListener, View.OnClickListener okListener,
                              View.OnClickListener cancelLisener) {
        super(context);
        View v = LayoutInflater.from(context).inflate(R.layout.dialog_singlechoice, null);
        addView(v);

        mListView = (ListView) findViewById(R.id.singlechoice_lv);
        mBtnOk = (Button) findViewById(R.id.singlechoice_btn_ok);
        mBtnCancel = (Button) findViewById(R.id.singlechoice_btn_cancel);

        setTitle(title);
        mBtnOk.setText(StringUtil.isEmpty(ok) ? context.getResources().getString(R.string.confirm) : ok);
        mBtnCancel.setText(StringUtil.isEmpty(cancel) ? context.getResources().getString(R.string.cancel) : cancel);
        mListView.setAdapter(adapter);
        mBtnOk.setOnClickListener(okListener);
        mBtnCancel.setOnClickListener(cancelLisener);
        mListView.setOnItemClickListener(itemClickListener);
    }
}
