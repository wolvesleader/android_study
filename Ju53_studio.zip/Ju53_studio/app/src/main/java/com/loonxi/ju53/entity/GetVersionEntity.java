package com.loonxi.ju53.entity;

/**
 * "获取版本信息Entity"
 * Created by laojiaqi on 2016/2/19.
 */
public class GetVersionEntity {
    /*
    {
    "current_version":"1.0",
    "flag":1,
    "update_url":"https://itunes.apple.com/",
    "update_desc":"全新界面，全新体验，只为等待更好的你！\r\n\r\n1.",
    "current_versionid":1,
    "current_versiontitle":"iphone最新版本"}

     */

    double current_version;
    int flag;
    String update_url;
    String update_desc;
    int current_versionid;
    String current_versiontitle;

    public double getCurrent_version() {
        return current_version;
    }

    public void setCurrent_version(double current_version) {
        this.current_version = current_version;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getUpdate_url() {
        return update_url;
    }

    public void setUpdate_url(String update_url) {
        this.update_url = update_url;
    }

    public int getCurrent_versionid() {
        return current_versionid;
    }

    public void setCurrent_versionid(int current_versionid) {
        this.current_versionid = current_versionid;
    }

    public String getCurrent_versiontitle() {
        return current_versiontitle;
    }

    public void setCurrent_versiontitle(String current_versiontitle) {
        this.current_versiontitle = current_versiontitle;
    }

    public String getUpdate_desc() {
        return update_desc;
    }

    public void setUpdate_desc(String update_desc) {
        this.update_desc = update_desc;
    }

    @Override
    public String toString() {
        return "GetVersionEntity{" +
                "current_version='" + current_version + '\'' +
                ", flag=" + flag +
                ", update_url='" + update_url + '\'' +
                ", update_desc='" + update_desc + '\'' +
                ", current_versionid=" + current_versionid +
                ", current_versiontitle='" + current_versiontitle + '\'' +
                '}';
    }
}
