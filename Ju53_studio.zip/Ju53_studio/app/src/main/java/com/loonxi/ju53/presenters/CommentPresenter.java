package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.models.impl.ProductDetailModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ICommentView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/22.
 */
public class CommentPresenter {

    private ICommentView mView;
    private ProductDetailModel mModel;

    public CommentPresenter(ICommentView view) {
        mView = view;
        mModel = new ProductDetailModel();
    }


    /**
     * 获得评论
     *
     * @param productId
     * @param page
     * @param score 0-全部 1-满意 2-一般 3-不满意
     */
    public void getComments(String productId, int page, int score) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productId", productId);
        map.put("page", page + "");
        map.put("score", score + "");
        mModel.getComments(map, new Callback<TotalCommentEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, TotalCommentEntity data) {

            }

            @Override
            public void onSuccess(TotalCommentEntity data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onGetCommentsSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetCommentsFailed(apiErrorCode, message);
            }
        });
    }
}
