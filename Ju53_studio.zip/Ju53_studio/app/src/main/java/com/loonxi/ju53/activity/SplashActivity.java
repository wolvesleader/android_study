package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;

import org.xutils.x;

/**
 * Created by Xuzue on 2015/12/19.
 */
public class SplashActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        x.view().inject(this);
        initContent();
    }

    private void initContent() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(mContext, MainActivity.class));
                finish();
            }
        }, 2000);
    }
}
