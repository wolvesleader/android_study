package com.loonxi.ju53.utils;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * 图片上传Dialog回调
 * Created by Xuze on 2015/9/5.
 */
public class PicDialogCallback {
    private static Activity mActivity;
    private static int mRequestCode;
    private static int mResultCode;
    private static Intent mData;
    private static String mPicPath;

    public PicDialogCallback(Activity activity, int requestCode, int resultCode, Intent data, String picPath) {
        mActivity = activity;
        mRequestCode = requestCode;
        mResultCode = resultCode;
        mData = data;
        mPicPath = picPath;
    }

    public static Bundle onPicResult() {
        PicDialogUtil.ActivityResult result = null;
        if (mRequestCode == IntentUtil.REQUEST_CODE_ALBUM) {
            result = PicDialogUtil.onAlbumResult(mActivity, mRequestCode, mResultCode, mData);
        } else if (mRequestCode == IntentUtil.REQUEST_CODE_CAMERA) {
            result = PicDialogUtil.onCameraResult(mActivity, mRequestCode, mResultCode, mData, mPicPath);
        }
        if (result == null) {
            return null;
        }
        switch (result.getResult()) {
            case ERROR:
                showToast("获取图片返回出错");
                break;
            case NO_DATA:
                showToast("未找到此图片资源");
                break;
            case CANCEL:
                showToast("用户取消");
                break;
            case NO_PERMISSION:
                showToast("缺少SD卡访问权限");
                break;
            case SD_UNAVAILABLE:
                showToast("SD卡当前不可用");
                break;
            case SUCCESS:
                return result.getData();
        }
        return null;
    }

    private static void showToast(String text) {
        ToastUtil.showShortToast(text);
    }
}
