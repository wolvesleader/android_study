package com.loonxi.ju53.models.impl;

import com.google.gson.Gson;
import com.loonxi.ju53.entity.SendCommentEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.service.CommentService;
import com.loonxi.ju53.repos.PrefsRepos;

import java.util.Map;

import retrofit.Call;

/**
 * 评论model
 * Created by laojiaqi on 2016/2/16.
 */
public class SendCommentModel {

    public Call<BaseJsonInfo> sendComment(SendCommentEntity sendCommentEntity,Callback<BaseJsonInfo> callback) {
        if(sendCommentEntity==null||callback==null){
            return null;
        }
        Map<String ,Object> map= PrefsRepos.getObjectMap();
        Gson gson=new Gson();
        map.put("trade",gson.toJson(sendCommentEntity));
        Call<BaseJsonInfo> baseJsonInfoCall = Request.creatApi(CommentService.class).sendMessage(map);
        baseJsonInfoCall.enqueue(callback);
        return baseJsonInfoCall;
    }
}
