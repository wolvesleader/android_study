package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;

import org.xutils.view.annotation.ViewInject;

/**
 * Created by Xuzue on 2016/2/23.
 */
public class QuestionActivity extends ActionBarActivity implements View.OnClickListener {

    @ViewInject(R.id.question_webview)
    private WebView mWebView;
    @ViewInject(R.id.question_tv_feedback)
    private TextView mTvFeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
    }

    @Override
    public void initView() {
        setTitle(R.string.question_title);
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mWebView.loadUrl(ApiConst.QUESTION_URL);
        WebSettings settings = mWebView.getSettings();
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        mWebView.setWebViewClient(new MyWebviewClient());
    }


    private class MyWebviewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mTvFeedback.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
            case R.id.question_tv_feedback:
                startActivity(new Intent(mContext, FeedbackActivity.class));
                break;
        }
    }
}
