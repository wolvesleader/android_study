package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * Created by Xuzue on 2016/1/18.
 */
public interface IOrderView extends IBaseView{
    void onGetOrdersSuccess(JsonArrayInfo<OrderEntity> jsonArrayInfo);
    void onGetOrdersFailed(int apiErrorCode, String message);
    void onConfirmOrderSuccess(BaseJsonInfo jsonInfo);
    void onConfirmOrderFailed(int apiErrorCode, String message);
    void onPayOrderSuccess(AliPayEntity entity, double payMoney, String orderId);
    void onPayOrderFailed(int apiErrorCode, String message);
    void getTransOrderSuccess(LogisticsEntity logisticsEntity);
    void getTransOrderFailure(int apiErrorCode, String message);
    void onCloseOrderSuccess();
    void onCloseOrderFailed(int apiErrorCode, String message);
}
