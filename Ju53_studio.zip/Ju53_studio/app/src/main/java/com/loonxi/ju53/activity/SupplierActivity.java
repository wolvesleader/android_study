package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.SupplierAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.presenters.SupplierPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ISupplierView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedGridView;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/2/18.
 */
public class SupplierActivity extends ActionBarActivity implements View.OnClickListener, ISupplierView {

    @ViewInject(R.id.supplier_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.supplier_tv_stars)
    private TextView mTvStars;
    @ViewInject(R.id.supplier_layout_fav)
    private LinearLayout mLayoutFav;
    @ViewInject(R.id.supplier_iv_fav)
    private ImageView mIvFav;
    @ViewInject(R.id.supplier_fixedgridview)
    private FixedGridView mFlv;

    private SupplierAdapter mAdapter;
    private SupplierPresenter mPresenter;
    private String mUserName;
    private String mUserId;
    private int mCurrentPage = 1;

    private SupplierEntity mSupplier;
    private List<BaseProductEntity> mProducts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier);
    }

    @Override
    public void initView() {
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mCurrentPage = 1;
        mPresenter = new SupplierPresenter(this);
        mUserId = getIntent().getStringExtra("userId");
        mUserName = getIntent().getStringExtra("userName");
        setUserName();
        mAdapter = new SupplierAdapter(mContext, mProducts);
        mFlv.setAdapter(mAdapter);
        mPresenter.getSupplierInfo(mUserId, mCurrentPage);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mLayoutFav.setOnClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getSupplierInfo(mUserId, mCurrentPage);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getSupplierInfo(mUserId, mCurrentPage);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
            case R.id.supplier_layout_fav:
                mPresenter.fav(mUserId, 2, mSupplier == null ? 1 : mSupplier.getFollow());
                break;
        }
    }

    private void setUserName(){
        setTitle(StringUtil.isEmpty(mUserName) ? "" : mUserName + "的展厅");
    }

    /**
     * 设置店铺信息
     *
     * @param supplierEntity
     */
    private void setSupplierInfo(SupplierEntity supplierEntity) {
        if (supplierEntity == null) {
            return;
        }
        mSupplier = supplierEntity;
        mUserName = supplierEntity.getName();
        setUserName();
        mTvStars.setText("满意率：" + supplierEntity.getScore() + "%");
        mIvFav.setSelected(supplierEntity.getFollow() == 0 ? true : false);
    }

    @Override
    public void onGetSupplierInfoSuccess(SupplierEntity supplierEntity) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        setSupplierInfo(supplierEntity);
        if (mCurrentPage == 1) {
            mProducts.clear();
        }
        if (supplierEntity != null && !ListUtil.isEmpty(supplierEntity.getList())) {
            mProducts.addAll(supplierEntity.getList());
        }
        mAdapter.notifyDataSetChanged();
        mCurrentPage++;
    }

    @Override
    public void onGetSupplierInfoFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void onFavSuccess(boolean isFav) {
        showToast(isFav ? R.string.fav_cancel_success : R.string.fav_success);
        if(mSupplier != null) {
            mSupplier.setFollow(isFav ? 1 : 0);
        }
        mIvFav.setSelected(isFav ? false : true);
    }

    @Override
    public void onFavFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }
}
