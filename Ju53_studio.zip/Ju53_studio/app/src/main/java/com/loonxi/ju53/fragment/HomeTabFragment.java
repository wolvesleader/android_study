package com.loonxi.ju53.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.astuetz.PagerSlidingTabStrip;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.activity.MessageActivity;
import com.loonxi.ju53.activity.SearchHistoryActivity;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.MainTabEntity;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.presenters.HomeTabPresenter;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.PackageUtil;
import com.loonxi.ju53.views.ITabHomeView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.CustomViewPager;
import com.loonxi.ju53.widgets.dialog.BtnDialog;

import org.xutils.common.util.DensityUtil;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 首页 fragment
 * Created by yingjiafeng on 2015/5/31.
 */
@ContentView(R.layout.fragment_tab_home)
public class HomeTabFragment extends BaseSafeFragment<ITabHomeView, HomeTabPresenter> implements ViewPager.OnPageChangeListener,ITabHomeView,  View.OnClickListener, OnNetWorkListener {
    @ViewInject(R.id.fragment_home_actionbar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_home_iv_top)
    private ImageView mIvTotop;
    @ViewInject(R.id.empty_net_layout_root)
    private RelativeLayout empty_net_layout_root;
    @ViewInject(R.id.rl_top)
    private RelativeLayout  rl_top;

    @ViewInject(R.id.tabs)
    PagerSlidingTabStrip tabs;

    @ViewInject(R.id.viewpage)
    private CustomViewPager viewpage;
    private BtnDialog mBtnDialog;
    public  String[] CHANELS ;
    private List<BaseFragment> fragmentS = new ArrayList<BaseFragment>();
    JsonArrayInfo<MainTabEntity> data;
    @Override
    protected HomeTabPresenter createPresenter(ITabHomeView iHomeView) {
        return new HomeTabPresenter(this);
    }
    @Override
    public void initView() {
        empty_net_layout_root.setVisibility(View.GONE);
        mActionBar.setBackgroundColorResource(R.color.app_title);
        mActionBar.setLineVisibility(View.GONE);
        mActionBar.setTitleVisibility(View.INVISIBLE);
        mActionBar.setTitleImgVisibility(View.VISIBLE);
        mActionBar.setTitleImgResource(R.drawable.home_nav_logo);
        mActionBar.setLeftImageResource(R.drawable.nav_icon_message);
        mActionBar.setLineVisibility(View.VISIBLE);
        mActionBar.setRightImageVisibility(View.VISIBLE);
        mActionBar.setRightVisibility(View.VISIBLE);
        mActionBar.setRightImageResource(R.drawable.nav_icon_search);
        mActionBar.setRightTextSize(11);
        mActionBar.setRightTextColor(Color.WHITE);
        mIvTotop.setAlpha(0);
        tabs.setIndicatorHeight(DensityUtil.dip2px(2));
        tabs.setTextColor(Color.parseColor("#666666"));
        tabs.setTextSize(DisplayUtil.dip2px(14, DisplayUtil.getScreenDensity(mContext)));
        tabs.setTypeface(null, Typeface.NORMAL);
        tabs.setDividerColor(Color.WHITE);



    }

    @Override
    public void initContent() {
        mPresenter.initTitleDisappearLength(mContext);
        mPresenter.getMainTabData();
    }
    /**
     * 获得版本信息
     */
    public void getVersion() {
        if (mPresenter != null) {
            mPresenter.getVersion();
        }
    }


    @Override
    public void setListener() {
        setOnNetWorkListener(this);
        mActionBar.setOnLeftClickListener(this);
        mActionBar.setOnRightClickListener(this);
        mIvTotop.setOnClickListener(this);
        empty_net_layout_root.setOnClickListener(this);
        viewpage.addOnPageChangeListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case ActionBar.LEFT_CLICK_ID:
                IntentUtil.intentCommonActivity(mContext, MessageActivity.class);
                break;
            case ActionBar.RIGHT_CLICK_ID:
                IntentUtil.intentCommonActivity(mContext, SearchHistoryActivity.class);
                break;
            case R.id.empty_net_layout_root:
                Log.e("empty_net_layout_root","empty_net_layout_root");
                mPresenter.getMainTabData();
                break;
        }
    }

    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {

    }

    /**
     * 主界面tab 数据获取成功
     */
    @Override
    public void onGetTabListDataSuccess(JsonArrayInfo<MainTabEntity> data) {
        if (data==null || data.getData()==null || data.getData().size()==0)
        {
            rl_top.setVisibility(View.GONE);
            return;
        }
        empty_net_layout_root.setVisibility(View.GONE);
        rl_top.setVisibility(View.VISIBLE);
        this.data=data;
        CHANELS=new String[data.getData().size()];
        viewpage.setOffscreenPageLimit(CHANELS.length);
        //加载数据
        for (int i = 0; i < data.getData().size(); i++) {
            fragmentS.add(getFragment(i));
            CHANELS[i]=data.getData().get(i).getName();
        }
        viewpage.setAdapter(new MyPagerAdapter(((BaseActivity) mActivity).getSupportFragmentManager()));
        tabs.setTabBackground(R.drawable.btn_page_sliding);
        tabs.setViewPager(viewpage);

        LinearLayout  layout= (LinearLayout) tabs.getChildAt(0);
        TextView  textView= (TextView) layout.getChildAt(0);
        textView.setTextColor(Color.RED);
    }

    /**
     * 主界面数据获取失败
     * @param apiErrorCode
     * @param message
     */
    @Override
    public void onGetTabListDataFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
        rl_top.setVisibility(View.GONE);
        empty_net_layout_root.setVisibility(View.VISIBLE);

    }

    /**
     * 版本号获取成功
     * @param getVersionEntity
     */
    @Override
    public void onGetVersionSuccess(GetVersionEntity getVersionEntity) {
        double currentCode = PackageUtil.getVersionCode(mContext);
        if (currentCode < getVersionEntity.getCurrent_version()) {
            showUpdateDialog(getVersionEntity);
        }
    }

    private void showUpdateDialog(final GetVersionEntity getVersionEntity) {
        if(mContext == null || getActivity() == null){
            return;
        }
        mBtnDialog = new BtnDialog(mContext, "版本升级", getVersionEntity.getUpdate_desc(), "马上升级", "以后再说",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        gotoWebView(getVersionEntity.getUpdate_url(), "版本升级");
                        mBtnDialog.dismiss();
                    }
                }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBtnDialog.dismiss();
            }
        });
        mBtnDialog.show();
    }

    private void gotoWebView(String url, String title) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        Intent intent = new Intent(mContext, CommonWebviewActivity.class);
        intent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, title);
        intent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, url);
        getActivity().startActivity(intent);
    }


    /**
     * 版本号获取失败
     * @param message
     */
    @Override
    public void onGetVersionFailed(String message) {

    }


    @Override
    public void startAsyncTask() {
//        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        Log.e("onPageSelected", "position" + position);
        //改变字体颜色
        LinearLayout  layout= (LinearLayout) tabs.getChildAt(0);
        int childCount=layout.getChildCount();
        for (int i = 0; i <childCount ; i++) {
            TextView textView = (TextView) layout.getChildAt(i);
            if (i == position) {
                textView.setTextColor(Color.RED);
            } else {
                textView.setTextColor(Color.parseColor("#666666"));
            }
        }

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }


    class MyPagerAdapter extends FragmentPagerAdapter {

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
            // TODO Auto-generated constructor stub
        }

        @Override
        public Fragment getItem(int arg0) {
            return fragmentS.get(arg0);
        }

        @Override
        public int getCount() {
            return fragmentS.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return  CHANELS[position];
        }
    }

    private BaseFragment getFragment(int id) {
        BaseFragment fragment = null;
        MainTabEntity  mainTabEntity=   data.getData().get(id);
        fragment = WebViewFragment.newInstance(mainTabEntity.getName(),mainTabEntity.getUrl());
        return fragment;
    }
}
