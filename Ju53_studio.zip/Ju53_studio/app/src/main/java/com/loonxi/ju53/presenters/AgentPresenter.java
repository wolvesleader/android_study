package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.models.impl.AgentModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IAgentView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/19.
 */
public class AgentPresenter {
    private IAgentView mView;
    private AgentModel mModel;

    public AgentPresenter(IAgentView mView) {
        this.mView = mView;
        mModel = new AgentModel();
    }

    /**
     * 获取已代理的商品
     */
    public void getAgentProducts(){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getAgentProduct(map, new Callback<JsonArrayInfo<AgentProductEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<AgentProductEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<AgentProductEntity> data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onGetAgentProductSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.onGetAgentProductFailed(apiErrorCode, message);
            }
        });
    }


    /**
     * 搜索已代理商品
     * @param productName
     */
    public void searchAgentProduct(String productName){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("productName", productName);
        mModel.searchAgentProduct(map, new Callback<JsonArrayInfo<AgentProductEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<AgentProductEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<AgentProductEntity> data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onGetAgentProductSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.onGetAgentProductFailed(apiErrorCode, message);
            }
        });
    }
}
