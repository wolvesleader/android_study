package com.loonxi.ju53.fragment.accountSafe;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.presenters.UpdatePasswordPresenter;
import com.loonxi.ju53.utils.CountDownTimer;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IRegistCodeView;
import com.loonxi.ju53.views.IRegistPhoneView;
import com.loonxi.ju53.views.IUpdatePasswordView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.DeleteEditText;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * 验证码fragment
 * Created by laojiaqi on 2016/2/17.
 */
public class AccountSafeVerifyCodeFragment extends BaseFragment implements View.OnClickListener, IUpdatePasswordView, IRegistCodeView, IRegistPhoneView {

    private TextView mTvTip;
    private DeleteEditText mTvCode;
    private LinearLayout mLayoutTimer;
    private TextView mTvTime;
    private TextView mBtnNext;
    protected boolean mIsChange = true;

    private CountDownTimer mTimer;
    private static final long TOTAL_TIME = 60 * 1000;
    private static final long INTERVAL_TIME = 1000;

    private View mView;
    private String mPhone;
    private String mCode;
    @ViewInject(R.id.fragment_account_safe_verify_code_action_bar)
    private ActionBar mActionBar;
    private UpdatePasswordPresenter mPresenter;
    private int mCurrentType;
    private String mLoginPassword;//忘记支付密码--输入登录密码
    private String mMobile;//手机号


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getData();
    }


    private void getData() {
        Bundle bundle = getArguments();
        mCurrentType = bundle.getInt(AccountSafeTypeFragment.UPDATE_TYPE);
        mLoginPassword = bundle.getString(AccountSafeLoginPasswordFragment.LOGIN_PASS_WORD_FLAG, "");
        mMobile = bundle.getString(AccountSafeLoginPasswordFragment.LOGIN_MOBILE_FLAG, "");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_account_safe_verify_code, null);
        x.view().inject(mView);
        return mView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mTimer != null && !mTimer.isCanceled()) {
            mTimer.cancel();
        }
    }

    @Override
    public void initView() {
        mTvTip = (TextView) mView.findViewById(R.id.include_register_code_tv_tip);
        mTvCode = (DeleteEditText) mView.findViewById(R.id.include_register_code_tv_code);
        mLayoutTimer = (LinearLayout) mView.findViewById(R.id.include_register_layout_timer);
        mTvTime = (TextView) mView.findViewById(R.id.include_register_code_tv_time);
        mBtnNext = (TextView) mView.findViewById(R.id.include_register_code_btn_next);
        mBtnNext.setEnabled(false);
        mActionBar.setTitle(R.string.account_safe_get_verify_code);
        mTvCode.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
    }

    public void initEvents() {
        mTvTime.setOnClickListener(this);
        mBtnNext.setOnClickListener(this);
        mTvCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mIsChange = true;
                if (StringUtil.isEmpty(mTvCode.getText().toString())) {
                    mBtnNext.setEnabled(false);
                } else {
                    mBtnNext.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }


    @Override
    public void initContent() {
        mPresenter = new UpdatePasswordPresenter(this);
        mPhone = getPhone();
        mTvTip.setText("请输入" + (StringUtil.isEmpty(mPhone) ? "" : "手机号" + mPhone) + "收到的验证码");
        getVerifyCode();
    }


    /**
     * 获得手机号
     * 1.从“忘记密码入口来”，则直接获取mMobile
     * 2.从“我的”来,则读取sp中mobile
     *
     * @return
     */
    private String getPhone() {
        if (!TextUtils.isEmpty(mMobile)) {
            return mMobile;//
        }
        return SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_MOBILE);
    }

    private void getVerifyCode() {
        //TODO 根绝不同的类别

        if (mCurrentType == AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD) {
            mPresenter.getLoginPasswordVerifyCode(mPhone);
        }
        initTimer();
    }


    @Override
    public void setListener() {
        initEvents();
        mActionBar.setOnLeftClickListener(this);
    }

    private void initTimer() {
        mTimer = new CountDownTimer(TOTAL_TIME, INTERVAL_TIME) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (mTvTime == null) {
                    return;
                }
                mTvTime.setEnabled(false);
                mTvTime.setTextColor(mContext.getResources().getColor(R.color.app_gray));
                mTvTime.setText(millisUntilFinished / 1000 + mContext.getResources().getString(R.string.register_timer));
            }

            @Override
            public void onFinish() {
                if (mTvTime == null) {
                    return;
                }
                mTvTime.setEnabled(true);
                mTvTime.setTextColor(mContext.getResources().getColor(R.color.app_black));
                mTvTime.setText(mContext.getResources().getString(R.string.register_get_code));
            }
        };
        mTimer.start();
    }

    public CountDownTimer getTimer() {
        return mTimer;
    }

    public void afterChangeInit() {
        mTvCode.setText("");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.include_register_code_tv_time:
                getCheckCode();
                break;
            case R.id.include_register_code_btn_next:
                mCode = mTvCode.getText().toString();
                next();
                break;
        }
    }

    private void goBack() {
        getFragmentManager().popBackStack();
    }


    private void next() {
        mCode = mTvCode.getText().toString();
        if (TextUtils.isEmpty(mCode) || TextUtils.isEmpty(mPhone)) {
            return;
        }
        mPresenter.checkLoginPasswordVerifyCode(mPhone, mCode);
    }

    /**
     * 重发验证码
     */
    private void getCheckCode() {
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD) {
            mPresenter.getLoginPasswordVerifyCode(mPhone);
            return;
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_PAY_PASSWORD) {
            mPresenter.checkLoginPassword(mLoginPassword);
            return;
        }

    }

    @Override
    public void showToast(int resId) {
        ToastUtil.showToast(mContext, resId);
    }

    @Override
    public void onGetCodeSuccess() {
        //TODO 获得验证码成功
        if (mTimer != null) {
            mTimer.start();
        }
    }

    @Override
    public void onGetCodeFailed(int apiErrorCode, String message) {
        //TODO 获得验证码失败
        checkError(apiErrorCode, message);
    }

    @Override
    public void onVerifyCodeSuccess() {
        //TODO  验证成功
        mIsChange = false;
        gotoResetPasswordFragment();

    }

    private void gotoResetPasswordFragment() {
        FragmentManager fm = getFragmentManager();
        if (fm.findFragmentByTag(AccountSafeResetPasswordFragment.TAG) != null) {
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        ft.addToBackStack("accountSafeVerifyCodeFragment");
        AccountSafeResetPasswordFragment accountSafeResetPasswordFragment = new AccountSafeResetPasswordFragment();
        Bundle bundle = new Bundle();
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD) {
            bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, AccountSafeTypeFragment.UPDATE_FORGET_LOGIN_PASSWORD);//忘记登录密码
            bundle.putString(AccountSafeLoginPasswordFragment.LOGIN_MOBILE_FLAG, getPhone());
        }
        if (mCurrentType == AccountSafeTypeFragment.UPDATE_PAY_PASSWORD) {
            bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, AccountSafeTypeFragment.UPDATE_FORGET_PAY_PASSWORD);//忘记支付密码
        }
        accountSafeResetPasswordFragment.setArguments(bundle);
        ft.add(R.id.fragment_account_safe_container, accountSafeResetPasswordFragment, AccountSafeResetPasswordFragment.TAG);
        ft.commitAllowingStateLoss();
    }


    public void onVerifyCodeFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
        //TODO 验证失败
    }

    @Override
    public void onUpdatePasswordSuccess(String message) {
    }

    @Override
    public void onUpdatePasswordFailure(String message) {
    }

    @Override
    public void startAsyncTask() {

    }

    @Override
    public void endAsyncTask() {

    }
}
