package com.loonxi.ju53.entity;

import java.util.List;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreDetailEntity {

    private String picture;
    private String name;
    private List<StoreProductEntity> datas;

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<StoreProductEntity> getDatas() {
        return datas;
    }

    public void setDatas(List<StoreProductEntity> datas) {
        this.datas = datas;
    }
}
