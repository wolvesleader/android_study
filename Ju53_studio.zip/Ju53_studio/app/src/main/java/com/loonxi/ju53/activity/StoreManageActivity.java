package com.loonxi.ju53.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.manager.FileManager;
import com.loonxi.ju53.manager.StoreManager;
import com.loonxi.ju53.utils.AESUtil;
import com.loonxi.ju53.utils.FileImageUpload;
import com.loonxi.ju53.utils.ImageUtil;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.PicDialogCallback;
import com.loonxi.ju53.utils.PicDialogUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.dialog.UploadPicDialog;

import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.view.annotation.ViewInject;

import java.io.File;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreManageActivity extends ActionBarActivity implements View.OnClickListener {

    @ViewInject(R.id.store_manage_layout_name)
    private LinearLayout mLayoutName;
    @ViewInject(R.id.store_manage_tv_name)
    private TextView mTvName;
    @ViewInject(R.id.store_manage_layout_head)
    private LinearLayout mLayoutHead;
    @ViewInject(R.id.store_manage_iv_head)
    private ImageView mIvHead;
    @ViewInject(R.id.store_manage_tv_tip)
    private TextView mTvTip;

    private UploadPicDialog mUploadPicDialog;
    private String mPicPath = "";
    private String mPicName = "";
    private static final int REQUEST_CODE_EDIT_NAME = 1001;//修改店铺名称

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_manage);
    }

    @Override
    public void initView() {
        setTitle("店铺管理");
        setRightVisibility(View.VISIBLE);
        setRightTextVisibility(View.VISIBLE);
        setRightText("查看店铺  ");
    }

    @Override
    public void initContent() {
        StoreManager.setStoreBaseInfo(mIvHead, mTvName);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mLayoutName.setOnClickListener(this);
        mLayoutHead.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                Intent intent = new Intent(mContext, StoreDetailActivity.class);
                startActivity(intent);
                break;
            case R.id.store_manage_layout_name:
                intent = new Intent(mContext, StoreEditActivity.class);
                intent.putExtra("name", mTvName.getText().toString());
                startActivityForResult(intent, REQUEST_CODE_EDIT_NAME);
                break;
            case R.id.store_manage_layout_head:
                mPicName = System.currentTimeMillis() + ".png";
                mUploadPicDialog = new UploadPicDialog(this, mContext, "修改店铺LOGO", FileManager.initCameraFolder(), mPicName);
                mUploadPicDialog.setDialogAttribute(this, Gravity.BOTTOM);
                mUploadPicDialog.show();
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IntentUtil.REQUEST_CODE_CAMERA || requestCode == IntentUtil.REQUEST_CODE_ALBUM) {
            PicDialogCallback callback = new PicDialogCallback(StoreManageActivity.this, requestCode, resultCode,
                    data, FileManager.initCameraFolder() + mPicName);
            Bundle b = callback.onPicResult();
            if (b == null) {
                return;
            }
            mPicPath = b.getString(PicDialogUtil.ActivityResult.DATA_PATH);
            if (!StringUtil.isEmpty(mPicPath) && new File(mPicPath).exists()) {
//                IntentUtil.startPhotoZoom(StoreManageActivity.this, Uri.fromFile(new File(mPicPath)));
                Bitmap bitmap = ImageUtil.getBitmapByPath(mContext, mPicPath);
                String newPicPath = FileManager.initImgFolder() + "store_head.jpg";
                boolean isSuccess = ImageUtil.compressImage(bitmap, newPicPath, ApiConst.Common.MINI_PIC_MAX_SIZE);
                if (isSuccess) {
                    uploadPic(new File(newPicPath));
                } else {
                    showToast("头像保存失败，请重试");
                }
            }
        } else if (requestCode == IntentUtil.REQUEST_CODE_CROP) {
            if (resultCode == RESULT_OK && data != null) {
                Bitmap bitmap = data.getParcelableExtra("data");
                String newPicPath = FileManager.initImgFolder() + "store_head.jpg";
                boolean isSuccess = ImageUtil.compressImage(bitmap, newPicPath, ApiConst.Common.MINI_PIC_MAX_SIZE);
                if (isSuccess) {
                    uploadPic(new File(newPicPath));
                } else {
                    showToast("头像保存失败，请重试");
                }
            } else {
                showToast("取消操作");
            }
        } else if (requestCode == REQUEST_CODE_EDIT_NAME) {
            if (data != null) {
                String newName = data.getStringExtra("name");
                mTvName.setText(newName);
            }
        }
    }

    /**
     * 上传头像
     */
    private void uploadPic(File file) {
        AsyncTask<File, Void, String> uploadTask = new AsyncTask<File, Void, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                showLoadingDialog();
            }

            @Override
            protected String doInBackground(File... params) {
                String result = "";
                String userId = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, "");
                if (!StringUtil.isEmpty(userId)) {
                    try {
                        String uidu = AESUtil.encrypt("", userId);
                        String url = ApiConst.URL_ROOT_PHP + ApiConst.URL_UPLOAD_PIC_STORE + "?uidu=" + userId;
                        LogUtil.mLog().i(url);
                        result = FileImageUpload.uploadFile(params[0], url);
                        LogUtil.mLog().i(result);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return result;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                dismissLoadingDialog();
                dealResult(s);
            }
        };
        uploadTask.execute(file);
    }

    /**
     * 上传图片结果处理
     *
     * @param result
     */
    private void dealResult(String result) {
        if (!StringUtil.isEmpty(result)) {
            LogUtil.mLog().e(result);
            mTvTip.setText(result);
            try {
                JSONObject object = new JSONObject(result);
                String flag = object.optString("flag");
                String message = object.optString("message");
                String newUrl = object.optString("data");
                if ("0".equals(flag)) {
                    showToast(message);
                } else if ("1".equals(flag)) {
                    showToast("上传成功");
                    if (!StringUtil.isEmpty(newUrl)) {
                        StoreManager.sendBroad(mContext);
                        StoreManager.saveStoreBaseInfo(newUrl, SpUtil.getString(BaseApplication.instance, SpUtil.STORE_NAME, ""));
                        Glide.with(mContext).load(AppConst.PIC_HEAD + newUrl).into(mIvHead);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
                showToast("上传失败");
            }
        } else {
            showToast("上传失败");
        }
    }
}
