package com.loonxi.ju53.convert;

import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductRuleEntity;
import com.loonxi.ju53.entity.StockEntity;
import com.loonxi.ju53.utils.LogUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 转换购物车数据
 * Created by Administrator on 2016/1/15.
 */
public class CartDataConvert {

    public static List<ProductRuleEntity> converData(ProductAttributeEntity productAttributeEntity) {
        if (productAttributeEntity == null) {
            return null;
        }
        Map<String, List<StockEntity>> skuName = productAttributeEntity.getSkuName();
        if (skuName == null) {
            return null;
        }
        Set<String> keySet = skuName.keySet();
        Iterator<String> iterator = keySet.iterator();
        List<ProductRuleEntity> afterConvertData = new ArrayList<ProductRuleEntity>();
        int index = 0;
        while (iterator.hasNext()) {
            String attrbuteOneTemp = iterator.next();
            List<StockEntity> listTemp = skuName.get(attrbuteOneTemp);
            if(listTemp==null){
                continue;
            }
            Iterator<StockEntity> listIterator=listTemp.iterator();
            while(listIterator.hasNext()){
                StockEntity stockEntityTemp=listIterator.next();
                if(stockEntityTemp==null){
                    continue;
                }
                ProductRuleEntity productRuleEntity = new ProductRuleEntity();
                productRuleEntity.setAttrbuteOne(attrbuteOneTemp);
                productRuleEntity.setAttrbuteTwo(stockEntityTemp.getSkuName());
                productRuleEntity.setPrice(stockEntityTemp.getPrice());
                productRuleEntity.setStockId(stockEntityTemp.getStockId());
                productRuleEntity.setStock(stockEntityTemp.getStock());
                afterConvertData.add(productRuleEntity);
            }
            index++;
        }
        return afterConvertData;
    }

    public static ProductAttributeEntity convertProp(String result) {
        try {
            JSONObject json = new JSONObject(result);
            String skuProp = json.optString("skuProp");
            JSONObject skuName = json.optJSONObject("skuName");

            ProductAttributeEntity attribute = new ProductAttributeEntity();
            Map<String, List<StockEntity>> map = new HashMap<>();

            Iterator it = skuName.keys();
            while (it.hasNext()) {
                String key = String.valueOf(it.next());
                JSONArray arrayName = (JSONArray) skuName.get(key);
                List<StockEntity> stockList = new ArrayList<>();
                for (int i = 0; i < arrayName.length(); i++) {
                    JSONObject object = arrayName.getJSONObject(i);
                    String name = object.optString("skuName");
                    double price = object.optDouble("price");
                    long stock = object.optLong("stock");
                    int stockId = object.optInt("stockId");
                    LogUtil.mLog().i(name + "/" + price + "/" + stockId);
                    StockEntity stockEntity = new StockEntity();
                    stockEntity.setSkuName(name);
                    stockEntity.setPrice(price);
                    stockEntity.setStock(stock);
                    stockEntity.setStockId(stockId);
                    stockList.add(stockEntity);
                }
                map.put(key, stockList);
            }
            attribute.setSkuProp(skuProp);
            attribute.setSkuName(map);
            return attribute;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

}
