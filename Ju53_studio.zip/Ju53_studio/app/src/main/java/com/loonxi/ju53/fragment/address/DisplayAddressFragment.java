package com.loonxi.ju53.fragment.address;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.AddressActivity;
import com.loonxi.ju53.activity.OrderConfirmActivity;
import com.loonxi.ju53.adapter.DomesticAddressAdapter;
import com.loonxi.ju53.adapter.OverseasAddressAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.presenters.DisplayAddressPresenter;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IAddressView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * 展示收货地址Fragment
 * Created by laojiaqi on 2016/1/25.
 */
@ContentView(R.layout.fragment_display_address)
public class DisplayAddressFragment extends BaseSafeFragment<IAddressView, DisplayAddressPresenter> implements IAddressView, View.OnClickListener {
    public static final int ADDRESS_OVERSEAS_FLAG = 1;//国外
    public static final int ADDRESS_DOMESTIC_FLAG = 0;//国内

    @ViewInject(R.id.address_listview)
    private SwipeMenuListView mDomesticListView;
    @ViewInject(R.id.address_action_bar)
    private ActionBar mActionBar;
    @ViewInject(R.id.address_add_view)
    private TextView mAddButton;
    @ViewInject(R.id.address_overseas_listview)
    private SwipeMenuListView mOverseasListView;
    @ViewInject(R.id.address_domestic_title)
    private TextView mDomesticTitleView;
    @ViewInject(R.id.address_oversea_title)
    private TextView mOverseasTitleView;

    private DomesticAddressAdapter mDomesticAdapter;
    private List<AddressEntity> mDomesticDataList;


    private OverseasAddressAdapter mOverseasAdapter;
    private List<AddressEntity> mOverseasDataList;

    private Context mContex;
    private int mCurrentTab = ADDRESS_DOMESTIC_FLAG;

    int mCurrentFromType = AddressActivity.MANAGE_ADDRESS;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_display_address, null);
        return view;
    }

    @Override
    public void initView() {
        mContex = getActivity();
        mActionBar.setTitle(getResources().getString(R.string.address_title));
        if (mCurrentTab == ADDRESS_DOMESTIC_FLAG) {
            hiddenOverseas();
        }
        if (mCurrentTab == ADDRESS_OVERSEAS_FLAG) {
            hiddenDomestic();
        }
    }

    /**
     * 获得来源
     */
    private void getFromTypeData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            mCurrentFromType = bundle.getInt(AddressActivity.FROM_FLAG);
        }
    }


    @Override
    public void initContent() {
        if (mContex == null) {
            return;
        }

        mDomesticDataList = new ArrayList<AddressEntity>();
        mDomesticAdapter = new DomesticAddressAdapter(mContext, mDomesticDataList);

        mOverseasDataList = new ArrayList<AddressEntity>();
        mOverseasAdapter = new OverseasAddressAdapter(mContext, mOverseasDataList);

        initSwipeListView(mDomesticListView, mDomesticDataList, mDomesticAdapter);
        initSwipeListView(mOverseasListView, mOverseasDataList, mOverseasAdapter);

        mDomesticListView.setAdapter(mDomesticAdapter);
        mOverseasListView.setAdapter(mOverseasAdapter);

        mPresenter.getAddressData();
        getFromTypeData();
    }

    @Override
    public void setListener() {
        mAddButton.setOnClickListener(this);
        mActionBar.setOnLeftClickListener(this);
        mDomesticTitleView.setOnClickListener(this);
        mOverseasTitleView.setOnClickListener(this);
    }


    /**
     * 初始化 侧滑listView参数
     */
    private void initSwipeListView(SwipeMenuListView swipeMenuListView, final List<AddressEntity> dataList, final BaseAdapter domesticAddressAdapter) {
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {

                SwipeMenuItem openItem = new SwipeMenuItem(
                        mContext);
                // set item background
                openItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F,
                        0x25)));
                // set item width
                openItem.setWidth(DisplayUtil.dip2px(mContext, 90));
                // set item title
                openItem.setTitle(R.string.delete);
                // set item title fontsize
                openItem.setTitleSize(18);
                // set item title font color
                openItem.setTitleColor(Color.WHITE);
                // add to menu
                menu.addMenuItem(openItem);
            }
        };

        swipeMenuListView.setMenuCreator(creator);
        swipeMenuListView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                mPresenter.deleteAddressData(dataList.get(position));
                if (dataList != null && domesticAddressAdapter != null) {
                    dataList.remove(position);
                    domesticAddressAdapter.notifyDataSetChanged();
                }
                //TODO删除操作
                return false;
            }
        });
        swipeMenuListView.setSwipeDirection(SwipeMenuListView.DIRECTION_LEFT);
        swipeMenuListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (dataList != null && position < dataList.size()) {
                    if (mCurrentFromType == AddressActivity.MANAGE_ADDRESS) {
                        gotoAddAddressFragment(OperateDomesticAddressFragment.ADDRESS_MODIFY_FLAGE, dataList.get(position));
                        return;
                    }
                    if (mCurrentFromType == AddressActivity.ORDER_GET_ADDRESS) {
                        Bundle bundle = new Bundle();
                        bundle.putParcelable(OrderConfirmActivity.GET_ADDRESS_ENTITY, dataList.get(position));
                        Intent intent = new Intent();
                        intent.putExtras(bundle);
                        ((Activity) mContex).setResult(Activity.RESULT_OK, intent);
                        ((Activity) mContex).finish();
                        return;
                    }
                }
            }
        });

    }


    @Override
    protected DisplayAddressPresenter createPresenter(IAddressView iAddressView) {
        return new DisplayAddressPresenter(this);
    }

    /**
     * 获得地址信息成功（国内国外）
     *
     * @param dataList
     */
    @Override
    public void getAddressSuccess(List<AddressEntity> dataList) {
        if (dataList != null && dataList.size() > 0) {
            initListData(dataList);

            if (mDomesticAdapter != null && mOverseasAdapter != null) {
                mDomesticAdapter.notifyDataSetChanged();
                mOverseasAdapter.notifyDataSetChanged();
            }

        }
    }


    /**
     * 初始化列表数据
     *
     * @param dataList
     */
    public void initListData(List<AddressEntity> dataList) {
        if (mDomesticDataList == null || mOverseasDataList == null) {
            return;
        }
        mDomesticDataList.clear();
        mOverseasDataList.clear();

        for (AddressEntity temp : dataList) {
            if (temp.getIsOverseas() == ADDRESS_OVERSEAS_FLAG) {
                mOverseasDataList.add(temp);
            }
            if (temp.getIsOverseas() == ADDRESS_DOMESTIC_FLAG) {
                mDomesticDataList.add(temp);
            }
        }
    }


    @Override
    public void getAddressFailure(String message) {

        ToastUtil.showToast(message, false);
        //TODO
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.address_add_view:
                gotoAddAddressFragment(OperateDomesticAddressFragment.ADDRESS_ADD_FLAGE);
                break;
            case R.id.address_oversea_title:
                hiddenDomestic();
                break;
            case R.id.address_domestic_title:
                hiddenOverseas();
                break;
        }
    }

    /**
     * 回退，根据类型
     */
    private void goBack() {
        if (mCurrentTab == AddressActivity.ORDER_GET_ADDRESS) {
            ((Activity) mContex).setResult(Activity.RESULT_CANCELED);
            ((Activity) mContex).finish();
            return;
        }
        if (mCurrentTab == AddressActivity.MANAGE_ADDRESS) {
            ((Activity) mContex).finish();
            return;
        }
    }

    /**
     * 隐藏国内
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void hiddenDomestic() {
        mOverseasListView.setVisibility(View.VISIBLE);
        mDomesticListView.setVisibility(View.GONE);
        mCurrentTab = ADDRESS_OVERSEAS_FLAG;
        //TODO
        mDomesticTitleView.setBackground(null);
        mDomesticTitleView.setSelected(false);
        mOverseasTitleView.setBackgroundResource(R.drawable.addressbackground_xz);
        mOverseasTitleView.setSelected(true);
    }

    /**
     * 隐藏国外
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void hiddenOverseas() {
        mOverseasListView.setVisibility(View.GONE);
        mDomesticListView.setVisibility(View.VISIBLE);
        mCurrentTab = ADDRESS_DOMESTIC_FLAG;
        //TODO
        mDomesticTitleView.setBackgroundResource(R.drawable.addressbackground_xz);
        mDomesticTitleView.setSelected(true);
        mOverseasTitleView.setBackground(null);
        mOverseasTitleView.setSelected(false);
    }

    /**
     * 跳转到“添加\修改 Fragment”
     */
    private void gotoAddAddressFragment(int type, AddressEntity... args) {
        Bundle bundle = new Bundle();
        if (type == OperateDomesticAddressFragment.ADDRESS_ADD_FLAGE) {
            bundle.putInt(OperateDomesticAddressFragment.ADDRESS_FRAGMENT_TYPE, type);
        }
        if (type == OperateDomesticAddressFragment.ADDRESS_MODIFY_FLAGE) {
            bundle.putInt(OperateDomesticAddressFragment.ADDRESS_FRAGMENT_TYPE, type);
            if (args.length > 0) {
                bundle.putParcelable(OperateDomesticAddressFragment.ADDRESS_MODIFY_ENTITY, args[0]);
            }
        }
        if (mCurrentTab == ADDRESS_DOMESTIC_FLAG) {
            FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
            OperateDomesticAddressFragment addAddressFragment = new OperateDomesticAddressFragment();
            addAddressFragment.setArguments(bundle);
            fragmentTransaction.addToBackStack("addAddressFragment");
            fragmentTransaction.replace(R.id.fragment_container, addAddressFragment);
            fragmentTransaction.commitAllowingStateLoss();
        }
        if (mCurrentTab == ADDRESS_OVERSEAS_FLAG) {
            FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
            OperateOverseasAddressFragment addAddressFragment = new OperateOverseasAddressFragment();
            addAddressFragment.setArguments(bundle);
            fragmentTransaction.addToBackStack("addAddressFragment");
            fragmentTransaction.replace(R.id.fragment_container, addAddressFragment);
            fragmentTransaction.commitAllowingStateLoss();
        }
    }

}

