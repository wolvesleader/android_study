package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 首页内容Json用该类解析
 * Created by Xuzue on 2015/12/18.
 */
public class IndexJsonInfo implements Parcelable {
    private int flag;
    private String message;
    private List<IndexEntity> banners;
    private List<IndexEntity> topics;
    private List<IndexEntity> pushs;

    public IndexJsonInfo(){

    }

    protected IndexJsonInfo(Parcel in) {
        flag = in.readInt();
        message = in.readString();
        banners = in.createTypedArrayList(IndexEntity.CREATOR);
        topics = in.createTypedArrayList(IndexEntity.CREATOR);
        pushs = in.createTypedArrayList(IndexEntity.CREATOR);
    }

    public static final Creator<IndexJsonInfo> CREATOR = new Creator<IndexJsonInfo>() {
        @Override
        public IndexJsonInfo createFromParcel(Parcel in) {
            return new IndexJsonInfo(in);
        }

        @Override
        public IndexJsonInfo[] newArray(int size) {
            return new IndexJsonInfo[size];
        }
    };

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<IndexEntity> getBanners() {
        return banners;
    }

    public void setBanners(List<IndexEntity> banners) {
        this.banners = banners;
    }

    public List<IndexEntity> getTopics() {
        return topics;
    }

    public void setTopics(List<IndexEntity> topics) {
        this.topics = topics;
    }

    public List<IndexEntity> getPushs() {
        return pushs;
    }

    public void setPushs(List<IndexEntity> pushs) {
        this.pushs = pushs;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(flag);
        dest.writeString(message);
        dest.writeTypedList(banners);
        dest.writeTypedList(topics);
        dest.writeTypedList(pushs);
    }
}
