package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.utils.StringUtil;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerviewViewHolder;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;

import java.util.List;

/**
 * 首页 瀑布流 adapter
 * Created by laojiaqi on 2016/3/3.
 */
public class HomeRecommendReCycleAdapter extends UltimateViewAdapter<HomeRecommendReCycleAdapter.HomeRecommendViewHolder> {
    private List<IndexEntity> mDatas;
    private Context mContext;

    public HomeRecommendReCycleAdapter(Context context, List<IndexEntity> datas) {
        this.mContext = context;
        this.mDatas = datas;
    }

    @Override
    public HomeRecommendViewHolder getViewHolder(View view) {
        return new HomeRecommendViewHolder(view);
    }

    @Override
    public HomeRecommendViewHolder onCreateViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.griditem_home_recommend, null);
        HomeRecommendViewHolder viewHolder = new HomeRecommendViewHolder(v);
        return viewHolder;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getAdapterItemCount() {
        return mDatas == null ? 0 : mDatas.size();
    }

    @Override
    public long generateHeaderId(int position) {
        return 0;
    }

    @Override
    public void onBindViewHolder(final HomeRecommendViewHolder holder, final int position) {
        if (position > mDatas.size() || position < 0 || position >= getItemCount()) {
            return;
        }
        if (position == 0) {
            //1.针对headView
            StaggeredGridLayoutManager.LayoutParams layoutParams = new StaggeredGridLayoutManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            layoutParams.setFullSpan(true);
            holder.itemView.setLayoutParams(layoutParams);
        }
        if (position > 0) {
            //2.针对热门推荐View
            holder.mLayoutRoot.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    int width = holder.mLayoutRoot.getWidth();
//                    LogUtil.mLog().e(position + ":" + width);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, width);
                    holder.mIvPic.setLayoutParams(params);
                    holder.mLayoutRoot.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                }
            });
            final IndexEntity entity = mDatas.get(position - 1);
            Glide.with(mContext).load(AppConst.PIC_HEAD + entity.getImgUrl() + AppConst.PIC_SIZE_80).into(holder.mIvPic);
            holder.mTvName.setText(entity.getProductName());
            holder.mTvPrice.setText("¥" + entity.getPrice());
            holder.mTvSales.setText("已售" + (StringUtil.isEmpty(entity.getQuantity()) ? "0" : entity.getQuantity()) + "件");
            holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, ProductDetailActivity.class);
//                    Intent intent = new Intent(mContext, StoreProductDetailActivity.class);
                    intent.putExtra("productId", entity.getProductId());
                    mContext.startActivity(intent);
                }
            });
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    public class HomeRecommendViewHolder extends UltimateRecyclerviewViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvPic;
        TextView mTvName;
        TextView mTvPrice;
        TextView mTvSales;

        public HomeRecommendViewHolder(View itemView) {
            super(itemView);
            mLayoutRoot = (LinearLayout) itemView.findViewById(R.id.griditem_home_recomment_layout_root);
            mIvPic = (ImageView) itemView.findViewById(R.id.griditem_home_recommend_img);
            mTvName = (TextView) itemView.findViewById(R.id.griditem_home_recommend_tv_name);
            mTvPrice = (TextView) itemView.findViewById(R.id.griditem_home_recommend_tv_price);
            mTvSales = (TextView) itemView.findViewById(R.id.griditem_home_recommend_tv_sales);
        }
    }
}
