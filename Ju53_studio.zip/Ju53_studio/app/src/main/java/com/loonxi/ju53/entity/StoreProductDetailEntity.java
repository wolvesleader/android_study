package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.HashMap;

/**
 * 分销商产品详情实体
 * Created by Xuzue on 2016/1/11.
 */
public class StoreProductDetailEntity implements Parcelable {

    /**
     *  产品id
     */
    private String productId;

    /**
     *  产品名称或标题
     */
    private String productName;

    /**
     *  单位
     */
    private String unit;

    /**
     *  参考价
     */
    private float markPrice;

    /**
     * 销量
     */
    private int sold;

    /**
     *  产品单价
     */
    private double price;


    /**
     *  供应商id
     */
    private String userId;

    /**
     * 供应商名称
     */
    private String userName;

    /**
     * 描述
     */
    private String desc;

    /**
     * props
     */
    private HashMap<String, String> props;

    /**
     * 评论数
     */
    private int commentNum;

    /**
     * 评论用户名
     */
    private String commentName;

    /**
     * 评论内容
     */
    private String commentContent;

    /**
     * 是否收藏 0:收藏 1：未收藏
     */
    private int follow;

    /**
     * 城市
     */
    private String locateCity;

    /**
     * 活动
     */
    private String activity;

    /**
     * 图片列表
     */
    private String picture;

    /**
     * 快递
     */
    private String freight;
    /**
     * sku属性
     */
    private String skuProp;
    /**
     * 运费模板
     */
    private int freightId;
    /**
     * 库存
     */
    private int stock;
    /**
     * 库存id
     */
    private long stokId;
    /**
     * 产品状态 0-下架,1-上架,9-违规,-1-删除
     */
    private int state;
    /**
     * 是否能一键上架 0：不能 1：能
     */
    private int cycles;

    public StoreProductDetailEntity(){

    }

    protected StoreProductDetailEntity(Parcel in) {
        productId = in.readString();
        productName = in.readString();
        unit = in.readString();
        markPrice = in.readFloat();
        sold = in.readInt();
        price = in.readDouble();
        userId = in.readString();
        userName = in.readString();
        desc = in.readString();
        commentNum = in.readInt();
        commentName = in.readString();
        commentContent = in.readString();
        follow = in.readInt();
        locateCity = in.readString();
        activity = in.readString();
        picture = in.readString();
        freight = in.readString();
        skuProp = in.readString();
        freightId = in.readInt();
        stock = in.readInt();
        stokId = in.readLong();
        state = in.readInt();
        cycles = in.readInt();
    }

    public static final Creator<StoreProductDetailEntity> CREATOR = new Creator<StoreProductDetailEntity>() {
        @Override
        public StoreProductDetailEntity createFromParcel(Parcel in) {
            return new StoreProductDetailEntity(in);
        }

        @Override
        public StoreProductDetailEntity[] newArray(int size) {
            return new StoreProductDetailEntity[size];
        }
    };

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public float getMarkPrice() {
        return markPrice;
    }

    public void setMarkPrice(float markPrice) {
        this.markPrice = markPrice;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public HashMap<String, String> getProps() {
        return props;
    }

    public void setProps(HashMap<String, String> props) {
        this.props = props;
    }

    public int getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(int commentNum) {
        this.commentNum = commentNum;
    }

    public String getCommentName() {
        return commentName;
    }

    public void setCommentName(String commentName) {
        this.commentName = commentName;
    }

    public String getCommentContent() {
        return commentContent;
    }

    public void setCommentContent(String commentContent) {
        this.commentContent = commentContent;
    }

    public int getFollow() {
        return follow;
    }

    public void setFollow(int follow) {
        this.follow = follow;
    }

    public String getLocateCity() {
        return locateCity;
    }

    public void setLocateCity(String locateCity) {
        this.locateCity = locateCity;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getFreight() {
        return freight;
    }

    public void setFreight(String freight) {
        this.freight = freight;
    }

    public String getSkuProp() {
        return skuProp;
    }

    public void setSkuProp(String skuProp) {
        this.skuProp = skuProp;
    }

    public int getFreightId() {
        return freightId;
    }

    public void setFreightId(int freightId) {
        this.freightId = freightId;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public long getStokId() {
        return stokId;
    }

    public void setStokId(long stokId) {
        this.stokId = stokId;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getCycles() {
        return cycles;
    }

    public void setCycles(int cycles) {
        this.cycles = cycles;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(productId);
        dest.writeString(productName);
        dest.writeString(unit);
        dest.writeFloat(markPrice);
        dest.writeInt(sold);
        dest.writeDouble(price);
        dest.writeString(userId);
        dest.writeString(userName);
        dest.writeString(desc);
        dest.writeInt(commentNum);
        dest.writeString(commentName);
        dest.writeString(commentContent);
        dest.writeInt(follow);
        dest.writeString(locateCity);
        dest.writeString(activity);
        dest.writeString(picture);
        dest.writeString(freight);
        dest.writeString(skuProp);
        dest.writeInt(freightId);
        dest.writeInt(stock);
        dest.writeLong(stokId);
        dest.writeInt(state);
        dest.writeInt(cycles);
    }
}
