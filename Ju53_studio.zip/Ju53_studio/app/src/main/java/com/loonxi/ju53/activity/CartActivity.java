package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.fragment.ShoppingFragment;
import com.loonxi.ju53.utils.LogUtil;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
public class CartActivity extends BaseActivity {

    private ShoppingFragment mShoppingFragment;

    public static final int REQUEST_CODE_CART_INVOICE = 1001;//购物车结算

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        initContent();
    }

    private void initContent() {
        mShoppingFragment = (ShoppingFragment)getSupportFragmentManager().findFragmentById(R.id.cart_fragment);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        LogUtil.mLog().e("result");
        switch (requestCode){
            case REQUEST_CODE_CART_INVOICE:
                if (resultCode == RESULT_OK) {
                    LogUtil.mLog().e("ok");
                    if (mShoppingFragment != null) {
                        LogUtil.mLog().e("refresh");
                        mShoppingFragment.onRefresh();
                    }
                }
                break;
        }

    }
}
