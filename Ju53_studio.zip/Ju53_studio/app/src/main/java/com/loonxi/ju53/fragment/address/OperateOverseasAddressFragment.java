package com.loonxi.ju53.fragment.address;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.bigkoo.pickerview.OptionsPickerView;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.AddressActivity;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.RegionEntity;
import com.loonxi.ju53.presenters.OverseasAddressOperatePresenter;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IOverseasAddressInfoView;
import com.loonxi.ju53.views.IUpdateAddressView;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/**
 * 增加、修改国际地址Fragment
 * Created by laojiaqi on 2016/1/27.
 */
@ContentView(R.layout.fragment_add_oversea_address)
public class OperateOverseasAddressFragment extends BaseSafeFragment<IOverseasAddressInfoView, OverseasAddressOperatePresenter> implements IOverseasAddressInfoView, View.OnClickListener, IUpdateAddressView {

    public static final int PHONE_NUM_LENGTH = 11;

    @ViewInject(R.id.address_oversea_add_action_bar)
    ActionBar mActionBar;
    @ViewInject(R.id.address_overseas_add_name)
    EditText mNameView;//名字
    @ViewInject(R.id.address_oversea_add_country)
    TextView mRegionView;//区域
    @ViewInject(R.id.address_oversea_add_city)
    EditText mCityView;//城市
    @ViewInject(R.id.address_oversea_add_unit)
    EditText mUnitView;//
    @ViewInject(R.id.address_oversea_add_province)
    EditText mProvinceView;//
    @ViewInject(R.id.address_oversea_add_zip)
    EditText mZipView;//邮编
    @ViewInject(R.id.address_oversea_add_phone_code)
    EditText mCountryCodeView;//国际区号
    @ViewInject(R.id.address_oversea_add_phone_num)
    EditText mPhoneNum;//电话号码
    @ViewInject(R.id.address_oversea_add_confirm)
    TextView mConfirmView;//保存
    @ViewInject(R.id.address_oversea_default_address_check_box)
    CheckBox mCheckBox;
    @ViewInject(R.id.address_oversea_add_street)
    EditText mSreetView;//街道

    private Map<String, String> mDataMap;//存储国外地区信息
    private ArrayList<RegionEntity> mRegionList;
    private OptionsPickerView mSelectRegionView;
    private Context mContext;
    private String mRegionId;
    private String mPid;//修改时的Id值
    private int mFragmentType;//表示当前类别
    private AddressEntity mModifyEntity;
    private String mAddress;//国家名字

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_add_oversea_address, null);
    }

    @Override
    public void initView() {

    }

    @Override
    public void initContent() {
        mContext = getActivity();
        mFragmentType = getArguments().getInt(OperateDomesticAddressFragment.ADDRESS_FRAGMENT_TYPE);
        setContentByType();

    }

    @Override
    public void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mRegionView.setOnClickListener(this);
        mConfirmView.setOnClickListener(this);
    }

    @Override
    protected OverseasAddressOperatePresenter createPresenter(IOverseasAddressInfoView iOverseasAddressInfoView) {
        return new OverseasAddressOperatePresenter(this);
    }

    @Override
    public void getAddressInfoSuccess(Map<String, String> dataMap) {
        if (isAdded()) {
            changeMapToList(dataMap);
            initSelectRegionView();
            mSelectRegionView.show();
        }
    }

    /**
     * 设置View的内容
     */
    private void setContentByType() {
        if (mFragmentType == OperateDomesticAddressFragment.ADDRESS_ADD_FLAGE) {
            mActionBar.setTitle(getString(R.string.address_add_title));
            return;
        }
        if (mFragmentType == OperateDomesticAddressFragment.ADDRESS_MODIFY_FLAGE) {
            mActionBar.setTitle(getString(R.string.address_modify_title));
            mModifyEntity = (getArguments().getParcelable(OperateDomesticAddressFragment.ADDRESS_MODIFY_ENTITY));
            if (mModifyEntity != null) {
                mNameView.setText(mModifyEntity.getContact());
                mRegionView.setText(mModifyEntity.getAddress() + "");//TODO 以后会返回country字段
                mSreetView.setText(mModifyEntity.getStreetAddress());
                mUnitView.setText(mModifyEntity.getUnit());
                mCityView.setText(mModifyEntity.getCity());
                mProvinceView.setText(mModifyEntity.getProvinceArea());
                mZipView.setText(mModifyEntity.getZip());
                mCheckBox.setChecked(mModifyEntity.getIsDefault() == 1 ? true : false);
                //收货地址id
                mPid = mModifyEntity.getPid();
                //区域id
                mRegionId = mModifyEntity.getRegionId();
                //国家名字
                mAddress = mModifyEntity.getAddress();
                if (!TextUtils.isEmpty(mModifyEntity.getPhones())) {
                    if (mModifyEntity.getPhones().length() >= PHONE_NUM_LENGTH) {
                        String code = mModifyEntity.getPhones().substring(0, 2);
                        String num = mModifyEntity.getPhones().substring(2, mModifyEntity.getPhones().length());
                        mPhoneNum.setText(num);
                        mCountryCodeView.setText(code);
                    }
                }
            }
            return;
        }
    }


    /**
     * @param message
     */
    @Override
    public void getAddressInfoFailure(String message) {

        ToastUtil.showToast(message, false);
    }

    /**
     * 区域信息map转成list
     *
     * @param dataMap
     */
    private void changeMapToList(Map<String, String> dataMap) {
        if (dataMap != null && dataMap.size() > 0) {
            Set<String> keySet = dataMap.keySet();
            mRegionList = new ArrayList<RegionEntity>();
            for (String key : keySet) {
                RegionEntity temp = new RegionEntity();
                temp.setRegionId(key);
                temp.setRegionName(dataMap.get(key));
                mRegionList.add(temp);
            }
        }
    }


    /**
     * 初始化选择区域视图
     */
    private void initSelectRegionView() {
        if (mRegionList != null && mRegionList.size() > 0 && mContext != null) {
            mSelectRegionView = new OptionsPickerView(mContext);
            mSelectRegionView.getWheelOptions().setTextSizeLevelOne(17);
            mSelectRegionView.setPicker(mRegionList);
            mSelectRegionView.setCyclic(false);
            mSelectRegionView.setTitle(getString(R.string.address_oversea_select_country));
            mSelectRegionView.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {
                @Override
                public void onOptionsSelect(int options1, int option2, int options3) {
                    if (mRegionList != null && mRegionList.size() > options1) {
                        mRegionId = mRegionList.get(options1).getRegionId();
                        mRegionView.setText(mRegionList.get(options1).getRegionName());
                        mAddress = mRegionList.get(options1).getRegionName();
                    }
                }
            });
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.address_oversea_add_country:
                getRegionInfo();
                hiddenKeyboard();
                break;
            case R.id.address_oversea_add_confirm:
                createOrUpdate();
                break;
        }
    }

    private void createOrUpdate() {
        if (checkDataHasEmpty()) {
            showToast(R.string.address_has_empty);
            return;
        }
        if (mFragmentType == OperateDomesticAddressFragment.ADDRESS_ADD_FLAGE) {
            mPresenter.saveAddress(getInputData());
            return;
        }
        if (mFragmentType == OperateDomesticAddressFragment.ADDRESS_MODIFY_FLAGE) {
            mPresenter.updateAddress(getInputData());
        }
    }

    /**
     * 隐藏键盘
     */
    private void hiddenKeyboard() {
        if (getActivity() == null) {
            return;
        }
        ((AddressActivity) getActivity()).hiddenKeyboard();
    }

    /**
     * 检查是否有未填项
     *
     * @return
     */
    private boolean checkDataHasEmpty() {
        String contact = mNameView.getText().toString();
        String regionId = mRegionId;
        String street = mSreetView.getText().toString();
        String city = mCityView.getText().toString();
        String unit = mUnitView.getText().toString();
        String province = mProvinceView.getText().toString();
        String zip = mZipView.getText().toString();
        String code = mCountryCodeView.getText().toString();
        String num = mPhoneNum.getText().toString();
        String address = mAddress;
        if (StringUtil.isEmpty(contact) || StringUtil.isEmpty(regionId) || StringUtil.isEmpty(street)
                || StringUtil.isEmpty(city) || StringUtil.isEmpty(unit) || StringUtil.isEmpty(province)
                || StringUtil.isEmpty(zip) || StringUtil.isEmpty(code) || StringUtil.isEmpty(num)
                || StringUtil.isEmpty(address)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 获得输入数据
     *
     * @return
     */
    private AddressEntity getInputData() {
        String contact = mNameView.getText().toString();
        String regionId = mRegionId;
        String street = mSreetView.getText().toString();
        String city = mCityView.getText().toString();
        String unit = mUnitView.getText().toString();
        String province = mProvinceView.getText().toString();
        String zip = mZipView.getText().toString();
        String code = mCountryCodeView.getText().toString();
        String num = mPhoneNum.getText().toString();
        String address = mAddress;

        //TODO 做合法性判断

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setPid(mPid);
        addressEntity.setContact(contact);
        addressEntity.setRegionId(regionId);
        addressEntity.setCity(city);
        addressEntity.setUnit(unit);
        addressEntity.setProvinceArea(province);
        addressEntity.setZip(zip);
        addressEntity.setPhones(code + num);
        addressEntity.setIsDefault(mCheckBox.isChecked() ? 1 : 0);
        addressEntity.setStreetAddress(street);
        addressEntity.setAddress(address);

        return addressEntity;
    }


    /**
     * 获得区域信息
     */
    private void getRegionInfo() {
        if (mRegionList == null || mRegionList.size() == 0 || mSelectRegionView == null) {
            mPresenter.getOverseasAddressInfo();
        } else {
            mSelectRegionView.show();
        }
    }

    @Override
    public void updateAddressSuccess() {
        goBack();
    }

    @Override
    public void updateAddressFailure(String message) {
        ToastUtil.showToast(message, false);
    }


    /**
     * 回退栈
     */
    private void goBack() {
        getFragmentManager().popBackStack();
    }
}
