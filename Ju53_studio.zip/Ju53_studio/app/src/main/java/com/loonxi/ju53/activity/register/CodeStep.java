package com.loonxi.ju53.activity.register;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.RegisterActivity;
import com.loonxi.ju53.presenters.RegisterPresenter;
import com.loonxi.ju53.utils.CountDownTimer;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IRegistCodeView;
import com.loonxi.ju53.views.IRegistPhoneView;
import com.loonxi.ju53.widgets.DeleteEditText;

/**
 * Created by Xuzue on 2016/1/4.
 */
public class CodeStep extends RegisterStep implements View.OnClickListener, IRegistCodeView, IRegistPhoneView {

    private TextView mTvTip;
    private DeleteEditText mTvCode;
    private LinearLayout mLayoutTimer;
    private TextView mTvTime;
    private TextView mBtnNext;

    private CountDownTimer mTimer;
    private static final long TOTAL_TIME = 60 * 1000;
    private static final long INTERVAL_TIME = 1000;

    private RegisterPresenter mPresenter;

    public CodeStep(RegisterActivity activity, Context context, View contentView) {
        super(activity, context, contentView);
        mPresenter = new RegisterPresenter(this, this);
    }

    @Override
    public void initViews() {
        mTvTip = (TextView) findViewById(R.id.include_register_code_tv_tip);
        mTvCode = (DeleteEditText) findViewById(R.id.include_register_code_tv_code);
        mLayoutTimer = (LinearLayout) findViewById(R.id.include_register_layout_timer);
        mTvTime = (TextView) findViewById(R.id.include_register_code_tv_time);
        mBtnNext = (TextView) findViewById(R.id.include_register_code_btn_next);
        mBtnNext.setEnabled(false);
    }

    @Override
    public void initEvents() {
        mTvTime.setOnClickListener(this);
        mBtnNext.setOnClickListener(this);
        mTvCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mIsChange = true;
                if (StringUtil.isEmpty(mTvCode.getText().toString())) {
                    mBtnNext.setEnabled(false);
                } else {
                    mBtnNext.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void initContent() {
        initTimer();
        mTvTip.setText("请输入" + (StringUtil.isEmpty(getMobile()) ? "" : "手机号" + getMobile()) + "收到的验证码");
        mTvCode.setText(getCode());
    }

    private void initTimer() {
        mTimer = new CountDownTimer(TOTAL_TIME, INTERVAL_TIME) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTvTime.setEnabled(false);
                mTvTime.setTextColor(mContext.getResources().getColor(R.color.app_gray));
                mTvTime.setText(millisUntilFinished / 1000 + mContext.getResources().getString(R.string.register_timer));
            }

            @Override
            public void onFinish() {
                mTvTime.setEnabled(true);
                mTvTime.setTextColor(mContext.getResources().getColor(R.color.app_black));
                mTvTime.setText(mContext.getResources().getString(R.string.register_get_code));
            }
        };
        mTimer.start();
    }

    public CountDownTimer getTimer(){
        return mTimer;
    }

    @Override
    public void afterChangeInit() {
        mTvCode.setText("");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.include_register_code_tv_time:
                getCheckCode();
                break;
            case R.id.include_register_code_btn_next:
                mCode = mTvCode.getText().toString();
                next();
                break;
        }
    }

    private void next() {
        setCode(mCode);
        if(!mIsChange){
            mOnNextActionListener.next(false);
            return;
        }
        mPresenter.verifyCode(mPhone, mCode);
    }

    private void getCheckCode(){
        mPresenter.getCheckCode(mPhone);
    }

    @Override
    public void showToast(int resId) {
        ToastUtil.showToast(mContext, resId);
    }

    @Override
    public void onGetCodeSuccess() {
        if(mTimer != null){
            mTimer.start();
        }
    }

    @Override
    public void onGetCodeFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onVerifyCodeSuccess() {
        mCode = mTvCode.getText().toString();
        mOnNextActionListener.next(mIsChange);
        mIsChange = false;
    }

    @Override
    public void onVerifyCodeFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
