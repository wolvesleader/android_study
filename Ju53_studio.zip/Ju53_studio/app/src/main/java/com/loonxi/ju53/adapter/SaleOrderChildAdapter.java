package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.SaleOrderDetailActivity;
import com.loonxi.ju53.activity.StoreProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.constants.OrderState;
import com.loonxi.ju53.constants.RefundState;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.entity.SaleOrderUnitEntity;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;

/**
 * "分销订单adapter"
 * Created by Xuzue on 2016/1/7.
 */
public class SaleOrderChildAdapter extends BaseObjectListAdapter<SaleOrderUnitEntity> {

    private SaleOrderEntity mOrderParent;
    private FROM mFrom;

    public SaleOrderChildAdapter(Context context, List<SaleOrderUnitEntity> datas, SaleOrderEntity parent) {
        this(context, datas, parent, FROM.SALE_ORDER_LIST);
    }

    public SaleOrderChildAdapter(Context context, List<SaleOrderUnitEntity> datas, SaleOrderEntity parent, FROM from) {
        super(context, datas);
        mOrderParent = parent;
        mFrom = from;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_sale_order_child, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_sale_order_child_layout_root);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_sale_order_child_iv_head);
            holder.mTvName = (TextView) convertView.findViewById(R.id.listitem_sale_order_child_tv_name);
            holder.mTvAttr = (TextView) convertView.findViewById(R.id.listitem_sale_order_child_tv_attr);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_sale_order_child_tv_price);
            holder.mTvNum = (TextView) convertView.findViewById(R.id.listitem_sale_order_child_tv_num);
            holder.mTvStatus = (TextView) convertView.findViewById(R.id.listitem_sale_order_child_tv_status);
            holder.mDivider = convertView.findViewById(R.id.listitem_sale_order_child_divider);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final SaleOrderUnitEntity order = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + order.getPicture()).into(holder.mIvHead);
        holder.mTvName.setText(order.getProductName());
        holder.mTvAttr.setText(order.getAttribute());
        holder.mTvPrice.setText("¥" + order.getPrice());
        holder.mTvNum.setText(order.getNum() + "件");
        if (!StringUtil.isEmpty(order.getIs_backed())) {
            setRefundStatus(holder.mTvStatus, Integer.parseInt(order.getIs_backed()));
        }

        if (mFrom == FROM.SALE_ORDER_DETAIL) {
            holder.mDivider.setVisibility(View.GONE);
        } else {
            holder.mDivider.setVisibility(View.VISIBLE);
        }

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mOrderParent == null) {
                    return;
                }
                if (mFrom == FROM.SALE_ORDER_DETAIL) {
                    Intent intent = new Intent(mContext, StoreProductDetailActivity.class);
                    StoreBaseInfoEntity mStoreBaseInfo = new StoreBaseInfoEntity();
                    mStoreBaseInfo.setStore_id(mOrderParent.getCustomId());
                    mStoreBaseInfo.setStore_name(mOrderParent.getCustomName());
                    intent.putExtra("store", mStoreBaseInfo);
                    intent.putExtra("productId", order.getProductId());
                    intent.putExtra("isOnSale", true);
                    mContext.startActivity(intent);
                } else if (mFrom == FROM.SALE_ORDER_LIST) {
                    Intent intent = new Intent(mContext, SaleOrderDetailActivity.class);
                    intent.putExtra("orderId", mOrderParent.getOrderId());
                    intent.putExtra("state", mOrderParent.getState());
                    mContext.startActivity(intent);
                }
            }
        });
        return convertView;
    }

    /**
     * 设置订单退款状态
     *
     * @param holder
     * @param status
     */
    /**
     * 设置退款状态
     *
     * @param mTvStatus
     * @param isBacked
     */
    private void setRefundStatus(TextView mTvStatus, int isBacked) {
        RefundState.setRefundState(mTvStatus, isBacked);
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvHead;
        TextView mTvName;
        TextView mTvAttr;
        TextView mTvPrice;
        TextView mTvNum;
        TextView mTvStatus;
        View mDivider;
    }

    enum FROM {
        SALE_ORDER_LIST, SALE_ORDER_DETAIL
    }
}
