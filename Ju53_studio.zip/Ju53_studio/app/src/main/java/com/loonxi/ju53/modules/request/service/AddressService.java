package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 收货地址service
 * Created by Administrator on 2016/1/25.
 */
public interface AddressService {

    /**
     * 获得默认收货地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/defaultAddress")
    Call<JsonInfo<AddressEntity>> getDefaultAddress(@FieldMap Map<String, Object> map);

    /**
     * 获得国内收货地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/address")
    Call<JsonArrayInfo<AddressEntity>> getAddress(@FieldMap Map<String, Object> map);


    /**
     * 删除收货地址
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/deleteAddress")
    Call<BaseJsonInfo> deleteAddress(@FieldMap Map<String, Object> map);

}
