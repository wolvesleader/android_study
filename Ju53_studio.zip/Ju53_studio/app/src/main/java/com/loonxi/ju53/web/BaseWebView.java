package com.loonxi.ju53.web;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.NetUtil;
import com.loonxi.ju53.widgets.dialog.BtnDialog;


/**
 * WebView控件
 */
public class BaseWebView extends FrameLayout {
    private static int PROGRESS_HIDDEN_NUM = 50;
    private ViewPageWebView mWebView;
    private ViewGroup mErrorLayout;
    private boolean mErrorFlag = false;
    private BtnDialog mDialog;
    private Context mContext;
    private OnClickListener clickListener;
    private ProgressBar mProgressBar;
    onWebViewListener onWebViewListener;
    private boolean mRefreshEnable = false;

    public void setOnWebViewListener(onWebViewListener onWebViewListener) {
        this.onWebViewListener = onWebViewListener;
    }

    public interface onWebViewListener {
        void onHtmlFinsh();
    }

    public BaseWebView(Context context) {
        super(context);
        initView();
    }

    public BaseWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public BaseWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        View.inflate(getContext(), R.layout.base_webview_layout, this);
        mWebView = (ViewPageWebView) findViewById(R.id.custom_webview);
        mErrorLayout = (ViewGroup) findViewById(R.id.error_layout);
        mProgressBar = (ProgressBar) findViewById(R.id.custom_webview_progress_bar);
        mContext = getContext();
    }

    public void setScrollViewGroup(ViewGroup viewGroup) {
        mWebView.setScrollView(viewGroup);
    }

    @SuppressLint({"JavascriptInterface", "SetJavaScriptEnabled"})
    private void setWebConfig() {
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.getSettings().setJavaScriptEnabled(true);
        //注入javascript对象
        mWebView.addJavascriptInterface(new JSInterface4Global(mContext, this), "android");
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
//        if (NetUtil.isConnected(mContext)) {
//            mWebView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT); // 设置缓存模式:根据cache-control决定是否从网络上取数据
//        } else {
//            mWebView.getSettings().setCacheMode(
//                    WebSettings.LOAD_CACHE_ELSE_NETWORK); // 设置缓存模式:只要本地有，无论是否过期，或者no-cache，都使用缓存中的数据
//        }

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                mErrorFlag = true;
                super.onReceivedError(view, errorCode, description, failingUrl);
            }


            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (mErrorFlag) {
                    hiddenWebView();
                } else {
                    displayWebView();
                }
                //页面加载完毕监听
                if (onWebViewListener != null) {
                    onWebViewListener.onHtmlFinsh();
                }
            }


            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                mErrorFlag = false;
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                //TODO 进度条
                if (newProgress < PROGRESS_HIDDEN_NUM) {
                    mProgressBar.setVisibility(View.GONE);
                    mProgressBar.setProgress(newProgress);
                } else {
                    mProgressBar.setVisibility(View.GONE);
                }

            }


            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                initClickListener(result);
                if (mContext == null) {
                    return false;
                }
                mDialog = new BtnDialog(mContext, BtnDialog.DEFALUT_TITLE, message, BtnDialog.DEFALUT_OK,
                        BtnDialog.DEFALUT_CANCEL, clickListener, clickListener);

                mDialog.show();
                return true;
            }
        });

        mWebView.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                getContext().startActivity(i);
            }
        });


    }


    public void start(String url) {
        mWebView.loadUrl(url);
    }

    public void loadDataWithBaseURL(String url) {
        mWebView.loadDataWithBaseURL("about:blank", url, "text/html", "utf-8", null);
    }

    private void initClickListener(final JsResult result) {
        clickListener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDialog != null) {
                    result.confirm();
                    mDialog.dismiss();
                }
            }
        };
    }


    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setWebConfig();
    }

    /**
     * 显示webView
     */
    private void displayWebView() {
        mWebView.setVisibility(View.VISIBLE);
        mErrorLayout.setVisibility(View.GONE);
    }

    /**
     * 隐藏webView
     */
    private void hiddenWebView() {
        mWebView.setVisibility(View.GONE);
        mErrorLayout.setVisibility(View.VISIBLE);
    }

    public void startAssetsFile(String fileName) {
        String str = "file:///android_asset/" + fileName;
        mWebView.loadUrl(str);
    }

    /**
     * 刷新
     */
    public void refResh() {
//        mWebView.clearCache(true);
        mWebView.reload();
    }

    public void setRefreshEnable(boolean enable){
        mRefreshEnable = enable;
    }



    public boolean getRefreshEnable(){
        return mRefreshEnable;
    }
}
