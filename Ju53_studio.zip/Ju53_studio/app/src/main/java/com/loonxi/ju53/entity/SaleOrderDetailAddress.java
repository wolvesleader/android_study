package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 分销订单详情-地址信息
 * Created by XuZue on 2016/5/12 0012.
 */
public class SaleOrderDetailAddress implements Parcelable {
    private String receiveName;
    private String mobile;
    private String receiveAddress;

    protected SaleOrderDetailAddress(Parcel in) {
        receiveName = in.readString();
        mobile = in.readString();
        receiveAddress = in.readString();
    }

    public static final Creator<SaleOrderDetailAddress> CREATOR = new Creator<SaleOrderDetailAddress>() {
        @Override
        public SaleOrderDetailAddress createFromParcel(Parcel in) {
            return new SaleOrderDetailAddress(in);
        }

        @Override
        public SaleOrderDetailAddress[] newArray(int size) {
            return new SaleOrderDetailAddress[size];
        }
    };

    public String getReceiveName() {
        return receiveName;
    }

    public void setReceiveName(String receiveName) {
        this.receiveName = receiveName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getReceiveAddress() {
        return receiveAddress;
    }

    public void setReceiveAddress(String receiveAddress) {
        this.receiveAddress = receiveAddress;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(receiveName);
        dest.writeString(mobile);
        dest.writeString(receiveAddress);
    }
}
