package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 订单提交成功后返回的实体
 * Created by Xuzue on 2016/1/26.
 */
public class OrderCreateEntity implements Parcelable{
    private int flag;
    private String message;
    private String data;
    private List<OrderNoEntity> orderIdList;

    public OrderCreateEntity(){

    }

    protected OrderCreateEntity(Parcel in) {
        flag = in.readInt();
        message = in.readString();
        data = in.readString();
        orderIdList = in.createTypedArrayList(OrderNoEntity.CREATOR);
    }

    public static final Creator<OrderCreateEntity> CREATOR = new Creator<OrderCreateEntity>() {
        @Override
        public OrderCreateEntity createFromParcel(Parcel in) {
            return new OrderCreateEntity(in);
        }

        @Override
        public OrderCreateEntity[] newArray(int size) {
            return new OrderCreateEntity[size];
        }
    };

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public List<OrderNoEntity> getOrderIdList() {
        return orderIdList;
    }

    public void setOrderIdList(List<OrderNoEntity> orderIdList) {
        this.orderIdList = orderIdList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(flag);
        dest.writeString(message);
        dest.writeString(data);
        dest.writeTypedList(orderIdList);
    }
}
