package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2015/12/30.
 */
public interface ShoppingService {

    /**
     * 获取购物车数据
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/showCart")
    Call<JsonArrayInfo<CartEntity>> getCarts(@FieldMap Map<String, Object> map);

    /**
     * 删除购物车里的产品
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/delCart")
    Call<JsonArrayInfo<CartEntity>> deleteProduct(@FieldMap Map<String, Object> map);

    /**
     * 修改购物车里的产品属性
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/updateCart")
    Call<BaseJsonInfo> updateCart(@FieldMap Map<String, Object> map);

    /**
     * 购物车产品移至收藏夹
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/cartMoveCollect")
    Call<BaseJsonInfo> moveToFav(@FieldMap Map<String, Object> map);


}
