package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * Created by XuZue on 2016/5/7 0007.
 */
public interface ISaleOrderView extends IBaseView {

    void onGetOrdersSuccess(JsonArrayInfo<SaleOrderEntity> jsonArrayInfo);

    void onGetOrdersFailed(int apiErrorCode, String message);
}
