package com.loonxi.ju53.utils;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuze on 2015/8/30.
 */
public class FileUtil {

    private static String TAG = "TEST";
    private static String WRITE_STORAGE_PERMISSION = "android.permission.WRITE_EXTERNAL_STORAGE";
    private static int MIN_EXTERNAL_MEMORY = 2000;
    public static final int SIZETYPE_B = 1;//获取文件大小单位为B的double值
    public static final int SIZETYPE_KB = 2;//获取文件大小单位为KB的double值
    public static final int SIZETYPE_MB = 3;//获取文件大小单位为MB的double值
    public static final int SIZETYPE_GB = 4;//获取文件大小单位为GB的double值
    /**
     * 文件扩展名间隔符号
     */
    public final static String FILE_EXTENSION_SEPARATOR = ".";

    /**
     * 判断SD卡是否可用
     *
     * @return
     */
    public static boolean isSDCardAvailable() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            return true;
        }
        return false;
    }

    /**
     * 判断是否有读取SD卡权限
     *
     * @param context
     * @return
     */
    public static boolean isHasSDCardPermission(Context context) {
        int permission = context.checkCallingOrSelfPermission(WRITE_STORAGE_PERMISSION);
        return permission == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * 获取手机内部可用空间大小
     *
     * @return
     */
    public static long getAvailableInternalMemorySize() {
        String path = Environment.getDataDirectory().getPath();
        StatFs statFs = new StatFs(path);
        long blocks = statFs.getAvailableBlocks();
        long size = statFs.getBlockSize();
        return blocks * size;
    }

    /**
     * 获取手机内部总空间大小
     *
     * @return
     */
    public static long getTotalInternalMemorySize() {
        String path = Environment.getDataDirectory().getPath();
        StatFs statFs = new StatFs(path);
        long blocks = statFs.getBlockCount();
        long size = statFs.getBlockSize();
        return blocks * size;
    }

    /**
     * 获取手机外部可用空间大小
     *
     * @return
     */
    public static long getAvailableExternalMemorySize() {
        if (!isSDCardAvailable()) {
            return -1;
        }
        String path = Environment.getExternalStorageDirectory().getPath();
        StatFs statFs = new StatFs(path);
        long blocks = statFs.getAvailableBlocks();
        long size = statFs.getBlockSize();
        return blocks * size;
    }

    /**
     * 获取手机外部总空间大小
     *
     * @return
     */
    public static long getTotalExternalMemorySize() {
        if (!isSDCardAvailable()) {
            return -1;
        }
        String path = Environment.getExternalStorageDirectory().getPath();
        StatFs statFs = new StatFs(path);
        long blocks = statFs.getBlockCount();
        long size = statFs.getBlockSize();
        return blocks * size;
    }

    /**
     * 判断SD卡可用空间是否足够
     *
     * @return
     */
    public static boolean isExternalMemoryEnough() {
        if (!isSDCardAvailable()) {
            return false;
        }
        if (getAvailableExternalMemorySize() > MIN_EXTERNAL_MEMORY) {
            return true;
        }
        Log.e(TAG, "SDCard No Enough Memory");
        return false;
    }

    /**
     * 创建根目录
     *
     * @param context
     * @param path
     * @return
     */
    public static File createDirFile(Context context, String path) {
        if (StringUtil.isEmpty(path)) {
            Log.e(TAG, "path is empty");
            return null;
        }
        if (!isSDCardAvailable()) {
            Log.e(TAG, "SDCard Not Available");
            return null;
        }
        if (!isHasSDCardPermission(context)) {
            Log.e(TAG, "No Permission android.permission.WRITE_EXTERNAL_STORAGE");
            return null;
        }
        if (!isExternalMemoryEnough()) {
            Log.e(TAG, "External Memory Not Enough");
            return null;
        }
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    /**
     * 创建文件
     *
     * @param context
     * @param path
     * @return
     */
    public static File createNewFile(Context context, String path) {
        if (StringUtil.isEmpty(path)) {
            return null;
        }
        if (!isSDCardAvailable()) {
            Log.e(TAG, "SDCard Unavailable");
            return null;
        }
        if (!isHasSDCardPermission(context)) {
            Log.e(TAG,
                    "No android.permission.WRITE_EXTERNAL_STORAGE Permission");
            return null;
        }
        File file = new File(path);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                Log.e(TAG, "Create New File Error");
                return null;
            }
        }
        return file;
    }

    /**
     * 判断文件是否存在
     *
     * @param filePath
     * @return
     */
    public static boolean isFileExist(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return false;
        }
        File file = new File(filePath);
        return file.exists() && file.isFile();
    }

    /**
     * 判断文件夹是否存在
     *
     * @param fileDirectoryPath
     * @return
     */
    public static boolean isFileDirectoryExist(String fileDirectoryPath) {
        if (StringUtil.isEmpty(fileDirectoryPath)) {
            return false;
        }
        File file = new File(fileDirectoryPath);
        return file.exists() && file.isDirectory();
    }

    /**
     * 删除文件
     *
     * @param path
     * @return
     */
    public static boolean deleteFile(String path) {
        if (StringUtil.isEmpty(path)) {
            return true;
        }
        File file = new File(path);
        if (!file.exists()) {
            return true;
        }
        if (file.isFile()) {
            return file.delete();
        }
        if (!file.isDirectory()) {
            return false;
        }
        for (File f : file.listFiles()) {
            if (f.isFile()) {
                return f.delete();
            } else if (f.isDirectory()) {
                deleteFile(f.getAbsolutePath());
            }
        }
        return file.delete();
    }

    public static long getFolderSize(File dir) {
        long total = 0;
        if (dir == null || !dir.isDirectory() || dir.listFiles() == null || dir.listFiles().length <= 0) {
            return total;
        }
        for (File child : dir.listFiles()) {
            if (child.isDirectory()) {
                total += getFolderSize(child);
            } else {
                total += getFileSize(child);
            }
        }
        return total;
    }

    /**
     * 获取指定文件大小
     *
     * @param file
     * @return
     * @throws Exception
     */
    private static long getFileSize(File file) {
        long size = 0;
        if (file.exists()) {
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
                size = fis.available();
                file.createNewFile();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Log.e("获取文件大小", "文件不存在!");
        }
        return size;
    }

    /**
     * 获取文件大小
     *
     * @param path
     * @return
     */
    public static long getFileSize(String path) {
        if (StringUtil.isEmpty(path)) {
            return -1;
        }
        File file = new File(path);
        return (file.exists() && file.isFile() ? file.length() : -1);
    }

    /**
     * 读取文件
     *
     * @param context
     * @param file
     * @param charsetName
     * @return
     */
    public static StringBuilder readFile(Context context, File file,
                                         String charsetName) {
        if (isSDCardAvailable() && isHasSDCardPermission(context)) {
            if (StringUtil.isEmpty(charsetName)) {
                charsetName = "UTF-8";
            }
            StringBuilder fileContent = new StringBuilder("");
            if (file == null || !file.isFile()) {
                return null;
            }

            BufferedReader reader = null;
            try {
                InputStreamReader is = new InputStreamReader(
                        new FileInputStream(file), charsetName);
                reader = new BufferedReader(is);
                String line = null;
                while ((line = reader.readLine()) != null) {
                    if (!fileContent.toString().equals("")) {
                        fileContent.append("\r\n");
                    }
                    fileContent.append(line);
                }
                reader.close();
                return fileContent;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;
    }

    /**
     * 根据字符串写文件
     *
     * @param file
     * @param content
     * @param append
     * @return
     */
    public static boolean writeFile(Context context, File file, String content,
                                    boolean append) {
        if (isSDCardAvailable() && isExternalMemoryEnough()
                && isHasSDCardPermission(context)) {
            if (file == null || StringUtil.isEmpty(content)) {
                return false;
            }
            if (!isFileExist(file.getPath())) {
                String dirPath = file.getParentFile().getPath();
                File dirFile = createDirFile(context, dirPath);
                if (dirFile != null) {
                    file = createNewFile(context, file.getPath());
                }
                if (file == null) {
                    return false;
                }
            }
            FileWriter fileWriter = null;
            try {
                fileWriter = new FileWriter(file, append);
                fileWriter.write(content);
                fileWriter.close();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fileWriter != null) {
                    try {
                        fileWriter.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return false;
    }

    /**
     * 通过输入流写文件
     *
     * @param filePath
     * @param stream
     * @return
     */
    public static boolean writeFile(Context context, String filePath,
                                    InputStream stream) {
        if (isSDCardAvailable() && isExternalMemoryEnough()
                && isHasSDCardPermission(context)) {
            if (StringUtil.isEmpty(filePath) || stream == null) {
                return false;
            }
            OutputStream o = null;
            try {
                o = new FileOutputStream(filePath);
                byte data[] = new byte[1024];
                int length = -1;
                while ((length = stream.read(data)) != -1) {
                    o.write(data, 0, length);
                }
                o.flush();
                return true;
            } catch (FileNotFoundException e) {
                throw new RuntimeException("FileNotFoundException occurred. ",
                        e);
            } catch (IOException e) {
                throw new RuntimeException("IOException occurred. ", e);
            } finally {
                if (o != null) {
                    try {
                        o.close();
                        stream.close();
                    } catch (IOException e) {
                        throw new RuntimeException("IOException occurred. ", e);
                    }
                }
            }
        }
        return false;
    }

    /**
     * 读取文件存入List
     *
     * @param filePath
     * @param charsetName
     * @return
     */
    public static List<String> readFileToList(Context context, String filePath,
                                              String charsetName) {
        if (isSDCardAvailable() && isHasSDCardPermission(context)) {
            if (StringUtil.isEmpty(filePath)) {
                return null;
            }
            if (StringUtil.isEmpty(charsetName)) {
                charsetName = "UTF-8";
            }
            File file = new File(filePath);
            List<String> fileContent = new ArrayList<String>();
            if (file == null || !file.isFile()) {
                return null;
            }

            BufferedReader reader = null;
            try {
                InputStreamReader is = new InputStreamReader(
                        new FileInputStream(file), charsetName);
                reader = new BufferedReader(is);
                String line = null;
                while ((line = reader.readLine()) != null) {
                    fileContent.add(line);
                }
                reader.close();
                return fileContent;
            } catch (IOException e) {
                throw new RuntimeException("IOException occurred. ", e);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        throw new RuntimeException("IOException occurred. ", e);
                    }
                }
            }
        }
        return null;
    }

    /**
     * 获取路径文件名称,不包含扩展名
     * <p/>
     * <pre>
     *      getFileNameWithoutExtension(null)               =   null
     *      getFileNameWithoutExtension("")                 =   ""
     *      getFileNameWithoutExtension("   ")              =   "   "
     *      getFileNameWithoutExtension("abc")              =   "abc"
     *      getFileNameWithoutExtension("a.mp3")            =   "a"
     *      getFileNameWithoutExtension("a.b.rmvb")         =   "a.b"
     *      getFileNameWithoutExtension("c:\\")              =   ""
     *      getFileNameWithoutExtension("c:\\a")             =   "a"
     *      getFileNameWithoutExtension("c:\\a.b")           =   "a"
     *      getFileNameWithoutExtension("c:a.txt\\a")        =   "a"
     *      getFileNameWithoutExtension("/home/admin")      =   "admin"
     *      getFileNameWithoutExtension("/home/admin/a.txt/b.mp3")  =   "b"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFileNameWithoutExtension(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int extenPosi = filePath.lastIndexOf(FILE_EXTENSION_SEPARATOR);
        int filePosi = filePath.lastIndexOf(File.separator);
        if (filePosi == -1) {
            return (extenPosi == -1 ? filePath : filePath.substring(0,
                    extenPosi));
        }
        if (extenPosi == -1) {
            return filePath.substring(filePosi + 1);
        }
        return (filePosi < extenPosi ? filePath.substring(filePosi + 1,
                extenPosi) : filePath.substring(filePosi + 1));
    }

    /**
     * 获取路径文件名称,包含扩展名
     * <p/>
     * <pre>
     *      getFileName(null)               =   null
     *      getFileName("")                 =   ""
     *      getFileName("   ")              =   "   "
     *      getFileName("a.mp3")            =   "a.mp3"
     *      getFileName("a.b.rmvb")         =   "a.b.rmvb"
     *      getFileName("abc")              =   "abc"
     *      getFileName("c:\\")              =   ""
     *      getFileName("c:\\a")             =   "a"
     *      getFileName("c:\\a.b")           =   "a.b"
     *      getFileName("c:a.txt\\a")        =   "a"
     *      getFileName("/home/admin")      =   "admin"
     *      getFileName("/home/admin/a.txt/b.mp3")  =   "b.mp3"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFileName(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int filePosi = filePath.lastIndexOf(File.separator);
        return (filePosi == -1) ? filePath : filePath.substring(filePosi + 1);
    }

    /**
     * 获取路径文件夹名称
     * <p/>
     * <pre>
     *      getFolderName(null)               =   null
     *      getFolderName("")                 =   ""
     *      getFolderName("   ")              =   ""
     *      getFolderName("a.mp3")            =   ""
     *      getFolderName("a.b.rmvb")         =   ""
     *      getFolderName("abc")              =   ""
     *      getFolderName("c:\\")              =   "c:"
     *      getFolderName("c:\\a")             =   "c:"
     *      getFolderName("c:\\a.b")           =   "c:"
     *      getFolderName("c:a.txt\\a")        =   "c:a.txt"
     *      getFolderName("c:a\\b\\c\\d.txt")    =   "c:a\\b\\c"
     *      getFolderName("/home/admin")      =   "/home"
     *      getFolderName("/home/admin/a.txt/b.mp3")  =   "/home/admin/a.txt"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFolderName(String filePath) {

        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int filePosi = filePath.lastIndexOf(File.separator);
        return (filePosi == -1) ? "" : filePath.substring(0, filePosi);
    }

    /**
     * 获取路径文件的扩展名
     * <p/>
     * <pre>
     *      getFileExtension(null)               =   ""
     *      getFileExtension("")                 =   ""
     *      getFileExtension("   ")              =   "   "
     *      getFileExtension("a.mp3")            =   "mp3"
     *      getFileExtension("a.b.rmvb")         =   "rmvb"
     *      getFileExtension("abc")              =   ""
     *      getFileExtension("c:\\")              =   ""
     *      getFileExtension("c:\\a")             =   ""
     *      getFileExtension("c:\\a.b")           =   "b"
     *      getFileExtension("c:a.txt\\a")        =   ""
     *      getFileExtension("/home/admin")      =   ""
     *      getFileExtension("/home/admin/a.txt/b")  =   ""
     *      getFileExtension("/home/admin/a.txt/b.mp3")  =   "mp3"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFileExtension(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int extenPosi = filePath.lastIndexOf(FILE_EXTENSION_SEPARATOR);
        int filePosi = filePath.lastIndexOf(File.separator);
        if (extenPosi == -1) {
            return "";
        }
        return (filePosi >= extenPosi) ? "" : filePath.substring(extenPosi + 1);
    }

    public static long getWebviewCacheSize(Context context){
        long total = 0;
        File dir = context.getCacheDir();
        if(dir == null || dir.listFiles() == null){
            return total;
        }
        for(File child : dir.listFiles()){
            if (child != null && child.isDirectory() && child.getName().contains("webview")) {
                total += getFolderSize(child);
                break;
            }
        }
        return total;
    }


    /**
     * 清除webview缓存
     *
     * @param dir
     * @param numDays
     * @return
     */
    public static int clearWebviewCacheFolder(File dir, long numDays) {
        int deletedFiles = 0;
        if (dir != null && dir.isDirectory() && dir.listFiles() != null) {
            try {
                for (File child : dir.listFiles()) {
                    if (child.isDirectory() && child.getName().contains("webview")) {
                        deletedFiles += clearWebviewCacheFolder(child, numDays);
                    }
                    if (child.lastModified() < numDays) {
                        if (child.delete()) {
                            deletedFiles++;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return deletedFiles;
    }

    /**
     * 转换文件大小
     *
     * @param files
     * @return
     */
    public static String FormatFileSize(long files) {
        return FormatFileSize(files, SIZETYPE_MB);
    }

    /**
     * 转换文件大小,指定转换的类型
     *
     * @param fileS
     * @param sizeType
     * @return
     */
    public static String FormatFileSize(long fileS, int sizeType) {
        DecimalFormat df = new DecimalFormat("#.00");
        String lStr = "";
        double fileSizeLong = 0;
        switch (sizeType) {
            case SIZETYPE_B:
                fileSizeLong = Double.valueOf(df.format((double) fileS));
                lStr = fileSizeLong + "B";
                break;
            case SIZETYPE_KB:
                fileSizeLong = Double.valueOf(df.format((double) fileS / 1024));
                lStr = fileSizeLong + "KB";
                break;
            case SIZETYPE_MB:
                fileSizeLong = Double.valueOf(df.format((double) fileS / (1024 * 1024)));
                lStr = fileSizeLong + "MB";
                break;
            case SIZETYPE_GB:
                fileSizeLong = Double.valueOf(df.format((double) fileS / (1024 * 1026 * 1024)));
                lStr = fileSizeLong + "GB";
                break;
            default:
                break;
        }
        return lStr;
    }
}
