package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.OrderService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/17.
 */
public class MineModel {

    /**
     * 获取进货订单数(全部、待付款、待发货等)
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonInfo<String>> getBuyOrderNum(Map<String, Object> map, Callback<JsonInfo<String>> callback) {
        Call<JsonInfo<String>> call = Request.creatApi(OrderService.class).getBuyOrderNum(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 获得订单总数
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonInfo<String>> getOrderTotalNum(Map<String, Object> map, Callback<JsonInfo<String>> callback) {
        Call<JsonInfo<String>> call = NewRequest.creatApi(OrderService.class).getOrderTotalNum(map);
        call.enqueue(callback);
        return call;
    }
}
