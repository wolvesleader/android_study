package com.loonxi.ju53.utils;

import android.content.Context;
import android.os.Environment;

import java.io.File;

/**
 * 文件路径工具类
 * Created by Leo on 2015/9/10.
 */
public class StorageUtil {
    public static final String DIR_IMG = "img";
    public static final String DIR_TEMP = "temp";
    public static final String DIR_LOG = "log";
    public static final String DIR_APK = "apk";
    public static final String DIR_DL = "download";

    public static String getDCIMDir(){
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath();
    }

    public static String getImageDir(Context context){
        return createAppDir(context, DIR_IMG);
    }

    public static String getLogDir(Context context){
        return createAppDir(context, DIR_LOG);
    }

    public static String getTempDir(Context context){
        return createAppDir(context, DIR_TEMP);
    }

    public static String getImageCacheDir(Context context){
        return createCacheDir(context, DIR_IMG);
    }

    public static String getApkDir(Context context){
        return createExternalFileDir(context, DIR_APK);
    }

    public static String getAppPublicImageDir(){
        return createDir(Environment.getExternalStorageDirectory() + File.separator + "shoufa88" + File.separator + "image");
    }

    public static String getDownloadDir(){
        return createDir(Environment.getExternalStorageDirectory() + File.separator + "shoufa88" + File.separator + DIR_DL);
    }

    public static String getExternalFileDir(Context context){
        return createExternalFileDir(context, null);
    }

    private static String createExternalFileDir(Context context, String type){
        return createDir(context.getExternalFilesDir(type));
    }

    private static String createAppDir(Context context, String type){
        return createDir(context.getFilesDir().getAbsolutePath() + File.separator + type);
    }

    private static String createCacheDir(Context context, String type){
        return createDir(context.getCacheDir().getAbsolutePath() + File.separator + type);
    }

    private static String createDir(String path){
        File file = new File(path);
        if(!file.exists()){
            file.mkdirs();
        }
        return file.getAbsolutePath();
    }

    private static String createDir(File file){
        if(!file.exists()){
            file.mkdirs();
        }
        return file.getAbsolutePath();
    }

}
