package com.loonxi.ju53.base;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.loonxi.ju53.utils.ToastUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Xuzue on 2015/9/6.
 */
public class BaseArrayListAdapter extends BaseAdapter{

    protected Context mContext;
    protected LayoutInflater mInflater;
    protected List<String> mDatas = new ArrayList<String>();
    public BaseArrayListAdapter(Context context, String... datas){
        mContext = context;
        if (context != null) {
            mInflater = LayoutInflater.from(context);
        }
        if(datas != null && datas.length > 0){
            mDatas = Arrays.asList(datas);
        }
    }

    @Override
    public int getCount() {
        return mDatas.size();
    }

    @Override
    public Object getItem(int i) {
        return mDatas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return null;
    }

    public String get(int position){
        return mDatas.get(position);
    }

    public List<String> getListDatas(){
        return mDatas;
    }

    public String[] getStringArrayDatas(){
        return mDatas == null ? null : ((String[])mDatas.toArray());
    }

    public void showToast(String text){
        ToastUtil.showToast(mContext, text);
    }

    public void showToast(String text, boolean isLong){
        ToastUtil.showToast(mContext, text, isLong);
    }

    public void showToast(int resId, String text){
        ToastUtil.showToast(mContext, resId, text);
    }
}
