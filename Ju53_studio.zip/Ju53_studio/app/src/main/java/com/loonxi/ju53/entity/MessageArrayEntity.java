package com.loonxi.ju53.entity;

import java.util.List;

/**
 * 消息列表 entity
 * Created by laojiaqi on 2016/2/2.
 */
public class MessageArrayEntity {

    private int flag;
    private String message;
    private List<MessageEntity> messageList;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<MessageEntity> getMessageList() {
        return messageList;
    }

    public void setMessageList(List<MessageEntity> messageList) {
        this.messageList = messageList;
    }

    @Override
    public String toString() {
        return "MessageArrayEntity{" +
                "flag=" + flag +
                ", message='" + message + '\'' +
                ", messageList=" + messageList +
                '}';
    }
}
