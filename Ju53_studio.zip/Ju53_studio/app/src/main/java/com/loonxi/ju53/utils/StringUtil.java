package com.loonxi.ju53.utils;

import android.content.ClipboardManager;
import android.content.Context;
import android.util.Base64;

import com.loonxi.ju53.base.BaseApplication;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by butterfly on 2015/8/28.
 */
public class StringUtil {

    private static String TAG = "StringUtil";

    /**
     * 是否为空
     *
     * @param str
     * @return
     */
    public static boolean isEmpty(String str) {
        if (str == null || str.trim().length() == 0) {
            return true;
        }
        return false;
    }

    /**
     * 是否是空白
     *
     * @param str
     * @return
     */
    public static boolean isBlank(String str) {
        if (str == null || str.length() == 0) {
            return true;
        }
        return false;
    }

    /**
     * 是否相等
     *
     * @param val1
     * @param val2
     * @return
     */
    public static boolean isEquals(String val1, String val2) {
        return ObjectUtil.isEquals(val1, val2);
    }

    /**
     * 空转换为字符串
     *
     * @param str
     * @return
     */
    public static String nullStrToString(String str) {
        return (str == null ? "" : str);
    }

    /**
     * 首字母变为大写
     *
     * @param str
     * @return
     */
    public static String capitalizeFirstLetter(String str) {
        if (isEmpty(str)) {
            return str;
        }
        char c = str.charAt(0);
        if (!Character.isLetter(c) || Character.isUpperCase(c)) {
            return str;
        } else {
            return new StringBuilder(str.length())
                    .append(Character.toUpperCase(c))
                    .append(str.substring(1)).toString();
        }
    }

    /**
     * 转换为utf8编码
     *
     * @param str
     * @return
     */
    public static String utf8Encode(String str) {
        if (!isEmpty(str) && str.getBytes().length != str.length()) {
            try {
                return URLEncoder.encode(str, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                throw new RuntimeException("UnSuportedEncodingException", e);
            }
        }
        return str;
    }

    /**
     * 转换为utf8编码，转换失败取默认值
     *
     * @param str
     * @param defaultValue
     * @return
     */
    public static String utf8Encode(String str, String defaultValue) {
        if (!isEmpty(str) && str.getBytes().length != str.length()) {
            try {
                return URLEncoder.encode(str, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return defaultValue;
            }
        }
        return str;
    }

    /**
     * 全宽字符变换半宽字符
     * <p/>
     * <pre>
     * fullWidthToHalfWidth(null) = null;
     * fullWidthToHalfWidth("") = "";
     * fullWidthToHalfWidth(new String(new char[] {12288})) = " ";
     * fullWidthToHalfWidth("！＂＃＄％＆) = "!\"#$%&";
     * </pre>
     *
     * @param s
     * @return
     */
    public static String fullWidthToHalfWidth(String s) {
        if (isEmpty(s)) {
            return s;
        }

        char[] source = s.toCharArray();
        for (int i = 0; i < source.length; i++) {
            if (source[i] == 12288) {
                source[i] = ' ';
            } else if (source[i] >= 65281 && source[i] <= 65374) {
                source[i] = (char) (source[i] - 65248);
            } else {
                source[i] = source[i];
            }
        }
        return new String(source);
    }

    /**
     * 半宽字符变换全宽字符
     * <p/>
     * <pre>
     * halfWidthToFullWidth(null) = null;
     * halfWidthToFullWidth("") = "";
     * halfWidthToFullWidth(" ") = new String(new char[] {12288});
     * halfWidthToFullWidth("!\"#$%&) = "！＂＃＄％＆";
     * </pre>
     *
     * @param s
     * @return
     */
    public static String halfWidthToFullWidth(String s) {
        if (isEmpty(s)) {
            return s;
        }

        char[] source = s.toCharArray();
        for (int i = 0; i < source.length; i++) {
            if (source[i] == ' ') {
                source[i] = (char) 12288;
            } else if (source[i] >= 33 && source[i] <= 126) {
                source[i] = (char) (source[i] + 65248);
            } else {
                source[i] = source[i];
            }
        }
        return new String(source);
    }

    /**
     * 判断是否是手机号
     * 13/15/17/18开头 true
     *
     * @param str
     * @return
     */
    public static boolean isMobile(String str) {
        Pattern p = Pattern.compile("^((13[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\\d{8}$");
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 判断是否只有数字和字母
     *
     * @param str
     * @return
     */
    public static boolean isNumberLetter(String str) {
        Pattern p = Pattern.compile("^[A-Za-z0-9]+$");
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 是否只有数字
     *
     * @param str
     * @return
     */
    public static boolean isNumber(String str) {
        Pattern p = Pattern.compile("^[0-9]+$");
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 是否只有字母
     *
     * @param str
     * @return
     */
    public static boolean isLetter(String str) {
        Pattern p = Pattern.compile("^[A-Za-z]+$");
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 是否是邮箱
     *
     * @param str
     * @return
     */
    public static boolean isEmail(String str) {
        String expr = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
        String expr1 = "^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$";
        if (str.matches(expr)) {
            return true;
        }
        if (str.matches(expr1)) {
            return true;
        }
        return false;
    }

    /**
     * 是否是中文
     *
     * @param str
     * @return
     */
    public static boolean isChinese(String str) {
        boolean isChinese = true;
        String chinese = "[\u0391-\uFFE5]";
        if (!isEmpty(str)) {
            for (int i = 0; i < str.length(); i++) {
                String temp = str.substring(i, i + 1);
                if (!temp.matches(chinese)) {
                    isChinese = false;
                }
            }
        }
        return isChinese;
    }

    /**
     * 是否包含中文
     *
     * @param str
     * @return
     */
    public static boolean isContainChinese(String str) {
        boolean isChinese = false;
        String chinese = "[\u0391-\uFFE5]";
        if (!isEmpty(str)) {
            for (int i = 0; i < str.length(); i++) {
                String temp = str.substring(i, i + 1);
                if (temp.matches(chinese)) {
                    isChinese = true;
                }
            }
        }
        return isChinese;
    }

    /**
     * 不足2位的字符串补“0”
     *
     * @param str
     * @return
     */
    public static String strFormat2(String str) {
        if (isEmpty(str)) {
            return str;
        }
        if (str.length() <= 1) {
            str = "0" + str;
        }
        return str;
    }

    /**
     * 获取一个字符串在另一个字符串中出现的次数
     *
     * @param str
     * @param find
     * @return
     */
    public static int getContainCount(String str, String find) {
        int count = 0;
        if (isEmpty(str)) {
            return 0;
        }
        while (str.indexOf(find) >= 0) {
            count++;
            str = str.replaceFirst(find, "");
        }
        return count;
    }

    /**
     * 金钱转换
     *
     * @param money
     * @return
     */
    public static String money(int money) {
        String newMoney = money + "";
        float temp = 0L;
        if (money >= 100000000L) {
            temp = ((float) money) / 100000000L;
            return String.format("%.0f亿", temp);
        } else if (money >= 10000L) {
            temp = ((float) money) / 10000L;
            return String.format("%.0f万", temp);
        }
        return newMoney;
    }

    /**
     * 从输入流获得文本内容
     *
     * @param is
     * @return
     */
    public static String readTextFile(InputStream is) {
        String str = "";
        BufferedReader br;
        if (is == null) {
            return str;
        }
        try {
            br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String temp = "";
            while ((temp = br.readLine()) != null) {
                str += temp;
            }
            is.close();
            br.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }

    /**
     * Base64加密
     *
     * @param str
     * @return
     */
    public static String toBase64String(String str) {
        if (isEmpty(str)) {
            return null;
        }
        return new String(Base64.encode(str.getBytes(), Base64.DEFAULT));
    }

    /**
     * 字符串转json对象
     *
     * @param str
     * @return
     */
    public static JSONObject str2Json(String str) {
        if (isEmpty(str)) {
            return null;
        }
        try {
            JSONObject object = new JSONObject(str);
            return object;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * unicode转字符串
     *
     * @param s
     * @return
     */
    public static String unicode2string(String s) {
        List<String> list = new ArrayList<String>();
        String zz = "\\\\u[0-9,a-z,A-Z]{4}";
        Pattern pattern = Pattern.compile(zz);
        Matcher m = pattern.matcher(s);
        while (m.find()) {
            list.add(m.group());
        }
        for (int i = 0, j = 2; i < list.size(); i++) {
            String st = list.get(i).substring(j, j + 4);
            char ch = (char) Integer.parseInt(st, 16);
            s = s.replace(list.get(i), String.valueOf(ch));
        }
        return s;
    }

    /**
     * 字符串转Unicode
     *
     * @param s
     * @return
     */
    public static String string2unicode(String s) {
        int in;
        String st = "";
        for (int i = 0; i < s.length(); i++) {
            in = s.codePointAt(i);
            st = st + "\\u" + Integer.toHexString(in).toUpperCase();
        }
        return st;
    }

    /**
     * 获取图片路径中的第一张图片
     *
     * @param s     例如：picture1_picture2_picture3
     * @param spilt 例如： , _ &
     * @return picture1
     */
    public static String getFirstPicture(String s, String spilt) {
        if (isEmpty(s) || s.indexOf(spilt) == -1) {
            return s;
        }
        return s.split(spilt)[0];
    }

    /**
     * 替换字符串中的特殊字符
     *
     * @param s
     * @return
     */
    public static String string2Json(String s) {
        StringBuffer sb = new StringBuffer();
        if(StringUtil.isEmpty(s)){
            return null;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '/':
                    sb.append("\\/");
                    break;
                case '\b':
                    sb.append("\\b");
                    break;
                case '\f':
                    sb.append("\\f");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * 复制到剪切板
     * @param content
     */
    public static void copyString(String content){
        if(isEmpty(content)){
            return;
        }
        ClipboardManager manager = (ClipboardManager) BaseApplication.instance.getSystemService(Context.CLIPBOARD_SERVICE);
        if(manager != null){
            manager.setText(content);
        }
    }
}