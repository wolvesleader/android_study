package com.loonxi.ju53.manager;

import android.content.Context;
import android.os.Environment;

import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.utils.AppUtil;
import com.loonxi.ju53.utils.PackageUtil;

import java.io.File;

/**
 * Created by XuZue on 2016/5/4 0004.
 */
public class FileManager {

    /**
     * 初始化crash文件目录
     *
     * @return
     */
    public static String initCrashFolder() {
        String path = Environment.getExternalStorageDirectory()
                .toString()
                + File.separator
                + "Android"
                + File.separator
                + "data"
                + File.separator
                + BaseApplication.instance.getPackageName()
                + File.separator
                + "crash"
                + File.separator;
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return path;
    }

    /**
     * 初始化img文件目录
     *
     * @return
     */
    public static String initImgFolder() {
        String path = Environment.getExternalStorageDirectory()
                .toString()
                + File.separator
                + "Android"
                + File.separator
                + "data"
                + File.separator
                + BaseApplication.instance.getPackageName()
                + File.separator
                + "img"
                + File.separator;
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return path;
    }

    /**
     * 初始化camera文件目录
     *
     * @return
     */
    public static String initCameraFolder() {
        String path = Environment.getExternalStorageDirectory()
                .getPath()
                + File.separator
                + "DCIM"
                + File.separator
                + "camera"
                + File.separator;
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return path;
    }

    /**
     * 初始化file文件目录
     *
     * @return
     */
    public static String initFileFolder() {
        String path = Environment.getExternalStorageDirectory()
                .toString()
                + File.separator
                + "Android"
                + File.separator
                + "data"
                + File.separator
                + BaseApplication.instance.getPackageName()
                + File.separator
                + "file"
                + File.separator;
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return path;
    }

}
