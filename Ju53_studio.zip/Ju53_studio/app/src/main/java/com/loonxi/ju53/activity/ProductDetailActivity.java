package com.loonxi.ju53.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.SupplierAdapter;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.constants.ProductState;
import com.loonxi.ju53.convert.OrderDataConvert;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.fragment.ProductDetailAttributeFragment;
import com.loonxi.ju53.fragment.ProductDetailPicFragment;
import com.loonxi.ju53.fragment.ProductDetailRecommendFragment;
import com.loonxi.ju53.listener.OnScrollDownListenter;
import com.loonxi.ju53.manager.BroadcastManager;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.presenters.ProductDetailPresenter;
import com.loonxi.ju53.utils.DisplayUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.MD5;
import com.loonxi.ju53.utils.MapUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IProductDetailView;
import com.loonxi.ju53.widgets.DetailTabBar;
import com.loonxi.ju53.widgets.SlideDetailsLayout;
import com.loonxi.ju53.widgets.dialog.CartEditDialog;
import com.loonxi.ju53.widgets.dialog.NetErrorDialog;
import com.loonxi.ju53.widgets.dialog.OnSaleDialog;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.viewpagerindicator.ProductDetailBanner;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * "供应商商品详情"activity
 * Created by Xuzue on 2016/1/11.
 */
public class ProductDetailActivity extends BaseActivity implements IProductDetailView, DetailTabBar.OnDetailTabClickListener,
        View.OnClickListener, OnScrollDownListenter {

    public static String LONG_XI_TAG = "loonxi";
    private static String LONG_XI_SIGN = "sign";
    private final static double BACKGROUND_DISAPPEAR_RATE = 0.5;
    private int TITLE_HIDDEN_LENGTH_ONE;//图标消失距离
    private int TITLE_HIDDEN_LENGTH_TWO;//背景显示距离

    @ViewInject(R.id.product_detail_layout_title)
    private LinearLayout mLayoutTitle;
    @ViewInject(R.id.product_detail_iv_title_back)
    private ImageView mIvBack;
    @ViewInject(R.id.product_detail_tv_title)
    private TextView mTvTitle;
    @ViewInject(R.id.product_detail_iv_cart)
    private ImageView mIvTitleCart;
    @ViewInject(R.id.product_detail_iv_right)
    private ImageView mIvRight;


    @ViewInject(R.id.product_detail_layout_container)
    private SlideDetailsLayout mScroolViewContainer;
    @ViewInject(R.id.product_detail_scrollview_one)
    private ScrollView mScrollViewOne;

    private ProductDetailBanner mCycleViewPager;
    @ViewInject(R.id.product_detail_tv_product_name)
    private TextView mTvName;
    @ViewInject(R.id.product_detail_tv_product_price)
    private TextView mTvPrice;
    @ViewInject(R.id.product_detail_tv_product_referprice)
    private TextView mTvReferPrice;
    @ViewInject(R.id.product_detail_tv_product_postage)
    private TextView mTvPostage;
    @ViewInject(R.id.product_detail_tv_product_sales)
    private TextView mTvSales;
    @ViewInject(R.id.product_detail_tv_product_address)
    private TextView mTvAddress;
    @ViewInject(R.id.product_detail_layout_rules)
    private LinearLayout mLayoutRules;
    @ViewInject(R.id.product_detail_tv_rules)
    private TextView mTvRules;
    @ViewInject(R.id.product_detail_layout_provider)
    private LinearLayout mLayoutProvider;
    @ViewInject(R.id.product_detail_tv_provider)
    private TextView mTvProvider;
    @ViewInject(R.id.product_detail_layout_hascomment)
    private LinearLayout mLayoutHasComment;
    @ViewInject(R.id.product_detail_tv_comment_total)
    private TextView mTvCommentTotal;
    @ViewInject(R.id.product_detail_tv_comment_tel)
    private TextView mTvCommentTel;
    @ViewInject(R.id.product_detail_tv_comment_first)
    private TextView mTvCommentContent;
    @ViewInject(R.id.product_detail_tv_to_recommend)
    private TextView mTvTomore;//继续拖动……
    @ViewInject(R.id.product_detail_btn_to_comments)
    private TextView mBtnToComments;


    @ViewInject(R.id.product_detail_layout_bottom_fav)
    private LinearLayout mLayoutFav;
    @ViewInject(R.id.product_detail_iv_fav)
    private ImageView mIvFav;
    @ViewInject(R.id.product_detail_tv_fav)
    private TextView mTvFav;
    @ViewInject(R.id.product_detail_layout_bottom_addtocart)
    private LinearLayout mLayoutAddtoCart;
    @ViewInject(R.id.product_detail_iv_tocart)
    private ImageView mIvAddtoCart;
    @ViewInject(R.id.product_detail_tv_tocart)
    private TextView mTvAddtoCart;
    @ViewInject(R.id.product_detail_layout_bottom_buy)
    private LinearLayout mLayoutBuy;
    @ViewInject(R.id.product_detail_layout_bottom_agent)
    private LinearLayout mLayoutAgent;
    @ViewInject(R.id.product_detail_dtabbar)
    private DetailTabBar mDetailTabBar;
    @ViewInject(R.id.product_detail_layout_banned)
    private LinearLayout mLayoutBanned;
    @ViewInject(R.id.product_detail_tv_banned)
    private TextView mTvBanned;

    private FragmentTransaction mTransaction;
    private ProductDetailPicFragment mPicFragment;
    private ProductDetailAttributeFragment mAttributeFragment;
    private ProductDetailRecommendFragment mRecommendFragment;

    private ProductDetailPresenter mPresenter;
    private NetErrorDialog mNetErrorDialog;
    private String mProductId = "";

    private String mDataPicDes = "";//图片描述
    private Map<String, String> mDataAttribute = new HashMap<>();//属性描述
    private List<ImageView> mHeadImgs = new ArrayList<>();
    private ProductDetailEntity mDetail;
    private CartEditDialog mCartEditDialog;
    private boolean mDirection = false;//false:向下 true:向上
    private float mLastPosition = 0;//记录上一次滑动距离

    private double mSelectPrice;
    private String mSelectColor = "";
    private String mSelectMula = "";
    private long mSelectStockId = -1;
    private int mNum = 1;
    private int mCurrentDialogType = -1;
    private static final int DIALOG_TYPE_RULE = 1;
    private static final int DIALOG_TYPE_ADDTOCART = 2;
    private static final int DIALOG_TYPE_BUY = 3;

    private SupplierAdapter mRecommendAdapter;
    private List<BaseProductEntity> mRecommends = new ArrayList<>();
    private int mCurrentPage = 1;
    private String mUserId = "";
    private OnSaleDialog mOnSaleDialog;
    private boolean mOnSaleBoth = false;//聚小店、淘宝是否同时上架

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        x.view().inject(this);
        initViews();
        initContent();
        setListener();
    }

    private void initViews() {
        mCycleViewPager = (ProductDetailBanner) getSupportFragmentManager().findFragmentById(R.id.product_detail_fragment_cycleviewpager);
        mCycleViewPager.setScrollable(false);
        mCycleViewPager.setCycle(false);
        mCycleViewPager.getView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int width = DisplayUtil.getScreenWidth(mContext);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, width);
                mCycleViewPager.getView().setLayoutParams(params);
                mCycleViewPager.getView().getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
        mScroolViewContainer.setSource(0);
    }

    private void initContent() {
        initTitleDisappearLength();
        initFragment();
        setFavView(false);
        setAddtocartView(false);
        setBottomBtnView(false);
        mPresenter = new ProductDetailPresenter(this);
        mRecommendAdapter = new SupplierAdapter(mContext, mRecommends);
        mProductId = getIntent().getStringExtra("productId");
        mPresenter.getProductBaseInfo(mProductId);

    }

    /**
     * 初始化 title 消失距离
     */
    private void initTitleDisappearLength() {
        TITLE_HIDDEN_LENGTH_ONE = (int) getResources().getDimension(R.dimen.product_detail_title_disappear_length_one);
        TITLE_HIDDEN_LENGTH_TWO = (int) getResources().getDimension(R.dimen.product_detail_title_disappear_length_two);
    }


    private void setListener() {
        mIvBack.setOnClickListener(this);
        mIvTitleCart.setOnClickListener(this);
        mIvRight.setOnClickListener(this);
        mLayoutRules.setOnClickListener(this);
        mLayoutProvider.setOnClickListener(this);
        mTvCommentTotal.setOnClickListener(this);
        mBtnToComments.setOnClickListener(this);
        mLayoutFav.setOnClickListener(this);
        mLayoutAddtoCart.setOnClickListener(this);
        mLayoutBuy.setOnClickListener(this);
        mLayoutAgent.setOnClickListener(this);
        mDetailTabBar.setOnDetailTabClickListener(this);
        mScroolViewContainer.setOnSlideDetailsListener(new SlideDetailsLayout.OnSlideDetailsListener() {
            @Override
            public void onStatucChanged(SlideDetailsLayout.Status status) {
                switch (status) {
                    case OPEN:
                        onDetailTabShown();
                        break;
                    case CLOSE:
                        onDetailTabHiden();
                        break;
                }
            }
        });
        setScrollViewOneListener();
    }

    private void setScrollViewOneListener() {
        if (mScrollViewOne != null) {
            mScrollViewOne.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                @Override
                public void onScrollChanged() {
                    float scrollY = mScrollViewOne.getScrollY(); //for verticalScrollView
                    float iconAlpha = getIconAlpha(scrollY);
                    float backgroundAlpha = getBackgroundAlpha(scrollY);
                    setDirection(scrollY);
                    setAlphaToIcon(iconAlpha, backgroundAlpha);
                    setAlphaToBackground(backgroundAlpha);
                    changeIconByAlpha(iconAlpha, backgroundAlpha);
                }
            });
        }

    }

    /**
     * 设置方向
     *
     * @param scrollY
     */
    private void setDirection(float scrollY) {
        if (scrollY > mLastPosition) {
            mDirection = false;
            mLastPosition = scrollY;
            return;
        }
        if (scrollY < mLastPosition) {
            mDirection = true;
            mLastPosition = scrollY;
            return;
        }


    }


    /**
     * 根据方向改变Title图标
     *
     * @param iconAlpha
     * @param backgroundAlpha
     */
    private void changeIconByAlpha(float iconAlpha, float backgroundAlpha) {
        //1.向下
        if (!mDirection) {
            if (iconAlpha == 0 && backgroundAlpha > BACKGROUND_DISAPPEAR_RATE) {
                mIvBack.setImageDrawable(getResources().getDrawable(R.drawable.detail_change_back));
                mIvTitleCart.setImageDrawable(getResources().getDrawable(R.drawable.detail_change_cart));
                mIvRight.setImageDrawable(getResources().getDrawable(R.drawable.detail_change_more));
                mIvBack.setAlpha(backgroundAlpha);
                mIvTitleCart.setAlpha(backgroundAlpha);
                mIvRight.setAlpha(backgroundAlpha);
                return;
            }
        }
        //2.向上
        if (mDirection) {
            if (iconAlpha > 0 && backgroundAlpha < BACKGROUND_DISAPPEAR_RATE) {
                mIvBack.setImageDrawable(getResources().getDrawable(R.drawable.detail_back));
                mIvTitleCart.setImageDrawable(getResources().getDrawable(R.drawable.detail_cart_top));
                mIvRight.setImageDrawable(getResources().getDrawable(R.drawable.detail_more));
                mIvBack.setAlpha(iconAlpha);
                mIvTitleCart.setAlpha(iconAlpha);
                mIvRight.setAlpha(iconAlpha);
                return;
            }
        }
    }

    /**
     * 获得背景颜色alpha
     *
     * @param value
     * @return
     */
    private float getBackgroundAlpha(float value) {
        float alpha = value / TITLE_HIDDEN_LENGTH_TWO;
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 1) {
            alpha = 1;
        }
        return alpha;
    }


    /**
     * 获取图标显示alpha
     *
     * @param value
     * @return
     */
    private float getIconAlpha(float value) {
        float alpha = 1 - value / TITLE_HIDDEN_LENGTH_ONE;
        if (alpha < 0) {
            alpha = 0;
        }
        if (alpha > 1) {
            alpha = 1;
        }
        return alpha;
    }

    /**
     * 设置图标透明度
     *
     * @param alpha
     * @param backgroundAlpha
     */
    private void setAlphaToIcon(float alpha, float backgroundAlpha) {
        if (!mDirection) {
            mIvBack.setAlpha(alpha);
            mIvTitleCart.setAlpha(alpha);
            mIvRight.setAlpha(alpha);
            return;
        }
        if (mDirection) {
            mIvBack.setAlpha(backgroundAlpha);
            mIvTitleCart.setAlpha(backgroundAlpha);
            mIvRight.setAlpha(backgroundAlpha);
            return;
        }
    }

    private void setAlphaToBackground(float alpha) {
        LogUtil.mLog().i(alpha + "");
        mLayoutTitle.getBackground().setAlpha((int) (alpha * 255));
    }


    private void initFragment() {
        mTransaction = getSupportFragmentManager().beginTransaction();
        if (mPicFragment != null) {
            mTransaction.remove(mPicFragment);
        }
        if (mAttributeFragment != null) {
            mTransaction.remove(mAttributeFragment);
        }
        if (mRecommendFragment != null) {
            mTransaction.remove(mRecommendFragment);
        }
        mPicFragment = new ProductDetailPicFragment();
        mAttributeFragment = new ProductDetailAttributeFragment();
        mRecommendFragment = new ProductDetailRecommendFragment();
        mTransaction.commitAllowingStateLoss();
    }

    /**
     * 设置图片
     *
     * @param pictureUrl
     */
    private void setCycleViewPager(String pictureUrl) {
        mHeadImgs.clear();
        if (StringUtil.isEmpty(pictureUrl)) {
            return;
        }
        mCycleViewPager.setCycle(false);
        mCycleViewPager.setData(pictureUrl);
    }

    /**
     * 设置“收藏”的可用性
     *
     * @param enable
     */
    private void setFavView(boolean enable) {
        mLayoutFav.setClickable(enable);
        mLayoutFav.setEnabled(enable);
        mIvFav.setEnabled(enable);
        mTvFav.setEnabled(enable);
    }

    /**
     * 设置“加入购物车”的可用性
     *
     * @param enable
     */
    private void setAddtocartView(boolean enable) {
        mLayoutAddtoCart.setClickable(enable);
        mLayoutAddtoCart.setEnabled(enable);
        mIvAddtoCart.setEnabled(enable);
        mTvAddtoCart.setEnabled(enable);
    }

    /**
     * 设置"立刻购买"，"一键上架"的可用性
     *
     * @param enable
     */
    private void setBottomBtnView(boolean enable) {
        mLayoutBuy.setClickable(enable);
        mLayoutAgent.setClickable(enable);
        mLayoutBuy.setEnabled(enable);
        mLayoutAgent.setEnabled(enable);
    }

    /**
     * 设置产品基本信息
     */
    private void setBaseInfo() {
        if (mDetail == null) {
            return;
        }
        mUserId = mDetail.getUserId();
        if (mRecommendFragment != null) {
            Bundle b = new Bundle();
            b.putString("userId", mDetail == null ? "" : mDetail.getUserId());
            mRecommendFragment.setArguments(b);
        }
        String price = "¥" + mDetail.getPrice();
        SpannableString sb = new SpannableString(price);
        sb.setSpan(new AbsoluteSizeSpan(15, true), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new AbsoluteSizeSpan(25, true), 1, price.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        mTvName.setText(mDetail.getProductName());
        mTvPrice.setText(sb);
        mTvReferPrice.setText(getResources().getString(R.string.search_advise) + ": ¥" + mDetail.getMarkPrice());
        mTvPostage.setText(mDetail.getFreight());
        mTvSales.setText(getResources().getString(R.string.sold) + mDetail.getSold() + getResources().getString(R.string.piece));
        mTvAddress.setText(mDetail.getLocateCity());
        mTvProvider.setText(mDetail.getUserName());
        if (mDetail.getCommentNum() == 0) {
            mTvCommentTotal.setText("暂无评价");
            mLayoutHasComment.setVisibility(View.GONE);
        } else {
            mTvCommentTotal.setText(getResources().getString(R.string.comments) + "(" + mDetail.getCommentNum() + ")");
            mLayoutHasComment.setVisibility(View.VISIBLE);
        }
        mTvCommentTel.setText(mDetail.getCommentName());
        mTvCommentContent.setText(mDetail.getCommentContent());

        setFavView(true);
        mIvFav.setEnabled(mDetail.getFollow() == 0 ? true : false);
        mTvFav.setText(getResources().getString(mDetail.getFollow() == 0 ? R.string.is_fav : R.string.fav));

        int top_default = getResources().getDimensionPixelSize(R.dimen.product_tab_detail_height);
        int banned_default = getResources().getDimensionPixelSize(R.dimen.product_bottom_banned);
        if (mDetail.getState() == ProductState.OFF || mDetail.getState() == ProductState.DELETE) {
            mScroolViewContainer.setChildLayoutTop(top_default);
            mScroolViewContainer.setChildLayoutBottom(banned_default);
            mLayoutBanned.setVisibility(View.VISIBLE);
            mLayoutRules.setVisibility(View.GONE);
            mTvTomore.setText(getResources().getString(R.string.product_detail_to_recommend));
            mTvBanned.setText(getResources().getString(mDetail.getState() == ProductState.OFF ?
                    R.string.product_detail_invalid_banned : R.string.product_detail_invalid_outline));
        } else {
            mScroolViewContainer.setChildLayoutTop(2 * top_default);
            mLayoutBanned.setVisibility(View.GONE);
            setAddtocartView(true);
            setBottomBtnView(true);
        }
        if (mDetail.getCycles() == 0) {
//            mLayoutAgent.setEnabled(false);
        }
    }

    @Override
    public void onGetBaseInfoSuccess(JsonInfo<ProductDetailEntity> jsonInfo) {
        if (jsonInfo.getData() == null) {
            return;
        }
        mDetail = jsonInfo.getData();
        setCycleViewPager(mDetail.getPicture());
        setBaseInfo();
    }

    @Override
    public void onGetBaseInfoFailed(int apiErrorCode, String message) {
        showNetErrorDialog();
    }

    @Override
    public void onGetDetailSuccess(JsonInfo<ProductDetailEntity> jsonInfo) {
        LogUtil.mLog().i(jsonInfo.getData());
        mDataPicDes = jsonInfo.getData().getDesc();
        mPicFragment.setDetailPic(mDataPicDes);
        mAttributeFragment.setData(jsonInfo.getData().getProps());
        onTabClick(1);
    }

    @Override
    public void onGetDetailFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onAddToCartSuccess(Object object) {
        showToast(R.string.product_detail_addtocart_success);
    }

    @Override
    public void onAddToCartFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onGetSkuSuccess(View view, CartEntity cart, BaseProductEntity product, ProductAttributeEntity attribute) {
        if (attribute == null) {
            return;
        }
        showEidtDialog(view, product, attribute);
    }

    @Override
    public void onGetSkuFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onFavSuccess(boolean isFav) {
        mDetail.setFollow(isFav ? 1 : 0);
        showToast(isFav ? R.string.fav_cancel_success : R.string.fav_success);
        mIvFav.setEnabled(!isFav);
        mTvFav.setText(getResources().getString(mDetail.getFollow() == 0 ? R.string.is_fav : R.string.fav));
    }

    @Override
    public void onFavFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onGetRecommendSuccess(SupplierEntity supplier) {
        if (mCurrentPage == 1) {
            mRecommends.clear();
        }
        if (supplier != null && !ListUtil.isEmpty(supplier.getList())) {
            mRecommends.addAll(supplier.getList());
        }
        mRecommendAdapter.notifyDataSetChanged();
        mCurrentPage++;
    }

    @Override
    public void onGetRecommendFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onSaleToJuSuccess() {
        showToast(R.string.store_product_on_success);
        BroadcastManager.sendStoreProductChanged(mContext);
        if(mOnSaleBoth){
            onSaleToTaobao();
        }
    }

    @Override
    public void onSaleToJuFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onTabClick(int position) {
        mTransaction = getSupportFragmentManager().beginTransaction();
        if (position == 1) {//图片详情
            if (mRecommendFragment.isAdded()) {
                mTransaction.hide(mRecommendFragment);
            }
            if (mAttributeFragment.isAdded()) {
                mTransaction.hide(mAttributeFragment);
            }
            if (mPicFragment.isAdded()) {
                mTransaction.show(mPicFragment);
            } else {
                mTransaction.add(R.id.product_detail_layout_more_container, mPicFragment, mPicFragment.getClass().getSimpleName());
            }
        } else if (position == 2) {//商品属性
            if (mRecommendFragment.isAdded()) {
                mTransaction.hide(mRecommendFragment);
            }
            if (mPicFragment.isAdded()) {
                mTransaction.hide(mPicFragment);
            }
            if (mAttributeFragment.isAdded()) {
                mTransaction.show(mAttributeFragment);
            } else {
                mTransaction.add(R.id.product_detail_layout_more_container, mAttributeFragment, mAttributeFragment.getClass().getSimpleName());
            }
        } else if (position == 3) {//同店推荐
            if (mPicFragment.isAdded()) {
                mTransaction.hide(mPicFragment);
            }
            if (mAttributeFragment.isAdded()) {
                mTransaction.hide(mAttributeFragment);
            }
            if (mRecommendFragment.isAdded()) {
                mTransaction.show(mRecommendFragment);
            } else {
                mTransaction.add(R.id.product_detail_layout_more_container, mRecommendFragment, mRecommendFragment.getClass().getSimpleName());
            }
        }
        mTransaction.commitAllowingStateLoss();
    }

    @Override
    public void onDetailTabShown() {
        int isBanned = mDetail != null ? mDetail.getState() : 1;
        mTvTitle.setText(isBanned == 1 ? "商品详情" : "同店推荐");
        if (isBanned == ProductState.OFF || isBanned == ProductState.DELETE) {
            onTabClick(3);
        } else {
            mDetailTabBar.setVisibility(View.VISIBLE);
            if (StringUtil.isEmpty(mDataPicDes)) {
                mPresenter.getProductDetailInfo(mProductId);
            }
        }
    }

    @Override
    public void onDetailTabHiden() {
        mDetailTabBar.setVisibility(View.GONE);
        mTvTitle.setText("");
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.product_detail_iv_title_back:
                finish();
                break;
            case R.id.product_detail_iv_cart:
                startActivity(new Intent(mContext, CartActivity.class));
                break;
            case R.id.product_detail_iv_right:
                ActionBarRightPopupWindow.show(mContext, mIvRight, true);
                break;
            case R.id.product_detail_layout_rules:
                mCurrentDialogType = DIALOG_TYPE_RULE;
                selectRules();
                break;
            case R.id.product_detail_layout_provider:
                Intent intent = new Intent(mContext, SupplierActivity.class);
                intent.putExtra("userId", mDetail.getUserId());
                intent.putExtra("userName", mDetail.getUserName());
                startActivity(intent);
                break;
            case R.id.product_detail_btn_to_comments:
                intent = new Intent(mContext, CommentActivity.class);
                intent.putExtra("num", mDetail.getCommentNum());
                intent.putExtra("productId", mDetail.getProductId());
                startActivity(intent);
                break;
            case R.id.product_detail_layout_bottom_fav:
                if (mDetail.getState() == ProductState.DELETE) {
                    showToast(R.string.product_detail_not_fav);
                } else {
                    mPresenter.fav(mDetail.getProductId(), 1, mDetail.getFollow());
                }
                break;
            case R.id.product_detail_layout_bottom_addtocart:
                mCurrentDialogType = DIALOG_TYPE_ADDTOCART;
                selectRules();
                break;
            case R.id.product_detail_layout_bottom_buy:
                if (mSelectStockId == -1) {
                    mCurrentDialogType = DIALOG_TYPE_BUY;
                    selectRules();
                } else {
                    if (!isLogin()) {
                        startActivity(new Intent(mContext, LoginActivity.class));
                        return;
                    }
                    toBuy();
                }
                break;
            case R.id.product_detail_layout_bottom_agent:
                onSale();
                break;
        }
    }

    /**
     * 上架到聚小店
     */
    private void onSaleToJuxiaodian(){
        mPresenter.onSaleToJu(mDetail);
    }

    /**
     * 上架到淘宝
     */
    private void onSaleToTaobao() {
        String url = initUrl();
        String title = getResources().getString(R.string.webview_one_up_title);
        gotoCommonWebView(url, title);
    }

    private void onSale() {
        if (!isLogin()) {
            startActivity(new Intent(mContext, LoginActivity.class));
            return;
        }
        boolean tbEnable = true;
        if (mDetail != null && mDetail.getCycles() == 0) {
            tbEnable = false;
        }
        mOnSaleDialog = new OnSaleDialog(mContext, tbEnable, new OnSaleDialog.OnSaleCheckListener() {
            @Override
            public void checkResult(boolean checkedJu, boolean checkedTb) {
                if (checkedJu && checkedTb) {
                    mOnSaleBoth = true;
                    onSaleToJuxiaodian();
                }else if(checkedJu){
                    onSaleToJuxiaodian();
                }else if(checkedTb){
                    onSaleToTaobao();
                }
            }
        });
        mOnSaleDialog.setDialogAttribute(this, Gravity.BOTTOM);
        mOnSaleDialog.show();
    }


    /**
     * 网络出错
     */
    private void showNetErrorDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || mContext == null) {
                    return;
                }
                mNetErrorDialog = new NetErrorDialog(mContext, ProductDetailActivity.this,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mPresenter.getProductBaseInfo(mProductId);
                                mNetErrorDialog.dismiss();
                            }
                        },
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                finish();
                            }
                        });
                mNetErrorDialog.show();
            }
        });

    }

    /**
     * 规格选择dialog
     *
     * @param view
     * @param attribute
     */
    private void showEidtDialog(final View view, BaseProductEntity product, ProductAttributeEntity attribute) {
        mCartEditDialog = new CartEditDialog(mContext, product, attribute, new CartEditDialog.onCartConfirmListener() {
            public void OnConfirm(double price, String color, String size, long stockId, int count) {
                mCartEditDialog.dismiss();
                if (!isLogin()) {
                    startActivity(new Intent(mContext, LoginActivity.class));
                    return;
                }
                updateDataAfterChangeAttribute(view, price, color, size, stockId, count);
                if (mCurrentDialogType == DIALOG_TYPE_ADDTOCART) {
                    requestAddToCart();
                } else if (mCurrentDialogType == DIALOG_TYPE_BUY) {
                    toBuy();
                }
            }

            @Override
            public void AddtoCart(double price, String color, String size, long stockId, int count) {
                mCartEditDialog.dismiss();
                if (!isLogin()) {
                    startActivity(new Intent(mContext, LoginActivity.class));
                    return;
                }
                updateDataAfterChangeAttribute(view, price, color, size, stockId, count);
                requestAddToCart();
            }

            @Override
            public void Buy(double price, String color, String size, long stockId, int count) {
                mCartEditDialog.dismiss();
                if (!isLogin()) {
                    startActivity(new Intent(mContext, LoginActivity.class));
                    return;
                }
                updateDataAfterChangeAttribute(view, price, color, size, stockId, count);
                toBuy();
            }
        });
        mCartEditDialog.setDialogAttribute(this, Gravity.BOTTOM);
        if (mCurrentDialogType == DIALOG_TYPE_RULE) {
            mCartEditDialog.setLayoutConfirmVisibility(View.GONE);
            mCartEditDialog.setLayoutConfirmTwoVisibility(View.VISIBLE);
        } else {
            mCartEditDialog.setLayoutConfirmVisibility(View.VISIBLE);
            mCartEditDialog.setLayoutConfirmTwoVisibility(View.GONE);
        }
        mCartEditDialog.show();
    }

    /**
     * 更新库存信息
     *
     * @param view
     * @param color
     * @param size
     * @param stockId
     */
    private void updateDataAfterChangeAttribute(View view, double price, String color, String size, long stockId, int count) {
        if (mDetail != null) {
            mDetail.setStokId(stockId);
        }
        mSelectPrice = price;
        mSelectColor = color;
        mSelectMula = size;
        mSelectStockId = stockId;
        mNum = count;
        ((TextView) view).setText("已选:" + color + " " + size);
    }

    /**
     * 购买
     */
    private void toBuy() {
        Intent intent = new Intent(mContext, OrderConfirmActivity.class);
        ArrayList<CartEntity> carts = new ArrayList<>();
        CartEntity cart = OrderDataConvert.detailEntity2CartEntity(mDetail, mNum, mSelectPrice, mSelectColor, mSelectMula);
        carts.add(cart);
        intent.putExtra("freightIds", mDetail.getFreightId() + "");
        intent.putExtra("products", carts);
        startActivity(intent);
    }

    /**
     * 请求加入购物车
     */
    private void requestAddToCart() {
        if (mDetail == null || mPresenter == null) {
            return;
        }
        mPresenter.addToCart(mDetail.getProductId(), mDetail.getUserId(), mSelectColor, mSelectMula, mDetail.getStokId() + "", mNum);
    }

    /**
     * 选择规格
     */
    private void selectRules() {
        CartEntity cartEntity = OrderDataConvert.detailEntity2CartEntity(mDetail, mNum, mSelectPrice, mSelectColor, mSelectMula);
        BaseProductEntity product = new BaseProductEntity();
        product.setProductId(mDetail.getProductId());
        product.setPicture(StringUtil.getFirstPicture(mDetail.getPicture(), ","));
        product.setPrice(mDetail.getPrice());
        product.setAttributeColor(mSelectColor);
        product.setAttributeMula(mSelectMula);
        product.setStock(mDetail.getStock());
        product.setCount(mNum);
        mPresenter.getSku(mTvRules, cartEntity, product);
    }

    private String initUrl() {
        Map<String, Object> map = new TreeMap<>();
        map.put("type", "wap");
        map.put("uploadproduct", mDetail.getProductId());
        map.put("uid", SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, ""));
        String sign = MapUtil.toUrlString(map) + LONG_XI_TAG;

        String partOneString = MapUtil.toUrlString(map);
        String partTwoString = LONG_XI_SIGN + "=" + MD5.getMessageDigest((StringUtil.isEmpty(sign) ? "" : sign).getBytes());

        return ApiConst.OUTER_URL_ROOT + partOneString + "&" + partTwoString;
    }

}
