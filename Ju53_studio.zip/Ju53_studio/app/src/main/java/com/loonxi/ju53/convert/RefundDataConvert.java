package com.loonxi.ju53.convert;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;

/**
 * Created by Xuzue on 2016/2/16.
 */
public class RefundDataConvert {

    public static String reasonCode2String(int code){
        String[] reasons = BaseApplication.instance.getResources().getStringArray(R.array.refund_reason);
        if(reasons == null || reasons.length < code + 1){
            return null;
        }
        return reasons[code];
    }
}
