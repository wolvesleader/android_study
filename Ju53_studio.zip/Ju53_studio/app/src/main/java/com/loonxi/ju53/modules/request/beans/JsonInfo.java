package com.loonxi.ju53.modules.request.beans;

import java.io.Serializable;

/**
 * 返回的包含flag, message, data的json用该类解析
 * Created by Xuzue on 2015/12/16.
 */
public class JsonInfo<T> implements Serializable {
    private int flag;
    private String message;
    private T data;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
