package com.loonxi.ju53.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.Gravity;
import android.view.View;
import android.view.ViewStub;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CartActivity;
import com.loonxi.ju53.activity.LoginActivity;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.activity.OrderConfirmActivity;
import com.loonxi.ju53.adapter.ShoppingAdapter;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.convert.OrderDataConvert;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartCheckEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.listener.OnUpdateCartViewListener;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.presenters.ShoppingPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.Logger;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.NumberUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IShoppingView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.dialog.BtnDialog;
import com.loonxi.ju53.widgets.dialog.CartEditDialog;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * “购物车”fragment
 * Created by Xuzue on 2015/12/17.
 */

@ContentView(R.layout.fragment_shopping)
public class ShoppingFragment extends BaseFragment implements OnUpdateCartViewListener, View.OnClickListener, IShoppingView, OnNetWorkListener, FragmentLifeCircle {

    @ViewInject(R.id.fragment_shopping_layout_data)
    private LinearLayout mLayoutData;
    @ViewInject(R.id.fragment_shopping_stub)
    private ViewStub mStub;
    @ViewInject(R.id.fragment_shopping_actionbar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_shopping_flv)
    private PullToRefreshListView mPlv;
    @ViewInject(R.id.fragment_shopping_layout_bottom)
    private LinearLayout mLayoutBottom;
    @ViewInject(R.id.fragment_shopping_layout_check_all)
    private LinearLayout mLayoutCheckAll;
    @ViewInject(R.id.fragment_shopping_cbx_all)
    private CheckBox mCbxAll;
    @ViewInject(R.id.fragment_shopping_layout_bottom_totalfee)
    private LinearLayout mLayoutBottomInvoice;
    @ViewInject(R.id.fragment_shopping_tv_total_fee)
    private TextView mTvTotalFee;
    @ViewInject(R.id.fragment_shopping_layout_bottom_tofav)
    private LinearLayout mLayoutBottomTofav;
    @ViewInject(R.id.fragment_shopping_tv_to_fav)
    private TextView mTvToFav;
    @ViewInject(R.id.fragment_shopping_layout_bottom_invoice_delete)
    private LinearLayout mLayoutInvoiceDelete;
    @ViewInject(R.id.fragment_shopping_tv_total_nums)
    private TextView mTvTotalNums;

    private ShoppingAdapter mAdapter;
    private ShoppingPresenter mPresenter;
    private ListView mListView;

    private boolean mIsPullDown = true;
    private boolean mIsEditAll = false;
    private CartEditDialog mCartEditDialog;
    private BtnDialog mDeleteDialog;
    private int mProductTotalNums = 0;

    private List<CartEntity> mCarts = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void initView() {
        mActionBar.setTitle(R.string.shopping_title);
        mActionBar.setTitleColor(getResources().getColor(R.color.app_black));
        mActionBar.setTitleClickable(true);
        mActionBar.setRightImageVisibility(View.GONE);
        mActionBar.setRightVisibility(View.VISIBLE);
        mActionBar.setRightTextVisibility(View.VISIBLE);
        mActionBar.setRightTextColor(getResources().getColor(R.color.app_black));
        mActionBar.setRightText(R.string.edit);
        mCbxAll.clearFocus();
        mCbxAll.setClickable(false);
        mListView = mPlv.getRefreshableView();
        mPlv.setEmptyView(getEmptyView(R.string.empty_shopping, AppConst.Empty.CART));
    }

    @Override
    public void initContent() {
        mPresenter = new ShoppingPresenter(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mPresenter == null) {
            mPresenter = new ShoppingPresenter(this);
        }
        if (LoginUtil.isLoginNew() && ListUtil.isEmpty(mPresenter.getCarts())) {
            mPresenter.getCartsData(false);
        }
        updateBottomView();
    }

    @Override
    public void setListener() {
        setOnNetWorkListener(this);
        mActionBar.setOnLeftClickListener(this);
        mActionBar.setOnTitleClickListener(this);
        mActionBar.setOnRightClickListener(this);
        mLayoutCheckAll.setOnClickListener(this);
        mTvToFav.setOnClickListener(this);
        mLayoutInvoiceDelete.setOnClickListener(this);
        mPlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                mIsPullDown = true;
                mPresenter.getCartsData(true);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                mIsPullDown = false;
                mPresenter.getCartsData(true);
            }
        });
    }

    /**
     * 更新底部UI
     */
    public void updateBottomView() {
        int mCheckProductNums = mPresenter.getCheckProductNums();
        double mCheckPrice = mPresenter.getCheckPrice();
        String mCheckProductStockId = mPresenter.getCheckStockId();
        Logger.i("选中：" + mCheckProductNums + " stockId:" + mCheckProductStockId);
        mProductTotalNums = mPresenter.getProductTotalNums();
        if (mProductTotalNums == 0 || mCheckProductNums != mProductTotalNums) {
            mCbxAll.setChecked(false);
        } else {
            mCbxAll.setChecked(true);
        }
        if (mAdapter != null) {
            mAdapter.setIsCheckAll(mCbxAll.isChecked());
        }
        Spanned total = Html.fromHtml("合计：<font color=\"#ee0c00\">¥" + NumberUtil.format2Decimal(mCheckPrice) + "</font>");
        mTvTotalFee.setText(total);
        if (mIsEditAll) {
            mLayoutBottomTofav.setVisibility(View.VISIBLE);
            mLayoutBottomInvoice.setVisibility(View.GONE);
            mTvTotalNums.setText(getResources().getString(R.string.delete) + "(" + mCheckProductNums + ")");
        } else {
            mLayoutBottomTofav.setVisibility(View.GONE);
            mLayoutBottomInvoice.setVisibility(View.VISIBLE);
            mTvTotalNums.setText(getResources().getString(R.string.invoice) + "(" + mCheckProductNums + ")");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                getActivity().finish();
                break;
            case ActionBar.RIGHT_CLICK_ID://全编辑
                if (!ListUtil.isEmpty(mPresenter.getCarts())) {
                    mIsEditAll = !mIsEditAll;
                    mActionBar.setRightText(mIsEditAll ? R.string.finish : R.string.edit);
                    mPresenter.editAll(mIsEditAll);
                    if (mAdapter != null) {
                        mAdapter.setIsEditAll(mIsEditAll);
                        mAdapter.notifyDataSetChanged();
                    }
                    updateBottomView();
                } else {
                    if (ListUtil.isEmpty(mPresenter.getCarts()) && mIsEditAll) {
                        mIsEditAll = !mIsEditAll;
                        mActionBar.setRightText(mIsEditAll ? R.string.finish : R.string.edit);
                        if (mAdapter != null) {
                            mAdapter.setIsEditAll(mIsEditAll);
                            mAdapter.notifyDataSetChanged();
                        }
                        updateBottomView();
                    }
                }
                break;
            case R.id.fragment_shopping_layout_check_all://全选
                mCbxAll.setChecked(mCbxAll.isChecked() ? false : true);
                mPresenter.checkAll(mCbxAll.isChecked());
                if (mAdapter != null) {
                    mAdapter.setIsCheckAll(mCbxAll.isChecked());
                    mAdapter.notifyDataSetChanged();
                }
                updateBottomView();
                break;
            case R.id.fragment_shopping_tv_to_fav://移至收藏夹
                moveToFav();
                break;
            case R.id.fragment_shopping_layout_bottom_invoice_delete://结算/删除
                if (mIsEditAll) {
                    deleteProducts();
                } else {
                    invoice();
                }
                break;
        }
    }

    /**
     * 移至收藏夹
     */
    private void moveToFav() {
        if (ListUtil.isEmpty(mPresenter.getCheckProductList())) {
            showToast(R.string.shopping_check_none);
            return;
        }
        mPresenter.moveToFav(mPresenter.getCheckProductList());
    }

    /**
     * 删除多个产品
     */
    private void deleteProducts() {
        if (ListUtil.isEmpty(mPresenter.getCheckProductList())) {
            showToast(R.string.shopping_check_none);
            return;
        }
        showDeleteDialog();
    }


    /**
     * 删除提示框
     */
    private void showDeleteDialog() {
        mDeleteDialog = new BtnDialog(mContext,
                mContext.getResources().getString(R.string.tip),
                mContext.getResources().getString(R.string.shopping_delete),
                mContext.getResources().getString(R.string.confirm),
                mContext.getResources().getString(R.string.cancel),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDeleteDialog.dismiss();
                        mPresenter.deleteMultiProducts(mPresenter.getCheckProductList());
                    }
                },
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDeleteDialog.dismiss();
                    }
                });
        mDeleteDialog.show();
    }

    /**
     * 结算
     */
    private void invoice() {
        if (ListUtil.isEmpty(mPresenter.getCheckProductList())) {
            showToast(R.string.shopping_check_none);
            return;
        }
        ArrayList<CartEntity> carts = new ArrayList<>();
        OrderDataConvert.checkCartEntity2CartEntity(carts, mPresenter.getCheckProductList());

        Intent intent = new Intent();
        intent.putExtra("isCart", true);
        intent.putExtra("freightIds", mPresenter.getCheckFreightIds());
        intent.putExtra("products", carts);
        intent.setClass(mContext, OrderConfirmActivity.class);
        getActivity().startActivityForResult(intent, CartActivity.REQUEST_CODE_CART_INVOICE);
    }

    /**
     * 购物车编辑dialog
     *
     * @param view
     * @param cart
     * @param product
     * @param attribute
     */
    private void showEidtDialog(final View view, final CartEntity cart, final BaseProductEntity product, ProductAttributeEntity attribute) {
        final boolean productCheck = (product == null || StringUtil.isEmpty(product.getStockid())) ?
                false : mPresenter.getCheckProductMap().get(product.getStockid());
        mCartEditDialog = new CartEditDialog(mContext, product, attribute, new CartEditDialog.onCartConfirmListener() {
            public void OnConfirm(double price, String color, String size, long stockId, int count) {
                String newStockId = String.valueOf(stockId);
                boolean isExist = mPresenter.productIsExist(cart, newStockId);
                if (isExist) {
                    LogUtil.mLog().e("delete " + newStockId);
                    mPresenter.deleteOneProduct(cart, product);
                } else {
                    product.setAttributeColor(color);
                    product.setAttributeMula(size);
                    product.setStockid(newStockId);
                    product.setPrice(price);
                    mPresenter.updateDataAfterAltCartAttribute(cart, product, color, size, productCheck);
                    ((TextView) view).setText(color + " " + size);
                    mPresenter.altCartAttribute(product.getPid() + "", color, size, newStockId, count);
                }
            }

            @Override
            public void AddtoCart(double price, String color, String size, long stockId, int count) {

            }

            @Override
            public void Buy(double price, String color, String size, long stockId, int count) {

            }
        });
        mCartEditDialog.setDialogAttribute(mActivity, Gravity.BOTTOM);
        mCartEditDialog.setLayoutNumVisibility(View.GONE);
        mCartEditDialog.show();
    }

    @Override
    public void onGetCartsSuccess(JsonArrayInfo<CartEntity> carts) {
        if (mPlv == null) {
            return;
        }
        setNetErrorView(mLayoutData, mStub, false);
        mPlv.setVisibility(View.VISIBLE);
        if (mPlv.isRefreshing()) {
            mPlv.onRefreshComplete();
        }
        if (!ListUtil.isEmpty(carts.getData())) {
            mLayoutBottom.setVisibility(View.VISIBLE);
        }
        if (mIsPullDown) {
            mCarts.clear();
            if (!ListUtil.isEmpty(carts.getData())) {
                mCarts.addAll(carts.getData());
            }
            initData(carts.getData());
        }
        if (mAdapter == null) {
            mAdapter = new ShoppingAdapter(mContext, mPresenter.getCarts(), this, mPresenter);
            mAdapter.setIsEditAll(false);
            mAdapter.setIsCheckAll(false);
            mListView.setAdapter(mAdapter);
        }
        mAdapter.notifyDataSetChanged();
        updateBottomView();
    }

    @Override
    public void onGetCartsFailed(int apiErrorCode, String message) {
        if (mPlv == null) {
            return;
        }
        if (mPlv.isRefreshing()) {
            mPlv.onRefreshComplete();
        }
        checkError(apiErrorCode, message, mLayoutData, mStub);
    }

    /**
     * 初始化数据
     *
     * @param carts
     */
    private void initData(List<CartEntity> carts) {
        mPresenter.initData(carts);
        if (mIsEditAll) {
            mIsEditAll = !mIsEditAll;
            mActionBar.setRightText(mIsEditAll ? R.string.finish : R.string.edit);
        }
    }

    /**
     * 错误检查（有视图替换）
     *
     * @param apiErrorCode
     * @param message
     * @param hideView     替换视图
     */
    @Override
    protected void checkError(int apiErrorCode, String message, View hideView, View showView) {
        LogUtil.mLog().i(apiErrorCode);
        switch (apiErrorCode) {
            case ApiError.REQUEST_FAILURE:
                if (hideView != null && showView != null && mNetWorkListener != null) {
                    setNetErrorView(hideView, showView, true);
                } else {
                    showToast(R.string.error_disconnect);
                }
                break;
            case ApiError.TIMEOUT:
                showToast(R.string.error_timeout);
                break;
            case ApiError.REQUEST_FAILURE_OFFLINE:
                if (isAdded()) {
                    gotoLogin();
                }
                break;
            default:
                showToast(message);
                break;

        }
    }


    private void gotoLogin() {
        if (mContext == null) {
            return;
        }
        Intent intent = new Intent(mContext, LoginActivity.class);
//        intent.putExtra(LoginActivity.LOGIN_TYPE, MainActivity.REQUEST_CODE_LOGIN_CART);
//        ((Activity) mContext).startActivityForResult(intent, MainActivity.REQUEST_CODE_LOGIN_CART);
        ((Activity) mContext).startActivity(intent);
    }


    public void onRefresh() {
        if (mPresenter != null) {
            mPresenter.getCartsData(false);
        }
    }

    @Override
    public void onDeleteOneProductSuccess(CartEntity cart, BaseProductEntity product) {
        mPresenter.updateDataAfterDeleteOneProduct(cart, product);
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        updateBottomView();
    }

    @Override
    public void onDeleteOneProductFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onDeleteMultiProductsSuccess(List<CartCheckEntity> carts) {
        mPresenter.updataDataAfterDeleteMultiProducts(carts);
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        updateBottomView();
    }

    @Override
    public void onDeleteMultiProductsFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onUpdateCartSuccess() {
    }

    @Override
    public void onUpdateCartFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onGetSkuSuccess(View view, CartEntity cart, BaseProductEntity product, ProductAttributeEntity attribute) {
        if (attribute != null) {
            showEidtDialog(view, cart, product, attribute);
        }
    }

    @Override
    public void onGetSkuFailed(int apiErorCode, String message) {

    }

    @Override
    public void onMoveToFavSuccess(List<CartCheckEntity> carts) {
        showToast(R.string.shopping_move_success);
        mPresenter.updataDataAfterDeleteMultiProducts(carts);
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        updateBottomView();
    }

    @Override
    public void onMoveToFavFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void OnDisconnected() {

    }

    @Override
    public void OnConnected() {

    }

    @Override
    public void OnRetry() {
        mPresenter.getCartsData(false);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void fragmentPause() {

    }

    @Override
    public void fragmentResume(int position) {
        if (mPresenter == null) {
            mPresenter = new ShoppingPresenter(this);
        }
        if (mPresenter != null) {
            if (LoginUtil.isLoginNew() && ListUtil.isEmpty(mPresenter.getCarts())) {
                mPresenter.getCartsData(false);
            } else {
//                setDataAfterChangeUser();
            }
        }
    }

    /**
     * 切换账号后重新拉取数据
     */
    private void setDataAfterChangeUser() {
        String latestUserId = SpUtil.getString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_CART, "");
        String currentUserId = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, "");
        if (!StringUtil.isEmpty(latestUserId) && !latestUserId.equals(currentUserId)) {
            SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_CART, currentUserId);
            mCarts.clear();
            mPresenter.initData(mCarts);
            mPresenter.getCartsData(false);
        } else if (!ListUtil.isEmpty(mPresenter.getCheckProductList())) {
            mPresenter.initData(mCarts, false);
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        updateBottomView();
    }

    @Override
    public void onNetWorkConnected() {
        super.onNetWorkConnected();
        if (mCarts == null || mCarts.size() == 0) {
            fragmentResume(0);
        }
    }
}
