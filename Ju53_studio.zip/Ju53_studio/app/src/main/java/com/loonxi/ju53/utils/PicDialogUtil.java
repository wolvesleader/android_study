package com.loonxi.ju53.utils;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import java.io.File;

/**
 * 图片上传Dialog工具类
 * Created by Xuze on 2015/9/4.
 */
public class PicDialogUtil {

    /**
     * 当使用IntentUtil.intentToAlbum时在onActivityResult中调用获取结果
     * <ul>
     * <strong>ActivityResult.result返回值</strong>
     * <li><b>ERROR</b>: RequestCode不等于IntentUtil.REQUEST_CODE_ALBUM时返回</li>
     * <li><b>NO_DATA</b>: 参数Intent data
     * 为空或者data.getData()为空或者Cursor为空或者Cursor未找到相关值时返回</li>
     * <li><b>CANCEL</b>:ResultCode不等于Activity.RESULT_OK时返回</li>
     * <li><b>SD_UNAVAILABLE</b>:SD卡不可用时返回</li>
     * <li><b>NO_PERMISSION</b>:没有SD卡读写权限时返回</li>
     * <li><b>SUCCESS</b>:成功获取时返回</li>
     * </ul>
     *
     * @param activity
     * @param requestCode
     * @param resultCode
     * @param data
     * @return
     */
    public static ActivityResult onAlbumResult(Activity activity, int requestCode, int resultCode, Intent data) {
        if (requestCode == IntentUtil.REQUEST_CODE_ALBUM) {
            if (resultCode == Activity.RESULT_OK) {
                if (!FileUtil.isSDCardAvailable()) {
                    return new ActivityResult(Result.SD_UNAVAILABLE, null);
                }
                if (!FileUtil.isHasSDCardPermission(activity)) {
                    return new ActivityResult(Result.NO_PERMISSION, null);
                }
                if (data != null && data.getData() != null) {
                    Uri uri = data.getData();
//                    String path = ImageUtil.getPicPathByUri(activity, uri);
                    String path = ImageUtil.getImageAbsolutePath(activity, uri);
                    Bitmap image = ImageUtil.getBitmapByPath(activity, path);
                    Bundle bundle = new Bundle();
                    bundle.putString(ActivityResult.DATA_PATH, path);
                    bundle.putParcelable(ActivityResult.DATA_IMAGE, image);
                    return new ActivityResult(Result.SUCCESS, bundle);
                }
                return new ActivityResult(Result.NO_DATA, null);
            } else {
                return new ActivityResult(Result.CANCEL, null);
            }
        }
        return new ActivityResult(Result.ERROR, null);
    }

    /**
     * 当使用IntentUtil.intentToCamera时在onActivityResult中调用获取结果
     * <ul>
     * <strong>ActivityResult.result返回值</strong>
     * <li><b>ERROR</b>: RequestCode不等于IntentUtil.REQUEST_CODE_CAMERA时返回</li>
     * <li><b>NO_DATA</b>: 参数Intent data
     * 为空或者data.getData()为空或者Cursor为空或者Cursor未找到相关值时返回</li>
     * <li><b>CANCEL</b>:ResultCode不等于Activity.RESULT_OK时返回</li>
     * <li><b>SD_UNAVAILABLE</b>:SD卡不可用时返回</li>
     * <li><b>NO_PERMISSION</b>:没有SD卡读写权限时返回</li>
     * <li><b>SUCCESS</b>:成功获取时返回</li>
     * </ul>
     *
     * @param activity
     * @param requestCode
     * @param resultCode
     * @param data
     * @param picPath
     * @return
     */
    public static ActivityResult onCameraResult(Activity activity, int requestCode, int resultCode, Intent data, String picPath) {
        if (requestCode == IntentUtil.REQUEST_CODE_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                if (!FileUtil.isSDCardAvailable()) {
                    return new ActivityResult(Result.SD_UNAVAILABLE, null);
                }
                if (!FileUtil.isHasSDCardPermission(activity)) {
                    return new ActivityResult(Result.NO_PERMISSION, null);
                }
                if (StringUtil.isEmpty(picPath)) {
                    return new ActivityResult(Result.NO_DATA, null);
                }
                if (new File(picPath).exists()) {
                    Bitmap image = ImageUtil.getBitmapByPath(activity, picPath);
                    Bundle bundle = new Bundle();
                    bundle.putString(ActivityResult.DATA_PATH, picPath);
                    bundle.putParcelable(ActivityResult.DATA_IMAGE, image);
                    return new ActivityResult(Result.SUCCESS, bundle);
                }
            } else {
                return new ActivityResult(Result.CANCEL, null);
            }
        }
        return new ActivityResult(Result.ERROR, null);
    }

    public static class ActivityResult {
        public static final String DATA_PATH = "_path";
        public static final String DATA_IMAGE = "_image";
        private Result mResult;
        private Bundle mData;

        public ActivityResult(Result result, Bundle data) {
            super();
            mResult = result;
            mData = data;
        }

        public Result getResult() {
            return mResult;
        }

        public void setResult(Result result) {
            mResult = result;
        }

        public Bundle getData() {
            return mData;
        }

        public void setData(Bundle data) {
            mData = data;
        }
    }

    public enum Result {
        ERROR, NO_DATA, CANCEL, SD_UNAVAILABLE, NO_PERMISSION, SUCCESS
    }
}
