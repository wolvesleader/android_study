package com.loonxi.ju53.listener;

/**
 * 监听密码输入dialog
 * Created by Xuzue on 2016/1/25.
 */
public interface OnGridPasswordViewListener {
    void textChanged(String psw);
    void inputFinish(String psw);
}
