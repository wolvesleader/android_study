package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.entity.UserEntity;
import com.loonxi.ju53.models.impl.LoginModel;
import com.loonxi.ju53.models.impl.TestModel;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.presenters.LoginPresenter;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ILoginView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.DeleteEditText;

import org.xutils.view.annotation.ViewInject;

import retrofit.Retrofit;

/**
 * "登入"Activity
 * Created by Xuzue on 2016/1/4.
 */
public class LoginActivity extends ActionBarActivity implements View.OnClickListener, ILoginView {

    public static final String LOGIN_TYPE = "login_type";

    public static final int REQUEST_CODE_LOGIN_MINE = 1001;//购物车
    public static final int REQUEST_CODE_LOGIN_CART = 1002;//“我的”

    public static final int MESSAGE_ACTIVITY_LOGIN_FLAG = 1;//消息
    public static final int DEFAULT_LOGIN = -1;//默认登入

    @ViewInject(R.id.login_tv_name)
    private DeleteEditText mTvName;
    @ViewInject(R.id.login_tv_pswd)
    private DeleteEditText mTvPswd;
    @ViewInject(R.id.login_btn_eye)
    private ToggleButton mBtnEye;
    @ViewInject(R.id.login_btn_login)
    private TextView mBtnLogin;
    @ViewInject(R.id.login_tv_forget_pswd)
    private TextView mTvForgetPswd;
    @ViewInject(R.id.login_btn_regist)
    private TextView mBtnRegist;

    private LoginPresenter mPresenter;
    private TextWatcher mTextWatcher;
    private int mCurrentLoginType = DEFAULT_LOGIN;//记录登入类型

    private static final int REQEST_CODE_REGIST = 1001;

    private LoginModel mLoginModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getLoginFlag();
        LoginUtil.setLoginFlag(false);
    }

    /**
     * 获得登入标志,以此判断下一步的操作
     */
    private void getLoginFlag() {
        mCurrentLoginType = getIntent().getIntExtra(LoginActivity.LOGIN_TYPE, DEFAULT_LOGIN);
    }


    @Override
    public void initView() {
        setTitle(R.string.login_title);
        mBtnLogin.setEnabled(false);
    }

    @Override
    public void initContent() {
        mPresenter = new LoginPresenter(this);
        mLoginModel = new LoginModel();
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        mBtnLogin.setOnClickListener(this);
        mBtnRegist.setOnClickListener(this);
        mTvForgetPswd.setOnClickListener(this);
        mBtnEye.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mTvPswd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    mTvPswd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                if (!StringUtil.isEmpty(mTvPswd.getText().toString())) {
                    mTvPswd.setSelection(mTvPswd.getText().toString().length());
                }
            }
        });
        mTvName.addTextChangedListener(new MyTextWatcher());
        mTvPswd.addTextChangedListener(new MyTextWatcher());

        //TODO 测试
//        mTvName.setText("xuzue");
//        mTvPswd.setText("123456a");

    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    private class MyTextWatcher implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String name = mTvName.getText().toString();
            String pswd = mTvPswd.getText().toString();
            if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(pswd)) {
                mBtnLogin.setEnabled(true);
            } else {
                mBtnLogin.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;
            case R.id.login_btn_regist:
                startActivityForResult(new Intent(mContext, RegisterActivity.class), REQEST_CODE_REGIST);
                break;
            case R.id.login_btn_login:
                mPresenter.login(mTvName.getText().toString(), mTvPswd.getText().toString());
                break;
            case R.id.login_tv_forget_pswd:
                gotoAccountSafeActivity();
                break;
        }

    }

    /**
     * 跳转到 “账户与安全”
     */
    private void gotoAccountSafeActivity(){
        Intent intent=new Intent(this,AccountSafeActivity.class);
        intent.putExtra(AccountSafeActivity.FROM_TYPE,AccountSafeActivity.FROM_LOGIN_ACTIVITY);
        startActivity(intent);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQEST_CODE_REGIST:
                if (resultCode == RESULT_OK) {
                    setResult(RESULT_OK);
                    finish();
                }
                break;
        }
    }

    @Override
    public void onLoginSuccess(UserEntity object) {
        if (object != null) {
            mLoginModel.saveLoginInfo(mContext, object);
            LoginUtil.setLoginFlag(true);
            showToast(R.string.login_success);
            setResult(RESULT_OK);
            gotoNext();
            finish();
        }

    }

    /**
     * 登入成功后跳转到下一个界面
     */
    private void gotoNext() {
        if (mCurrentLoginType == DEFAULT_LOGIN) {
            return;
        }
        if (mCurrentLoginType == MESSAGE_ACTIVITY_LOGIN_FLAG) {
            startActivity(new Intent(this, MessageActivity.class));
            return;
        }
    }

    @Override
    public void onLoginFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message, null, null);
    }

    /**
     * 错误检查（有视图替换）
     *
     * @param apiErrorCode
     * @param message
     * @param hideView     替换视图
     */
    protected void checkError(int apiErrorCode, String message, View hideView, View showView) {
        switch (apiErrorCode) {
            case ApiError.REQUEST_FAILURE:
                if (hideView != null && showView != null && mNetWorkListener != null) {
                    setNetErrorView(hideView, showView, true);
                } else {
                    showToast(R.string.error_disconnect);
                }
                break;
            case ApiError.HTTP:
                showToast(R.string.error_http);
                break;
            case ApiError.TIMEOUT:
                showToast(R.string.error_timeout);
                break;
            case ApiError.REQUEST_FAILURE_OFFLINE:
                showToast(R.string.error_disconnect);
                break;
            default:
                showToast(message);
                break;

        }
    }

    /**
     * 回退一步操作
     */
    private void goBack() {
        finish();
    }


}
