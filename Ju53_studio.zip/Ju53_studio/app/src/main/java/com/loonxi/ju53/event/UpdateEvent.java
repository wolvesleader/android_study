package com.loonxi.ju53.event;

import java.io.Serializable;

/**
 * Created by Xuzue on 2015/12/17.
 */
public class UpdateEvent extends BaseEvent implements Serializable {

}
