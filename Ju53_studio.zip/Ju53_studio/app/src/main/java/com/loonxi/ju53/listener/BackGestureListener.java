package com.loonxi.ju53.listener;

import android.view.GestureDetector;
import android.view.MotionEvent;

import com.loonxi.ju53.base.BaseActivity;

/**
 * 手势监听器
 * Created by Xuzue on 2015/12/17.
 */
public class BackGestureListener implements GestureDetector.OnGestureListener {

    private BaseActivity activity;

    public BackGestureListener(BaseActivity activity){
        this.activity = activity;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        if((e2.getX() - e1.getX()) > 150 || Math.abs(e1.getY() - e2.getY()) < 80){
            activity.finish();
            return true;
        }
        return false;
    }
}
