package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.OrderConfirmAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.FreightRule;
import com.loonxi.ju53.entity.OrderCreateEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderFreightEntity;
import com.loonxi.ju53.entity.PaySuccessEntity;
import com.loonxi.ju53.listener.AlipayListener;
import com.loonxi.ju53.manager.AlipayManager;
import com.loonxi.ju53.presenters.OrderConfirmPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IOrderConfirmView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.dialog.BtnDialog;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class OrderConfirmActivity extends ActionBarActivity implements View.OnClickListener, IOrderConfirmView, AlipayListener {

    @ViewInject(R.id.order_confirm_slv)
    private ScrollView mSlv;
    @ViewInject(R.id.order_confirm_layout_personal_info)
    private LinearLayout mLayoutPersonalInfo;
    @ViewInject(R.id.order_confirm_tv_name)
    private TextView mTvPersonName;
    @ViewInject(R.id.order_confirm_tv_tel)
    private TextView mTvPersonTel;
    @ViewInject(R.id.order_confirm_tv_address)
    private TextView mTvPersonAddress;
    @ViewInject(R.id.order_confirm_layout_personal_info_empty)
    private LinearLayout mLayoutPersonalInfoEmpty;
    @ViewInject(R.id.order_confirm_flv)
    private FixedListView mFlv;
    @ViewInject(R.id.order_confirm_layout_discount)
    private LinearLayout mLayoutDiscount;
    @ViewInject(R.id.order_confirm_tv_discount)
    private TextView mTvDiscount;
    @ViewInject(R.id.order_confirm_layout_pay_ali)
    private LinearLayout mLayoutPayAli;
    @ViewInject(R.id.order_confirm_cbx_alipay)
    private CheckBox mCbxAli;
    @ViewInject(R.id.order_confirm_layout_pay_weixin)
    private LinearLayout mLayoutPayWeixin;
    @ViewInject(R.id.order_confirm_cbx_weixin)
    private CheckBox mCbxWeixin;
    @ViewInject(R.id.order_confirm_layout_bottom)
    private LinearLayout mLayoutBottom;
    @ViewInject(R.id.order_confirm_tv_total)
    private TextView mTvTotal;
    @ViewInject(R.id.order_confirm_layout_confirm)
    private LinearLayout mLayoutConfirm;

    private BtnDialog mBtnDialog;

    public static String GET_ADDRESS_ENTITY = "get_address_entity";
    public static final int REQUEST_GET_ADDRESS_ENTITY = 1; //获得地址信息Request
    private AddressEntity mAddressEntity;//地址entity
    private OrderConfirmPresenter mPresenter;
    private OrderConfirmAdapter mAdapter;
    private ArrayList<CartEntity> mCarts = new ArrayList<>();

    private String mFreightIds = "";
    private boolean mIsCart = false;

    private OrderCreateEntity mOrderCreateEntity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirm);
    }

    @Override
    public void initView() {
        setTitle(R.string.order_confirm_title);
        setBackgroundColorResource(R.color.app_bg);
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mPresenter = new OrderConfirmPresenter(this);

        //        Bundle b = getIntent().getExtras();
        //        if(b != null){
        //            mIsCart = b.getBoolean("isCart", false);
        //            mFreightIds = b.getString("freightIds", "");
        //            ArrayList<CartEntity> carts = (ArrayList<CartEntity>) b.getSerializable("products");
        //            mCarts.clear();
        //            if (!ListUtil.isEmpty(carts)) {
        //                mCarts.addAll(carts);
        //            }
        //            for(int i = 0; i < mCarts.size(); i++){
        //                if(!(mCarts.get(i) instanceof CartEntity)){
        //                    mCarts.remove(i);
        //                }
        //            }
        //        }

        mIsCart = getIntent().getBooleanExtra("isCart", false);
        mFreightIds = getIntent().getStringExtra("freightIds");
        ArrayList<CartEntity> carts = (ArrayList<CartEntity>) getIntent().getSerializableExtra("products");
        mCarts.clear();
        if (!ListUtil.isEmpty(carts)) {
            mCarts.addAll(carts);
        }
        for (int i = 0; i < mCarts.size(); i++) {
            if (!(mCarts.get(i) instanceof CartEntity)) {
                mCarts.remove(i);
            }
        }

        mPresenter.getDefaultAddress(false);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mLayoutConfirm.setOnClickListener(this);
        mLayoutPersonalInfo.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
            case R.id.order_confirm_layout_confirm:
                if (ListUtil.isEmpty(mCarts)) {
                    return;
                }
                setNotes();
                mPresenter.createOrder(mCarts, mAddressEntity, mIsCart, mCarts.size() > 1 ? true : false, getRegionId());
                break;
            case R.id.order_confirm_layout_personal_info:
                gotoSelectAddress();
                break;
        }
    }

    private void setNotes() {
        for (int i = 0; i < mFlv.getChildCount(); i++) {
            OrderConfirmAdapter.ViewHolder holder = (OrderConfirmAdapter.ViewHolder) mFlv.getChildAt(i).getTag();
            if (holder != null && holder.mTvNotes != null) {
                String notes = holder.mTvNotes.getText().toString();
                if (mCarts != null && mCarts.size() >= i + 1) {
                    mCarts.get(i).setNotes(StringUtil.isEmpty(notes) ? "" : notes);
                }
            }
        }

    }


    /**
     * 跳转到地址选择activity
     */
    private void gotoSelectAddress() {
        Intent intent = new Intent(this, AddressActivity.class);
        intent.putExtra(AddressActivity.FROM_FLAG, AddressActivity.ORDER_GET_ADDRESS);
        startActivityForResult(intent, REQUEST_GET_ADDRESS_ENTITY);
    }

    private void setViewEnable(boolean enable) {
        mSlv.setVisibility(enable ? View.VISIBLE : View.GONE);
        mLayoutBottom.setVisibility(enable ? View.VISIBLE : View.GONE);
    }


    /**
     * 获取运费模板
     */
    private void getFrightRule() {
        if (mAddressEntity != null && mPresenter != null) {
            int isOversea = mAddressEntity.getIsOverseas();
            String regionId = mAddressEntity.getRegionId();
            if (isOversea == 0 && !StringUtil.isEmpty(regionId)) {
                regionId = regionId.substring(0, 2);
            }
            mPresenter.getFreightRule(mFreightIds, regionId);
        }
    }

    /**
     * 请求获取订单运费
     */
    private void getOrdersFreight() {
        if (mAddressEntity != null && mPresenter != null) {
            String regionId = getRegionId();
            mPresenter.getOrderFreight(regionId, mCarts);
        }
    }

    /**
     * 获取region
     * @return
     */
    private String getRegionId() {
        if (mAddressEntity == null) {
            return null;
        }
        int isOversea = mAddressEntity.getIsOverseas();
        String regionId = mAddressEntity.getRegionId();
        if (isOversea == 0 && !StringUtil.isEmpty(regionId)) {
            regionId = regionId.substring(0, 2);
        }
        return regionId;
    }

    @Override
    public void onGetDefaultAddressSuccess(AddressEntity addressEntity) {
        mAddressEntity = addressEntity;
        setPersonInfo();
//        getFrightRule();
        getOrdersFreight();
    }

    @Override
    public void onGetDefaultAddressFailed(int apiErrorCode, String message) {
        if (!StringUtil.isEmpty(message) && message.contains("没有默认地址")) {
            showAddressEmptyDialog(message);
        } else {
            checkError(apiErrorCode, message);
        }

    }

    @Override
    public void onCreateOrderSuccess(OrderCreateEntity entity) {
        mOrderCreateEntity = entity;
        String data = entity.getData();
        new AlipayManager().pay(this, data, this);
    }

    @Override
    public void onCreateOrderFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void onGetFreightRuleSuccess(List<FreightRule> rules) {
        setViewEnable(true);
        mPresenter.updateDataAfterGetFreight(mCarts, rules);
        if (mAdapter == null) {
            mAdapter = new OrderConfirmAdapter(mContext, mCarts);
            mFlv.setAdapter(mAdapter);
        }
        mAdapter.notifyDataSetChanged();
        updateBottom();
    }

    @Override
    public void onGetFreightRuleFailed(int apiErrorCode, String message) {
        if (!StringUtil.isEmpty(message) && message.contains("请新建")) {
            showAddressEmptyDialog(message);
        } else {
            checkError(apiErrorCode, message);
        }
    }

    @Override
    public void onGetSupplierFreightSuccess(List<OrderFreightEntity> results) {
        setViewEnable(true);
        mPresenter.updateDataAfterGetFreights(mCarts, results);
        if (mAdapter == null) {
            mAdapter = new OrderConfirmAdapter(mContext, mCarts);
            mFlv.setAdapter(mAdapter);
        }
        mAdapter.notifyDataSetChanged();
        updateBottom();
    }

    @Override
    public void onGetSupplierFrgightFailed(int apiErrorCode, String message) {
        LogUtil.mLog().i("onGetSupplierFrgightFailed");
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    private void updateBottom() {
        Spanned total = Html.fromHtml("共" + mPresenter.getTotalCount(mCarts) + "件商品 合计: <font color=\"#ee0c00\">¥" + mPresenter.getTotalFee(mCarts) + "</font>");
        mTvTotal.setText(total);
    }

    @Override
    public void onAlipaySuccess(double payMoney, String orderId) {
        showToast(R.string.pay_success);
        toNext(MyOrderActivity.ORDER_DFH_INDEX);
    }

    @Override
    public void onAlipayCancel() {
        showToast(R.string.pay_cancel);
        backToSource();
    }

    @Override
    public void onAlipayFailed() {
        showToast(R.string.pay_failed);
        backToSource();
    }

    @Override
    public void onAlipayConfirming() {
        showToast(R.string.pay_confirming);
    }

    /**
     * 去订单详情页面
     */
    private void toOrderDetail() {
        Intent intent = new Intent(mContext, OrderDetailActivity.class);
        OrderEntity order = new OrderEntity();
        order.setOrderId((mOrderCreateEntity == null || ListUtil.isEmpty(mOrderCreateEntity.getOrderIdList())) ?
                "" : mOrderCreateEntity.getOrderIdList().get(0).getOrdno());
        intent.putExtra("order", order);
        startActivity(intent);
        finish();
    }

    /**
     * 回到来源页
     */
    private void backToSource() {
        finish();
    }

    /**
     * 去新的页面
     *
     * @param type
     */
    private void toNext(int type) {
//        if (mIsCart) {
//            toMyOrder(type);
//        } else {
//            toOrderDetail();
//        }
        toPaySuccess();
    }

    /**
     * 去“支付成功”页面
     */
    private void toPaySuccess() {
        if (mIsCart) {
            setResult(RESULT_OK);
        }
        PaySuccessEntity paySuccessEntity = new PaySuccessEntity();
        if (mAddressEntity != null) {
            String orderId = (mOrderCreateEntity == null || ListUtil.isEmpty(mOrderCreateEntity.getOrderIdList())) ?
                    "" : mOrderCreateEntity.getOrderIdList().get(0).getOrdno();
            paySuccessEntity.setName(mAddressEntity.getContact());
            paySuccessEntity.setTel(mAddressEntity.getPhones());
            paySuccessEntity.setAddress(mAddressEntity.getCompleteAddress());
            paySuccessEntity.setMoney(mPresenter == null ? "0.00" : mPresenter.getTotalFee(mCarts) + "");
            paySuccessEntity.setOrderId(orderId);
        }
        Intent intent = new Intent(mContext, OrderPaySuccessActivity.class);
        intent.putExtra("successEntity", paySuccessEntity);
        startActivity(intent);
        finish();
    }

    /**
     * 去“我的订单”
     */
    private void toMyOrder(int type) {
        setResult(RESULT_OK);
        Intent intent = new Intent(mContext, MyOrderActivity.class);
        intent.putExtra(MyOrderActivity.FIRST_DISPLAY_FRAGMENT_FLAG, type);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_GET_ADDRESS_ENTITY:
                if (resultCode == RESULT_OK) {
                    if (data != null) {
                        if (mBtnDialog != null && mBtnDialog.isShowing()) {
                            mBtnDialog.dismiss();
                        }
                        Bundle bundle = data.getExtras();
                        mAddressEntity = bundle.getParcelable(GET_ADDRESS_ENTITY);
                    }
                    setPersonInfo();
//                    getFrightRule();
                    getOrdersFreight();
                }
                break;
        }
    }

    /**
     * 设置个人信息
     */
    private void setPersonInfo() {
        if (mAddressEntity != null) {
            mLayoutPersonalInfo.setVisibility(View.VISIBLE);
            mLayoutPersonalInfoEmpty.setVisibility(View.GONE);
            mTvPersonName.setText(getResources().getString(R.string.order_confirm_title_name) + mAddressEntity.getContact());
            mTvPersonTel.setText(mAddressEntity.getPhones());
            mTvPersonAddress.setText(getResources().getString(R.string.order_confirm_title_address) + mAddressEntity.getCompleteAddress());
        } else {
            mLayoutPersonalInfo.setVisibility(View.GONE);
            mLayoutPersonalInfoEmpty.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 无默认收货地址提示
     *
     * @param message
     */
    private void showAddressEmptyDialog(String message) {
        mBtnDialog = new BtnDialog(mContext, "", message, "", "",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //                        mBtnDialog.dismiss();
                        gotoSelectAddress();
                    }
                },
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mBtnDialog.dismiss();
                        finish();
                    }
                });
        mBtnDialog.setCancelable(false);
        mBtnDialog.show();
    }
}
