package com.loonxi.ju53.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 分类
 * Created by Xuzue on 2015/12/24.
 */
public class SortEntity implements Serializable {
    private long pid;
    private long parentId;
    private String categoryId;
    private String name;
    private String url;
    private String imgUrl;
    private String sort;
    private List<SortEntity> list;

    public long getPid() {
        return pid;
    }

    public void setId(int id) {
        this.pid = id;
    }

    public long getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public List<SortEntity> getList() {
        return list;
    }

    public void setList(List<SortEntity> list) {
        this.list = list;
    }
}
