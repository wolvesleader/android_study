package com.loonxi.ju53.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.MessageListAdapter;
import com.loonxi.ju53.base.BaseSafeActivity;
import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.MessageEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.presenters.MessagePresenter;
import com.loonxi.ju53.utils.InterflowUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.IMessageView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshListView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * “消息”activity
 * Created by laojiaqi on 2016/2/2.
 */
public class MessageActivity extends BaseSafeActivity<IMessageView, MessagePresenter> implements IMessageView, View.OnClickListener {

    @ViewInject(R.id.message_action_bar)
    ActionBar mActionBar;
    @ViewInject(R.id.message_pull_to_refresh)
    PullToRefreshListView mListView;
    @ViewInject(R.id.message_empty)
    LinearLayout mEmptyView;
    List<MessageEntity> mMessageList;
    MessageListAdapter mMessageListAdpater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        x.view().inject(this);
        initView();
        setListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initContent();
    }

    private void initView() {
        mActionBar.setTitle(R.string.message_action_bar_title);
    }

    private void initContent() {
        mPresenter.getMessage();
        mMessageList = new ArrayList<MessageEntity>();
        mMessageListAdpater = new MessageListAdapter(mContext, mMessageList);
        mListView.setAdapter(mMessageListAdpater);
    }

    private void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onRefresh(PullToRefreshBase<ListView> refreshView) {
                if (mPresenter != null) {
                    mPresenter.getMessage();
                }
            }
        });
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MessageEntity messageEntity = (MessageEntity) (parent.getAdapter().getItem(position));
                gotoDetailInfo(messageEntity);
            }
        });


    }

    /**
     * 跳转到详情(订单或者物流)
     *
     * @param messageEntity
     */
    private void gotoDetailInfo(MessageEntity messageEntity) {
        if (messageEntity == null || mPresenter == null || mContext == null) {
            return;
        }
        //1.判断是否已读
        if (messageEntity.getStatus() == MessageListAdapter.UNREAD) {
            mPresenter.setReadFlag(messageEntity);
        }
        //2.交易助手
        if (messageEntity.getType() == MessageListAdapter.TRADE) {
            gotoOrderDetailActivity(messageEntity);
        }
        //3.物流信息
        if (messageEntity.getType() == MessageListAdapter.LOGISTICS) {
            mPresenter.getOrderTrans(messageEntity);
        }

    }


    private void gotoOrderDetailActivity(MessageEntity messageEntity) {
        if (!TextUtils.isEmpty(messageEntity.getJointId())) {
            int order_cate = messageEntity.getOrder_cate();
            if (order_cate == 1) {//进货
                OrderEntity orderEntity = new OrderEntity();
                orderEntity.setOrderId(messageEntity.getJointId());
                Intent intent = new Intent(mContext, OrderDetailActivity.class);
                intent.putExtra("order", orderEntity);
                startActivity(intent);
            } else if (order_cate == 2) {//分销
                Intent intent = new Intent(mContext, SaleOrderDetailActivity.class);
                intent.putExtra("orderId", messageEntity.getJointId());
                startActivity(intent);
            }

        }
    }


    @Override
    protected MessagePresenter createPresenter(IMessageView iMessageView) {
        return new MessagePresenter(this);
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
        }
    }

    @Override
    public void getMessageSuccess(List<MessageEntity> messageEntityList) {
        mListView.onRefreshComplete();
        if (messageEntityList == null || messageEntityList.size() == 0) {
            setEmptyView();
            return;
        }
        mMessageList.clear();
        mMessageList.addAll(messageEntityList);
        mMessageListAdpater.notifyDataSetChanged();
        mActionBar.setTitle(getTitle(messageEntityList.size()));
    }


    private void setEmptyView() {
        mEmptyView.setVisibility(View.VISIBLE);
        mListView.setVisibility(View.GONE);
        mActionBar.setTitle("消息");
    }

    private String getTitle(int size) {
        String temp = getString(R.string.message_action_bar_title);
        String title = temp + "(" + size + ")";
        return title;
    }


    @Override
    public void getMessageFailure(int code, String message) {
        mListView.onRefreshComplete();
        if (code == ApiError.REQUEST_FAILURE_OFFLINE && mContext != null) {
            LoginUtil.gotoLogin(mContext, LoginActivity.MESSAGE_ACTIVITY_LOGIN_FLAG);
            ((Activity) mContext).finish();
        } else {
            setEmptyView();
            if (!TextUtils.isEmpty(message) && code != ApiError.REQUEST_FAILURE) {
                ToastUtil.showShortToast(message);
            }
        }
    }

    @Override
    public void getTransOrderSuccess(LogisticsEntity logisticsEntity) {
        InterflowUtil.gotoInterflowActivity(mContext, logisticsEntity);
    }

    @Override
    public void getTransOrderFailure(int code, String message) {
        ToastUtil.showShortToast(message);
    }


    /**
     * 跳转到当前activity
     *
     * @param context
     */
    public static void gotoMessageActivity(Context context) {
        if (context == null) {
            return;
        }
        if (LoginUtil.isLoginNew()) {
            Intent intent = new Intent(context, MessageActivity.class);
            context.startActivity(intent);
        } else {
            LoginUtil.gotoLogin(context, LoginActivity.MESSAGE_ACTIVITY_LOGIN_FLAG);
        }
    }
}
