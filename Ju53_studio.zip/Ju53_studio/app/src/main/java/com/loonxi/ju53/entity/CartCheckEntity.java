package com.loonxi.ju53.entity;

import java.io.Serializable;


/**
 * 购物车中选中的产品（带supperId）
 * Created by Xuzue on 2016/1/22.
 */
public class CartCheckEntity extends BaseProductEntity implements Serializable {
    private String supperId;
    private String companyName;
    private double totalFee;

    public CartCheckEntity() {
        super();
    }

    public String getSupperId() {
        return supperId;
    }

    public void setSupperId(String supperId) {
        this.supperId = supperId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public double getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(double totalFee) {
        this.totalFee = totalFee;
    }

    public boolean copy(BaseProductEntity baseProductEntity) {
        if (baseProductEntity == null) {
            return false;
        }
        setPid(baseProductEntity.getPid());
        setProductId(baseProductEntity.getProductId());
        setProductName(baseProductEntity.getProductName());
        setPrice(baseProductEntity.getPrice());
        setMarkPrice(baseProductEntity.getMarkPrice());
        setPicture(baseProductEntity.getPicture());
        setSold(baseProductEntity.getSold());
        setCount(baseProductEntity.getCount());
        setAttributeColor(baseProductEntity.getAttributeColor());
        setAttributeMula(baseProductEntity.getAttributeMula());
        setModified(baseProductEntity.getModified());
        setCreated(baseProductEntity.getCreated());
        setStock(baseProductEntity.getStock());
        setStockid(baseProductEntity.getStockid());
        setFreight(baseProductEntity.getFreight());
        setFreightId(baseProductEntity.getFreightId());
        setFollow(baseProductEntity.getFollow());
        setState(baseProductEntity.getState());
        setWeight(baseProductEntity.getWeight());
        return true;

    }
}
