package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.BaseProductEntity;

import java.util.List;

/**
 * Created by Xuzue on 2016/3/3.
 */
public interface IProductDetailRecommendView extends IBaseView{
    void onGetRecommendSuccess(List<BaseProductEntity> products);
    void onGetRecommendFailed(int apiErrorCode, String message);
}
