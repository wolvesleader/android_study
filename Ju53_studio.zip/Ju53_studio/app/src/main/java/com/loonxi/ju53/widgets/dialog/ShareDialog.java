package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseApplication;
import com.loonxi.ju53.listener.UmengAuthListener;
import com.loonxi.ju53.listener.UmengShareListener;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;

import java.util.Map;

/**
 * Created by Xuzue on 2016/4/5.
 */
public class ShareDialog extends Dialog implements View.OnClickListener {

    private LinearLayout mLayoutSina;
    private LinearLayout mLayoutWeixin;
    private LinearLayout mLayoutWXLine;
    private LinearLayout mLayoutQQ;
    private LinearLayout mLayoutQzone;
    private LinearLayout mLayoutSms;
    private LinearLayout mLayoutTweibo;
    private LinearLayout mLayoutCopy;
    private TextView mTvCancel;

    private Context mContext;
    private UMShareAPI mShareAPI;
    private UmengShareListener umengShareListener;
    private UmengAuthListener umengAuthListener;

    private String mTitle;
    private String mContent;
    private String mTargetUrl;
    private String mImgUrl;
    private UMImage mImage;

    private String mTitleWechat;
    private String mContentWechat;
    private String mTitleWeline;
    private String mContentWeline;


    public ShareDialog(Context context) {
        super(context, R.style.cartdialog_style);
        init(context);
    }

    public ShareDialog(Context context, String title, String content) {
        this(context, title, content, null);
    }

    public ShareDialog(Context context, String title, String content, String imgUrl) {
        this(context, title, content, imgUrl, null);
    }

    public ShareDialog(Context context, String title, String content, String imgUrl, String targetUrl) {
        super(context, R.style.cartdialog_style);
        init(context);
        mTitle = title;
        mContent = content;
        mImgUrl = imgUrl;
        mTargetUrl = targetUrl;
        if (!StringUtil.isEmpty(mImgUrl)) {
            mImage = new UMImage(mContext, mImgUrl);
        }
    }

    private void init(Context context) {
        if (context == null) {
            return;
        }
        mContext = context;
        setContentView(R.layout.dialog_share);
        setCancelable(true);
        initView();
        initContent();
        setListener();
    }

    private void initView() {
        mLayoutSina = (LinearLayout) findViewById(R.id.dialog_share_layout_sina);
        mLayoutWeixin = (LinearLayout) findViewById(R.id.dialog_share_layout_weixin);
        mLayoutWXLine = (LinearLayout) findViewById(R.id.dialog_share_layout_wxcircle);
        mLayoutQQ = (LinearLayout) findViewById(R.id.dialog_share_layout_qq);
        mLayoutQzone = (LinearLayout) findViewById(R.id.dialog_share_layout_qzone);
        mLayoutTweibo = (LinearLayout) findViewById(R.id.dialog_share_layout_tweibo);
        mLayoutSms = (LinearLayout) findViewById(R.id.dialog_share_layout_sms);
        mLayoutCopy = (LinearLayout) findViewById(R.id.dialog_share_layout_copy);
        mTvCancel = (TextView) findViewById(R.id.dialog_share_tv_cancle);
    }

    private void initContent() {
        mShareAPI = UMShareAPI.get(mContext);
        umengShareListener = new UmengShareListener();
        umengAuthListener = new UmengAuthListener();
    }

    private void setListener() {
        mLayoutSina.setOnClickListener(this);
        mLayoutWeixin.setOnClickListener(this);
        mLayoutWXLine.setOnClickListener(this);
        mLayoutQQ.setOnClickListener(this);
        mLayoutQzone.setOnClickListener(this);
        mLayoutTweibo.setOnClickListener(this);
        mLayoutSms.setOnClickListener(this);
        mLayoutCopy.setOnClickListener(this);
        mTvCancel.setOnClickListener(this);
    }


    /**
     * 设置微信分享内容
     *
     * @param title
     * @param content
     */
    public void setWechatShareContent(String title, String content) {
        mTitleWechat = title;
        mContentWechat = content;
    }

    /**
     * 设置微信朋友圈分享内容
     *
     * @param title
     * @param content
     */
    public void setWelineShareContent(String title, String content) {
        mTitleWeline = title;
        mContentWeline = content;
    }

    public void setDialogAttribute(Activity activity, int gravity) {
        if (activity == null) {
            return;
        }
        Display display = activity.getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = (int) display.getWidth();
        lp.gravity = gravity;
        getWindow().setAttributes(lp);
    }

    @Override
    public void onClick(View v) {
        if (mContext == null) {
            return;
        }
        switch (v.getId()) {
            case R.id.dialog_share_layout_sina:
                if (!mShareAPI.isAuthorize((Activity) mContext, SHARE_MEDIA.SINA)) {
                    mShareAPI.doOauthVerify((Activity) mContext, SHARE_MEDIA.SINA, new UMAuthListener() {
                        @Override
                        public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {
                            shareToSina();
                        }

                        @Override
                        public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
                            Toast.makeText(BaseApplication.instance, "授权失败" + throwable.getMessage(), Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onCancel(SHARE_MEDIA share_media, int i) {
                            Toast.makeText(BaseApplication.instance, "授权取消", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    shareToSina();
                }
                break;
            case R.id.dialog_share_layout_weixin:
                new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.WEIXIN).setCallback(umengShareListener)
                        .withTitle(StringUtil.isEmpty(mTitle) ? "" : mTitle)
                        .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                        .withTargetUrl(StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl)
                        .withMedia(mImage)
                        .share();
                break;
            case R.id.dialog_share_layout_wxcircle:
                new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE).setCallback(umengShareListener)
                        .withTitle(StringUtil.isEmpty(mContent) ? "" : mContent)
                        .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                        .withTargetUrl(StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl)
                        .withMedia(mImage)
                        .share();
                break;
            case R.id.dialog_share_layout_qq:
                new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.QQ).setCallback(umengShareListener)
                        .withTitle(StringUtil.isEmpty(mTitle) ? "" : mTitle)
                        .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                        .withTargetUrl(StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl)
                        .withMedia(mImage)
                        .share();
                break;
            case R.id.dialog_share_layout_qzone:
                new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.QZONE).setCallback(umengShareListener)
                        .withTitle(StringUtil.isEmpty(mTitle) ? "" : mTitle)
                        .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                        .withTargetUrl(StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl)
                        .withMedia(mImage)
                        .share();
                break;
            case R.id.dialog_share_layout_sms:
                new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.SMS).setCallback(umengShareListener)
                        .withTitle(StringUtil.isEmpty(mTitle) ? "" : mTitle)
                        .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                        .share();
                break;
            case R.id.dialog_share_layout_tweibo:
                mShareAPI.doOauthVerify((Activity) mContext, SHARE_MEDIA.TENCENT, new UMAuthListener() {
                    @Override
                    public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {
                        shareToTencentWeibo();
                    }

                    @Override
                    public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
                        Toast.makeText(BaseApplication.instance, "授权失败", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancel(SHARE_MEDIA share_media, int i) {
                        Toast.makeText(BaseApplication.instance, "授权取消", Toast.LENGTH_SHORT).show();
                    }
                });
                break;
            case R.id.dialog_share_layout_copy:
                String title = StringUtil.isEmpty(mTitle) ? "" : mTitle;
                String content = StringUtil.isEmpty(mContent) ? "" : mContent;
                String targetUrl = StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl;
                StringUtil.copyString(title + content + "\n" + targetUrl);
                ToastUtil.showShortToast("成功复制到剪贴板");
                break;
            case R.id.dialog_share_tv_cancle:
                dismiss();
                break;
        }
    }

    /**
     * 新浪微博分享
     */
    private void shareToSina() {
        new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.SINA).setCallback(umengShareListener)
                .withTitle(StringUtil.isEmpty(mTitle) ? "" : mTitle)
                .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                .withTargetUrl(StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl)
                .withMedia(mImage)
                .share();
    }

    /**
     * 腾讯微博分享
     */
    private void shareToTencentWeibo() {
        new ShareAction((Activity) mContext).setPlatform(SHARE_MEDIA.TENCENT).setCallback(umengShareListener)
                .withTitle(StringUtil.isEmpty(mTitle) ? "" : mTitle)
                .withText(StringUtil.isEmpty(mContent) ? "" : mContent)
                .withTargetUrl(StringUtil.isEmpty(mTargetUrl) ? "" : mTargetUrl)
                .withMedia(mImage)
                .share();
    }
}
