package com.loonxi.ju53.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by Xuzue on 2015/10/20.
 */
public class ShortCutUtil {
    /**
     * 判断是否有快捷方式
     *
     * @param context
     * @return
     */
    public static boolean hasShortCut(Context context) {
        String authroity = getAuthority(context);
        String url = "content://" + authroity + "/favorites?notify=true";
        LogUtil.mLog().d("shortcut url: " + url);
        String title = null;
        try {
            PackageManager pm = context.getPackageManager();
            title = pm.getApplicationLabel(pm.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA)).toString();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        try {
            ContentResolver resolver = context.getContentResolver();
            Cursor cursor = resolver.query(Uri.parse(url), null, "title=?", new String[]{title}, null);
            if (cursor != null && cursor.moveToFirst()) {
                cursor.close();
                LogUtil.mLog().d("已有快捷方式：" + title);
                return true;
            } else {
                url = "content://" + "com.android.launcher3.settings" + "/favorites?notity=true";
                cursor = resolver.query(Uri.parse(url), null, "title=?", new String[]{title}, null);
                if (cursor != null && cursor.moveToFirst()) {
                    cursor.close();
                    LogUtil.mLog().d("已有快捷方式：" + title);
                    return true;
                }
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    /**
     * 删除当前应用程序的快捷方式（自动创建的）
     *
     * @param context
     */
    public static void deleteShortCut(Context context) {
        Intent intent = new Intent("com.android.launcher.action.UNINSTALL_SHORTCUT");
        String title = null;
        try {
            final PackageManager pm = context.getPackageManager();
            title = pm.getApplicationLabel(pm.getApplicationInfo(context.getPackageName(),
                    PackageManager.GET_META_DATA)).toString();
            LogUtil.mLog().d("deleteShotCut：" + title);
        } catch (Exception e) {
            e.printStackTrace();
        }
        intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, title);
        Intent shortcutIntent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        context.sendBroadcast(intent);
    }

    /**
     * 删除快捷方式（根据title查询所有的title下所有的快捷方式并删除）
     *
     * @param context
     * @param title
     */
    public static void deleteShortCut(Context context, String title) {
        ContentResolver resolver = context.getContentResolver();
        String authority = getAuthority(context);
        String url = "content://" + authority + "/favorites?notify=true";
        try {
            Cursor c = resolver.query(Uri.parse(url), new String[]{"_id", "title", "iconPackage"},
                    "title=?", new String[]{title}, null);
            while (c.moveToFirst()) {
                resolver.delete(Uri.parse("content://" + authority + "/favorites/" + c.getLong(0) + "?notify=true"),
                        null, null);// 根据_id删除
            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        resolver.notifyChange(Uri.parse(url), null);
    }

    /**
     * 添加快捷方式
     * @param context
     * @param shortCutResId
     */
    public static void addShortCut(Context context, int shortCutResId) {
        Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        Parcelable icon = Intent.ShortcutIconResource.fromContext(context, shortCutResId);
        String title = null;
        try {
            final PackageManager pm = context.getPackageManager();
            title = pm.getApplicationLabel(pm.getApplicationInfo(context.getPackageName(),
                            PackageManager.GET_META_DATA)).toString();
            LogUtil.mLog().d("addShortCut：" + title);
        } catch (Exception e) {

        }
        Intent shortCutIntent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortCutIntent);
        intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, title);
        intent.putExtra("duplicate", false);
        intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, icon);
        context.sendBroadcast(intent);
    }


    /**
     * 获取provider
     *
     * @param context
     * @return 通过这个方法遍历，会有1-2S的延时，循环可能有100多次，所以应该把返回的数据保存到文件/数据库中
     */
    public static String getAuthority(Context context) {
        List<PackageInfo> packageInfos = context.getPackageManager().getInstalledPackages(PackageManager.GET_PROVIDERS);
        if (packageInfos == null) {
            return null;
        }
        for (PackageInfo pack : packageInfos) {
            ProviderInfo[] providers = pack.providers;
            if (providers != null) {
                for (ProviderInfo provider : providers) {
                    if (provider.readPermission == null || provider.writePermission == null) {
                        continue;
                    }
                    if (!StringUtil.isEmpty(provider.readPermission) && provider.readPermission.contains("launcher")) {
                        return provider.authority;
                    }
                }
            }
        }
        return null;
    }

}
