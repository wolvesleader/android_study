package com.loonxi.ju53.views;

import com.loonxi.ju53.entity.SortEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

/**
 * Created by Xuzue on 2015/12/25.
 */
public interface ISortView {
    void showToast(int resId);
    void onGetSortsSuccess(JsonArrayInfo<SortEntity> sorts);
    void onGetSortsFailed(int apiErrorCode, String message);
    void onGetSortByIdSuccess(JsonArrayInfo<SortEntity> sorts);
    void onGetSortByIdFailed(int apiErrorCode, String message);
}
