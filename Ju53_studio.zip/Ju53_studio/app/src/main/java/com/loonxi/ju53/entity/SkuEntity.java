package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import org.json.JSONObject;

/**
 * Created by Xuzue on 2016/1/28.
 */
public class SkuEntity extends BaseJsonInfo implements Parcelable {
    private int totalStock;
    private String skuProp;
    private JSONObject skuName;

    public SkuEntity() {

    }

    protected SkuEntity(Parcel in) {
        super(in);
        totalStock = in.readInt();
        skuProp = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(totalStock);
        dest.writeString(skuProp);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<SkuEntity> CREATOR = new Creator<SkuEntity>() {
        @Override
        public SkuEntity createFromParcel(Parcel in) {
            return new SkuEntity(in);
        }

        @Override
        public SkuEntity[] newArray(int size) {
            return new SkuEntity[size];
        }
    };

    public int getTotalStock() {
        return totalStock;
    }

    public void setTotalStock(int totalStock) {
        this.totalStock = totalStock;
    }

    public String getSkuProp() {
        return skuProp;
    }

    public void setSkuProp(String skuProp) {
        this.skuProp = skuProp;
    }

    public JSONObject getSkuName() {
        return skuName;
    }

    public void setSkuName(JSONObject skuName) {
        this.skuName = skuName;
    }

}
