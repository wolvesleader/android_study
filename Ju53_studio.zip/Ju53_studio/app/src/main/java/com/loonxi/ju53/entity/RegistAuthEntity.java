package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * 注册：验证
 * Created by Xuzue on 2016/1/30.
 */
public class RegistAuthEntity extends BaseJsonInfo implements Parcelable {
    private String userId;
    private String userName;

    public RegistAuthEntity() {

    }

    protected RegistAuthEntity(Parcel in) {
        super(in);
        userId = in.readString();
        userName = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(userId);
        dest.writeString(userName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RegistAuthEntity> CREATOR = new Creator<RegistAuthEntity>() {
        @Override
        public RegistAuthEntity createFromParcel(Parcel in) {
            return new RegistAuthEntity(in);
        }

        @Override
        public RegistAuthEntity[] newArray(int size) {
            return new RegistAuthEntity[size];
        }
    };

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
