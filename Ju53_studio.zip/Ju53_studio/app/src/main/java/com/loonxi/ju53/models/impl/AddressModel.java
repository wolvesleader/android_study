package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.service.AddressService;

import java.util.Map;

import retrofit.Call;

/**
 * 获得收货地址model
 * Created by laojiaqi on 2016/1/25.
 */
public class AddressModel {

    /**获得收货地址（国内、国外）
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonArrayInfo<AddressEntity>> getAddress(Map<String, Object> map, Callback<JsonArrayInfo<AddressEntity>> callback) {
        if (map.size() == 0 || callback == null) {
            return null;
        }
        Call<JsonArrayInfo<AddressEntity>> call = Request.creatApi(AddressService.class).getAddress(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 删除国内国外地址
     * @param map
     * @param callback
     * @return
     */
    public Call<BaseJsonInfo> deleteAddress(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        if (map.size() == 0 || callback == null) {
            return null;
        }
        Call<BaseJsonInfo> call = Request.creatApi(AddressService.class).deleteAddress(map);
        call.enqueue(callback);
        return call;
    }


}
