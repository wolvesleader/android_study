package com.loonxi.ju53.web;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ProgressBar;

import java.lang.ref.WeakReference;


public abstract class JU53WebChromeClient extends WebChromeClient {
    /**
     * 最大进度
     */
    private static final int TOTAL = 100;
    /**
     * 进度临界值
     */
    private static final int THRESOLD = 80;
    /**
     * 更新进度的flag
     */
    private static final int UPDATE = 0;
    /**
     * 每次增加进度的延迟
     */
    private static final int DELAY = 50;
    /**
     * 每次增加的进度
     */
    private static final int STEP = 1;
    /**
     * 进度条
     */
    private ProgressBar mBar;
    /**
     * 模拟的进度
     */
    private static int mProgress = 0;
    /**
     * 真实加载进度
     */
    private static int mWebProgress = 0;

    private ProgressHandler mHandler;

    public JU53WebChromeClient(ProgressBar mBar) {
        this.mBar = mBar;
        mHandler = new ProgressHandler(this);
    }

    @Override
    public void onProgressChanged(WebView view, int newProgress) {
        super.onProgressChanged(view, newProgress);
        mWebProgress = newProgress;
        if(newProgress == 0){
            mBar.setProgress(0);
            mBar.setVisibility(View.VISIBLE);
        }
        if (mBar != null) {
            if (!mHandler.hasMessages(UPDATE)) {
                updateProgress();
            }
        }
    }

    /**
     * 控制进度如何显示
     */
    private void updateProgress() {
        if (mProgress < THRESOLD) {//模拟进度在80之前，以STEP/DELAY的速度递增
            mProgress += STEP;
        } else {//模拟进度达到80之后
            mProgress = (int) ((double) mWebProgress / TOTAL * (TOTAL - THRESOLD) + THRESOLD);
        }
        if (mProgress < mWebProgress) {//一旦真实进度超越模拟进度，则以真实进度为准
            mProgress = mWebProgress;
        }
        mHandler.sendEmptyMessageDelayed(UPDATE, DELAY);
    }

    private static class ProgressHandler extends Handler {
        private final WeakReference<ProgressBar> mProgressBar;
        private final WeakReference<JU53WebChromeClient> mClient;
        private ProgressHandler(JU53WebChromeClient client) {
            mClient = new WeakReference<>(client);
            mProgressBar = new WeakReference<>(client.mBar);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(mClient.get() == null || mProgressBar.get() == null){
                return;
            }
            switch (msg.what) {
                case UPDATE:
                    if (mProgress == 0) {
                        mProgressBar.get().setVisibility(View.VISIBLE);
                    } else if (mProgress > 0 && mProgress < TOTAL) {
                        mProgressBar.get().setProgress(mProgress);
                        mClient.get().updateProgress();
                    } else {
                        mProgressBar.get().setVisibility(View.GONE);
                        removeMessages(UPDATE);
                        mProgress = 0;
                        mWebProgress = 0;
                    }
                    break;
            }
        }
    }


}