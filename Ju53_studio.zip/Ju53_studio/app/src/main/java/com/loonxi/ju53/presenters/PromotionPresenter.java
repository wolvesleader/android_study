package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.models.IPromotionModel;
import com.loonxi.ju53.models.impl.PromotionModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IPromotionView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2015/12/23.
 */
public class PromotionPresenter extends BasePresenter<IPromotionView> {
    private IPromotionModel mModel;
    private IPromotionView mView;

    public PromotionPresenter(IPromotionView view) {
        super(view);
        mView = getView();
        mModel = new PromotionModel();
    }

    /**
     * 获取活动内容
     */
    public void getPromotions() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getPromotion(map, new Callback<JsonArrayInfo<PromotionEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<PromotionEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<PromotionEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.onGetPromotionSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.onGetPromotionFailed(apiErrorCode, message);
            }
        });
    }


}
