package com.loonxi.ju53.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;


public class ActionBar extends LinearLayout implements View.OnClickListener {

    @ViewInject(R.id.actionbar_layout_root)
    private LinearLayout mLayoutRoot;
    @ViewInject(R.id.actionbar_layout_left)
    private LinearLayout mLayoutLeft;
    @ViewInject(R.id.actionbar_iv_left)
    private ImageView mIvLeft;
    @ViewInject(R.id.action_tv_left)
    private TextView mTvLeft;
    @ViewInject(R.id.actionbar_layout_title)
    private LinearLayout mLayoutTitle;
    @ViewInject(R.id.actionbar_tv_title)
    private TextView mTvTitle;
    @ViewInject(R.id.actionbar_iv_title)
    private ImageView mIvTitle;
    @ViewInject(R.id.actionbar_layout_middle)
    private LinearLayout mLayoutMiddle;
    @ViewInject(R.id.actionbar_iv_middle)
    private ImageView mIvMiddle;
    @ViewInject(R.id.actionbar_tv_middle)
    private TextView mTvMiddle;
    @ViewInject(R.id.actionbar_layout_right)
    private LinearLayout mLayoutRight;
    @ViewInject(R.id.actionbar_iv_right)
    private ImageView mIvRight;
    @ViewInject(R.id.actionbar_tv_right)
    private TextView mTvRight;
    @ViewInject(R.id.actionbar_line)
    private View mViewLine;

    private String mTitle;
    private Drawable mDrawableLeft;
    private Drawable mDrawableTitle;
    private Drawable mDrawableMiddle;
    private Drawable mDrawableRight;
    private int mLeftVisibility = 0;//visible
    private int mMiddleVisibility = 2;//gone
    private int mRightVisibility = 1;//invisible

    private OnClickListener mOnLeftClickListener;
    private OnClickListener mOnTitleClickListener;
    private OnClickListener mOnMiddleClickListener;
    private OnClickListener mOnRightClickListener;

    public static final int LEFT_CLICK_ID = R.id.actionbar_layout_left;
    public static final int TITLE_CLICK_ID = R.id.actionbar_tv_title;
    public static final int MIDDLE_CLICK_ID = R.id.actionbar_layout_middle;
    public static final int RIGHT_CLICK_ID = R.id.actionbar_layout_right;


    public ActionBar(Context context) {
        this(context, null);
    }

    public ActionBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (isInEditMode()) {
            return;
        }
        View actionbar = LayoutInflater.from(context).inflate(R.layout.include_actionbar, null);
        addView(actionbar, LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        x.view().inject(this, actionbar);

        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.actionbar);
        mTitle = array.getString(R.styleable.actionbar_text);
        if (mTitle == null) {
            int titleResId = array.getResourceId(R.styleable.actionbar_text, -1);
            if (titleResId != -1) {
                mTitle = context.getResources().getString(titleResId);
            }
        }
        mLeftVisibility = getVisibility(array.getInt(R.styleable.actionbar_left_visibility, 0));
        mDrawableLeft = getResources().getDrawable(array.getResourceId(R.styleable.actionbar_left_src, R.drawable.back));
        mMiddleVisibility = getVisibility(array.getInt(R.styleable.actionbar_middle_visibility, 2));
        mDrawableMiddle = getResources().getDrawable(array.getResourceId(R.styleable.actionbar_middle_src, R.drawable.icon_home));
        mRightVisibility = getVisibility(array.getInt(R.styleable.actionbar_right_visibility, 1));
//        mDrawableRight = getResources().getDrawable(array.getResourceId(R.styleable.actionbar_right_src, R.drawable.ic_action_nothing));
        array.recycle();
        initView();
    }

    private void initView() {
        setLeftImageDrawable(mDrawableLeft);
        setLeftVisibility(mLeftVisibility);
        setTitle(mTitle);
        setTitleClickable(false);
        setTitleColor(getResources().getColor(R.color.app_black));
        setMiddleVisibility(mMiddleVisibility);
        setMiddleImageDrawable(mDrawableMiddle);
        setRightVisibility(mRightVisibility);
        setRightImageDrawable(null);
        mLayoutLeft.setOnClickListener(this);
        mTvTitle.setOnClickListener(this);
        mLayoutMiddle.setOnClickListener(this);
        mLayoutRight.setOnClickListener(this);
    }


    public void setOnLeftClickListener(OnClickListener listener) {
        mOnLeftClickListener = listener;
    }

    public void setOnTitleClickListener(OnClickListener listener) {
        mOnTitleClickListener = listener;
    }

    public void setOnMiddleClickListener(OnClickListener listener) {
        mOnMiddleClickListener = listener;
    }

    public void setOnRightClickListener(OnClickListener listener) {
        mOnRightClickListener = listener;
    }

    public void setLeftImageResource(int resId) {
        setLeftImageDrawable(getResources().getDrawable(resId));
    }

    public void setLeftImageDrawable(Drawable drawable) {
        mDrawableLeft = drawable;
        mIvLeft.setImageDrawable(drawable);
    }

    public void setLeftImageBitmap(Bitmap bitmap) {
        setLeftImageDrawable(new BitmapDrawable(bitmap));
    }

    public void setLeftText(int resId) {
        mTvLeft.setText(getResources().getString(resId));
    }

    public void setLeftText(String text) {
        mTvLeft.setText(text);
    }

    public void setLeftVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mLayoutLeft.setVisibility(visibility);
        }
    }

    public void setLeftImgVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mIvLeft.setVisibility(visibility);
        }
    }

    public void setLeftTextVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mTvLeft.setVisibility(visibility);
        }
    }

    public ImageView getLeftImage() {
        return mIvLeft;
    }

    public LinearLayout getLeftLayout() {
        return mLayoutLeft;
    }

    public void setTitleClickable(boolean clickable) {
        mTvTitle.setClickable(clickable);
    }

    public void setTitle(int resId) {
        mTvTitle.setText(getResources().getString(resId));
    }

    public void setTitle(String title) {
        mTvTitle.setText(title);
    }

    public void setTitleColor(int color) {
        mTvTitle.setTextColor(color);
    }

    public void setTitleSize(float size) {
        mTvTitle.setTextSize(size);
    }

    public void setTitleImgResource(int resId) {
        mIvTitle.setImageResource(resId);
    }

    public void setTitleImgDrawable(Drawable drawable) {
        mIvTitle.setImageDrawable(drawable);
    }

    public void setTitleVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mTvTitle.setVisibility(visibility);
        }
    }

    public void setTitleImgVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mIvTitle.setVisibility(visibility);
        }
    }

    public TextView getTitleTextView() {
        return mTvTitle;
    }

    public LinearLayout getTitleLayout() {
        return mLayoutTitle;
    }


    public ImageView getMiddleImage() {
        return mIvMiddle;
    }

    public LinearLayout getMiddleLayout() {
        return mLayoutMiddle;
    }

    public TextView getMiddleTextView() {
        return mTvMiddle;
    }

    public void setMiddleText(int resId) {
        mTvMiddle.setText(getResources().getString(resId));
    }

    public void setMiddleText(String text) {
        mTvMiddle.setText(text);
    }

    public void setMiddleTextColor(int color) {
        mTvMiddle.setTextColor(color);
    }

    public void setMiddleTextSize(float size) {
        mTvMiddle.setTextSize(size);
    }

    public void setMiddleImageResource(int resId) {
        setMiddleImageDrawable(getResources().getDrawable(resId));
    }

    public void setMiddleImageDrawable(Drawable drawable) {
        mDrawableMiddle = drawable;
        mIvMiddle.setImageDrawable(mDrawableMiddle);
    }

    public void setMiddleImageBitmap(Bitmap bitmap) {
        setRightImageDrawable(new BitmapDrawable(bitmap));
    }

    public void setMiddleVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mLayoutMiddle.setVisibility(visibility);
        }
    }

    public void setMiddleImageVisibility(int visibility) {
        if (visibility == View.GONE || visibility == View.VISIBLE || visibility == View.INVISIBLE) {
            mIvMiddle.setVisibility(visibility);
        }
    }

    public void setMiddleTextViewVisibility(int visibility) {
        if (visibility == View.GONE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mTvMiddle.setVisibility(visibility);
        }
    }

    public void setLineVisibility(int visibility){
        if(visibility == View.GONE || visibility == View.INVISIBLE || visibility == VISIBLE){
            mViewLine.setVisibility(visibility);
        }
    }

    public ImageView getRightImage() {
        return mIvRight;
    }

    public LinearLayout getRightLayout() {
        return mLayoutRight;
    }

    public TextView getRightTextView() {
        return mTvRight;
    }

    public void setRightImageResource(int resId) {
        setRightImageDrawable(getResources().getDrawable(resId));
    }

    public void setRightImageDrawable(Drawable drawable) {
        mDrawableRight = drawable;
        mIvRight.setImageDrawable(mDrawableRight);
    }

    public void setRightImageBitmap(Bitmap bitmap) {
        setRightImageDrawable(new BitmapDrawable(bitmap));
    }

    public void setRightText(int resId) {
        mTvRight.setText(getResources().getString(resId));
    }

    public void setRightText(String text) {
        mTvRight.setText(text);
    }

    public void setRightTextColor(int color) {
        mTvRight.setTextColor(color);
    }

    public void setRightTextSize(float size) {
        mTvRight.setTextSize(size);
    }

    public void setRightVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mLayoutRight.setVisibility(visibility);
        }
    }

    public void setRightImageVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mIvRight.setVisibility(visibility);
        }
    }

    public void setRightTextVisibility(int visibility) {
        if (visibility == View.VISIBLE || visibility == View.INVISIBLE || visibility == View.GONE) {
            mTvRight.setVisibility(visibility);
        }
    }


    public void setLeftWidth(int width) {
        LayoutParams params = new LayoutParams(width, LayoutParams.WRAP_CONTENT);
        mLayoutLeft.setLayoutParams(params);
    }

    public void setMiddleWidth(int width) {
        LayoutParams params = new LayoutParams(width, LayoutParams.WRAP_CONTENT);
        mLayoutMiddle.setLayoutParams(params);
    }

    public void setRightWidth(int width) {
        LayoutParams params = new LayoutParams(width, LayoutParams.WRAP_CONTENT);
        mLayoutRight.setLayoutParams(params);
    }

    public void setBackgroundColor(int color) {
        mLayoutRoot.setBackgroundColor(color);
    }

    public void setBackgroundColorResource(int colorId) {
        mLayoutRoot.setBackgroundColor(getResources().getColor(colorId));
    }

    public void setBackgroundResource(int resId) {
        mLayoutRoot.setBackgroundResource(resId);
    }

    public ViewGroup getRootLayout(){
        return mLayoutRoot;
    }

    private int getVisibility(int visibility) {
        switch (visibility) {
            case 0:
                return View.VISIBLE;
            case 1:
                return View.INVISIBLE;
            case 2:
                return View.GONE;
        }
        return View.VISIBLE;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case LEFT_CLICK_ID:
                if (mOnLeftClickListener != null) {
                    mOnLeftClickListener.onClick(mLayoutLeft);
                }
                break;
            case MIDDLE_CLICK_ID:
                if (mOnMiddleClickListener != null) {
                    mOnMiddleClickListener.onClick(mLayoutMiddle);
                }
                break;
            case RIGHT_CLICK_ID:
                if (mOnRightClickListener != null) {
                    mOnRightClickListener.onClick(mLayoutRight);
                }
                break;
            case TITLE_CLICK_ID:
                if (mOnTitleClickListener != null) {
                    mOnTitleClickListener.onClick(mTvTitle);
                }
                break;
        }
    }
}
