package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/6.
 */
public class SearchHistroyRecentAdapter extends BaseObjectListAdapter<String> {


    public SearchHistroyRecentAdapter(Context context, List<String> datas) {
        super(context, datas);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_search_history_recent, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_search_history_layout_root);
            holder.mTvName = (TextView) convertView.findViewById(R.id.listitem_search_history_recent_tv_name);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.mTvName.setText(get(position));

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast(get(position));
            }
        });
        return convertView;
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        TextView mTvName;
    }

}
