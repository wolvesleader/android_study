package com.loonxi.ju53.presenters;

import com.loonxi.ju53.models.impl.InterflowModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IInterflowView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/25.
 */
public class InterflowPresenter {
    private InterflowModel mModel;
    private IInterflowView mView;

    public InterflowPresenter(IInterflowView mView) {
        this.mView = mView;
        mModel = new InterflowModel();
    }

    /**
     * 查询物流详情
     * @param comCode 快递公司代码
     * @param interflowNo 快递单号
     */
    public void getInterflowDetail(String comCode, String interflowNo){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("id", "608fd9438a924e45854796d18a3780d2");
        map.put("com", comCode);
        map.put("nu", interflowNo);
        map.put("show", "0");
        map.put("muti", "0");
        map.put("order", "desc");
        mModel.getInterflowDetail(map, new Callback<Object>() {

            @Override
            public void onOtherFlag(int flag, String message, Object data) {

            }

            @Override
            public void onSuccess(Object data, Retrofit retrofit) {
                if(mView == null){
                    return;
                }
                mView.onGetInterflowDetailSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if(mView == null){
                    return;
                }
                mView.onGetInterflowDetailFailed(apiErrorCode, message);
            }
        });

    }

}
