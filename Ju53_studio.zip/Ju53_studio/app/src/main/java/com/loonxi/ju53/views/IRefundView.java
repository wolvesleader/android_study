package com.loonxi.ju53.views;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

/**
 * Created by Xuzue on 2016/1/28.
 */
public interface IRefundView extends IBaseView{
    void onRefundSuccess(BaseJsonInfo jsonInfo);
    void onRefundFailed(int apiErrorCode, String message);
}
