package com.loonxi.ju53.constants;

/**
 * Created by Xuzue on 2015/12/16.
 */
public class AppConst {
    public static final String DB_NAME = "ju53.db";
    public static final int DB_VERSION = 1;

    public static final String HOT_LINE = "400-618-5353";

    /**
     * 选择的默认浏览器
     */
    public static final String DEFAULT_BROWSER = "default_browser";
    /**
     * 图片的默认根地址
     */
    public static String PIC_HEAD = AppConst.PIC_HEAD_OUTER;
    public static final String PIC_HEAD_LOCAL = "http://restest.loonxi.com";//测试环境
    public static final String PIC_HEAD_OUTER = "http://picju53.loonxi.com";//正式环境
    /**
     * 图片大小
     * 1.原图，2.分类图288*288，2.分类图250*250，3.80*80
     */
    public static final String PIC_SIZE_288 = "@288x288";
    public static final String PIC_SIZE_250 = "@250x250";
    public static final String PIC_SIZE_80 = "@80x80";
//    public static final String PIC_SIZE_288 = "";
//    public static final String PIC_SIZE_250 = "";
//    public static final String PIC_SIZE_80 = "";
    /**
     * 默认超时时间
     */
    public static final int TIME_OUT = 10;

    /**
     * 开发者模式标识
     */
    public static final String DEVELOPER_TAG = "developer";

    /**
     * 列表为空时的缺省页
     */
    public class Empty {
        public static final int ORDER = 1;//无订单
        public static final int ADDRESS = 2;//无收货地址
        public static final int PRODUCT_MANAGE = 3;//无已代理商品
        public static final int FAV = 4;//无收藏商品
        public static final int SERRCH = 5;//搜索产品空
        public static final int CART = 6;//购物车空
        public static final int MESSAGE = 7;//无消息
        public static final int COMMENT = 8;//无评价
        public static final int SORT = 9;//无分类
        public static final int PROMOTION = 10;//无活动
        public static final int STORE = 11;//无店铺数据
        public static final int CASH_RECORD = 12;//无提现记录
    }

    public class PrefKey {
        public static final String PREF_REQ_TYPE = "request_type";
    }

    public class Action{
        public static final String ACTION_STORE_ALT_BASEINFO = "action_store_alt_baseinfo";//店铺基本信息有修改
        public static final String ACTION_STORE_ALT_PRODUCT = "action_store_alt_product";//店铺产品状态有修改（上架、下架等）
    }

    /**
     * 是否开启内存泄露检测器
     */
    public static final boolean OPEN_REF_WATCH = false;

}
