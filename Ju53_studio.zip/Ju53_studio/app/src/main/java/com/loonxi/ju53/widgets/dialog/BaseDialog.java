package com.loonxi.ju53.widgets.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.StringUtil;


/**
 * Created by butterfly on 2015/8/28.
 */
public class BaseDialog extends Dialog {

    private LinearLayout mLayoutContainer;
    private TextView mTvTitle;
    private Context mContext;

    public BaseDialog(Context context) {
        super(context, R.style.dialog_style);
        mContext = context;
        setContentView(R.layout.dialog_base);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        mLayoutContainer = (LinearLayout) findViewById(R.id.dialog_layout_container);
        mTvTitle = (TextView) findViewById(R.id.dialog_tv_title);
    }

    public void setTitle(String title) {
        mTvTitle.setText(StringUtil.isEmpty(title) ? mContext.getResources().getString(R.string.tip) : title);
    }

    public void addView(View v) {
        mLayoutContainer.addView(v, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    public View findViewById(int id) {
        if (super.findViewById(id) == null) {
            return mLayoutContainer.findViewById(id);
        }
        return super.findViewById(id);
    }

}
