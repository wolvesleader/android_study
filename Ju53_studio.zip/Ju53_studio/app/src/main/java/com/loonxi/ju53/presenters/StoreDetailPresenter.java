package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreDetailEntity;
import com.loonxi.ju53.models.IStoreModel;
import com.loonxi.ju53.models.impl.StoreModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IStoreDetailView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/3 0003.
 */
public class StoreDetailPresenter {

    private IStoreDetailView mView;
    private IStoreModel mModel;

    public StoreDetailPresenter(IStoreDetailView mView) {
        this.mView = mView;
        mModel = new StoreModel();
    }


    /**
     * 获取店铺基本信息
     */
    public void getStoreBaseInfo() {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        mModel.getStoreBaseInfo(map, new Callback<JsonInfo<StoreBaseInfoEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<StoreBaseInfoEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<StoreBaseInfoEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.getBaseInfoSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.getBaseInfoFailed(apiErrorCode, message);
                }
            }
        });

    }

    /**
     * 获取店铺详情
     */
    public void getStoreDetail(int page) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("page", page + "");
        map.put("pageSize", "20");
        mModel.getStoreDetail(map, new Callback<JsonInfo<StoreDataEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<StoreDataEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<StoreDataEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onGetStoreDetailSuccess(data == null ? null : data.getData());
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.endAsyncTask();
                    mView.onGetStoreDetailFailed(apiErrorCode, message);
                }
            }
        });
    }

}
