package com.loonxi.ju53.fragment.accountSafe;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseFragment;
import com.loonxi.ju53.widgets.ActionBar;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * 重置密码类型选择（1.知道原密码 2.忘记原密码）
 * Created by laojiaqi on 2016/2/17.
 */
public class AccountSafeTypeFragment extends BaseFragment implements View.OnClickListener {
    public static final String ACCOUNT_RESET_FRAGMENT="account_safe_reset";
    public static final String ACCOUNT_VERIFY_CODE_FRAGMENT="account_safe_verify_code_fragment";
    public static final String ACCOUNT_INPUT_LOGIN_PASSWORD_FRAGMENT="account_safe_input_login_password_fragment";
    public static final String UPDATE_TYPE = "update_type";
    public static final int UPDATE_LOGIN_PASSWORD = 1;//登录-记得密码-更新密码
    public static final int UPDATE_FORGET_LOGIN_PASSWORD = 3;//登录-忘记密码-更新密码
    public static final int UPDATE_PAY_PASSWORD = 2;//支付-记得密码-更新密码
    public static final int UPDATE_FORGET_PAY_PASSWORD = 4;//支付-忘记密码-更新密码
    private int mCurrentType;

    @ViewInject(R.id.fragment_account_safe_type_know_password)
    private LinearLayout mKnowPasswordLayout;
    @ViewInject(R.id.fragment_account_safe_type_forget_password)
    private LinearLayout mForgetPasswordLayout;
    @ViewInject(R.id.fragment_account_safe_type_action_bar)
    private ActionBar mActionBar;
    @ViewInject(R.id.fragment_account_safe_type_forget_password_text)
    private TextView mForgetPasswordText;
    @ViewInject(R.id.fragment_account_safe_type_know_password_text)
    private TextView mKnowPasswordText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getData();
    }


    private void getData() {
        Bundle bundle = getArguments();
        mCurrentType = bundle.getInt(UPDATE_TYPE);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account_safe_type, null);
        x.view().inject(view);
        return view;
    }

    @Override
    public void initView() {
        setContent();
    }

    private void setContent() {
        if (mCurrentType == UPDATE_LOGIN_PASSWORD) {
            mActionBar.setTitle(R.string.account_safe_login_title);
            mForgetPasswordText.setText(R.string.account_safe_login_forget_password);
            mKnowPasswordText.setText(R.string.account_safe_login_know_password);
        }
        if (mCurrentType == UPDATE_PAY_PASSWORD) {
            mActionBar.setTitle(R.string.account_safe_pay_title);
            mForgetPasswordText.setText(R.string.account_safe_pay_forget_password);
            mKnowPasswordText.setText(R.string.account_safe_pay_know_password);
        }
    }


    @Override
    public void initContent() {

    }

    @Override
    public void setListener() {
        mKnowPasswordLayout.setOnClickListener(this);
        mForgetPasswordLayout.setOnClickListener(this);
        mActionBar.setOnLeftClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goBack();
                break;

            case R.id.fragment_account_safe_type_know_password:
                goToResetPassword(mCurrentType);
                break;

            case R.id.fragment_account_safe_type_forget_password:
                goToForgetNextStep(mCurrentType);
                break;
        }
    }


    /**
     * 进入忘记密码（支付，登录）下一步
     */
    private void goToForgetNextStep(int flag){
        if(flag==AccountSafeTypeFragment.UPDATE_LOGIN_PASSWORD){
            goToGetVerifyCode(mCurrentType);
        }
        if(flag==AccountSafeTypeFragment.UPDATE_PAY_PASSWORD){
            //TODO
            gotoInputLoginPasswordFragment(mCurrentType);
        }
    }


    /**
     * 忘记支付密码
     * @param flag
     */
    private void gotoInputLoginPasswordFragment(int flag){
        FragmentManager fm = getFragmentManager();
        if(fm.findFragmentByTag(ACCOUNT_INPUT_LOGIN_PASSWORD_FRAGMENT)!=null){
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        AccountSafeLoginPasswordFragment accountSafeLoginPasswordFragment = new AccountSafeLoginPasswordFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, flag);//类别
        accountSafeLoginPasswordFragment.setArguments(bundle);
        ft.replace(R.id.fragment_account_safe_container, accountSafeLoginPasswordFragment, ACCOUNT_INPUT_LOGIN_PASSWORD_FRAGMENT);
        ft.addToBackStack("accountSafeMainFragment");
        ft.commitAllowingStateLoss();
    }


    /**
     * 忘记登录密码
     * @param flag
     */
    private void goToGetVerifyCode(int flag){
        FragmentManager fm = getFragmentManager();
        if(fm.findFragmentByTag(ACCOUNT_VERIFY_CODE_FRAGMENT)!=null){
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        AccountSafeVerifyCodeFragment accountSafeVerifyCodeFragment = new AccountSafeVerifyCodeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, flag);//类别
        accountSafeVerifyCodeFragment.setArguments(bundle);
        ft.replace(R.id.fragment_account_safe_container, accountSafeVerifyCodeFragment,ACCOUNT_VERIFY_CODE_FRAGMENT);
        ft.addToBackStack("accountSafeTypeFragment");
        ft.commitAllowingStateLoss();
    }

    /**
     * 跳转到“修改密码”
     */
    private void goToResetPassword(int flag) {
        FragmentManager fm = getFragmentManager();
        if(fm.findFragmentByTag(ACCOUNT_RESET_FRAGMENT)!=null){
            //防止多次添加fragment
            return;
        }
        FragmentTransaction ft = fm.beginTransaction();
        ft.addToBackStack("accountSafeMainFragment");
        AccountSafeResetPasswordFragment accountSafeResetPasswordFragment = new AccountSafeResetPasswordFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(AccountSafeTypeFragment.UPDATE_TYPE, flag);
        accountSafeResetPasswordFragment.setArguments(bundle);
        ft.add(R.id.fragment_account_safe_container, accountSafeResetPasswordFragment,ACCOUNT_RESET_FRAGMENT);
        ft.commitAllowingStateLoss();
    }


    private void goBack() {
        FragmentManager fm = getFragmentManager();
        fm.popBackStack();
    }
}
