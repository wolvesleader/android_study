package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.FreightRule;
import com.loonxi.ju53.entity.OrderCreateEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderFreightEntity;
import com.loonxi.ju53.entity.SaleOrderDetailEntity;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/18.
 */
public interface IOrderModel {
    Call<JsonInfo<AddressEntity>> getDefaultAddress(Map<String, Object> map, Callback<JsonInfo<AddressEntity>> callback);
    Call<JsonArrayInfo<FreightRule>> getFreightRule(Map<String, Object> map, Callback<JsonArrayInfo<FreightRule>> callback);
    Call<OrderCreateEntity> createOrder(Map<String, Object> map, Callback<OrderCreateEntity> callback);
    Call<JsonArrayInfo<OrderEntity>> getOrders(Map<String, Object> map, Callback<JsonArrayInfo<OrderEntity>> callback);
    Call<JsonArrayInfo<OrderEntity>> getBackOrders(Map<String, Object> map, Callback<JsonArrayInfo<OrderEntity>> callback);
    Call<OrderDetailEntity> getOrderById(Map<String, Object> map, Callback<OrderDetailEntity> callback);
    Call<BaseJsonInfo> sureOrder(Map<String, Object> map, Callback<BaseJsonInfo> callback);
    Call<BaseJsonInfo> createRefunds(Map<String, Object> map, Callback<BaseJsonInfo> callback);
    Call<BaseJsonInfo> updateRefunds(Map<String, Object> map, Callback<BaseJsonInfo> callback);
    Call<AliPayEntity> payOrder(Map<String, Object> map, Callback<AliPayEntity> callback);
    Call<BaseJsonInfo> closeOrder(Map<String, Object> map, Callback<BaseJsonInfo> callback);
    Call<JsonArrayInfo<SaleOrderEntity>> getSaleOrders(Map<String, Object> map, Callback<JsonArrayInfo<SaleOrderEntity>> callback);
    Call<JsonInfo<SaleOrderDetailEntity>> getSaleOrderDetail(Map<String, Object> map, Callback<JsonInfo<SaleOrderDetailEntity>> callback);
    Call<JsonArrayInfo<OrderFreightEntity>> getSupplierFreight(Map<String, Object> map, Callback<JsonArrayInfo<OrderFreightEntity>> callback);
}
