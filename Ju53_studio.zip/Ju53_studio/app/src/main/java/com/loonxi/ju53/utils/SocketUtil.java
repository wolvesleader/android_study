package com.loonxi.ju53.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 * socket通信工具类（即时通信会用到）
 * 说明：多线程中在每次操作最后不需要调用socket.close，以保持长连接
 * Created by Xuzue on 2015/9/10.
 */
public class SocketUtil {

    /**
     * UDP服务器ip地址
     */
    private static final String SERVER_IP_UDP = "192.168.1.1";
    /**
     * UDP服务器监听端口
     */
    private static final int SERVER_PORT_UDP = 6001;
    /**
     * TCP服务器ip地址
     */
    private static final String SERVER_IP_TCP = "192.168.1.1";
    /**
     * TCP服务器监听端口
     */
    private static final int SERVER_PORT_TCP = 6002;

    private static DatagramSocket mUdpClientSocket;
    private static DatagramSocket mUdpServerSocket;
    private static Socket mTcpClientSocket;
    private static ServerSocket mTcpServerSocket;

    public static DatagramSocket getUDPClientSocket(){
        if(mUdpClientSocket == null){
            synchronized (SocketUtil.class){
                if(mUdpClientSocket == null){
                    try {
                        mUdpClientSocket = new DatagramSocket();
                    } catch (SocketException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return mUdpClientSocket;
    }

    public static DatagramSocket getUDPServerSocket(){
        if(mUdpServerSocket == null){
            synchronized (SocketUtil.class){
                if(mUdpServerSocket == null){
                    try {
                        mUdpServerSocket = new DatagramSocket(SERVER_PORT_UDP);
                    } catch (SocketException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return mUdpServerSocket;
    }

    public static Socket getTcpClientSocket(){
        if(mTcpClientSocket == null){
            synchronized (SocketUtil.class){
                if(mTcpClientSocket == null){
                    try {
                        mTcpClientSocket = new Socket(SERVER_IP_TCP, SERVER_PORT_TCP);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return mTcpClientSocket;
    }

    public static ServerSocket getTcpServerSocket(){
        if(mTcpServerSocket == null){
            synchronized (SocketUtil.class){
                if(mTcpServerSocket == null){
                    try {
                        mTcpServerSocket = new ServerSocket(SERVER_PORT_TCP);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return mTcpServerSocket;
    }

    /**
     * UDP客户端发送请求
     * @param message
     */
    public static void udpClientSendReqest(String message){
        DatagramSocket socket = getUDPClientSocket();
        try {
            DatagramPacket packet = new DatagramPacket(message.getBytes(), message.getBytes().length,
                    InetAddress.getByName(SERVER_IP_UDP), SERVER_PORT_UDP);
            socket.send(packet);
            socket.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * UDP客户端接收返回数据
     */
    public static void udpClientGetResponse(){
        DatagramSocket socket = getUDPClientSocket();
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        try {
            socket.receive(packet);
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * UDP服务端接收请求
     */
    public static void udpServerReceiveRequest(){
        DatagramSocket socket = getUDPServerSocket();
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        try {
            socket.receive(packet);
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * UDP服务端响应客户端
     * @param message
     * @param clientAddress
     * @param clientPort
     */
    public static void udpServerSendResponse(String message, String clientAddress, int clientPort){
        DatagramSocket socket = getUDPServerSocket();
        try {
            DatagramPacket packet = new DatagramPacket(message.getBytes(), message.getBytes().length,
                    InetAddress.getByName(clientAddress), clientPort);
            socket.send(packet);
            socket.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * TCP客户端发送请求
     * @param message
     */
    public static void tcpClientSendRequest(String message){
        Socket socket = getTcpClientSocket();
        OutputStream os = null;
        try {
            os = socket.getOutputStream();
            os.write(message.getBytes());
            os.flush();
            os.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * TCP客户端接收返回数据
     */
    public static void tcpClientGetResponse(){
        Socket socket = getTcpClientSocket();
        InputStream is = null;
        OutputStream os = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        try {
            is = socket.getInputStream();
            int l = -1;
            while ((l = is.read(buffer)) != -1){
                os.write(buffer, 0, l);
            }
            os.flush();
            is.close();
            os.close();
            socket.close();
            String message = new String(buffer);//接收到的消息内容
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * TCP服务端接收请求
     */
    public static void tcpServerReceiveRequest(){
        ServerSocket serverSocket = getTcpServerSocket();
        try {
            Socket socket = serverSocket.accept();
            InputStream is = socket.getInputStream();
            OutputStream os = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int l = -1;
            while ((l = is.read(buffer)) != -1){
                os.write(buffer, 0, l);
            }
            os.flush();
            is.close();
            os.close();
            socket.close();
            String message = new String(buffer);//收到的请求具体内容
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * TCP服务端响应客户端
     * @param response 响应内容
     */
    public static void tcpServerSendResponse(String response){
        ServerSocket serverSocket = getTcpServerSocket();
        try {
            Socket socket = serverSocket.accept();
            OutputStream os = socket.getOutputStream();
            os.write(response.getBytes());
            os.flush();
            os.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
