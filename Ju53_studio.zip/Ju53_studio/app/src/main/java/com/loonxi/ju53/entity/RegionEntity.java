package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2016/3/9.
 */
public class RegionEntity implements Parcelable{
    String regionId;
    String regionName;

    public RegionEntity() {

    }

    protected RegionEntity(Parcel in) {
        regionId = in.readString();
        regionName = in.readString();
    }

    public static final Creator<RegionEntity> CREATOR = new Creator<RegionEntity>() {
        @Override
        public RegionEntity createFromParcel(Parcel in) {
            return new RegionEntity(in);
        }

        @Override
        public RegionEntity[] newArray(int size) {
            return new RegionEntity[size];
        }
    };

    public String getPickerViewText() {
        //这里还可以判断文字超长截断再提供显示
        return regionName;
    }

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(regionId);
        dest.writeString(regionName);
    }
}
