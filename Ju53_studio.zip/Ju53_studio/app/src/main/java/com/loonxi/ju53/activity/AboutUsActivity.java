package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.web.BaseWebView;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

/**
 * Created by Xuzue on 2016/2/23.
 */
public class AboutUsActivity extends BaseActivity {

    @ViewInject(R.id.about_iv_close)
    private ImageView mIvClose;
    @ViewInject(R.id.aboutus_base_web_view)
    private BaseWebView mWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        x.view().inject(this);
        initContent();



    }

    private void initContent() {
        mIvClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mWebView.start("http://m.ju53.com/about.html");
    }
}
