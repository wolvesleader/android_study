package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by Xuzue on 2016/2/19.
 */
public interface FeedbackService {
    /**
     * 提交反馈
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("user/core/createSuggest")
    Call<BaseJsonInfo> feedback(@FieldMap Map<String, Object> map);
}
