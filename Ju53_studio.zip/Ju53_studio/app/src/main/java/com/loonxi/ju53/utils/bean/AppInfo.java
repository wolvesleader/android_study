package com.loonxi.ju53.utils.bean;

import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2015/9/9.
 */
public class AppInfo implements Parcelable{


    private String appName;
    private String packageName;
    private String versionCode;
    private String versionName;
    private Drawable appIcon;


    public AppInfo(){

    }

    public AppInfo(String appName, String packageName, String versionCode, String versionName, Drawable appIcon){
        this.appName = appName;
        this.packageName = packageName;
        this.versionCode = versionCode;
        this.versionName = versionName;
        this.appIcon = appIcon;
    }

    protected AppInfo(Parcel in) {
        appName = in.readString();
        packageName = in.readString();
        versionCode = in.readString();
        versionName = in.readString();
    }

    public static final Creator<AppInfo> CREATOR = new Creator<AppInfo>() {
        @Override
        public AppInfo createFromParcel(Parcel in) {
            return new AppInfo(in);
        }

        @Override
        public AppInfo[] newArray(int size) {
            return new AppInfo[size];
        }
    };

    public Drawable getAppIcon() {
        return appIcon;
    }

    public void setAppIcon(Drawable appIcon) {
        this.appIcon = appIcon;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String parseToString(){
        return "[appName:" + appName + ", packageName:" + packageName + ", versionCode:" + versionCode + ", versionName:" + versionName + "]";
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(appName);
        dest.writeString(packageName);
        dest.writeString(versionCode);
        dest.writeString(versionName);
    }
}
