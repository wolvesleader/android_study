package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.models.IPromotionModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.PromotionService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/23.
 */
public class PromotionModel implements IPromotionModel {
    /**
     * 获取活动内容
     * @param callback
     */
    @Override
    public Call<JsonArrayInfo<PromotionEntity>> getPromotion(Map<String, Object> map, Callback<JsonArrayInfo<PromotionEntity>> callback) {
        Call<JsonArrayInfo<PromotionEntity>> call = Request.creatApi(PromotionService.class).getPromotion(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取活动详情
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonInfo<PromotionEntity>> getPromotionDetail(Map<String, Object> map, Callback<JsonInfo<PromotionEntity>> callback) {
        Call<JsonInfo<PromotionEntity>> call = Request.creatApi(PromotionService.class).getPromotionDetail(map);
        call.enqueue(callback);
        return call;
    }
}
