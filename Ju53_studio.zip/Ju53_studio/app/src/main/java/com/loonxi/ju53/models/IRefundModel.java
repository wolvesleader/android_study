package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.RefundEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/16.
 */
public interface IRefundModel {
    Call<JsonInfo<RefundEntity>> getRefundDetail(Map<String, Object> map, Callback<JsonInfo<RefundEntity>> callback);
    Call<BaseJsonInfo> updateRefund(Map<String, Object> map, Callback<BaseJsonInfo> callback);
}
