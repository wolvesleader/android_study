package com.loonxi.ju53.utils;

import java.text.DecimalFormat;

/**
 * Created by Xuzue on 2015/12/31.
 */
public class NumberUtil {
    public static String format2Decimal(double d) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(d);
    }

    public static double double2Decimal(double d) {
        DecimalFormat df = new DecimalFormat("0.00");
        String dStr = df.format(d);
        if (!StringUtil.isEmpty(dStr)) {
            return Double.valueOf(dStr);
        }
        return 0.00;
    }
}
