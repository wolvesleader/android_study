package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.utils.StringUtil;

import java.util.List;

/**
 * Created by Xuzue on 2015/12/19.
 */
public class HomeRecommendAdapter extends BaseObjectListAdapter<IndexEntity> {
    public HomeRecommendAdapter(Context context, List<IndexEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.griditem_home_recommend, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.griditem_home_recomment_layout_root);
            holder.mIvPic = (ImageView) convertView.findViewById(R.id.griditem_home_recommend_img);
            holder.mTvName = (TextView) convertView.findViewById(R.id.griditem_home_recommend_tv_name);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.griditem_home_recommend_tv_price);
            holder.mTvSales = (TextView) convertView.findViewById(R.id.griditem_home_recommend_tv_sales);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final IndexEntity entity = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + entity.getImgUrl() + AppConst.PIC_SIZE_80).into(holder.mIvPic);
        holder.mTvName.setText(entity.getProductName());
        holder.mTvPrice.setText("¥" + entity.getPrice());
        holder.mTvSales.setText("已售" + (StringUtil.isEmpty(entity.getQuantity()) ? "0" : entity.getQuantity()) + "件");

        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ProductDetailActivity.class);
                intent.putExtra("productId", entity.getProductId());
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    static class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvPic;
        TextView mTvName;
        TextView mTvPrice;
        TextView mTvSales;
    }
}
