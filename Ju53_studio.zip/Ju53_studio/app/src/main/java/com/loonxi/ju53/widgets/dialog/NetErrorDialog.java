package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

import com.loonxi.ju53.R;

/**
 * Created by Xuzue on 2016/1/12.
 */
public class NetErrorDialog extends BtnDialog {

    public NetErrorDialog(Context context, Activity activity, View.OnClickListener retryListener, View.OnClickListener backListener) {
        super(context, "提示",
                context.getResources().getString(R.string.error_request),
                context.getResources().getString(R.string.retry),
                context.getResources().getString(R.string.back),
                retryListener, backListener);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCanceledOnTouchOutside(false);
        setCancelable(false);

    }

}
