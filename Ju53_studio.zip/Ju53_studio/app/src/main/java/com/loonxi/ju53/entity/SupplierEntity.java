package com.loonxi.ju53.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 供应商实体
 */
public class SupplierEntity implements Serializable{

    /**
     *  用户ID
     */
    private long userId;

    /**
     *  供应商名称
     */
    private String name;

    /**
     *  供应商Logo地址
     */
    private String picPath;

    /**
     *  满意率
     */
    private String score;
    
    /**
     * 产品
     */
    private List<BaseProductEntity> list;
    
    /**
     * 商品数
     */
    private int num;
    
    /**
     * 修改时间
     */
    private long updatedTime;
    
    /**
     * 是否收藏
     */
    private int follow;


	public int getFollow() {
		return follow;
	}

	public void setFollow(int follow) {
		this.follow = follow;
	}

	public long getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(long updatedTime) {
		this.updatedTime = updatedTime;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPicPath() {
		return picPath;
	}

	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}

	

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public List<BaseProductEntity> getList() {
		return list;
	}

	public void setList(List<BaseProductEntity> list) {
		this.list = list;
	}

}