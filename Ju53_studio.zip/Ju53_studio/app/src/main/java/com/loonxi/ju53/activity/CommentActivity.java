package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.CommentAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.FlowLayoutItem;
import com.loonxi.ju53.entity.ProductCommentEntity;
import com.loonxi.ju53.entity.TotalCommentEntity;
import com.loonxi.ju53.presenters.CommentPresenter;
import com.loonxi.ju53.utils.ArrayUtil;
import com.loonxi.ju53.utils.FlowLayoutUtil;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ICommentView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.FlowLinearLayout;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/2/22.
 */
public class CommentActivity extends ActionBarActivity implements View.OnClickListener, ICommentView {

    @ViewInject(R.id.comment_layout_sort)
    private FlowLinearLayout mLayoutSort;
    @ViewInject(R.id.comment_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.comment_flv)
    private FixedListView mFlv;

    private int mTotal;
    private int mCurrentPage = 1;
    private int mScore = 0;
    private String mProductId;

    private CommentPresenter mPresenter;
    private CommentAdapter mAdapter;
    private List<ProductCommentEntity> mComments = new ArrayList<>();
    private List<String> mLabels = new ArrayList<>();
    private int mCurrentLablePosition = 0;
    private View.OnClickListener mLableClickListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);
    }

    @Override
    public void initView() {
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
        mFlv.setEmptyView(getEmptyView(R.string.empty_comment, AppConst.Empty.COMMENT, false));
        mPtr.setVisibility(View.GONE);
    }

    @Override
    public void initContent() {
        mPresenter = new CommentPresenter(this);
        mTotal = getIntent().getIntExtra("num", 0);
        mProductId = getIntent().getStringExtra("productId");
        mScore = 0;
        setTitle(getString(R.string.comments) + "(" + mTotal + ")");
        initCommentSort();
        mAdapter = new CommentAdapter(mContext, mComments);
        mFlv.setAdapter(mAdapter);
        mPresenter.getComments(mProductId, 1, mScore);
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnRightClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getComments(mProductId, mCurrentPage, mScore);
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getComments(mProductId, mCurrentPage, mScore);
            }
        });
        mLableClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object object = v.getTag();
                if (object == null || mContext == null) {
                    return;
                }
                FlowLayoutItem itemInfor = (FlowLayoutItem) object;
                int position = itemInfor.getPosition();
                String name = itemInfor.getName();
                if (position != mCurrentLablePosition) {
                    FlowLayoutUtil.resetView(mContext, mLayoutSort, mCurrentLablePosition);
                    FlowLayoutUtil.setView(mContext, mLayoutSort, position);
                    mCurrentLablePosition = position;
                    mScore = mCurrentLablePosition;
                    mCurrentPage = 1;
                    mComments.clear();
                    if (mAdapter != null) {
                        mAdapter.notifyDataSetChanged();
                    }
                    mPresenter.getComments(mProductId, mCurrentPage, mScore);
                }
            }
        };
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
        }
    }

    /**
     * 设置评论分类选择布局
     */
    private void initCommentSort() {
        setLableData();
        FlowLayoutUtil.generateLable(mContext, mLabels, mLayoutSort, mLableClickListener, true);
    }

    /**
     * 初始化标签文字内容
     */
    private void setLableData() {
        String[] labels = getResources().getStringArray(R.array.comment_lable);
        for (String label : labels) {
            mLabels.add(label);
        }
    }

    /**
     * 设置评论数
     *
     * @param num
     */
    private void setCommentNum(String num) {
        if (StringUtil.isEmpty(num) || ArrayUtil.isEmpty(num.split("_")) || mLayoutSort == null) {
            return;
        }
        String[] nums = num.split("_");
        if (nums != null && nums.length >= 3) {
            for (int i = 1; i < mLayoutSort.getChildCount(); i++) {
                TextView tv = (TextView) mLayoutSort.getChildAt(i);
                if (tv != null) {
                    tv.setText(mLabels.get(i) + "(" + nums[i - 1] + ")");
                }
            }
        }
    }

    @Override
    public void onGetCommentsSuccess(TotalCommentEntity comment) {
        if (mPtr != null) {
            mPtr.setVisibility(View.VISIBLE);
            if (mPtr.isRefreshing()) {
                mPtr.onRefreshComplete();
            }
        }
        if (mCurrentPage == 1) {
            mComments.clear();
            if (mScore == 0) {
                setCommentNum(comment.getNum());
                if (mPtr != null) {
                    mPtr.getRefreshableView().smoothScrollTo(0, 0);
                }
            }
        }
        if (!ListUtil.isEmpty(comment.getData())) {
            mCurrentPage++;
            mComments.addAll(comment.getData());
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onGetCommentsFailed(int apiErrorCode, String message) {
        if (mPtr != null) {
            mPtr.setVisibility(View.VISIBLE);
            if (mPtr.isRefreshing()) {
                mPtr.onRefreshComplete();
            }
        }
        checkError(apiErrorCode, message);
    }

}
