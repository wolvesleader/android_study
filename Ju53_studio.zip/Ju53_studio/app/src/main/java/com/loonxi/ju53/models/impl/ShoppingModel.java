package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartCheckEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.models.IShoppingModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.service.ProductService;
import com.loonxi.ju53.modules.request.service.ShoppingService;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.Logger;
import com.loonxi.ju53.utils.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/30.
 */
public class ShoppingModel implements IShoppingModel {

    private static final int DELETE_SUCCESS_EMPTY = -2;//产品删除成功，店铺下没有产品
    private static final int DELETE_FAILED = -3;//产品删除失败

    /**
     * 购物车所有信息
     */
    private List<CartEntity> mCarts = new ArrayList<>();

    /**
     * 存储编辑的店铺，格式：<companyId, true>
     */
    private Map<String, Boolean> mEditMap = new HashMap<>();
    /**
     * 存储某个店铺是否选中，格式：<companyId, true>
     */
    private Map<String, Boolean> mCheckCompanyMap = new HashMap<>();
    /**
     * 存储某个宝贝是否选中，格式：<productId, true>
     */
    private Map<String, Boolean> mCheckProductMap = new HashMap<>();
    /**
     * 存储某个店铺选中的宝贝数，格式：<companyId, 3>
     */
    private Map<String, Integer> mCheckProductNumsMap = new HashMap<>();
    /**
     * 存储选中的宝贝
     */
    private List<CartCheckEntity> mCheckProductList = new ArrayList<>();

    @Override
    public void _setCarts(List<CartEntity> carts) {
        mCarts.clear();
        if (!ListUtil.isEmpty(carts)) {
            mCarts.addAll(carts);
        }
    }

    @Override
    public List<CartEntity> _getCarts() {
        return mCarts;
    }

    @Override
    public void _initData(List<CartEntity> carts) {
        _initData(carts, true);
    }

    @Override
    public void _initData(List<CartEntity> carts, boolean changeEdit) {
        mCheckProductList.clear();
        _setCarts(carts);
        if (ListUtil.isEmpty(carts)) {
            return;
        }
        for (CartEntity cart : carts) {
            if(changeEdit){
                mEditMap.put(cart.getSupperId(), false);
            }
            mCheckCompanyMap.put(cart.getSupperId(), false);
            mCheckProductNumsMap.put(cart.getSupperId(), 0);
            List<BaseProductEntity> products = cart.getList();
            if (!ListUtil.isEmpty(products)) {
                for (BaseProductEntity product : products) {
                    mCheckProductMap.put(product.getStockid(), false);
                }
            }
        }
    }

    @Override
    public void _putEditMap(String companyId, boolean isEdit) {
        if (StringUtil.isEmpty(companyId))
            return;
        mEditMap.put(companyId, isEdit);
    }

    @Override
    public void _putCheckCompanyMap(String companyId, boolean isChecked) {
        if (StringUtil.isEmpty(companyId))
            return;
        mCheckCompanyMap.put(companyId, isChecked);
    }

    @Override
    public void _putCheckProductMap(String stockId, boolean isChecked) {
        if (StringUtil.isEmpty(stockId))
            return;
        mCheckProductMap.put(stockId, isChecked);
    }

    @Override
    public void _putCheckProductNumsMap(String companyId, String stockId, boolean isChecked) {
        if (StringUtil.isEmpty(companyId)) {
            return;
        }
        int oldNum = mCheckProductNumsMap.get(companyId);
        boolean checkProduct = mCheckProductMap.get(stockId);
        if (isChecked && !checkProduct) {
            mCheckProductNumsMap.put(companyId, oldNum + 1);
        } else if (!isChecked && checkProduct) {
            mCheckProductNumsMap.put(companyId, oldNum <= 0 ? 0 : oldNum - 1);
        }
        LogUtil.mLog().e(mCheckProductNumsMap.get(companyId));
    }

    @Override
    public void _putCheckProductList(CartEntity cart, BaseProductEntity product, boolean isAdd) {
        if (product == null || StringUtil.isEmpty(product.getStockid())) {
            return;
        }
        boolean isExist = false;
        CartCheckEntity checked = new CartCheckEntity();
        for (CartCheckEntity p : mCheckProductList) {
            if (product.getStockid().equals(p.getStockid())) {
                isExist = true;
                checked = p;
                break;
            }
        }
        CartCheckEntity checkEntity = new CartCheckEntity();
        checkEntity.copy(product);
        checkEntity.setSupperId(cart.getSupperId());
        checkEntity.setCompanyName(cart.getUserName());
        if (isAdd) {
            if (!isExist) {
                LogUtil.mLog().e("add " + product.getStockid());
                mCheckProductList.add(checkEntity);
            }
        } else {
            if (isExist) {
                LogUtil.mLog().e("delete " + product.getStockid());
                mCheckProductList.remove(checked);
            }
        }
    }

    /**
     * 判断是否选中了某个店铺中的所有宝贝
     *
     * @param cart
     * @param isCheckProduct
     * @return
     */
    @Override
    public boolean _isCheckAllProduct4Company(CartEntity cart, boolean isCheckProduct) {
        if (!isCheckProduct || cart == null || ListUtil.isEmpty(cart.getList())) {
            return false;
        }
        int checkNums = mCheckProductNumsMap.get(cart.getSupperId() + "");
        Logger.i(cart.getSupperId() + "checkNums:" + checkNums + " cart size:" + cart.getList().size());
        if (cart.getList().size() == checkNums) {
            return true;
        }
        return false;
    }


    /**
     * 获取店铺数据的index
     *
     * @param companyId
     * @return
     */
    public int getCartEntityIndexByCompanyId(String companyId) {
        if (StringUtil.isEmpty(companyId) || ListUtil.isEmpty(mCarts)) {
            return -1;
        }
        for (int i = 0; i < mCarts.size(); i++) {
            CartEntity cart = mCarts.get(i);
            if (companyId.equals(cart.getSupperId())) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 删除产品数据
     *
     * @param companyId
     * @param stockId
     * @return true: -3:删除失败 -2:删除成功,店铺空 其他：删除成功，店铺不空，返回剩余产品数
     */
    public int _deleteCartProduct(String companyId, String stockId) {
        if (StringUtil.isEmpty(companyId) || StringUtil.isEmpty(stockId)) {
            return DELETE_FAILED;
        }
        if(mCarts.size() == 0){
            return DELETE_SUCCESS_EMPTY;
        }
        for (int i = 0; i < mCarts.size(); i++) {
            CartEntity cart = mCarts.get(i);
            if (companyId.equals(cart.getSupperId())) {
                if (!ListUtil.isEmpty(cart.getList())) {
                    for (BaseProductEntity product : cart.getList()) {
                        if (stockId.equals(product.getStockid())) {
                            mCarts.get(i).getList().remove(product);
                            if (ListUtil.isEmpty(mCarts.get(i).getList())) {
                                return DELETE_SUCCESS_EMPTY;
                            } else {
                                return mCarts.get(i).getList().size();
                            }
                        }
                    }
                }
            }
        }
        return DELETE_FAILED;
    }

    /**
     * 删除店铺数据
     *
     * @param companyId
     */
    public void _deleteCartCompany(String companyId) {
        if (StringUtil.isEmpty(companyId) || ListUtil.isEmpty(mCarts)) {
            return;
        }
        for (CartEntity cart : mCarts) {
            if (companyId.equals(cart.getSupperId())) {
                mCarts.remove(cart);
                Logger.i("remove " + companyId + " size:" + mCarts.size());
                break;
            }
        }
    }

    @Override
    public Map<String, Boolean> _getEditCompanyMap() {
        return mEditMap;
    }

    @Override
    public Map<String, Boolean> _getCheckCompanyMap() {
        return mCheckCompanyMap;
    }

    @Override
    public Map<String, Boolean> _getCheckProductMap() {
        return mCheckProductMap;
    }

    @Override
    public Map<String, Integer> _getCheckProductNumsMap() {
        return mCheckProductNumsMap;
    }

    @Override
    public List<CartCheckEntity> _getCheckProductList() {
        return mCheckProductList;
    }


    /**
     * 获取产品总数
     *
     * @return
     */
    @Override
    public int _getProductTotalNums() {
        int total = 0;
        if (ListUtil.isEmpty(mCarts)) {
            total = 0;
        }
        for (CartEntity cart : mCarts) {
            if (!ListUtil.isEmpty(cart.getList())) {
                total += cart.getList().size();
            }
        }
        return total;
    }

    /**
     * 获取所有选中产品的总价
     *
     * @return
     */
    @Override
    public double _getCheckPrice() {
        double mCheckPrice = 0;
        for (BaseProductEntity product : mCheckProductList) {
            mCheckPrice += product.getPrice() * product.getCount();
        }
        return mCheckPrice;
    }

    /**
     * 获取所有选中产品的stockId
     *
     * @return
     */
    @Override
    public String _getCheckStockId() {
        String mCheckProductStockId = "";
        for (BaseProductEntity product : mCheckProductList) {
            mCheckProductStockId += product.getStockid() + "/";
        }
        return mCheckProductStockId;
    }

    /**
     * 获取所有选中产品的freightId
     *
     * @return
     */
    @Override
    public String _getCheckFreightIds() {
        StringBuffer sb = new StringBuffer();
        for (BaseProductEntity product : mCheckProductList) {
            sb.append("_").append(product.getFreightId());
        }
        if (sb.toString().length() > 0) {
            sb = sb.deleteCharAt(0);
        }
        return sb.toString();
    }

    /**
     * 判断购物车中,某个店铺下是否已存在某个产品（stockId唯一标识产品）
     *
     * @param cart
     * @return
     */
    @Override
    public boolean _productIsExist(CartEntity cart, String stockId) {
        if (cart == null || ListUtil.isEmpty(mCarts) || ListUtil.isEmpty(cart.getList()) || StringUtil.isEmpty(stockId)) {
            return false;
        }
        for (BaseProductEntity entity : cart.getList()) {
            if (stockId.equals(entity.getStockid())) {
                return true;
            }
        }
        return false;
    }


    /**
     * “全选”后，更新数据
     *
     * @param isCheckAll
     */
    public void _updateDataAfterCheckAll(boolean isCheckAll) {
        mCheckProductList.clear();
        for (CartEntity cart : mCarts) {
            String companyId = cart.getSupperId();
            mCheckCompanyMap.put(companyId, isCheckAll);
            List<BaseProductEntity> products = cart.getList();
            List<CartCheckEntity> checkList = new ArrayList<>();
            for (BaseProductEntity product : products) {
                CartCheckEntity check = new CartCheckEntity();
                check.copy(product);
                check.setSupperId(companyId);
                check.setCompanyName(cart.getUserName());
                checkList.add(check);
            }
            if (isCheckAll) {
                mCheckProductList.addAll(checkList);
                mCheckProductNumsMap.put(companyId, products.size());
            } else {
                mCheckProductNumsMap.put(companyId, 0);
            }
            for (BaseProductEntity product : products) {
                mCheckProductMap.put(product.getStockid(), isCheckAll);
            }
        }
    }

    /**
     * 全“编辑”后，更新数据
     *
     * @param isCheckAll
     */
    public void _updateDataAfterEditAll(boolean isCheckAll) {
        Set<Map.Entry<String, Boolean>> entries = mEditMap.entrySet();
        for (Map.Entry<String, Boolean> entry : entries) {
            mEditMap.put(entry.getKey(), isCheckAll);
        }
    }

    /**
     * “编辑”店铺后，更新数据
     *
     * @param cart
     * @param isEdit
     */
    @Override
    public void _updateDataAfterEditCompany(CartEntity cart, boolean isEdit) {
        if (cart == null) {
            return;
        }
        _putEditMap(cart.getSupperId(), isEdit);
    }

    /**
     * 选择某个产品后，更新数据
     *
     * @param cart
     * @param product
     * @param isChecked
     */
    @Override
    public void _updateDataAfterCheckProduct(CartEntity cart, BaseProductEntity product, boolean isChecked) {
        if (cart == null || product == null) {
            return;
        }
        _putCheckProductNumsMap(cart.getSupperId(), product.getStockid(), isChecked);
        _putCheckProductMap(product.getStockid(), isChecked);
        _putCheckProductList(cart, product, isChecked);
        if (isChecked) {
            if (_isCheckAllProduct4Company(cart, true)) {
                _putCheckCompanyMap(cart.getSupperId(), true);
            } else {
                _putCheckCompanyMap(cart.getSupperId(), false);
            }
        } else {
            _putCheckCompanyMap(cart.getSupperId(), false);
        }
    }

    /**
     * 选择某个店铺后，更新数据
     *
     * @param cart
     * @param isChecked
     */
    @Override
    public void _updateDataAfterCheckCompany(CartEntity cart, boolean isChecked) {
        if (cart == null) {
            return;
        }
        for (BaseProductEntity product : cart.getList()) {
            _updateDataAfterCheckProduct(cart, product, isChecked);
        }
    }

    /**
     * 删除单个产品后，更新数据
     *
     * @param cart
     * @param product
     */
    @Override
    public void _updateDataAfterDeleteOneProduct(CartEntity cart, BaseProductEntity product) {
        if (cart == null || product == null) {
            return;
        }
        String companyId = cart.getSupperId();
        String stockId = product.getStockid();
        int state = _deleteCartProduct(companyId, stockId);
        if (state != DELETE_FAILED) {
            if (state == DELETE_SUCCESS_EMPTY) {//删除了店铺里的最后一个产品
                _deleteCartCompany(companyId);
                mCheckProductNumsMap.put(companyId, 0);
                _putCheckProductMap(stockId, false);
                _putCheckProductList(cart, product, false);
            } else {//删除后店铺里还有产品
                _putCheckProductNumsMap(companyId, stockId, false);
                _putCheckProductMap(stockId, false);
                _putCheckProductList(cart, product, false);
                boolean checkCompany = mCheckProductNumsMap.get(companyId) == state ? true : false;
                _putCheckCompanyMap(companyId, checkCompany);
            }
        }
    }

    /**
     * 删除多个产品后，更新数据
     *
     * @param carts
     */
    @Override
    public void _updateDataAfterDeleteMultiProduct(List<CartCheckEntity> carts) {
        if (ListUtil.isEmpty(carts)) {
            return;
        }
        for (int i = 0; i < carts.size(); ) {
            CartCheckEntity check = carts.get(i);
            CartEntity cart = new CartEntity();
            cart.setSupperId(check.getSupperId());
            cart.setUserName(check.getCompanyName());
            BaseProductEntity product = check;
            carts.remove(i);
            _updateDataAfterDeleteOneProduct(cart, product);
            i = 0;
        }
    }


    /**
     * 修改产品数量后，更新数据
     *
     * @param parentIndex
     * @param productIndex
     * @param nums
     */
    @Override
    public void _updateDataAfterAltCartNums(int parentIndex, int productIndex, int nums) {
        List<BaseProductEntity> products = mCarts.get(parentIndex).getList();
        String stockId = "";
        if (!ListUtil.isEmpty(products)) {
            products.get(productIndex).setCount(nums);
            stockId = products.get(productIndex).getStockid();
        }
        if(!ListUtil.isEmpty(mCheckProductList)){
            for(CartCheckEntity product : mCheckProductList){
                if(product != null && !StringUtil.isEmpty(product.getStockid()) && product.getStockid().equals(stockId)){
                    product.setCount(nums);
                    break;
                }
            }
        }
    }

    /**
     * 修改产品属性后，更新数据
     *
     * @param companyId
     * @param product
     * @param color
     * @param size
     * @param checkProduct 修改之前产品是否是选中状态
     */
    @Override
    public void _updateDataAfterAltCartAttribute(String companyId, BaseProductEntity product, String color, String size, boolean checkProduct) {
        if (StringUtil.isEmpty(companyId) || product == null || StringUtil.isEmpty(product.getStockid())) {
            return;
        }
        mCheckProductMap.put(product.getStockid(), checkProduct);
        int index = getCartEntityIndexByCompanyId(companyId);
        if (index == -1) {
            return;
        }
        List<BaseProductEntity> products = mCarts.get(index).getList();
        if (!ListUtil.isEmpty(products)) {
            for (int i = 0; i < products.size(); i++) {
                if (product.getStockid().equals(products.get(i).getStockid())) {
                    products.get(i).setStockid(product.getStockid());
                    products.get(i).setAttributeColor(color);
                    products.get(i).setAttributeMula(size);
                    break;
                }
            }
        }
    }


    @Override
    public Call<JsonArrayInfo<CartEntity>> getCarts(Map<String, Object> params, Callback<JsonArrayInfo<CartEntity>> callback) {
        Call<JsonArrayInfo<CartEntity>> call = Request.creatApi(ShoppingService.class).getCarts(params);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<JsonArrayInfo<CartEntity>> deleteProduct(Map<String, Object> map, Callback<JsonArrayInfo<CartEntity>> callback) {
        Call<JsonArrayInfo<CartEntity>> call = Request.creatApi(ShoppingService.class).deleteProduct(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<ProductAttributeEntity> getSku(Map<String, Object> map, Callback<ProductAttributeEntity> callback) {
        Call<ProductAttributeEntity> call = Request.creatApi(ProductService.class).getSku(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> updateCart(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(ShoppingService.class).updateCart(map);
        call.enqueue(callback);
        return call;
    }

    @Override
    public Call<BaseJsonInfo> moveToFav(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(ShoppingService.class).moveToFav(map);
        call.enqueue(callback);
        return call;
    }


}
