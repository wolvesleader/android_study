package com.loonxi.ju53.modules.request.service;

import android.database.Observable;

import com.squareup.okhttp.Response;


import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;

/**
 * 文件/图片上传接口
 * Created by XuZue on 2016/5/4 0004.
 */
public interface UploadService {
//    @Multipart
//    @POST("")
//    Observable<Response> uploadStoreHead(@Part("uploadFile") TypedFile file);

}
