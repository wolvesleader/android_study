package com.loonxi.ju53.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * 固定高度的ListView，与ScrollView嵌套使用。
 * 解决与ScrollView嵌套时Listview内容不能完全显示的问题
 * Created by Xuzue on 2015/9/11.
 */
public class FixedListView extends ListView {

    public FixedListView(Context context) {
        this(context, null);
    }

    public FixedListView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FixedListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int expandSpec = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2, MeasureSpec.AT_MOST);
        super.onMeasure(widthMeasureSpec, expandSpec);
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
    }


}
