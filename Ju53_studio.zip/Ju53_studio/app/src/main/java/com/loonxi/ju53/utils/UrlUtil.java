package com.loonxi.ju53.utils;

import android.text.TextUtils;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Url工具类
 */
public class UrlUtil {

	public static Map<String, String> splitUrlQuery(URL url) {
		Map<String, String> query_pairs = new LinkedHashMap<>();
		String query = url.getQuery();
		String[] pairs = query.split("&");
		for (String pair : pairs) {
			int idx = pair.indexOf("=");
			try {
				query_pairs.put(
						URLDecoder.decode(pair.substring(0, idx), "UTF-8"),
						URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return query_pairs;
	}
	
	public static Map<String, String> splitUrlQuery(String urlStr) {
		URL url = formatUrl(urlStr);
		Map<String, String> query_pairs = new LinkedHashMap<>();
		String query = url != null ? url.getQuery() : "";
		if(TextUtils.isEmpty(query)) return query_pairs;
		String[] pairs = query.split("&");
		for (String pair : pairs) {
			int idx = pair.indexOf("=");
			try {
				query_pairs.put(
						URLDecoder.decode(pair.substring(0, idx), "UTF-8"),
						URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return query_pairs;
	}
	
	public static URL formatUrl(String urlStr){
		try {
			return new URL(urlStr);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static String getProtocol(String urlStr){
		URL url = formatUrl(urlStr);
		return url != null ? url.getProtocol() : "";
	}
	
	public static String getHost(String urlStr){
		URL url = formatUrl(urlStr);
		return url != null ? url.getHost() : "";
	}
	
	public static String getPath(String urlStr){
		URL url = formatUrl(urlStr);
		return url != null ? url.getPath() : "";
	}
	
	public static String rebuildUrl(String url, Map<String, String> map){
		String newUrl;
		String queryString = formatUrl(url).getQuery();
		if(TextUtils.isEmpty(queryString)){
			newUrl = url;
		} else{
			newUrl = url.replace(formatUrl(url).getQuery(), "");
		}
		StringBuilder queryBuilder = new StringBuilder();
		for(Map.Entry<String, String> entry : map.entrySet()){
			queryBuilder.append(entry.getKey()).append("=").append(entry.getValue());
			queryBuilder.append("&");
		}
		String s = queryBuilder.toString();
		if(s.endsWith("&")){
			s = s.substring(0, s.length() - 1);
		}
		if(newUrl.contains("?")){
			return newUrl + s;
		} else{
			return newUrl + "?" + s;
		}
	}

	public static String getFileName(String url){
		int startIndex = url.lastIndexOf("/") + 1;
		return url.substring(startIndex, url.length());
	}

	/**
	 * 从字符串中提取Url
	 * @param content
	 * @return
	 */
	public static String splitUrl(String content) {
		String regex = "(((http|https)://)?(\\w+[.])|(www.))\\w+[.]([a-z]{2,4})?[[.]([a-z]{2,4})]+((/[\\S&&[^,;\u4E00-\u9FA5]]+)+)?([.][a-z]{2,4}+|/?)";
		StringBuffer sb = new StringBuffer();
		Pattern pat = Pattern.compile(regex);
		Matcher mat = pat.matcher(content);
		while (mat.find()) {
			String url = mat.group();
			sb.append(url);
		}
		return sb.toString();
	}
}
