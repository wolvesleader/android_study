package com.loonxi.ju53.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.ProductDetailActivity;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.constants.ProductState;
import com.loonxi.ju53.entity.BaseProductEntity;

import java.util.List;

/**
 * Created by Xuzue on 2016/1/7.
 */
public class AgentChildAdapter extends BaseObjectListAdapter<BaseProductEntity> {


    public AgentChildAdapter(Context context, List<BaseProductEntity> datas) {
        super(context, datas);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_agent_child, null);
            holder.mLayoutRoot = (LinearLayout) convertView.findViewById(R.id.listitem_agent_child_layout_root);
            holder.mIvHead = (ImageView) convertView.findViewById(R.id.listitem_agent_child_iv_head);
            holder.mTvProductName = (TextView) convertView.findViewById(R.id.listitem_agent_child_tv_name);
            holder.mTvState = (TextView) convertView.findViewById(R.id.listitem_agent_child_tv_status);
            holder.mTvPrice = (TextView) convertView.findViewById(R.id.listitem_agent_child_tv_price);
            holder.mTvNum = (TextView) convertView.findViewById(R.id.listitem_agent_child_tv_num);
            holder.mDivider = convertView.findViewById(R.id.listitem_agent_child_divider);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        BaseProductEntity product = get(position);
        Glide.with(mContext).load(AppConst.PIC_HEAD + product.getPicture() + AppConst.PIC_SIZE_80).into(holder.mIvHead);
        holder.mTvProductName.setText(product.getProductName());
        Spanned total = Html.fromHtml("分销价:  <font color=\"#ee0c00\">¥" + product.getPrice() + "</font>");
        holder.mTvPrice.setText(total);
        holder.mTvNum.setText("库存:  " + product.getStock());
        setDivider(holder, position);
        setListener(holder, product);
        ProductState.setProductState(holder.mTvState, product.getState());

        return convertView;
    }

    private void setDivider(ViewHolder holder, int position) {
        if (position == getCount() - 1) {
            holder.mDivider.setVisibility(View.GONE);
        } else {
            holder.mDivider.setVisibility(View.VISIBLE);
        }
    }

    private void setListener(ViewHolder holder, final BaseProductEntity product) {
        if (holder == null) {
            return;
        }
        holder.mLayoutRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int state = product.getState();
                if(state == ProductState.ON || state == ProductState.OFF) {
                    Intent intent = new Intent(mContext, ProductDetailActivity.class);
                    intent.putExtra("productId", product.getProductId());
                    mContext.startActivity(intent);
                }
            }
        });
    }

    class ViewHolder {
        LinearLayout mLayoutRoot;
        ImageView mIvHead;
        TextView mTvProductName;
        TextView mTvState;
        TextView mTvPrice;
        TextView mTvNum;
        View mDivider;
    }

}
