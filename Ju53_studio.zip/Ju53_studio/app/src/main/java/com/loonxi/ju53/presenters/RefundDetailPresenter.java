package com.loonxi.ju53.presenters;

import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.entity.RefundEntity;
import com.loonxi.ju53.models.IRefundModel;
import com.loonxi.ju53.models.impl.RefundModel;
import com.loonxi.ju53.modules.open.alipay.Base64;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IRefundDetailView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/2/16.
 */
public class RefundDetailPresenter {
    private IRefundModel mModel;
    private IRefundDetailView mView;

    public RefundDetailPresenter(IRefundDetailView mView) {
        this.mView = mView;
        mModel = new RefundModel();
    }

    /**
     * 获取退款详情
     *
     * @param order
     */
    public void getRefundDetail(OrderEntity order, OrderUnitEntity unit) {
        if (order == null || unit == null) {
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("attrId", unit.getPid() + "");
        map.put("supplierId", order.getSupplierId() + "");
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.getRefundDetail(map, new Callback<JsonInfo<RefundEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonInfo<RefundEntity> data) {

            }

            @Override
            public void onSuccess(JsonInfo<RefundEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetRefundDetailSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetRefundDetailFailed(apiErrorCode, message);
            }
        });
    }

    /**
     * 修改退款
     *
     * @param attrId
     * @param orderId
     * @param backapply
     * @param productId
     * @param reason
     * @param notes
     * @param applyType
     * @param orderState
     */
    public void updateRefund(String attrId, String orderId, String backapply, String productId,
                             final int reason, String notes, int applyType, int orderState,
                             String pid, boolean isCancel) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        JSONObject refundsObject = new JSONObject();
        JSONObject object = new JSONObject();
        try {
            object.put("attrId", attrId);
            object.put("orderId", orderId);
            object.put("backapply", backapply);
            object.put("productId", productId);
            object.put("reason", reason + "");
            object.put("notes", notes);
            object.put("applyType", applyType + "");
            object.put("orderState", orderState + "");
            object.put("pid", pid);
            object.put("state", isCancel ? -1 : 4);
            refundsObject.put("refunds", object);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        map.put("refunds", Base64.encode(refundsObject.toString().getBytes()));
        if (mView != null) {
            mView.startAsyncTask();
        }
        mModel.updateRefund(map, new Callback<BaseJsonInfo>() {

            @Override
            public void onOtherFlag(int flag, String message, BaseJsonInfo data) {

            }

            @Override
            public void onSuccess(BaseJsonInfo data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onUpdateRefundSuccess();
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onUpdateRefundFailed(apiErrorCode, message);
            }
        });
    }
}
