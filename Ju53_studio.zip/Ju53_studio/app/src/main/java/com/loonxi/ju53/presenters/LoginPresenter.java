package com.loonxi.ju53.presenters;

import android.content.Context;

import com.loonxi.ju53.R;
import com.loonxi.ju53.constants.ApiConst;
import com.loonxi.ju53.entity.UserEntity;
import com.loonxi.ju53.models.ILoginModel;
import com.loonxi.ju53.models.impl.LoginModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.utils.MD5;
import com.loonxi.ju53.utils.MapUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.ILoginView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/1/5.
 */
public class LoginPresenter {
    private ILoginModel mModel;
    private ILoginView mView;

    public LoginPresenter(ILoginView mView) {
        this.mView = mView;
        mModel = new LoginModel();
    }

    /**
     * 登录
     *
     * @param account
     * @param password
     */
    public void login(String account, String password) {
        if (StringUtil.isEmpty(account) || StringUtil.isEmpty(password)) {
            mView.showToast(R.string.login_info_null);
            return;
        }
        Map<String, Object> map = PrefsRepos.getDefaultOrderedMap();
        map.put("service", ApiConst.Code.LOGIN);
        map.put("userName", account);
        map.put("password", StringUtil.toBase64String(password));
        map.put("isBeginner", "0");
        String sign = MapUtil.toUrlString(map);
        map.put("sign", MD5.getMessageDigest(((StringUtil.isEmpty(sign) ? "" : sign) + ApiConst.KEY_REGISTER).getBytes()));
        mView.startAsyncTask();
        mModel.login(map, new Callback<UserEntity>() {

            @Override
            public void onOtherFlag(int flag, String message, UserEntity data) {

            }

            @Override
            public void onSuccess(UserEntity data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mModel.saveLoginInfo((Context) mView, data);
                mView.onLoginSuccess(data);
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onLoginFailed(apiErrorCode, message);
            }
        });
    }
}
