package com.loonxi.ju53.fragment;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.SupplierAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.presenters.ProductDetailRecommendPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.IProductDetailRecommendView;
import com.loonxi.ju53.widgets.FixedGridView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/12.
 */
@ContentView(R.layout.fragment_product_detail_recommend)
public class ProductDetailRecommendFragment extends BaseSafeFragment<IProductDetailRecommendView, ProductDetailRecommendPresenter> implements IProductDetailRecommendView {

    @ViewInject(R.id.fragment_product_detail_recommend_fgv)
    private FixedGridView mFgv;

    private SupplierAdapter mAdapter;
    private List<BaseProductEntity> mDatas = new ArrayList<>();
    private int mCurrentPage = 1;
    private String mUserId = "";

    @Override
    public void initView() {

    }

    @Override
    public void initContent() {
        mPresenter = new ProductDetailRecommendPresenter(this);
        mCurrentPage = 1;
        if (getArguments() != null) {
            mUserId = getArguments().getString("userId");
        }
        mAdapter = new SupplierAdapter(mContext, mDatas);
        mFgv.setAdapter(mAdapter);
        mPresenter.getSupplierRecommends(mUserId, mCurrentPage);
    }

    @Override
    public void setListener() {

    }


    @Override
    protected ProductDetailRecommendPresenter createPresenter(IProductDetailRecommendView iProductDetailRecommendView) {
        return new ProductDetailRecommendPresenter(this);
    }

    @Override
    public void onGetRecommendSuccess(List<BaseProductEntity> products) {
        if (mCurrentPage == 1) {
            mDatas.clear();
        }
        if (!ListUtil.isEmpty(products)) {
            mDatas.addAll(products);
        }
        mAdapter.notifyDataSetChanged();
        mCurrentPage++;
    }

    @Override
    public void onGetRecommendFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog(null);
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }
}
