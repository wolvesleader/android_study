package com.loonxi.ju53.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.widget.FrameLayout;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseActivity;
import com.loonxi.ju53.fragment.address.DisplayAddressFragment;

/**
 * 管理收货地址activity
 * Created by Administrator on 2016/1/25.
 */
public class AddressActivity extends BaseActivity {
    public static String FROM_FLAG="from_flag";
    public static int ORDER_GET_ADDRESS=1;//从订单进入
    public static int MANAGE_ADDRESS=0;//从管理地址进入
    int mCurrentFromType=MANAGE_ADDRESS;
    FrameLayout mFrameLayout;
    Bundle mBundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_layout);
        getIntentData();
        gotoDisplayFragment();
    }

    /**
     * 跳转到“我的收货地址Fragment”
     */
    private void gotoDisplayFragment(){
        DisplayAddressFragment displayAddressFragment=new DisplayAddressFragment();
        displayAddressFragment.setArguments(mBundle);
        FragmentTransaction fm=getSupportFragmentManager().beginTransaction();
        fm.add(R.id.fragment_container, displayAddressFragment);
        fm.commitAllowingStateLoss();
    }

    /**
     * 初始化来源标志
     */
    private void getIntentData(){
        mCurrentFromType=getIntent().getIntExtra(FROM_FLAG,MANAGE_ADDRESS);
        mBundle=new Bundle();
        mBundle.putInt(FROM_FLAG, mCurrentFromType);

    }


}
