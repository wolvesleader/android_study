package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.AddressEntity;
import com.loonxi.ju53.entity.AliPayEntity;
import com.loonxi.ju53.entity.FreightRule;
import com.loonxi.ju53.entity.OrderCreateEntity;
import com.loonxi.ju53.entity.OrderDetailEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderFreightEntity;
import com.loonxi.ju53.entity.SaleOrderDetailEntity;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.models.IOrderModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.NewRequest;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.AddressService;
import com.loonxi.ju53.modules.request.service.OrderService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/18.
 */
public class OrderModel implements IOrderModel {

    /**
     * 获取默认收货地址
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonInfo<AddressEntity>> getDefaultAddress(Map<String, Object> map, Callback<JsonInfo<AddressEntity>> callback) {
        Call<JsonInfo<AddressEntity>> call = Request.creatApi(AddressService.class).getDefaultAddress(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取运费模板
     * @param map
     * @param callback
     */
    @Override
    public Call<JsonArrayInfo<FreightRule>> getFreightRule(Map<String, Object> map, Callback<JsonArrayInfo<FreightRule>> callback) {
        Call<JsonArrayInfo<FreightRule>> call = Request.creatApi(OrderService.class).getFreightRule(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 提交订单
     * @param map
     * @param callback
     */
    @Override
    public Call<OrderCreateEntity> createOrder(Map<String, Object> map, Callback<OrderCreateEntity> callback) {
        Call<OrderCreateEntity> call = Request.creatApi(OrderService.class).createOrders(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取订单
     * @param map
     * @param callback
     */
    @Override
    public Call<JsonArrayInfo<OrderEntity>> getOrders(Map<String, Object> map, Callback<JsonArrayInfo<OrderEntity>> callback){
        Call<JsonArrayInfo<OrderEntity>> call = Request.creatApi(OrderService.class).getOrders(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取退款订单
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonArrayInfo<OrderEntity>> getBackOrders(Map<String, Object> map, Callback<JsonArrayInfo<OrderEntity>> callback) {
        Call<JsonArrayInfo<OrderEntity>> call = Request.creatApi(OrderService.class).getBackOrders(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 根据订单id查询订单详情
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<OrderDetailEntity> getOrderById(Map<String, Object> map, Callback<OrderDetailEntity> callback) {
        Call<OrderDetailEntity> call = Request.creatApi(OrderService.class).getOrderById(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 确认收货
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> sureOrder(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(OrderService.class).confirmOrder(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 申请退款
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> createRefunds(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(OrderService.class).createRefunds(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 修改退款
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> updateRefunds(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(OrderService.class).updateRefunds(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 付款
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<AliPayEntity> payOrder(Map<String, Object> map, Callback<AliPayEntity> callback) {
        Call<AliPayEntity> call = Request.creatApi(OrderService.class).payOrder(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 关闭订单
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<BaseJsonInfo> closeOrder(Map<String, Object> map, Callback<BaseJsonInfo> callback) {
        Call<BaseJsonInfo> call = Request.creatApi(OrderService.class).closeOrder(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取分销订单
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonArrayInfo<SaleOrderEntity>> getSaleOrders(Map<String, Object> map, Callback<JsonArrayInfo<SaleOrderEntity>> callback) {
        Call<JsonArrayInfo<SaleOrderEntity>> call = NewRequest.creatApi(OrderService.class).getSaleOrders(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取分销订单详情
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonInfo<SaleOrderDetailEntity>> getSaleOrderDetail(Map<String, Object> map, Callback<JsonInfo<SaleOrderDetailEntity>> callback) {
        Call<JsonInfo<SaleOrderDetailEntity>> call = NewRequest.creatApi(OrderService.class).getSaleOrderDetail(map);
        call.enqueue(callback);
        return call;
    }

    /**
     * 获取进货订单运费
     * @param map
     * @param callback
     * @return
     */
    @Override
    public Call<JsonArrayInfo<OrderFreightEntity>> getSupplierFreight(Map<String, Object> map, Callback<JsonArrayInfo<OrderFreightEntity>> callback) {
        Call<JsonArrayInfo<OrderFreightEntity>> call = Request.creatApi(OrderService.class).getOrdersFreight(map);
        call.enqueue(callback);
        return call;
    }


}
