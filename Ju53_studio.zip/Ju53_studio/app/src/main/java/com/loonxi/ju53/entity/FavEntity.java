package com.loonxi.ju53.entity;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Xuzue on 2016/2/17.
 */
public class FavEntity implements Serializable{

    /**
     *  产品列表
     */
    private List<BaseProductEntity> proList;

    /**
     * 供应商列表
     */
    private List<SupplierEntity> supList;


    public List<BaseProductEntity> getProList() {
        return proList;
    }

    public void setProList(List<BaseProductEntity> proList) {
        this.proList = proList;
    }

    public List<SupplierEntity> getSupList() {
        return supList;
    }

    public void setSupList(List<SupplierEntity> supList) {
        this.supList = supList;
    }

}
