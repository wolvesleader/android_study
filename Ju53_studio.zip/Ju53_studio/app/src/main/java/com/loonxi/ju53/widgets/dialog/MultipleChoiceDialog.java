package com.loonxi.ju53.widgets.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.StringUtil;


/**
 * 自定义带“多选”功能的Dialog
 *
 * @author Administrator
 */
public class MultipleChoiceDialog extends BaseDialog {

    private ListView mLvDisplay;
    private Button mBtnOk;
    private Button mBtnCancel;

    public MultipleChoiceDialog(Context context, String title, String ok, String cancel,
                                BaseAdapter adapter, View.OnClickListener okListener,
                                View.OnClickListener cancelListener) {
        super(context);
        View v = LayoutInflater.from(context)
                .inflate(R.layout.dialog_multiplechoice, null);
        addView(v);
        mLvDisplay = (ListView) findViewById(R.id.dialog_lv_display_multiple);
        mBtnOk = (Button) findViewById(R.id.dialog_btn_ok_multiple);
        mBtnCancel = (Button) findViewById(R.id.dialog_btn_cancel_multiple);
        setTitle(StringUtil.isEmpty(title) ? context.getResources().getString(R.string.tip) : title);
        mBtnOk.setText(StringUtil.isEmpty(ok) ? context.getResources().getString(R.string.confirm) : ok);
        mBtnOk.setOnClickListener(okListener);
        mBtnCancel.setText(StringUtil.isEmpty(cancel) ? context.getResources().getString(R.string.cancel) : cancel);
        mBtnCancel.setOnClickListener(cancelListener);
        mLvDisplay.setAdapter(adapter);
    }

}
