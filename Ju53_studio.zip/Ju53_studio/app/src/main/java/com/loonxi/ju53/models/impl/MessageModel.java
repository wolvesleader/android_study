package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.LogisticsEntity;
import com.loonxi.ju53.entity.MessageArrayEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.MessageService;
import com.loonxi.ju53.repos.PrefsRepos;

import java.util.Map;

import retrofit.Call;

/**
 * "消息"model
 * Created by laojiaqi on 2016/2/2.
 */
public class MessageModel {

    /**
     * 获得消息
     * @param callback
     * @return
     */
    public Call<MessageArrayEntity> getMessage(Callback<MessageArrayEntity> callback) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        Call<MessageArrayEntity> call = Request.creatApi(MessageService.class).getMessage(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 设置已读标记
     * @param callback
     * @param pid
     * @return
     */
    public Call<BaseJsonInfo> setReadFlag(Callback<BaseJsonInfo> callback,long pid){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("pid", String.valueOf(pid));
        Call<BaseJsonInfo> call = Request.creatApi(MessageService.class).setReadFlag(map);
        call.enqueue(callback);
        return call;
    }


    /**
     * 根据订单id查询物流详情
     * @param jointId
     * @param callback
     * @return
     */
    public Call<JsonInfo<LogisticsEntity>>  getLogistics(String jointId, Callback<JsonInfo<LogisticsEntity>> callback) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("orderId", jointId);
        Call<JsonInfo<LogisticsEntity>> call = Request.creatApi(MessageService.class).getLogistics(map);
        call.enqueue(callback);
        return call;
    }



}
