package com.loonxi.ju53.views;

import java.util.Map;

/**
 * 地址信息（国外） 回调接口
 * Created by laojiaqi on 2016/1/27.
 */
public interface IOverseasAddressInfoView {
    
    public void getAddressInfoSuccess(Map<String,String> dataMap);

    public void getAddressInfoFailure(String message);
}
