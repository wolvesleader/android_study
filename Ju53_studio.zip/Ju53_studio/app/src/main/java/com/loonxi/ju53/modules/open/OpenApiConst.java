package com.loonxi.ju53.modules.open;

public class OpenApiConst {

    // 支付宝常量
    public static class AliPay {
        // 商户PID
        public static final String PARTNER = "2088901881475465";
        // 商户收款账号
        public static final String SELLER = "xiaozhu@loonxi-inc1.com";
        // 商户私钥，pkcs8格式
        public static final String RSA_PRIVATE = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIcPFaCRylDTYt+vhAfOycn41jnE1075BWasuJuImd9YfrDRQ8BGO75RPQLsTZgizyrG1u55OoTrpEMwLHAWbPvEqauPCe6sEi4CK0w/rWtXncRPfrMp+y2qOUDw0gHBtqjfi3DpyZDp1XAj9y73Tg7H6iufhy2bOJ7rBPCYJzJzAgMBAAECgYAzLZIicFxb2F5FKPs9Ai0Q7cwvw9lawZ48VAL4XQEB00Tet82WlIabDamy69xTZA1gxkw3vZRhPfHWy/Bq4PSWvbpzqChPebFglOndTMor8BNyfqh8+SREJ4vII4bwNYJQwAWNWtHgmYbl7MfDPZaa2+f6r2kM/KhbimZSLqMHIQJBAMU6hXNd14N9xbdf/ECpADGG8kUgrm38tUAMuy5klgdfxPis2gGcW4WtyiYoMc/FKrm6i3kcIMXis6PMNPr05WkCQQCvTfuMbSafA9bBJrR55j+fvDQNWLlHw4iu89mTBKC6tIJHAMITK7WibE7t+l3at7+ZdxPhBkAB6oYKm/9KGRF7AkAygdURATQikT/jwOnpaR4KkONT/pWMxw1ndJsuu0WMZ+MaR7GgffkWF7ZP5TU0XuqdG3+CKUjfRDn6tV3P8o0ZAkAKDhACkvQnJMI5m+24HDPEBrh5l4AxFI8Pcd8l5psNenMKfYmkLdqiMVIppjWh6O4tcD4Mpx4evgPoMeBnsJ5nAkABn8ArzYs+q2+2bE+B0xAoQE5QpYH5anVrfZJUOA/XmvoTFvt8bmAcMYJ7wQky/UR9/Sg+CrYpH+PqLd1053me";
        // 支付宝公钥
        public static final String RSA_PUBLIC = "";

    }

    // 微信常量
    public static class Wechat {
        public static final String APP_ID = "wx851380e2d2fdd870";
        public static final String APP_SECRET = "04e4b1c6666cb0b3019b281455d9ebbb";
        public static final String NAME = "wechat_name";
        public static final String AVATAR = "wechat_avatar";
        public static final String GENDER = "wechat_gender";
    }

    // 新浪微博用到的常量
    public static class Sina {
        public static final String APP_KEY = "3480078687";
        public static final String APP_SECRET = "ce8ca4fac736bbb4580377bd257875a4";
        public static final String REDIRECT_URL = "";
        public static final String UID = "weibo_uid";
        public static final String ACCESS_TOKEN = "weibo_access_token";
        public static final String EXPIRES_IN = "weibo_expires_in";
        public static final String NAME = "weibo_name";
        public static final String AVATAR = "weibo_avatar";
        public static final String GENDER = "weibo_gender";
        public static final String PROVINCE = "weibo_province";
        public static final String CITY = "weibo_city";
    }

    // QQ好友和空间用到的常量
    public static class Tencent {
        public static final String APP_ID = "1105167635";
        public static final String APP_KEY = "1AVHqgPOt0pYZ3xK";
        public static final String QQ_NAME = "qq_name";
        public static final String QQ_AVATAR = "qq_avatar";
        public static final String QQ_GENDER = "qq_gender";
        public static final String QQ_ACCESS_TOKEN = "qq_token";
        public static final String QQ_EXPIRES_IN = "qq_expires";
        public static final String QQ_OPEN_ID = "qq_openid";
    }

    // 腾讯微博用到的常量
    public static class TencenWeibo{
        public static final String APP_ID = "1105167635";
        public static final String APP_KEY = "1AVHqgPOt0pYZ3xK";
        public static final String TQQ_NAME = "tqq_name";
        public static final String TQQ_AVATAR = "tqq_avatar";
        public static final String TQQ_GENDER = "tqq_gender";
        public static final String TQQ_ACCESS_TOKEN = "tqq_token";
        public static final String TQQ_EXPIRES_IN = "tqq_expires";
        public static final String TQQ_OPEN_ID = "tqq_openid";
    }

}
