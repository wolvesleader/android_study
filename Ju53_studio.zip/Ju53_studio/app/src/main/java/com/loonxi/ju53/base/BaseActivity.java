package com.loonxi.ju53.base;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewStub;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.CommonWebviewActivity;
import com.loonxi.ju53.activity.LoginActivity;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.event.UpdateEvent;
import com.loonxi.ju53.listener.BackGestureListener;
import com.loonxi.ju53.listener.OnNetWorkListener;
import com.loonxi.ju53.modules.request.ApiError;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.Logger;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.widgets.dialog.LoadingDialog;
import com.loonxi.ju53.widgets.dialog.NetErrorDialog;
import com.umeng.analytics.MobclickAgent;

import cn.jpush.android.api.JPushInterface;
import de.greenrobot.event.EventBus;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Activity父类
 * Created by Xuzue on 2015/12/16.
 */
public abstract class BaseActivity extends AppCompatActivity {

    protected Context mContext;
    protected LoadingDialog mLoadingDialog;
    protected LoadingDialog mDimedLoadingDialog;
    protected NetErrorDialog mNetErrorDialog;
    protected GestureDetector mGestureDetector;
    private boolean mNeedBackGesture = false;
    private boolean mViewVisible = false;

    private static String IMEI = "";
    private static final int PERMISSION_REQUEST_READ_PHONE = 1;
    private static final int PERMISSION_REQUEST_ACCESS_COARSE_LOCATION = 2;
    private static final int PERMISSION_REQUEST_ACCESS_FINE_LOCATION = 3;
    private static final int PERMISSION_REQUEST_CALL_PHONE = 4;
    private static final int PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE = 5;
    private static final int PERMISSION_REQUEST_READ_LOGS = 6;
    private static final int PERMISSION_REQUEST_SET_DEBUG_APP = 7;
    private static final int PERMISSION_REQUEST_SYSTEM_ALERT_WINDOW = 8;
    private static final int PERMISSION_REQUEST_GET_ACCOUNTS = 9;
    private static final int PERMISSION_REQUEST_CAMERA = 10;


    protected View mEmptyView;
    protected OnNetWorkListener mNetWorkListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        mLoadingDialog = new LoadingDialog(this);
        mDimedLoadingDialog = new LoadingDialog(this, true);
        checkPermission();
        setTheme();
        initGestureDetector();
    }

    @Override
    protected void onResume() {
        mViewVisible = true;
        super.onResume();
        MobclickAgent.onResume(this);
        MobclickAgent.onPageStart(getClass().getSimpleName());
        JPushInterface.onResume(this);
        Logger.i("Activity trace:" + getClass().getSimpleName());
    }


    /**
     * 检查权限
     */
    private void checkPermission(){
        int permissionCheckReadPhone = ContextCompat.checkSelfPermission(mContext, android.Manifest.permission.READ_PHONE_STATE);
        if(permissionCheckReadPhone == PackageManager.PERMISSION_GRANTED){
            getIMEI();
        }else{
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, PERMISSION_REQUEST_READ_PHONE);
        }
        int permissionCheckCamera = ContextCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA);
        if(permissionCheckCamera == PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CAMERA);
        }
        int permissionCheckWriteEST = ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if(permissionCheckWriteEST == PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE);
        }

    }

    private void setTheme(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            //            window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    /**
     * 初始化手势监听
     */
    private void initGestureDetector() {
        if (mGestureDetector == null) {
            mGestureDetector = new GestureDetector(getApplicationContext(), new BackGestureListener(this));
        }
    }

    private void getIMEI(){
        String imei = SpUtil.getString(mContext, SpUtil.IMEI, "");
        if(!StringUtil.isEmpty(imei)){
            return;
        }
        TelephonyManager manager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if(manager != null){
            IMEI = manager.getDeviceId();
            SpUtil.putString(mContext, SpUtil.IMEI, IMEI);
        }
    }

    /**
     * 设置是否进行手势监听
     *
     * @param isNeed
     */
    public void setNeedGestureDetector(boolean isNeed) {
        mNeedBackGesture = isNeed;
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (mNeedBackGesture) {
            return mGestureDetector.onTouchEvent(ev) || super.dispatchTouchEvent(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    /**
     * Toast提示
     *
     * @param text
     */
    public void showToast(String text) {
        ToastUtil.showToast(mContext, text);
    }

    /**
     * Toast提示
     *
     * @param resId
     */
    public void showToast(int resId) {
        ToastUtil.showToast(mContext, resId);
    }

    /**
     * 显示LoadingDialog
     */
    public void showLoadingDialog() {
        showLoadingDialog(null);
    }

    /**
     * 显示LoadingDialog
     *
     * @param listener
     */
    public void showLoadingDialog(DialogInterface.OnDismissListener listener) {
        if (listener != null) {
            mLoadingDialog.setOnDismissListener(listener);
        } else {
            mLoadingDialog.setOnDismissListener(null);
        }
        mLoadingDialog.show();
    }

    /**
     * 隐藏LoadingDialog
     */
    public void dismissLoadingDialog() {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    public void showDimedLoadingDialog(){
        if(mDimedLoadingDialog != null){
            mDimedLoadingDialog.show();
        }
    }

    public void dismissDimedLoadingDialog(){
        if(mDimedLoadingDialog != null && mDimedLoadingDialog.isShowing()){
            mDimedLoadingDialog.dismiss();
        }
    }

    public void showNetErrorDialog(Activity activity, View.OnClickListener retryListener, View.OnClickListener backListener) {
        mNetErrorDialog = new NetErrorDialog(mContext, activity, retryListener, backListener);
    }

    public void dismissNeterrorDialog() {
        if (mNetErrorDialog != null && mNetErrorDialog.isShowing()) {
            mNetErrorDialog.dismiss();
        }
    }

    /**
     * 软件更新Event
     *
     * @param event
     */
    public void onEventMainThread(UpdateEvent event) {

    }

    /**
     * 判断是否登入
     * @return
     */
    public boolean isLogin() {

        return LoginUtil.isLoginNew();
    }


    /**
     * 跳转到主页
     */
    public void gotoMainActivity(String flag) {
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.putExtra(MainActivity.FROM_FLAG, flag);
        startActivity(intent);
    }

    /**
     * 跳转到普通h5
     * @param url
     * @param title
     */
    public void gotoCommonWebView(String url, String title){
        Intent webViewIntent = new Intent(mContext, CommonWebviewActivity.class);
        webViewIntent.putExtra(CommonWebviewActivity.ARG_URL_VALUE, url);
        webViewIntent.putExtra(CommonWebviewActivity.ARG_TITLE_VALUE, title);
        startActivity(webViewIntent);
    }

    /**
     * 获取EmptyView
     *
     * @param resId
     * @param sourceId
     * @return
     */
    public View getEmptyView(int resId, int sourceId) {
        return getEmptyView(resId, sourceId, true);
    }

    /**
     * 获取EmptyView
     *
     * @param resId
     * @param sourceId
     * @param btnIsVisibile
     * @return
     */
    public View getEmptyView(int resId, final int sourceId, boolean btnIsVisibile) {
        if (mEmptyView == null) {
            mEmptyView = LayoutInflater.from(mContext).inflate(R.layout.empty_list, null);
        }
        TextView mTvTip = (TextView) mEmptyView.findViewById(R.id.empty_list_tv_tip);
        TextView mBtnGo = (TextView) mEmptyView.findViewById(R.id.empty_list_btn_go);
        mTvTip.setText(getResources().getString(resId));
        mBtnGo.setVisibility(btnIsVisibile ? View.VISIBLE : View.GONE);
        mBtnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoMainActivity(MainActivity.RESET_POPWINDOW);
            }
        });
        return mEmptyView;
    }


    /**
     * 设置网络未连接的View
     *
     * @param hideView 需隐藏的View
     * @param showView 网络出错的View
     * @param isError  true:显示网络未连接 false:隐藏网络未连接
     */
    public void setNetErrorView(View hideView, View showView, boolean isError) {
        if (hideView == null || showView == null) {
            return;
        }
        hideView.setVisibility(isError ? View.GONE : View.VISIBLE);
        showView.setVisibility(isError ? View.VISIBLE : View.GONE);
        if (showView instanceof ViewStub) {
            ViewStub mStub = (ViewStub) showView;
            View stubView = findViewById(mStub.getInflatedId());
            if (stubView != null) {
                LogUtil.mLog().i("find");
                stubView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mNetWorkListener != null) {
                            mNetWorkListener.OnRetry();
                        }
                    }
                });
            }
        }
    }

    /**
     * 错误检查（无视图替换）
     *
     * @param apiErrorCode
     * @param strId
     */
    public void checkError(int apiErrorCode, int strId) {
        checkError(apiErrorCode, getString(strId));
    }

    /**
     * 错误检查（无视图替换）
     *
     * @param apiErrorCode
     * @param message
     */
    public void checkError(int apiErrorCode, String message) {
        checkError(apiErrorCode, message, null, null);
    }

    /**
     * 错误检查有视图替换
     *
     * @param apiErrorCode
     * @param strId
     * @param hideView     替换视图
     */
    public void checkError(int apiErrorCode, int strId, View hideView, View showView) {
        checkError(apiErrorCode, getString(strId), hideView, showView);
    }

    /**
     * 错误检查（有视图替换）
     *
     * @param apiErrorCode
     * @param message
     * @param hideView     替换视图
     */
    protected void checkError(int apiErrorCode, String message, View hideView, View showView) {
        switch (apiErrorCode) {
            case ApiError.REQUEST_FAILURE:
                if (hideView != null && showView != null && mNetWorkListener != null) {
                    setNetErrorView(hideView, showView, true);
                } else {
                    showToast(R.string.error_disconnect);
                }
                break;
            case ApiError.HTTP:
                showToast(R.string.error_http);
                break;
            case ApiError.TIMEOUT:
                showToast(R.string.error_timeout);
                break;
            case ApiError.REQUEST_FAILURE_OFFLINE:
                startActivity(new Intent(mContext, LoginActivity.class));
                break;
            default:
                if(!StringUtil.isEmpty(message)){
                    showToast(message);
                }
                break;

        }
    }

    protected void setOnNetWorkListener(OnNetWorkListener listener) {
        mNetWorkListener = listener;
    }

    @Override
    protected void onPause() {
        super.onPause();
        mViewVisible = false;
        MobclickAgent.onPause(this);
        MobclickAgent.onPageEnd(getClass().getSimpleName());
        JPushInterface.onPause(this);
        //        ToastUtil.cancelToast();
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mViewVisible = false;
        //        ToastUtil.cancelToast();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }
    /**
     * 隐藏键盘
     */
    public void hiddenKeyboard(){
        // Check if no view has focus:
        View view =  this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode){
            case PERMISSION_REQUEST_READ_PHONE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    getIMEI();
                }else{
                }
                break;
        }

    }
}
