package com.loonxi.ju53.constants;

/**
 * Created by Xuzue on 2015/12/15.
 */
public class ApiConst {

    /**
     * JAVA接口请求根目录
     */
    public static String URL_ROOT = ApiConst.URL_ROOT_OUTER_DOMAIN;
    public static final String URL_ROOT_LOCAL_TEST = "http://192.168.1.241:8080/ms-server-test/";//测试环境
    public static final String URL_ROOT_LOCAL_DEV = "http://192.168.1.241:8080/ms-server/";//开发环境
    public static final String URL_ROOT_OUTER_85 = "http://120.26.68.224:8085/ms-server/";//正式环境8085
    public static final String URL_ROOT_OUTER_80 = "http://120.26.68.224:8080/ms-server/";//正式环境8080
    public static final String URL_ROOT_OUTER_DOMAIN = "http://server.ju53.com/";//正式环境
    /**
     * PHP接口请求根目录
     */
    public static String URL_ROOT_PHP = ApiConst.URL_ROOT_OUTER_DOMAIN_PHP;
    public static final String URL_ROOT_LOCAL_TEST_PHP = "http://192.168.1.241:80/";//测试环境
    public static final String URL_ROOT_LOCAL_DEV_PHP = "http://192.168.1.241:80/";//开发环境
    public static final String URL_ROOT_OUTER_DOMAIN_PHP = "http://120.26.68.224:80/";//正式环境


    public static String URL_UPLOAD_PIC_STORE = "store/modifylogo";//店铺LOGO修改
    public static String URL_UPLOAD_PIC_USER_HEAD = "store/modifyHead";//用户头像修改

    public static final String OUTER_URL_ROOT = "http://t.ju53.com/api/gettaobaoauth?";
    public static final String TRANS_ORDER_URL = "http://t.ju53.com/send/orders?";//查询物流地址
    public static final String TRANS_DETAIL_URL = "http://api.kuaidi.com/";//爱快递查询物流地址
    public static final String QUESTION_URL = "http://ts.ju53.com/help/help";//常见问题地址
    public static final String PROTOCAL_URL = "http://t.ju53.com/send/trade";//在线交易服务条款

    /**
     * 注册密钥
     */
    public static final String KEY_REGISTER = "2p9o9hhel5umoedch58fun337p2yxhve";
    public static final String KEY_AES = "";

    /**
     * 需加密的请求中必须传的常量值
     */
    public class Code {
        public static final String LOGIN = "201";//登录
        public static final String REGIST_GET_CODE = "101";//获取验证码
        public static final String REGIST_VERIFY_CODE = "102";//检验验证码
        public static final String REGIST_AUTH = "103";//注册
        public static final String PSWD_FORGET = "202";//忘记密码
        public static final String PSWD_UPDATE = "203";//修改密码
    }

    public class Common {
        /**
         * 缩略图最大大小（单位：kb）
         */
        public static final int MINI_PIC_MAX_SIZE = 50;
    }

}
