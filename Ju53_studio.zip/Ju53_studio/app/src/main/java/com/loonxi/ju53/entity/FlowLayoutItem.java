package com.loonxi.ju53.entity;

/**
 *
 * Created by Xuzue on 2016/3/2.
 */
public class FlowLayoutItem {
    String name;
    int position;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
