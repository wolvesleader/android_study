package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.utils.IntentUtil;
import com.loonxi.ju53.utils.StringUtil;

/**
 * Created by XuZue on 2016/5/9 0009.
 */
public class UploadPicDialog extends Dialog implements View.OnClickListener {

    private Activity mActivity;
    private TextView mTvTitle;
    private TextView mTvCamera;
    private TextView mTvAlbum;
    private TextView mTvCancel;

    private String mTitle;
    private String mDirPath;
    private String mPicName;
    private Context mContext;

    public UploadPicDialog(Activity activity, Context context, String dirPath, String picName) {
        this(activity, context, "", dirPath, picName);
    }

    public UploadPicDialog(Activity activity, Context context, String title, String dirPath, String picName) {
        super(context, R.style.cartdialog_style);
        if (context == null) {
            return;
        }
        mContext = context;
        mActivity = activity;
        mTitle = title;
        mDirPath = dirPath;
        mPicName = picName;
        setContentView(R.layout.dialog_upload_pic);
        setCancelable(true);
        initView();
        initContent();
        setListener();
    }

    private void initView() {
        mTvTitle = (TextView) findViewById(R.id.dialog_upload_pic_tv_title);
        mTvCamera = (TextView) findViewById(R.id.dialog_upload_pic_tv_photo);
        mTvAlbum = (TextView) findViewById(R.id.dialog_upload_pic_tv_album);
        mTvCancel = (TextView) findViewById(R.id.dialog_upload_pic_tv_cancle);
    }

    private void initContent() {
        mTvTitle.setText(StringUtil.isEmpty(mTitle) ? "上传图片" : mTitle);
    }

    private void setListener() {
        mTvCamera.setOnClickListener(this);
        mTvAlbum.setOnClickListener(this);
        mTvCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.dialog_upload_pic_tv_photo:
                IntentUtil.intentToCamera(mActivity, getContext(), mDirPath,
                        mPicName);
                break;
            case R.id.dialog_upload_pic_tv_album:
                IntentUtil.intentToAlbum(mActivity);
                break;
            case R.id.dialog_upload_pic_tv_cancle:
                break;
        }
        dismiss();
    }


    public void setDialogAttribute(Activity activity, int gravity) {
        if (activity == null) {
            return;
        }
        Display display = activity.getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = (int) display.getWidth();
        lp.gravity = gravity;
        getWindow().setAttributes(lp);
    }
}
