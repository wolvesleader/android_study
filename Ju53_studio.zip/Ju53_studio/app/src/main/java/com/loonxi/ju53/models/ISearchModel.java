package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/1/6.
 */
public interface ISearchModel {
    Call<JsonArrayInfo<BaseProductEntity>> getSearchList(Map<String, Object> map, Callback<JsonArrayInfo<BaseProductEntity>> callback);
    Call<JsonArrayInfo<BaseProductEntity>> getSortSearchList(Map<String, Object> map, Callback<JsonArrayInfo<BaseProductEntity>> callback);
    Call<JsonArrayInfo<String>> getHotSearch(Map<String, Object> map, Callback<JsonArrayInfo<String>> callback);
}
