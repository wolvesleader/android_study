package com.loonxi.ju53.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.util.ArrayList;
import java.util.List;

/**
 * 手机通讯录工具类
 * Created by Xuze on 2015/9/12.
 */
public class ContactsUtil {

    /**
     * 获取手机联系人
     * @param context
     * @return
     */
    public static List<Contact> getPhoneContacts(Context context){
        int contactIdIndex = 0;
        int nameIndex = 0;
        Cursor cursor = context.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if(cursor.getCount() > 0){
            contactIdIndex = cursor.getColumnIndex(ContactsContract.Contacts._ID);
            nameIndex = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
        }
        List<Contact> contacts = new ArrayList<Contact>();
        while (cursor.moveToNext()){
            String contactId = cursor.getString(contactIdIndex);
            String name = cursor.getString(nameIndex);
            //查找该联系人的phone信息
            Cursor phones = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=" + contactId,
                    null,
                    null);
            int phoneIndex = 0;
            if(phones.getCount() > 0){
                phoneIndex = phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            }
            List<String> contactPhones = new ArrayList<String>();
            while (phones.moveToNext()){
                String phoneNumber = phones.getString(phoneIndex);
                contactPhones.add(phoneNumber);
            }
            //查找该联系人的email信息
            Cursor emails = context.getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=" + contactId,
                    null,
                    null);
            int emailIndex = 0;
            if(emails.getCount() > 0){
                emailIndex = emails.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA);
            }
            List<String> contactEamils = new ArrayList<String>();
            while (emails.moveToNext()){
                String email = emails.getString(emailIndex);
                contactEamils.add(email);
            }
            Contact contact = new Contact();
            contact.setContactId(contactId);
            contact.setName(name);
            contact.setPhones(contactPhones);
            contact.setEmails(contactEamils);
            contacts.add(contact);
        }
        return contacts;
    }

    /**
     * 获取SIM卡联系人
     * @param context
     * @return
     */
    public static List<Contact> getSIMContacts(Context context){
        List<Contact> contacts = new ArrayList<Contact>();
        Uri uri = Uri.parse("content://icc/adn");
        Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
        int contactIndex = 0;
        int nameIndex = 0;
        int numberIndex = 0;
        if(cursor.getCount() > 0){
            contactIndex = cursor.getColumnIndex(ContactsContract.Contacts._ID);
            nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
        }
        while (cursor.moveToNext()){
            String contactId = cursor.getString(contactIndex);
            String name = cursor.getString(nameIndex);
            List<String> contactPhones = new ArrayList<String>();
            String phone = cursor.getString(nameIndex);
            contactPhones.add(phone);
            Contact contact = new Contact();
            contact.setContactId(contactId);
            contact.setName(name);
            contact.setPhones(contactPhones);
            contacts.add(contact);
        }
        return contacts;
    }


    /**
     * 联系人实体类
     */
    private static class Contact{
        String contactId;
        String name;
        List<String> phones;
        List<String> emails;

        public Contact(){

        }

        public String getContactId() {
            return contactId;
        }

        public void setContactId(String contactId) {
            this.contactId = contactId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<String> getPhones() {
            return phones;
        }

        public void setPhones(List<String> phones) {
            this.phones = phones;
        }

        public List<String> getEmails() {
            return emails;
        }

        public void setEmails(List<String> emails) {
            this.emails = emails;
        }
    }

}
