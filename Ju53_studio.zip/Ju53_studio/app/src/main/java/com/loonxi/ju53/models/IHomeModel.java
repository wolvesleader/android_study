package com.loonxi.ju53.models;

import com.loonxi.ju53.entity.GetVersionEntity;
import com.loonxi.ju53.entity.IndexEntity;
import com.loonxi.ju53.entity.IndexJsonInfo;
import com.loonxi.ju53.entity.MainTabEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2015/12/18.
 */
public interface IHomeModel {
    Call<IndexJsonInfo> getIndexContent(Map<String, Object> map, Callback<IndexJsonInfo> callback);
    Call<JsonArrayInfo<IndexEntity>> getRecommends(Map<String, Object> map, Callback<JsonArrayInfo<IndexEntity>> callback);
    Call<GetVersionEntity> getVersion(Callback<GetVersionEntity> callback);

    Call<JsonArrayInfo<MainTabEntity>>  getMainTab(Callback<JsonArrayInfo<MainTabEntity>> callback);
}
