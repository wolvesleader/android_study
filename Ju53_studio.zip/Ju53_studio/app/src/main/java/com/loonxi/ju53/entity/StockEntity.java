package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Xuzue on 2016/1/11.
 */
public class StockEntity implements Parcelable {
    private String skuName;
    private long stock;
    private long stockId;
    private double price;

    public StockEntity(){

    }

    protected StockEntity(Parcel in) {
        skuName = in.readString();
        stock = in.readLong();
        stockId = in.readLong();
        price = in.readDouble();
    }

    public static final Creator<StockEntity> CREATOR = new Creator<StockEntity>() {
        @Override
        public StockEntity createFromParcel(Parcel in) {
            return new StockEntity(in);
        }

        @Override
        public StockEntity[] newArray(int size) {
            return new StockEntity[size];
        }
    };

    public long getStockId() {
        return stockId;
    }

    public void setStockId(long stockId) {
        this.stockId = stockId;
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    public long getStock() {
        return stock;
    }

    public void setStock(long stock) {
        this.stock = stock;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(skuName);
        dest.writeLong(stock);
        dest.writeLong(stockId);
        dest.writeDouble(price);
    }
}
