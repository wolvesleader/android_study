package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.SaleOrderEntity;
import com.loonxi.ju53.models.IOrderModel;
import com.loonxi.ju53.models.impl.OrderModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.ISaleOrderView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by XuZue on 2016/5/7 0007.
 */
public class SaleOrderPresenter extends BasePresenter<ISaleOrderView> {

    private ISaleOrderView mView;
    private IOrderModel mModel;

    public SaleOrderPresenter(ISaleOrderView view) {
        super(view);
        mView = getView();
        mModel = new OrderModel();
    }

    /**
     * 获取分销订单
     *
     * @param position
     * @param showLoadingDialog
     */
    public void getOrders(int position, int page, final boolean showLoadingDialog) {
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("page", page + "");
        map.put("pageSize", "10");
        switch (position) {
            case 0://全部
                break;
            case 1:
//                map.put("state", "0");//待付款
                map.put("state", 0);//待付款
                break;
            case 2:
//                map.put("state", "1");//待发货
                map.put("state", 1);//待发货
                break;
            case 3:
//                map.put("state", "6");//待收货
                map.put("state", 6);//待收货
                break;
            case 4:
//                map.put("state", "refunds");//退款中
                map.put("state", -2);//退款中
                break;
        }
        if (showLoadingDialog && mView != null) {
            mView.startAsyncTask();
        }
        mModel.getSaleOrders(map, new Callback<JsonArrayInfo<SaleOrderEntity>>() {
            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<SaleOrderEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<SaleOrderEntity> data, Retrofit retrofit) {
                if (mView != null) {
                    mView.onGetOrdersSuccess(data);
                }
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView != null) {
                    mView.onGetOrdersFailed(apiErrorCode, message);
                }
            }
        });
    }


}
