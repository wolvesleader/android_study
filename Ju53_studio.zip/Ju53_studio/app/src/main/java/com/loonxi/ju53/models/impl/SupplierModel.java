package com.loonxi.ju53.models.impl;

import com.loonxi.ju53.entity.SupplierEntity;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.Request;
import com.loonxi.ju53.modules.request.beans.JsonInfo;
import com.loonxi.ju53.modules.request.service.SupplierService;

import java.util.Map;

import retrofit.Call;

/**
 * Created by Xuzue on 2016/2/18.
 */
public class SupplierModel {
    /**
     * 获取供销商信息
     * @param map
     * @param callback
     * @return
     */
    public Call<JsonInfo<SupplierEntity>> getSupplierInfo(Map<String, Object> map, Callback<JsonInfo<SupplierEntity>> callback){
        Call<JsonInfo<SupplierEntity>> call = Request.creatApi(SupplierService.class).getSupplierInfo(map);
        call.enqueue(callback);
        return call;
    }
}
