package com.loonxi.ju53.listener;

/**
 * Created by XuZue on 2016/6/3 0003.
 */
public interface SortFragmentLifeCircle {

    public void fragmentResume(String firstShowSort);
}
