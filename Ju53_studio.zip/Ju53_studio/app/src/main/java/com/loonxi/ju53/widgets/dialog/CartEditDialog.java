package com.loonxi.ju53.widgets.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.convert.CartDataConvert;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.FlowLayoutItem;
import com.loonxi.ju53.entity.ProductAttributeEntity;
import com.loonxi.ju53.entity.ProductRuleEntity;
import com.loonxi.ju53.entity.StockEntity;
import com.loonxi.ju53.utils.FlowLayoutUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.widgets.CircularImage;
import com.loonxi.ju53.widgets.FlowLinearLayout;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by Xuzue on 2015/12/30.
 */
public class CartEditDialog extends Dialog {

    private static int DEFAULT_POSITION = -1;
    private static String DEFAULT_NAME = "";

    private Context mContext;
    private onCartConfirmListener mListener;

    private RelativeLayout mLayoutClose;
    private CircularImage mIvHead;
    private TextView mTvPrice;
    private TextView mTvStock;
    private TextView mTvAttribute;
    private FlowLinearLayout mLayoutColor;

    private FlowLinearLayout mLayoutSize;
    private TextView mTvKey1;

    private TextView mTvKey2;
    private LinearLayout mLayoutConfirmTwo;

    private LinearLayout mLayoutNum;
    private ImageButton mIbtnMinus;
    private ImageButton mIbtnPlus;
    private TextView mTvNums;

    private LinearLayout mLayoutConfirm;
    private TextView mTvBottomAddtocart;
    private TextView mTvBottomTobuy;

    private BaseProductEntity mProduct;
    private ProductAttributeEntity mAttribute;
    private List<ProductRuleEntity> mCarSigleTypeList;
    private boolean mIsOne;
    private HashSet<String> mAttrbuteOneSet;
    private HashSet<String> mAttrbuteTwoSet;

    private double mAttributePrice;
    private long mStockTotal = 0;
    private String mAttrbuteOneName = DEFAULT_NAME;
    private String mAttrbuteTwoName = DEFAULT_NAME;
    private int NUM = 1;

    private View.OnClickListener mAttrbuteOneListener;
    private View.OnClickListener mAttrbuteTwoListener;

    private int mAttrbuteOneCurrentPosition = DEFAULT_POSITION;
    private int mAttrbuteTwoCurrentPosition = DEFAULT_POSITION;
    private long mStockId = DEFAULT_POSITION;


    public CartEditDialog(Context context, BaseProductEntity product, ProductAttributeEntity attribute, onCartConfirmListener listener) {
        super(context, R.style.cartdialog_style);
        mContext = context;
        mListener = listener;
        mProduct = product;
        mAttribute = attribute;
        setContentView(R.layout.dialog_cart_edit);
        setCancelable(true);
        initView();
        convertValue(attribute);

        initSelectedItem(product.getAttributeColor(), product.getAttributeMula());
    }

    /**
     * 设置dialog属性（宽度，对齐方式等）
     *
     * @param activity
     * @param gravity
     */
    public void setDialogAttribute(Activity activity, int gravity) {
        if(activity == null){
            return;
        }
        Display display = activity.getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = (int) display.getWidth();
        lp.gravity = gravity;
        getWindow().setAttributes(lp);
    }

    /**
     * 设置数量编辑view的可见性
     *
     * @param visibility
     */
    public void setLayoutNumVisibility(int visibility) {
        mLayoutNum.setVisibility(visibility);
    }

    /**
     * 初始化第一次选中
     *
     * @param attrOne
     * @param attrTwo
     */
    private void initSelectedItem(String attrOne, String attrTwo) {
        int num = mLayoutSize.getChildCount();
        for (int i = 0; i < num; i++) {
            TextView temp = (TextView) mLayoutSize.getChildAt(i);
            if (!StringUtil.isEmpty(attrOne) && attrOne.equals(temp.getText().toString())) {
                FlowLayoutUtil.setView(mContext, mLayoutSize, i);
                mAttrbuteOneCurrentPosition = i;
                mAttrbuteOneName = attrOne;
                break;
            }
        }
        num = mLayoutColor.getChildCount();
        for (int i = 0; i < num; i++) {
            TextView temp = (TextView) mLayoutColor.getChildAt(i);
            if (!StringUtil.isEmpty(attrTwo) && attrTwo.equals(temp.getText().toString())) {
                FlowLayoutUtil.setView(mContext, mLayoutColor, i);
                mAttrbuteTwoCurrentPosition = i;
                mAttrbuteTwoName = attrTwo;
                break;
            }
        }
        setDialogTitle(mAttrbuteOneName, mAttrbuteTwoName);
    }

    /**
     * 转换购物车数据
     *
     * @param attribute
     */
    private void convertValue(ProductAttributeEntity attribute) {
        mCarSigleTypeList = CartDataConvert.converData(attribute);
        if (mCarSigleTypeList != null && mCarSigleTypeList.size() > 0) {
            initClickListener();
            generateAttrbuteSet();
            generateView(mIsOne);
        }

    }

    /**
     * 设置button按钮监听
     */
    private void initClickListener() {
        mAttrbuteOneListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object object = v.getTag();
                if (object == null || mContext == null) {
                    return;
                }
                FlowLayoutItem itemInfor = (FlowLayoutItem) object;
                int position = itemInfor.getPosition();
                String name = itemInfor.getName();

                FlowLayoutUtil.resetView(mContext, mLayoutSize, mAttrbuteOneCurrentPosition);
                if (position != mAttrbuteOneCurrentPosition) {
                    FlowLayoutUtil.setView(mContext, mLayoutSize, position);
                    mAttrbuteOneCurrentPosition = position;
                    mAttrbuteOneName = name;
                } else {
                    mAttrbuteOneCurrentPosition = DEFAULT_POSITION;
                    mAttrbuteOneName = DEFAULT_NAME;
                }
                if (!mAttrbuteTwoName.equals(DEFAULT_NAME) && !mAttrbuteOneName.equals(DEFAULT_NAME)) {
                    setDialogTitle(mAttrbuteOneName, mAttrbuteTwoName);
                } else {
                    //TODO
                    resetDialogTitle();
                }
            }
        };

        mAttrbuteTwoListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object object = v.getTag();
                if (object == null || mContext == null) {
                    return;
                }
                FlowLayoutItem itemInfor = (FlowLayoutItem) object;
                int position = itemInfor.getPosition();
                String name = itemInfor.getName();

                FlowLayoutUtil.resetView(mContext, mLayoutColor, mAttrbuteTwoCurrentPosition);
                if (position != mAttrbuteTwoCurrentPosition) {
                    FlowLayoutUtil.setView(mContext, mLayoutColor, position);
                    mAttrbuteTwoCurrentPosition = position;
                    mAttrbuteTwoName = name;
                } else {
                    mAttrbuteTwoCurrentPosition = DEFAULT_POSITION;
                    mAttrbuteTwoName = DEFAULT_NAME;
                }

                if (!mAttrbuteOneName.equals(DEFAULT_NAME) && !mAttrbuteTwoName.equals(DEFAULT_NAME)) {
                    setDialogTitle(mAttrbuteOneName, mAttrbuteTwoName);
                } else {
                    //TODO
                    resetDialogTitle();
                }
            }
        };
    }


    /**
     * 设置库存，已选信息
     *
     * @param attrbuteOne
     * @param attrbuteTwo
     */
    private void setDialogTitle(String attrbuteOne, String attrbuteTwo) {
        if (mTvPrice == null || mTvStock == null || mTvAttribute == null) {
            return;
        }
        ProductRuleEntity temp = setarchBean(attrbuteOne, attrbuteTwo);
        if (temp == null) {
            return;
        }

        String selectOne = StringUtil.isEmpty(temp.getAttrbuteOne()) ? "" : temp.getAttrbuteOne();
        String selectTwo = StringUtil.isEmpty(temp.getAttrbuteTwo()) ? "" : temp.getAttrbuteTwo();

        mStockTotal = temp.getStock();
        mAttributePrice = temp.getPrice();
        mTvPrice.setText("¥" + temp.getPrice());
        mTvStock.setText("库存" + temp.getStock() + "件");
        mTvAttribute.setText("已选：" + selectOne + " " + selectTwo);
        mStockId = temp.getStockId();
    }

    /**
     * 重置Title
     */
    private void resetDialogTitle() {
//        mTvPrice.setText("¥");
//        mTvStock.setText("库存");
        mTvAttribute.setText("已选：" + mAttrbuteOneName + " " + mAttrbuteTwoName);
    }


    private ProductRuleEntity setarchBean(String attrbuteOne, String attrbuteTwo) {
        if (mCarSigleTypeList == null || mCarSigleTypeList.size() == 0 || TextUtils.isEmpty(attrbuteOne) ||
                TextUtils.isEmpty(attrbuteTwo)) {
            return null;
        }
        for (ProductRuleEntity temp : mCarSigleTypeList) {
            if (attrbuteOne.equals(temp.getAttrbuteOne()) && attrbuteTwo.equals(temp.getAttrbuteTwo())) {
                return temp;
            }
        }
        return null;
    }


    /**
     * 产生属性集合
     */
    private void generateAttrbuteSet() {
        if (mCarSigleTypeList == null && mCarSigleTypeList.size() == 0) {
            return;
        }
        mAttrbuteOneSet = new HashSet<>();
        mAttrbuteTwoSet = new HashSet<>();
        for (ProductRuleEntity temp : mCarSigleTypeList) {
            if (temp.getAttrbuteOne() != null) {
                mAttrbuteOneSet.add(temp.getAttrbuteOne());
            }
            if (temp.getAttrbuteTwo() != null) {
                mAttrbuteTwoSet.add(temp.getAttrbuteTwo());
            }
        }

    }


    /**
     * 生成标签页
     *
     * @param isOne
     */
    private void generateView(boolean isOne) {
        if (mAttrbuteOneSet == null || mAttrbuteTwoSet == null) {
            return;
        }
        if (mLayoutSize != null && mLayoutSize.getChildCount() > 0) {
            mLayoutSize.removeAllViews();
        }

        Iterator<String> mOneIterator = mAttrbuteOneSet.iterator();
        while (mOneIterator.hasNext()) {
            String name = mOneIterator.next();
            TextView textView = FlowLayoutUtil.addTextView(mContext, name);
            textView.setOnClickListener(mAttrbuteOneListener);
            FlowLayoutUtil.addInfoToView(name, textView, mLayoutSize);
            mLayoutSize.addView(textView);
        }
        if (!isOne) {
            if (mLayoutColor != null && mLayoutColor.getChildCount() > 0) {
                mLayoutColor.removeAllViews();
            }
            Iterator<String> mTwoIterator = mAttrbuteTwoSet.iterator();
            while (mTwoIterator.hasNext()) {
                String name = mTwoIterator.next();
                TextView textView = FlowLayoutUtil.addTextView(mContext, name);
                textView.setOnClickListener(mAttrbuteTwoListener);
                FlowLayoutUtil.addInfoToView(name, textView, mLayoutColor);
                mLayoutColor.addView(textView);
            }
        }
    }

    private void initView() {
        mLayoutClose = (RelativeLayout) findViewById(R.id.dialog_cart_edit_layout_close);
        mIvHead = (CircularImage) findViewById(R.id.dialog_cart_edit_iv_head);
        mTvPrice = (TextView) findViewById(R.id.dialog_cart_edit_tv_price);
        mTvStock = (TextView) findViewById(R.id.dialog_cart_edit_tv_stock);
        mTvAttribute = (TextView) findViewById(R.id.dialog_cart_edit_tv_selected);
        mLayoutColor = (FlowLinearLayout) findViewById(R.id.dialog_cart_edit_layout_color_container);
        mLayoutSize = (FlowLinearLayout) findViewById(R.id.dialog_cart_edit_layout_size_container);
        mTvKey1 = (TextView) findViewById(R.id.dialog_cart_edit_tv_key_1);
        mTvKey2 = (TextView) findViewById(R.id.dialog_cart_edit_tv_key_2);
        mLayoutNum = (LinearLayout) findViewById(R.id.dialog_cart_edit_layout_num);
        mIbtnMinus = (ImageButton) findViewById(R.id.dialog_cart_edit_btn_minus);
        mIbtnPlus = (ImageButton) findViewById(R.id.dialog_cart_edit_btn_plus);
        mTvNums = (TextView) findViewById(R.id.dialog_cart_edit_tv_num);
        mLayoutConfirm = (LinearLayout) findViewById(R.id.dialog_cart_edit_layout_confirm);
        mLayoutConfirmTwo = (LinearLayout) findViewById(R.id.dialog_cart_edit_layout_confirm_two);
        mTvBottomAddtocart = (TextView) findViewById(R.id.dialog_cart_edit_tv_bottom_addtocart);
        mTvBottomTobuy = (TextView) findViewById(R.id.dialog_cart_edit_tv_bottom_tobuy);

        if(mContext != null) {
            Glide.with(mContext).load(AppConst.PIC_HEAD + mProduct.getPicture() + AppConst.PIC_SIZE_80).placeholder(R.color.white).into(mIvHead);
        }
        mTvPrice.setText("¥" + mProduct.getPrice());
        mTvStock.setText("库存" + mProduct.getStock() + "件");
        String color = StringUtil.isEmpty(mProduct.getAttributeColor()) ? "" : mProduct.getAttributeColor();
        String size = StringUtil.isBlank(mProduct.getAttributeMula()) ? "" : mProduct.getAttributeMula();
        mTvAttribute.setText("已选：" + color + " " + size);

        setAttribute();

        mLayoutClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        mIbtnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NUM <= 1) {
                    return;
                }
                NUM--;
                mTvNums.setText(NUM + "");
            }
        });
        mIbtnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NUM++;
                mTvNums.setText(NUM + "");
            }
        });
        mLayoutConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!TextUtils.isEmpty(mAttrbuteOneName) && !TextUtils.isEmpty(mAttrbuteTwoName) && mStockTotal <= 0){
                    ToastUtil.showToast(mContext, R.string.shopping_sku_empty);
                    return;
                }
                if (!TextUtils.isEmpty(mAttrbuteOneName) && !TextUtils.isEmpty(mAttrbuteTwoName)) {
                    dismiss();
                    mListener.OnConfirm(mAttributePrice, mAttrbuteOneName, mAttrbuteTwoName, mStockId, NUM);
                } else {
                    ToastUtil.showToast(mContext, R.string.shopping_attribute_empty);
                }

            }
        });
        mTvBottomAddtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!TextUtils.isEmpty(mAttrbuteOneName) && !TextUtils.isEmpty(mAttrbuteTwoName) && mStockTotal <= 0){
                    ToastUtil.showToast(mContext, R.string.shopping_sku_empty);
                    return;
                }
                if (!TextUtils.isEmpty(mAttrbuteOneName) && !TextUtils.isEmpty(mAttrbuteTwoName)) {
                    dismiss();
                    mListener.AddtoCart(mAttributePrice, mAttrbuteOneName, mAttrbuteTwoName, mStockId, NUM);
                } else {
                    ToastUtil.showToast(mContext, R.string.shopping_attribute_empty);
                }
            }
        });
        mTvBottomTobuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!TextUtils.isEmpty(mAttrbuteOneName) && !TextUtils.isEmpty(mAttrbuteTwoName) && mStockTotal <= 0){
                    ToastUtil.showToast(mContext, R.string.shopping_sku_empty);
                    return;
                }
                if (!TextUtils.isEmpty(mAttrbuteOneName) && !TextUtils.isEmpty(mAttrbuteTwoName)) {
                    dismiss();
                    mListener.Buy(mAttributePrice, mAttrbuteOneName, mAttrbuteTwoName, mStockId, NUM);
                } else {
                    ToastUtil.showToast(mContext, R.string.shopping_attribute_empty);
                }
            }
        });
    }

    public void setLayoutConfirmVisibility(int visibility) {
        mLayoutConfirm.setVisibility(visibility);
    }

    public void setLayoutConfirmTwoVisibility(int visibility) {
        mLayoutConfirmTwo.setVisibility(visibility);
    }

    /**
     * 设置属性
     */
    private void setAttribute() {
        if (mAttribute == null) {
            return;
        }
        String prop = mAttribute.getSkuProp();
        String prop1 = "";
        String prop2 = "";
        Map<String, List<StockEntity>> attributeMap = mAttribute.getSkuName();
        if (!StringUtil.isEmpty(prop)) {
            if (prop.indexOf("_") != -1) {//多个属性
                String[] props = prop.split("_");
                if (props.length >= 2) {
                    prop1 = props[0];
                    prop2 = props[1];
                    mTvKey1.setText(prop1);
                    mTvKey2.setText(prop2);
                }
            } else {//单个属性
                mTvKey1.setText(prop);
            }
        }
        mIsOne = (!StringUtil.isEmpty(prop1) && !StringUtil.isEmpty(prop2)) ? false : true;
    }


    public interface onCartConfirmListener {
        void OnConfirm(double price, String color, String size, long stockId, int count);

        void AddtoCart(double price, String color, String size, long stockId, int count);

        void Buy(double price, String color, String size, long stockId, int count);
    }

}
