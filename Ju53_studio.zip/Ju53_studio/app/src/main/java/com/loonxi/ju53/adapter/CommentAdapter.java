package com.loonxi.ju53.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseObjectListAdapter;
import com.loonxi.ju53.entity.ProductCommentEntity;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.utils.TimeUtil;

import java.util.List;

/**
 * Created by Xuzue on 2016/2/22.
 */
public class CommentAdapter extends BaseObjectListAdapter<ProductCommentEntity> {
    public CommentAdapter(Context context, List<ProductCommentEntity> datas) {
        super(context, datas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.listitem_comment, null);
            holder.mTvUser = (TextView) convertView.findViewById(R.id.listitem_comment_user);
            holder.mTvContent = (TextView) convertView.findViewById(R.id.listitem_comment_content);
            holder.mTvTime = (TextView) convertView.findViewById(R.id.listitem_comment_time);
            holder.mTvAttribute = (TextView) convertView.findViewById(R.id.listitem_comment_attribute);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        ProductCommentEntity comment = get(position);
        holder.mTvUser.setText(comment.getUserName());
        holder.mTvContent.setText(comment.getContent());
        holder.mTvTime.setText(TimeUtil.getFormatTimeFromTimestamp(comment.getCreated(), "yyyy-MM-dd HH:MM:ss"));
        holder.mTvAttribute.setText(StringUtil.isEmpty(comment.getProductSpec()) ? "" : comment.getProductSpec());

        return convertView;
    }


    class ViewHolder {
        TextView mTvUser;
        TextView mTvContent;
        TextView mTvTime;
        TextView mTvAttribute;
    }
}
