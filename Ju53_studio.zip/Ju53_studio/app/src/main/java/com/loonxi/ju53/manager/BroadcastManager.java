package com.loonxi.ju53.manager;

import android.content.Context;
import android.content.Intent;

import com.loonxi.ju53.constants.AppConst;

/**
 * Created by XuZue on 2016/5/12 0012.
 */
public class BroadcastManager {

    /**
     * 店铺商品信息改变（上架、下架、删除等）
     * @param context
     */
    public static void sendStoreProductChanged(Context context) {
        if (context == null) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction(AppConst.Action.ACTION_STORE_ALT_PRODUCT);
        context.sendBroadcast(intent);
    }

}
