package com.loonxi.ju53.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 代理商品
 * Created by Xuzue on 2016/2/19.
 */
public class AgentProductEntity implements Serializable{

    /**
     *  供应商ID
     */
    private Long supplierUserId;

    /**
     *  供应商名称
     */
    private String supplierUserName;


    /**
     *  最近修改时间
     */
    private long modified;

    /**
     *  产品名称
     */
    private String productName;


    /**
     * 产品List
     */
    private List<BaseProductEntity> list;


    public Long getSupplierUserId() {
        return supplierUserId;
    }

    public void setSupplierUserId(Long supplierUserId) {
        this.supplierUserId = supplierUserId;
    }

    public String getSupplierUserName() {
        return supplierUserName;
    }

    public void setSupplierUserName(String supplierUserName) {
        this.supplierUserName = supplierUserName;
    }

    public long getModified() {
        return modified;
    }

    public void setModified(long modified) {
        this.modified = modified;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<BaseProductEntity> getList() {
        return list;
    }

    public void setList(List<BaseProductEntity> list) {
        this.list = list;
    }

}
