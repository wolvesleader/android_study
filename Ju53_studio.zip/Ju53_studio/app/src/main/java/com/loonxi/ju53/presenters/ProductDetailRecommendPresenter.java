package com.loonxi.ju53.presenters;

import com.loonxi.ju53.base.BasePresenter;
import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.models.impl.ProductDetailModel;
import com.loonxi.ju53.modules.request.Callback;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.repos.PrefsRepos;
import com.loonxi.ju53.views.IProductDetailRecommendView;

import java.util.Map;

import retrofit.Retrofit;

/**
 * Created by Xuzue on 2016/3/3.
 */
public class ProductDetailRecommendPresenter extends BasePresenter<IProductDetailRecommendView> {
    private ProductDetailModel mModel;
    private IProductDetailRecommendView mView;

    public ProductDetailRecommendPresenter(IProductDetailRecommendView mView) {
        super(mView);
        this.mView = getView();
        mModel = new ProductDetailModel();
    }

    /**
     * 获取同店推荐
     * @param userId
     * @param page
     */
    public void getSupplierRecommends(String userId, int page){
        Map<String, Object> map = PrefsRepos.getDefaultMap();
        map.put("userId", userId);
        if(mView != null && page == 1){
            mView.startAsyncTask();
        }
        mModel.getRecommends(map, new Callback<JsonArrayInfo<BaseProductEntity>>() {

            @Override
            public void onOtherFlag(int flag, String message, JsonArrayInfo<BaseProductEntity> data) {

            }

            @Override
            public void onSuccess(JsonArrayInfo<BaseProductEntity> data, Retrofit retrofit) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetRecommendSuccess(data == null ? null : data.getData());
            }

            @Override
            public void onFailed(int apiErrorCode, String message) {
                if (mView == null) {
                    return;
                }
                mView.endAsyncTask();
                mView.onGetRecommendFailed(apiErrorCode, message);
            }
        });
    }

}
