package com.loonxi.ju53.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;

import com.loonxi.ju53.R;
import com.loonxi.ju53.adapter.AgentAdapter;
import com.loonxi.ju53.base.ActionBarActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.AgentProductEntity;
import com.loonxi.ju53.presenters.AgentPresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.views.IAgentView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.popupwindow.ActionBarRightPopupWindow;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;

import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/2/18.
 */
public class AgentActivity extends ActionBarActivity implements View.OnClickListener, IAgentView {

    @ViewInject(R.id.agent_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.agent_flv)
    private FixedListView mFlv;

    private int mCurrentPage = 1;

    private List<AgentProductEntity> mAgents = new ArrayList<>();
    private AgentAdapter mAdapter;
    private AgentPresenter mPresenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent);
    }

    @Override
    public void initView() {
        setTitle(R.string.agent_title);
        setMiddleVisibility(View.VISIBLE);
        setMiddleImageVisibility(View.VISIBLE);
        setMiddleImageResource(R.drawable.icon_search_gray);
        setRightVisibility(View.VISIBLE);
        setRightImageResource(R.drawable.icon_more);
    }

    @Override
    public void initContent() {
        mPresenter = new AgentPresenter(this);
        mFlv.setEmptyView(getEmptyView(R.string.empty_agent, AppConst.Empty.PRODUCT_MANAGE));
        mFlv.setVisibility(View.GONE);
        mAdapter = new AgentAdapter(mContext, mAgents);
        mFlv.setAdapter(mAdapter);
        mPresenter.getAgentProducts();
    }

    @Override
    public void setListener() {
        setOnLeftClickListener(this);
        setOnMiddleClickListener(this);
        setOnRightClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getAgentProducts();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getAgentProducts();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                finish();
                break;
            case ActionBar.MIDDLE_CLICK_ID:
                startActivity(new Intent(mContext, AgentSearchActivity.class));
                break;
            case ActionBar.RIGHT_CLICK_ID:
                ActionBarRightPopupWindow.show(mContext, getRightImage());
                break;
        }
    }

    @Override
    public void onGetAgentProductSuccess(List<AgentProductEntity> jsonArrayInfo) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mPtr.setVisibility(View.VISIBLE);
        mAgents.clear();
        if (!ListUtil.isEmpty(jsonArrayInfo)) {
            mAgents.addAll(jsonArrayInfo);
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onGetAgentProductFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        mPtr.setVisibility(View.VISIBLE);
        checkError(apiErrorCode, message);
    }
}
