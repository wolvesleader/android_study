package com.loonxi.ju53.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 订单号实体
 * Created by Xuzue on 2016/1/26.
 */
public class OrderNoEntity implements Parcelable{
    private String ordno;
    private String paymentid;

    public OrderNoEntity(){

    }

    protected OrderNoEntity(Parcel in) {
        ordno = in.readString();
        paymentid = in.readString();
    }

    public static final Creator<OrderNoEntity> CREATOR = new Creator<OrderNoEntity>() {
        @Override
        public OrderNoEntity createFromParcel(Parcel in) {
            return new OrderNoEntity(in);
        }

        @Override
        public OrderNoEntity[] newArray(int size) {
            return new OrderNoEntity[size];
        }
    };

    public String getOrdno() {
        return ordno;
    }

    public void setOrdno(String ordno) {
        this.ordno = ordno;
    }

    public String getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(String paymentid) {
        this.paymentid = paymentid;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ordno);
        dest.writeString(paymentid);
    }
}
