package com.loonxi.ju53.activity;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.base.BaseSafeActivity;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.entity.ProductCommentEntity;
import com.loonxi.ju53.entity.SendCommentEntity;
import com.loonxi.ju53.presenters.SendCommentPresenter;
import com.loonxi.ju53.utils.ToastUtil;
import com.loonxi.ju53.views.ISendCommentView;
import com.loonxi.ju53.widgets.ActionBar;
import com.loonxi.ju53.widgets.CustomRatingBar;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * "发送评论"activity
 * Created by laojiaqi on 2016/2/15.
 */
public class SendCommentActivity extends BaseSafeActivity<ISendCommentView, SendCommentPresenter> implements View.OnClickListener, ISendCommentView {
    private static final int SPINNER_NUM=5;
    @ViewInject(R.id.send_comment_checkbox)
    private CheckBox mCheckBox;
    @ViewInject(R.id.send_comment_service_star)
    private CustomRatingBar mServiceBar;
    @ViewInject(R.id.send_comment_speed_star)
    private CustomRatingBar mSpeedBar;
    @ViewInject(R.id.send_comment_confirm)
    private TextView mConfirm;
    @ViewInject(R.id.send_comment_action_bar)
    private ActionBar mActionBar;
    @ViewInject(R.id.send_comment_container)
    private LinearLayout mContainer;
    @ViewInject(R.id.send_comment_spinner)
    private Spinner mTotalCommentSpinner;

    private List<OrderUnitEntity> mAttrs;

    private OrderEntity mOrderEntity;
    private List<ProductCommentEntity> mProductCommentEntityList=new ArrayList<ProductCommentEntity>();//评价列表

    private String mOrderId;
    private String mRatedUserName;
    private String mRatedUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_comment);
        x.view().inject(this);
        initData();
        initView();
        setListener();
    }

    @Override
    protected SendCommentPresenter createPresenter(ISendCommentView iSendCommentView) {
        return new SendCommentPresenter(this);
    }

    private void initData(){
        mOrderEntity = getIntent().getParcelableExtra("orderEntity");
        if(mOrderEntity!=null) {
            mAttrs = mOrderEntity.getAttrs();
            mRatedUserName=mOrderEntity.getCustomName();
            mRatedUserId=String.valueOf(mOrderEntity.getSupplierId());
        }
    }
    private void initView() {
        mActionBar.setTitle(getString(R.string.send_message_title));
    }

    private void setListener() {
        mActionBar.setOnLeftClickListener(this);
        mConfirm.setOnClickListener(this);
    }


    @Override
    protected void onResume() {
        super.onResume();
        generateViewByData();
    }

    private void generateViewByData() {
        if (mAttrs == null || mAttrs.size() == 0) {
            return;
        }
        mOrderId=mAttrs.get(0).getOrderId();
        int size = mAttrs.size();
        for (int i = 0; i < size; i++) {
            getItemView(mAttrs.get(i));
        }

    }

    private void getItemView(OrderUnitEntity orderUnitEntity) {
        if (orderUnitEntity == null) {
            return;
        }
        View view = LayoutInflater.from(this).inflate(R.layout.item_send_comment, null);
        TextView productName = (TextView) view.findViewById(R.id.send_comment_product_name);
        ImageView productImage = (ImageView) view.findViewById(R.id.send_comment_product_image);
        TextView productArg = (TextView) view.findViewById(R.id.send_comment_product_arguments);
        productName.setText(orderUnitEntity.getProductName());
        productArg.setText(orderUnitEntity.getAttribute());
        if (!isFinishing() && mContext != null && !TextUtils.isEmpty(orderUnitEntity.getPicture())) {
            Glide.with(mContext).load(AppConst.PIC_HEAD + orderUnitEntity.getPicture() + AppConst.PIC_SIZE_80).into(productImage);
        }
        mContainer.addView(view);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case ActionBar.LEFT_CLICK_ID:
                goback();
                break;
            case R.id.send_comment_confirm:
                sendComment();
        }

    }


    /**
     * 获取输入数据
     */
    private void getInputData() {
        int childCount = mContainer.getChildCount();
        if (childCount == 0) {
            return;
        }
        mProductCommentEntityList.clear();
        for (int i = 0; i < childCount; i++) {
            View view = mContainer.getChildAt(i);
            if(view == null || mAttrs == null || mAttrs.size() < i + 1){
                continue;
            }
            OrderUnitEntity orderUnitEntity = mAttrs.get(i);
            CustomRatingBar customRatingBar = (CustomRatingBar) view.findViewById(R.id.send_comment_product_quality_star);
            TextView productArg = (TextView) view.findViewById(R.id.send_comment_product_arguments);
            EditText editText = (EditText) view.findViewById(R.id.send_comment_content);
            TextView productName=(TextView)view.findViewById(R.id.send_comment_product_name);
            ProductCommentEntity productCommentEntity = new ProductCommentEntity();
            productCommentEntity.setProductSpec(productArg.getText().toString());//规格
            productCommentEntity.setContent(editText.getText().toString());//内容
            productCommentEntity.setProductPrice(orderUnitEntity.getAttriprice());//价格
            productCommentEntity.setProductId(orderUnitEntity.getProductId());//商品ID
            productCommentEntity.setScore(customRatingBar.getStarCount());//质量星级
            productCommentEntity.setProductName(productName.getText().toString());
            mProductCommentEntityList.add(productCommentEntity);
        }
    }

    /**
     * 发送评论
     */
    private void sendComment() {
        getInputData();
        SendCommentEntity sendCommentEntity=new SendCommentEntity();
        sendCommentEntity.setOrderId(mOrderId);
        sendCommentEntity.setAnon(mCheckBox.isChecked()?1:0);
        sendCommentEntity.setServiceScore(mServiceBar.getStarCount());
        sendCommentEntity.setSpeedScore(mSpeedBar.getStarCount());
        sendCommentEntity.setItems(mProductCommentEntityList);
        sendCommentEntity.setScore(SPINNER_NUM-mTotalCommentSpinner.getSelectedItemPosition());
        sendCommentEntity.setRatedUserId(mRatedUserId);
        sendCommentEntity.setRatedUserName(mRatedUserName);

        mPresenter.sendComment(sendCommentEntity); 
    }

    private void goback() {
        this.finish();
    }

    @Override
    public void onSendCommentViewSuccess(String string) {
        ToastUtil.showShortToast(string);
        if(mContext!=null){
            if(!((Activity)mContext).isFinishing()){
                ((Activity)mContext).finish();
            }
        }
    }

    @Override
    public void onSendCommentViewFailure(String string) {
        ToastUtil.showShortToast(string);
    }
}
