package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreDetailEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.entity.StoreProductExtraEntity;
import com.loonxi.ju53.modules.request.beans.BaseJsonInfo;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 分销商店铺接口
 * Created by XuZue on 2016/5/3 0003.
 */
public interface StoreService {

    /**
     * 获取店铺产品列表
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/GetDistributorProductList")
    Call<JsonInfo<StoreDataEntity>> getStoreProducts(@FieldMap Map<String, Object> map);

    /**
     * 获取分销商商品附加信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/GetGoodsExtraInfo")
    Call<JsonInfo<StoreProductExtraEntity>> getStoreProductExtraInfo(@FieldMap Map<String, Object> map);


    /**
     * 下架店铺产品
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/ShelvesProduct")
    Call<BaseJsonInfo> offSaleProduct(@FieldMap Map<String, Object> map);

    /**
     * 上架店铺产品(APP)
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/UpdateShelvesProductState")
    Call<BaseJsonInfo> onSaleStoreProduct(@FieldMap Map<String, Object> map);

    /**
     * 上架店铺产品(H5)
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/TProductAddOnSale")
    Call<BaseJsonInfo> onSaleH5StoreProduct(@FieldMap Map<String, Object> map);




    /**
     * 上架供销商产品
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/ProductAddOnSale")
    Call<BaseJsonInfo> onSaleProviderProduct(@FieldMap Map<String, Object> map);

    /**
     * 删除店铺产品
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/DeleteShelvesProduct")
    Call<BaseJsonInfo> deleteProduct(@FieldMap Map<String, Object> map);

    /**
     * 店铺产品移到顶部
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/GoodsTop")
    Call<BaseJsonInfo> moveToTop(@FieldMap Map<String, Object> map);

    /**
     * 获取店铺详情
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("Common/GetDistributorProductList")
    Call<JsonInfo<StoreDataEntity>> getStoreDetail(@FieldMap Map<String, Object> map);

    /**
     * 获取店铺基本信息
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("store/StoreInfo")
    Call<JsonInfo<StoreBaseInfoEntity>> getStoreBaseInfo(@FieldMap Map<String, Object> map);

    /**
     * 修改店铺名
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("store/modifystore")
    Call<BaseJsonInfo> altStoreName(@FieldMap Map<String, Object> map);

    /**
     * 修改店铺LOGO
     *
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("store/modifylogo")
    Call<BaseJsonInfo> altStoreLOGO(@FieldMap Map<String, Object> map);

}
