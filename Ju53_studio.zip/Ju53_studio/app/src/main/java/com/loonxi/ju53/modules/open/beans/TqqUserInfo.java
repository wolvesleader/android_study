package com.loonxi.ju53.modules.open.beans;

import java.io.Serializable;
import java.util.List;

/**
 * 腾讯微博
 *
 * @author Administrator
 */
public class TqqUserInfo extends OpenUserInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 2823305834891288871L;
    private long seqid;
    private String msg;
    private int errcode;
    private int ret;
    private UserInfo data;

    public long getSeqid() {
        return seqid;
    }

    public void setSeqid(long seqid) {
        this.seqid = seqid;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getErrcode() {
        return errcode;
    }

    public void setErrcode(int errcode) {
        this.errcode = errcode;
    }

    public int getRet() {
        return ret;
    }

    public void setRet(int ret) {
        this.ret = ret;
    }

    public UserInfo getData() {
        return data;
    }

    public void setData(UserInfo data) {
        this.data = data;
    }

    public class UserInfo implements Serializable {

        /**
         *
         */
        private static final long serialVersionUID = 4638894426146534974L;

        public class Tweet implements Serializable {
            /**
             *
             */
            private static final long serialVersionUID = -433101973680227399L;
            private String music;
            private String fromurl;
            private String text;
            private String geo;
            private int status;
            private String location;
            private String province_code;
            private String origtext;
            private List<String> image;
            private int self;
            private String from;
            private int type;
            private String country_code;
            private long timestamp;
            private String id;
            private String longitude;
            private String coty_code;
            private String latitude;
            private String video;
            private String emotionurl;
            private String emotiontype;

            public String getMusic() {
                return music;
            }

            public void setMusic(String music) {
                this.music = music;
            }

            public String getFromurl() {
                return fromurl;
            }

            public void setFromurl(String fromurl) {
                this.fromurl = fromurl;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getGeo() {
                return geo;
            }

            public void setGeo(String geo) {
                this.geo = geo;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getLocation() {
                return location;
            }

            public void setLocation(String location) {
                this.location = location;
            }

            public String getProvince_code() {
                return province_code;
            }

            public void setProvince_code(String province_code) {
                this.province_code = province_code;
            }

            public String getOrigtext() {
                return origtext;
            }

            public void setOrigtext(String origtext) {
                this.origtext = origtext;
            }

            public List<String> getImage() {
                return image;
            }

            public void setImage(List<String> image) {
                this.image = image;
            }

            public int getSelf() {
                return self;
            }

            public void setSelf(int self) {
                this.self = self;
            }

            public String getFrom() {
                return from;
            }

            public void setFrom(String from) {
                this.from = from;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public String getCountry_code() {
                return country_code;
            }

            public void setCountry_code(String country_code) {
                this.country_code = country_code;
            }

            public long getTimestamp() {
                return timestamp;
            }

            public void setTimestamp(long timestamp) {
                this.timestamp = timestamp;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getLongitude() {
                return longitude;
            }

            public void setLongitude(String longitude) {
                this.longitude = longitude;
            }

            public String getCoty_code() {
                return coty_code;
            }

            public void setCoty_code(String coty_code) {
                this.coty_code = coty_code;
            }

            public String getLatitude() {
                return latitude;
            }

            public void setLatitude(String latitude) {
                this.latitude = latitude;
            }

            public String getVideo() {
                return video;
            }

            public void setVideo(String video) {
                this.video = video;
            }

            public String getEmotionurl() {
                return emotionurl;
            }

            public void setEmotionurl(String emotionurl) {
                this.emotionurl = emotionurl;
            }

            public String getEmotiontype() {
                return emotiontype;
            }

            public void setEmotiontype(String emotiontype) {
                this.emotiontype = emotiontype;
            }
        }

        private int idoInum;
        private int sex;
        private String location;
        private String tag;
        private String province_code;
        private String verifyinfo;
        private int ismyblack;
        private int ismyfans;
        private int send_private_flag;
        private String homecountry_code;
        private int isent;
        private String homeprovince_code;
        private int level;
        private String hometown_code;
        private int favnum;
        private String name;
        private String openid;
        private String edu;
        private int industry_code;
        private String head;
        private List<Tweet> tweetinfo;
        private String comp;
        private String https_head;
        private int isrealname;
        private String country_code;
        private int birth_year;
        private String homepage;
        private int exp;
        private long regtime;
        private long fansnum;
        private String nick;
        private long ismyidol;
        private int birth_month;
        private String email;
        private String homecity_code;
        private int birth_day;
        private String city_code;
        private long mutual_fans_num;
        private long tweetnum;
        private int isvip;
        private String introduction;

        public int getIdoInum() {
            return idoInum;
        }

        public void setIdoInum(int idoInum) {
            this.idoInum = idoInum;
        }

        public int getSex() {
            return sex;
        }

        public void setSex(int sex) {
            this.sex = sex;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public String getTag() {
            return tag;
        }

        public void setTag(String tag) {
            this.tag = tag;
        }

        public String getProvince_code() {
            return province_code;
        }

        public void setProvince_code(String province_code) {
            this.province_code = province_code;
        }

        public String getVerifyinfo() {
            return verifyinfo;
        }

        public void setVerifyinfo(String verifyinfo) {
            this.verifyinfo = verifyinfo;
        }

        public int getIsmyblack() {
            return ismyblack;
        }

        public void setIsmyblack(int ismyblack) {
            this.ismyblack = ismyblack;
        }

        public int getIsmyfans() {
            return ismyfans;
        }

        public void setIsmyfans(int ismyfans) {
            this.ismyfans = ismyfans;
        }

        public int getSend_private_flag() {
            return send_private_flag;
        }

        public void setSend_private_flag(int send_private_flag) {
            this.send_private_flag = send_private_flag;
        }

        public String getHomecountry_code() {
            return homecountry_code;
        }

        public void setHomecountry_code(String homecountry_code) {
            this.homecountry_code = homecountry_code;
        }

        public int getIsent() {
            return isent;
        }

        public void setIsent(int isent) {
            this.isent = isent;
        }

        public String getHomeprovince_code() {
            return homeprovince_code;
        }

        public void setHomeprovince_code(String homeprovince_code) {
            this.homeprovince_code = homeprovince_code;
        }

        public int getLevel() {
            return level;
        }

        public void setLevel(int level) {
            this.level = level;
        }

        public String getHometown_code() {
            return hometown_code;
        }

        public void setHometown_code(String hometown_code) {
            this.hometown_code = hometown_code;
        }

        public int getFavnum() {
            return favnum;
        }

        public void setFavnum(int favnum) {
            this.favnum = favnum;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOpenid() {
            return openid;
        }

        public void setOpenid(String openid) {
            this.openid = openid;
        }

        public String getEdu() {
            return edu;
        }

        public void setEdu(String edu) {
            this.edu = edu;
        }

        public int getIndustry_code() {
            return industry_code;
        }

        public void setIndustry_code(int industry_code) {
            this.industry_code = industry_code;
        }

        public String getHead() {
            return head;
        }

        public void setHead(String head) {
            this.head = head;
        }

        public List<Tweet> getTweetinfo() {
            return tweetinfo;
        }

        public void setTweetinfo(List<Tweet> tweetinfo) {
            this.tweetinfo = tweetinfo;
        }

        public String getComp() {
            return comp;
        }

        public void setComp(String comp) {
            this.comp = comp;
        }

        public String getHttps_head() {
            return https_head;
        }

        public void setHttps_head(String https_head) {
            this.https_head = https_head;
        }

        public int getIsrealname() {
            return isrealname;
        }

        public void setIsrealname(int isrealname) {
            this.isrealname = isrealname;
        }

        public String getCountry_code() {
            return country_code;
        }

        public void setCountry_code(String country_code) {
            this.country_code = country_code;
        }

        public int getBirth_year() {
            return birth_year;
        }

        public void setBirth_year(int birth_year) {
            this.birth_year = birth_year;
        }

        public String getHomepage() {
            return homepage;
        }

        public void setHomepage(String homepage) {
            this.homepage = homepage;
        }

        public int getExp() {
            return exp;
        }

        public void setExp(int exp) {
            this.exp = exp;
        }

        public long getRegtime() {
            return regtime;
        }

        public void setRegtime(long regtime) {
            this.regtime = regtime;
        }

        public long getFansnum() {
            return fansnum;
        }

        public void setFansnum(long fansnum) {
            this.fansnum = fansnum;
        }

        public String getNick() {
            return nick;
        }

        public void setNick(String nick) {
            this.nick = nick;
        }

        public long getIsmyidol() {
            return ismyidol;
        }

        public void setIsmyidol(long ismyidol) {
            this.ismyidol = ismyidol;
        }

        public int getBirth_month() {
            return birth_month;
        }

        public void setBirth_month(int birth_month) {
            this.birth_month = birth_month;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getHomecity_code() {
            return homecity_code;
        }

        public void setHomecity_code(String homecity_code) {
            this.homecity_code = homecity_code;
        }

        public int getBirth_day() {
            return birth_day;
        }

        public void setBirth_day(int birth_day) {
            this.birth_day = birth_day;
        }

        public String getCity_code() {
            return city_code;
        }

        public void setCity_code(String city_code) {
            this.city_code = city_code;
        }

        public long getMutual_fans_num() {
            return mutual_fans_num;
        }

        public void setMutual_fans_num(long mutual_fans_num) {
            this.mutual_fans_num = mutual_fans_num;
        }

        public long getTweetnum() {
            return tweetnum;
        }

        public void setTweetnum(long tweetnum) {
            this.tweetnum = tweetnum;
        }

        public int getIsvip() {
            return isvip;
        }

        public void setIsvip(int isvip) {
            this.isvip = isvip;
        }

        public String getIntroduction() {
            return introduction;
        }

        public void setIntroduction(String introduction) {
            this.introduction = introduction;
        }

    }
}
