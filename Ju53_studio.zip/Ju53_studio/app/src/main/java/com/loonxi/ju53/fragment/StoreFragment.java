package com.loonxi.ju53.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.loonxi.ju53.R;
import com.loonxi.ju53.activity.MainActivity;
import com.loonxi.ju53.activity.StoreDetailActivity;
import com.loonxi.ju53.activity.StoreManageActivity;
import com.loonxi.ju53.adapter.StoreAdapter;
import com.loonxi.ju53.base.BaseSafeFragment;
import com.loonxi.ju53.constants.AppConst;
import com.loonxi.ju53.entity.StoreBaseInfoEntity;
import com.loonxi.ju53.entity.StoreDataEntity;
import com.loonxi.ju53.entity.StoreProductEntity;
import com.loonxi.ju53.listener.FragmentLifeCircle;
import com.loonxi.ju53.manager.StoreManager;
import com.loonxi.ju53.presenters.StorePresenter;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.LogUtil;
import com.loonxi.ju53.utils.LoginUtil;
import com.loonxi.ju53.utils.SpUtil;
import com.loonxi.ju53.utils.StringUtil;
import com.loonxi.ju53.views.IStoreView;
import com.loonxi.ju53.widgets.FixedListView;
import com.loonxi.ju53.widgets.dialog.ShareDialog;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshBase;
import com.loonxi.ju53.widgets.pulltorefresh.PullToRefreshScrollView;
import com.umeng.socialize.UMShareAPI;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by XuZue on 2016/4/29 0029.
 */
@ContentView(R.layout.fragment_store)
public class StoreFragment extends BaseSafeFragment<IStoreView, StorePresenter> implements IStoreView, View.OnClickListener, FragmentLifeCircle {

    @ViewInject(R.id.fragment_store_ptr)
    private PullToRefreshScrollView mPtr;
    @ViewInject(R.id.fragment_store_iv_head)
    private ImageView mIvHead;
    @ViewInject(R.id.fragment_store_tv_nick)
    private TextView mTvName;
    @ViewInject(R.id.fragment_store_iv_view)
    private ImageView mIvView;
    @ViewInject(R.id.fragment_store_layout_add)
    private LinearLayout mLayoutAdd;
    @ViewInject(R.id.fragment_store_tv_onsale)
    private TextView mTvOnSale;
    @ViewInject(R.id.fragment_store_tv_offsale)
    private TextView mTvOffSale;
    @ViewInject(R.id.fragment_store_flv)
    private FixedListView mFlv;
    @ViewInject(R.id.fragment_store_iv_top)
    private ImageView mIvTop;
    @ViewInject(R.id.fragment_store_onsale_line)
    private View mOnSaleLine;
    @ViewInject(R.id.fragment_store_offsale_line)
    private View mOffSaleLine;
    @ViewInject(R.id.fragment_store_layout_empty)
    private RelativeLayout mLayoutEmpty;

    private ShareDialog mShareDialog;

    private boolean isOffSale = false;
    private StoreAdapter mAdapter;
    private List<StoreProductEntity> mProducts = new ArrayList<>();
    private int mCurrentPage = 1;
    private StoreBaseInfoEntity mStoreBaseInfo;
    private boolean mIsRegister = false;
    private MyReceiver mReceiver = new MyReceiver();


    @Override
    protected StorePresenter createPresenter(IStoreView iStoreView) {
        return new StorePresenter(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.mLog.e("store resume");
    }

    @Override
    public void initView() {
        mFlv.setFocusable(false);
        mFlv.setEmptyView(getEmptyView(R.string.empty_store, AppConst.Empty.STORE));
        changeTab();
    }

    @Override
    public void initContent() {
        registReceiver();
        LogUtil.mLog().i("initContent");
        mCurrentPage = 1;
        mPresenter.getStoreProduct(isOffSale, mCurrentPage, true);
        mPresenter.getStoreBaseInfo();
    }

    @Override
    public void setListener() {
        mLayoutAdd.setOnClickListener(this);
        mIvHead.setOnClickListener(this);
        mTvOnSale.setOnClickListener(this);
        mTvOffSale.setOnClickListener(this);
        mIvView.setOnClickListener(this);
        mIvTop.setOnClickListener(this);
        mPtr.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mCurrentPage = 1;
                mPresenter.getStoreProduct(isOffSale, mCurrentPage, false);
                mPresenter.getStoreBaseInfo();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                mPresenter.getStoreProduct(isOffSale, mCurrentPage, false);
            }
        });
        mPtr.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                float scrollY = mPtr.getRefreshableView().getScrollY();
                float alpha = mPresenter.getAlpha(mContext, scrollY);
                if (alpha <= 0.3) {
                    mIvTop.setVisibility(View.GONE);
                } else {
                    mIvTop.setVisibility(View.VISIBLE);
                    mIvTop.setAlpha(alpha * 255);
                }
            }
        });
    }

    private void setEmptyView() {
        boolean empty = false;
        if (mProducts.size() <= 0) {
            empty = true;
        }
        mFlv.setVisibility(empty ? View.GONE : View.VISIBLE);
        mLayoutEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
    }

    /**
     * Tab切换
     */
    private void changeTab() {
        mOnSaleLine.setVisibility(isOffSale ? View.INVISIBLE : View.VISIBLE);
        mOffSaleLine.setVisibility(isOffSale ? View.VISIBLE : View.INVISIBLE);
        mTvOnSale.setSelected(isOffSale ? false : true);
        mTvOffSale.setSelected(isOffSale ? true : false);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fragment_store_layout_add:
                gotoMainActivity(MainActivity.RESET_SORT);
                break;
            case R.id.fragment_store_tv_onsale:
                if (!isOffSale) {
                    return;
                }
                isOffSale = false;
                mCurrentPage = 1;
                changeTab();
                mPresenter.getStoreProduct(isOffSale, mCurrentPage, true);
                break;
            case R.id.fragment_store_tv_offsale:
                if (isOffSale) {
                    return;
                }
                isOffSale = true;
                mCurrentPage = 1;
                changeTab();
                mPresenter.getStoreProduct(isOffSale, mCurrentPage, true);
                break;
            case R.id.fragment_store_iv_view:
                gotoActivity(1);
                break;
            case R.id.fragment_store_iv_head:
                gotoActivity(2);
                break;
            case R.id.fragment_store_iv_top:
                backToTop();
                break;
        }
    }

    @Override
    public void fragmentPause() {

    }

    @Override
    public void fragmentResume(int position) {
        LogUtil.mLog.e("store fragmentResume");
        if (mPresenter == null) {
            mPresenter = new StorePresenter(this);
        }
        if (mPresenter != null) {
            if (ListUtil.isEmpty(mProducts)) {
                String latestUserId = SpUtil.getString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_STORE, "");
                String currentUserId = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, "");
                if (!StringUtil.isEmpty(latestUserId) && !latestUserId.equals(currentUserId)) {
                    SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_STORE, currentUserId);
                    LogUtil.mLog.e("get");
                    initShowData();
                }
            } else {
                setDataAfterChangeUser();
            }
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (mContext != null && mIsRegister) {
            mContext.unregisterReceiver(mReceiver);
        }
    }

    private void gotoActivity(int type) {
        Intent intent = new Intent();
        if (type == 1) {
            intent.setClass(mContext, StoreDetailActivity.class);
        } else if (type == 2) {
            intent.setClass(mContext, StoreManageActivity.class);
        }
        startActivity(intent);
    }

    private void initShowData() {
        mProducts.clear();
        mCurrentPage = 1;
        StoreManager.saveStoreBaseInfo(null, null);
        StoreManager.setStoreBaseInfo(mIvHead, mTvName);
        mPresenter.getStoreProduct(isOffSale, mCurrentPage, false);
        mPresenter.getStoreBaseInfo();
    }

    /**
     * 切换账号后重新拉取数据
     */
    private void setDataAfterChangeUser() {
        String latestUserId = SpUtil.getString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_STORE, "");
        String currentUserId = SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_ID, "");
        if (!StringUtil.isEmpty(latestUserId) && !latestUserId.equals(currentUserId)) {
            SpUtil.putString(mContext, SpUtil.LATEST_ACCOUNT_USER_ID_STORE, currentUserId);
            initShowData();
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 注册广播
     */
    private void registReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(AppConst.Action.ACTION_STORE_ALT_BASEINFO);
        filter.addAction(AppConst.Action.ACTION_STORE_ALT_PRODUCT);
        if (!mIsRegister && mContext != null) {
            mIsRegister = true;
            mContext.registerReceiver(mReceiver, filter);
        }
    }

    /**
     * 回到顶部
     */
    private void backToTop() {
        mIvTop.setVisibility(View.GONE);
        mPtr.getRefreshableView().smoothScrollTo(0, 0);
    }

    /**
     * 设置商品数
     *
     * @param store
     */
    private void setProductNum(StoreDataEntity store) {
        mTvOnSale.setText(getResources().getString(R.string.store_main_onsale) + "(" + store.getCountOn() + ")");
        mTvOffSale.setText(getResources().getString(R.string.store_main_offsale) + "(" + store.getCountOff() + ")");
    }

    @Override
    public void onGetStoreProductSuccess(StoreDataEntity stores) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        if (stores != null) {
            if (mCurrentPage == 1) {
                mProducts.clear();
            }
            setProductNum(stores);
            if (!ListUtil.isEmpty(stores.getList())) {
                mProducts.addAll(stores.getList());
            }
//            if (mAdapter == null) {
            mAdapter = new StoreAdapter(mContext, this, mProducts, isOffSale);
            mFlv.setAdapter(mAdapter);
//            }
            mAdapter.notifyDataSetChanged();
            mCurrentPage++;
        }
        setEmptyView();
    }

    private void initData() {
        if (mPresenter != null) {
            mCurrentPage = 1;
            mPresenter.getStoreProduct(isOffSale, mCurrentPage, false);
        }
    }

    @Override
    public void onGetStoreProductFailed(int apiErrorCode, String message) {
        if (mPtr.isRefreshing()) {
            mPtr.onRefreshComplete();
        }
        checkError(apiErrorCode, message);
    }

    @Override
    public void onSaleSuccess() {
        showToast("上架成功");
        initData();
    }

    @Override
    public void onSaleFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void offSaleSuccess() {
        showToast("下架成功");
        initData();

    }

    @Override
    public void offSaleFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void deleteProductSuccess() {
        showToast("删除成功");
        initData();

    }

    @Override
    public void deleteProductFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void moveToTopSuccess() {
        showToast("移动成功");
        initData();

    }

    @Override
    public void moveToTopFailed(int apiErrorCode, String message) {
        checkError(apiErrorCode, message);
    }

    @Override
    public void getBaseInfoSuccess(StoreBaseInfoEntity storeBaseInfo) {
        setBaseInfo(storeBaseInfo);
    }

    @Override
    public void getBaseInfoFailed(int apiErrorCode, String message) {

    }

    @Override
    public void startAsyncTask() {
        showLoadingDialog();
    }

    @Override
    public void endAsyncTask() {
        dismissLoadingDialog();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(mContext).onActivityResult(requestCode, resultCode, data);
    }

    /**
     * 设置店铺基本信息
     *
     * @param baseInfo
     */
    private void setBaseInfo(StoreBaseInfoEntity baseInfo) {
        mStoreBaseInfo = baseInfo;
        if (baseInfo == null) {
            StoreManager.saveStoreBaseInfo(null, null);
            StoreManager.setStoreBaseInfo(mIvHead, mTvName);
            return;
        }
        StoreManager.saveStoreBaseInfo(mStoreBaseInfo.getStore_logo(), mStoreBaseInfo.getStore_name());
        StoreManager.setStoreBaseInfo(mIvHead, mTvName);
    }

    /**
     * 分享
     *
     * @param productEntity
     */
    public void share(StoreProductEntity productEntity) {
        if (productEntity == null) {
            return;
        }
        String storeName = mStoreBaseInfo == null ? (SpUtil.getString(mContext, SpUtil.ACCOUNT_USER_NAME, "") + "的聚小店") : mStoreBaseInfo.getStore_name();
        String title = (mStoreBaseInfo != null && !StringUtil.isEmpty(mStoreBaseInfo.getShare_title())) ?
                mStoreBaseInfo.getShare_title() : storeName;
        String content = productEntity.getProduct_type() == 1 ?
                ("这么nice又便宜的好东西，我就不独享了，一起拼团吧！\n" + productEntity.getProductName()) :
                ("极品好货，推荐你看看这个\n" + productEntity.getProductName());
        String imgUrl = AppConst.PIC_HEAD + productEntity.getPicture();
        String targetUrl = productEntity.getShare_url();
        mShareDialog = new ShareDialog(mContext, title, content, imgUrl, targetUrl);
        mShareDialog.setDialogAttribute(getActivity(), Gravity.BOTTOM);
        mShareDialog.show();
    }

    /**
     * 上架
     *
     * @param productEntity
     */
    public void onSale(StoreProductEntity productEntity) {
        if (productEntity == null || mPresenter == null) {
            return;
        }
        mPresenter.onSaleProduct(productEntity);
    }

    /**
     * 下架
     *
     * @param productEntity
     */
    public void offSale(StoreProductEntity productEntity) {
        if (productEntity == null || mPresenter == null) {
            return;
        }
        mPresenter.offSaleProduct(productEntity);
    }

    /**
     * 删除
     *
     * @param productEntity
     */
    public void deleteProduct(StoreProductEntity productEntity) {
        if (productEntity == null || mPresenter == null) {
            return;
        }
        mPresenter.deleteProduct(productEntity);
    }

    /**
     * 移到顶部
     *
     * @param productEntity
     */
    public void moveToTopProduct(StoreProductEntity productEntity) {
        if (productEntity == null || mPresenter == null) {
            return;
        }
        mPresenter.moveToTop(productEntity);
    }

    private class MyReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (AppConst.Action.ACTION_STORE_ALT_BASEINFO.equals(intent.getAction())) {
                LogUtil.mLog.e("broad alt baseinfo");
                if (mPresenter != null) {
                    mPresenter.getStoreBaseInfo();
                }
            } else if (AppConst.Action.ACTION_STORE_ALT_PRODUCT.equals(intent.getAction())) {
                LogUtil.mLog.e("broad alt product");
                if (mPresenter != null) {
                    mCurrentPage = 1;
                    isOffSale = false;
                    changeTab();
                    mPresenter.getStoreProduct(isOffSale, mCurrentPage, false);
                }
            }
        }
    }

}
