package com.loonxi.ju53.convert;

import com.loonxi.ju53.entity.BaseProductEntity;
import com.loonxi.ju53.entity.CartCheckEntity;
import com.loonxi.ju53.entity.CartEntity;
import com.loonxi.ju53.entity.OrderEntity;
import com.loonxi.ju53.entity.OrderUnitEntity;
import com.loonxi.ju53.entity.ProductDetailEntity;
import com.loonxi.ju53.utils.ListUtil;
import com.loonxi.ju53.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xuzue on 2016/1/18.
 */
public class OrderDataConvert {

    /**
     * 商品详情转CartEntity
     *
     * @param detail
     * @param count
     * @return
     */
    public static CartEntity detailEntity2CartEntity(ProductDetailEntity detail, int count, double price, String attributeColor, String attributeMelu) {
        CartEntity cart = new CartEntity();
        if (detail == null) {
            return cart;
        }
        cart.setSupperId(detail.getUserId());
        cart.setUserName(detail.getUserName());
        cart.setTotalCount(count);

        ArrayList<BaseProductEntity> products = new ArrayList<>();
        BaseProductEntity product = new BaseProductEntity();
        product.setProductId(detail.getProductId());
        product.setProductName(detail.getProductName());
        product.setPrice(price);
        product.setMarkPrice(detail.getMarkPrice());
        product.setPicture(StringUtil.getFirstPicture(detail.getPicture(), ","));
        product.setSold(detail.getSold());
        product.setCount(count);
        product.setStockid(detail.getStokId() + "");
        product.setAttributeColor(attributeColor);
        product.setAttributeMula(attributeMelu);
        product.setFreightId(detail.getFreightId());
        product.setWeight(detail.getWeight());
        products.add(product);
        cart.setList(products);
        return cart;
    }

    /**
     * 选中的产品转CartEntity
     *
     * @param checks
     * @return
     */
    public static ArrayList<CartEntity> checkCartEntity2CartEntity(ArrayList<CartEntity> carts, List<CartCheckEntity> checks) {
        if (carts == null || ListUtil.isEmpty(checks)) {
            return null;
        }

        for (CartCheckEntity check : checks) {
            String supperId = check.getSupperId();
            String companyName = check.getCompanyName();
            int index = -1;
            for (int i = 0; i < carts.size(); i++) {
                CartEntity c = carts.get(i);
                if (!StringUtil.isEmpty(c.getSupperId()) && c.getSupperId().equals(check.getSupperId())) {
                    index = i;
                    break;
                }
            }
            if (carts.size() == 0) {
                CartEntity cartEntity = new CartEntity();
                cartEntity.setSupperId(supperId);
                cartEntity.setUserName(companyName);
                cartEntity.setNotes("");
                ArrayList<BaseProductEntity> products = new ArrayList<>();
                products.add(check);
                cartEntity.setList(products);
                carts.add(cartEntity);
            } else {
                if (index != -1) {
                    CartEntity cartEntity = carts.get(index);
                    if (ListUtil.isEmpty(cartEntity.getList())) {
                        ArrayList<BaseProductEntity> products = new ArrayList<>();
                        products.add(check);
                        carts.get(index).setList(products);
                    } else {
                        cartEntity.getList().add(check);
                    }
                } else {
                    CartEntity cartEntity = new CartEntity();
                    cartEntity.setSupperId(supperId);
                    cartEntity.setUserName(companyName);
                    cartEntity.setNotes("");
                    ArrayList<BaseProductEntity> products = new ArrayList<>();
                    products.add(check);
                    cartEntity.setList(products);
                    carts.add(cartEntity);
                }

            }
        }
        for (CartEntity cart : carts) {
            if (!ListUtil.isEmpty(cart.getList())) {
                int total = 0;
                for (BaseProductEntity product : cart.getList()) {
                    total += product.getCount();
                }
                cart.setTotalCount(total);
            }
        }
        return carts;
    }


    /**
     * 订单实体转换为CartEntity
     *
     * @param order
     * @return
     */
    public static CartEntity orderEntity2CartEntity(OrderEntity order) {
        CartEntity cart = new CartEntity();
        if (order == null) {
            return cart;
        }
        cart.setSupperId(order.getUserId() + "");
        cart.setUserName(order.getCustomName());
        cart.setTotalCount(order.getOrderNum());
        cart.setTotalFee(order.getOrderSum());
        cart.setTotalFreight(order.getFreight());

        ArrayList<BaseProductEntity> products = new ArrayList<>();
        List<OrderUnitEntity> units = order.getAttrs();
        if (!ListUtil.isEmpty(units)) {
            for (OrderUnitEntity unit : units) {
                BaseProductEntity product = orderUnitEntity2BaseProductEntity(unit);
                products.add(product);
            }
        }
        cart.setList(products);
        return cart;
    }

    /**
     * OrderUnitEntity转BaseProductEntity
     *
     * @param unit
     * @return
     */
    public static BaseProductEntity orderUnitEntity2BaseProductEntity(OrderUnitEntity unit) {
        BaseProductEntity product = new BaseProductEntity();
        if (unit == null) {
            return product;
        }
        product.setProductId(unit.getProductId());
        product.setProductName(unit.getProductName());
        product.setPrice(unit.getPrice());
        product.setPicture(unit.getPicture());
        product.setCount(StringUtil.isEmpty(unit.getValue()) ? 0 : Integer.parseInt(unit.getValue()));
        product.setAttributeColor(unit.getAttribute());
        product.setStockid(unit.getAttributeId() + "");
        return product;
    }

}
