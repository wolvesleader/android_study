package com.loonxi.ju53.modules.request.service;

import com.loonxi.ju53.entity.PromotionEntity;
import com.loonxi.ju53.modules.request.beans.JsonArrayInfo;
import com.loonxi.ju53.modules.request.beans.JsonInfo;

import java.util.Map;

import retrofit.Call;
import retrofit.http.FieldMap;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * 活动API
 * Created by Xuzue on 2015/12/23.
 */
public interface PromotionService {

    /**
     * 获取活动
     * @param map
     */
    @FormUrlEncoded
    @POST("activity/activityList")
    Call<JsonArrayInfo<PromotionEntity>> getPromotion(@FieldMap Map<String, Object> map);


    /**
     * 获取活动详情
     * @param map
     * @return
     */
    @FormUrlEncoded
    @POST("activity/activityDetail")
    Call<JsonInfo<PromotionEntity>> getPromotionDetail(@FieldMap Map<String, Object> map);


}
