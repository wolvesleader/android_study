package com.loonxi.ju53.listener;

/**
 * 详情下滑到第二个界面 接口
 * Created by laojiaqi on 2016/1/29.
 */
public interface OnScrollDownListenter {

    public void onDetailTabShown();

    public void onDetailTabHiden();
}
